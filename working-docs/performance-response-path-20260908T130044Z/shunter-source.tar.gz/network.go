package shunter

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"net"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/ponchione/shunter/auth"
	"github.com/ponchione/shunter/executor"
	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/subscription"
	"github.com/ponchione/shunter/types"
)

const (
	defaultListenAddr            = "127.0.0.1:3000"
	defaultHTTPReadHeaderTimeout = 5 * time.Second
	defaultHTTPIdleTimeout       = 60 * time.Second
)

var (
	// ErrAuthSigningKeyRequired reports that strict protocol auth lacks verification material.
	ErrAuthSigningKeyRequired = errors.New("shunter: auth signing key, verification key, OIDC issuer, or OIDC discovery issuer required")
	// ErrAnonymousTokenTTLInvalid reports invalid anonymous token TTL configuration.
	ErrAnonymousTokenTTLInvalid = errors.New("shunter: anonymous token TTL must not be negative")
	// ErrRuntimeNotReady reports that protocol traffic reached a non-ready runtime.
	ErrRuntimeNotReady = errors.New("shunter: runtime is not ready")
	// ErrRuntimeServing reports that a serving loop is already active.
	ErrRuntimeServing = errors.New("shunter: runtime is already serving")
)

func buildProtocolOptions(cfg ProtocolConfig) (protocol.ProtocolOptions, error) {
	opts, err := protocol.NormalizeProtocolOptions(protocol.ProtocolOptions{
		PingInterval:           cfg.PingInterval,
		IdleTimeout:            cfg.IdleTimeout,
		CloseHandshakeTimeout:  cfg.CloseHandshakeTimeout,
		WriteTimeout:           cfg.WriteTimeout,
		DisconnectTimeout:      cfg.DisconnectTimeout,
		OutgoingBufferMessages: cfg.OutgoingBufferMessages,
		MaxOutboundQueuedBytes: cfg.MaxOutboundQueuedBytes,
		IncomingQueueMessages:  cfg.IncomingQueueMessages,
		MaxMessageSize:         cfg.MaxMessageSize,
		MaxOutboundMessageSize: cfg.MaxOutboundMessageSize,
	})
	if err != nil {
		return protocol.ProtocolOptions{}, fmt.Errorf("protocol %w", err)
	}
	return opts, nil
}

func buildAuthConfig(cfg Config) (*auth.JWTConfig, *auth.MintConfig, error) {
	signingKey := append([]byte(nil), cfg.AuthSigningKey...)
	verificationKeys := copyAuthVerificationKeys(cfg.AuthVerificationKeys)
	oidcIssuers := copyAuthOIDCIssuers(cfg.AuthOIDCIssuers)
	oidcDiscoveryIssuers := copyAuthOIDCDiscoveryIssuers(cfg.AuthOIDCDiscoveryIssuers)
	issuers := append([]string(nil), cfg.AuthIssuers...)
	audiences := append([]string(nil), cfg.AuthAudiences...)
	extraClaims := append([]string(nil), cfg.AuthExtraClaims...)

	switch cfg.AuthMode {
	case AuthModeDev:
		if cfg.AnonymousTokenTTL < 0 {
			return nil, nil, ErrAnonymousTokenTTLInvalid
		}
		issuer := cfg.AnonymousTokenIssuer
		if issuer == "" {
			issuer = "shunter-dev"
		}
		if len(issuer) > auth.MaxIssuerBytes {
			return nil, nil, fmt.Errorf("anonymous token issuer: %w: exceeds %d bytes", auth.ErrJWTClaimTooLarge, auth.MaxIssuerBytes)
		}
		if len(signingKey) == 0 {
			signingKey = make([]byte, 32)
			if _, err := rand.Read(signingKey); err != nil {
				return nil, nil, fmt.Errorf("generate dev auth signing key: %w", err)
			}
		}
		if len(issuers) > 0 && !slices.Contains(issuers, issuer) {
			issuers = append(issuers, issuer)
		}
		audience := cfg.AnonymousTokenAudience
		if audience == "" {
			if len(audiences) > 0 {
				audience = audiences[0]
			} else {
				audience = "shunter-dev"
			}
		} else if len(audiences) > 0 && !slices.Contains(audiences, audience) {
			audiences = append(audiences, audience)
		}
		jwtCfg := &auth.JWTConfig{
			SigningKey:          append([]byte(nil), signingKey...),
			VerificationKeys:    verificationKeys,
			JWKS:                oidcIssuers,
			OIDCDiscovery:       oidcDiscoveryIssuers,
			Issuers:             issuers,
			Audiences:           audiences,
			AuthMode:            auth.AuthModeAnonymous,
			ExtraClaims:         extraClaims,
			MaxExtraClaimBytes:  cfg.AuthMaxExtraClaimBytes,
			MaxExtraClaimsBytes: cfg.AuthMaxExtraClaimsBytes,
		}
		if err := auth.ValidateJWTConfig(jwtCfg); err != nil {
			return nil, nil, err
		}
		mintCfg := &auth.MintConfig{Issuer: issuer, Audience: audience, SigningKey: append([]byte(nil), signingKey...), Expiry: cfg.AnonymousTokenTTL}
		return jwtCfg, mintCfg, nil
	case AuthModeStrict:
		if len(signingKey) == 0 && len(verificationKeys) == 0 && len(oidcIssuers) == 0 && len(oidcDiscoveryIssuers) == 0 {
			return nil, nil, ErrAuthSigningKeyRequired
		}
		jwtCfg := &auth.JWTConfig{
			SigningKey:          signingKey,
			VerificationKeys:    verificationKeys,
			JWKS:                oidcIssuers,
			OIDCDiscovery:       oidcDiscoveryIssuers,
			Issuers:             issuers,
			Audiences:           audiences,
			AuthMode:            auth.AuthModeStrict,
			ExtraClaims:         extraClaims,
			MaxExtraClaimBytes:  cfg.AuthMaxExtraClaimBytes,
			MaxExtraClaimsBytes: cfg.AuthMaxExtraClaimsBytes,
		}
		if err := auth.ValidateJWTConfig(jwtCfg); err != nil {
			return nil, nil, err
		}
		return jwtCfg, nil, nil
	default:
		return nil, nil, fmt.Errorf("auth mode is invalid")
	}
}

// HTTPHandler returns a composable HTTP handler for the runtime network surface.
// The handler does not start runtime lifecycle; callers using it directly must
// call Start before serving traffic.
func (r *Runtime) HTTPHandler() http.Handler {
	mux := http.NewServeMux()
	if r != nil && r.buildConfig.EnableProtocol {
		mux.HandleFunc("/subscribe", r.handleSubscribe)
	}
	if r != nil {
		diagnostics := r.buildConfig.Observability.Diagnostics
		if diagnostics.MountHTTP || diagnostics.MountHealthHTTP || diagnostics.MountDebugHTTP || diagnostics.MountMetricsHTTP {
			mux.Handle("/", runtimeMountedDiagnosticsHandler(r))
		}
	}
	return mux
}

func (r *Runtime) handleSubscribe(w http.ResponseWriter, req *http.Request) {
	if r == nil || !r.buildConfig.EnableProtocol {
		http.NotFound(w, req)
		return
	}
	r.mu.Lock()
	if err := r.readyLocked(); err != nil || r.protocolServer == nil {
		r.mu.Unlock()
		http.Error(w, ErrRuntimeNotReady.Error(), http.StatusServiceUnavailable)
		return
	}
	server := r.protocolServer
	r.mu.Unlock()
	server.HandleSubscribe(w, req)
}

// ListenAndServe starts runtime lifecycle if needed, serves the runtime HTTP
// handler on Config.ListenAddr, and shuts serving plus runtime ownership down
// when ctx is canceled.
func (r *Runtime) ListenAndServe(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if !r.tryBeginServing() {
		return ErrRuntimeServing
	}
	addr := r.listenAddr()
	ln, err := listenTCP(ctx, addr)
	if err != nil {
		r.endServing()
		return fmt.Errorf("listen %q: %w", addr, err)
	}
	return r.serveStarted(ctx, ln)
}

func listenTCP(ctx context.Context, addr string) (net.Listener, error) {
	if strings.ContainsRune(addr, '\x00') {
		return nil, fmt.Errorf("listen address must not contain NUL byte")
	}
	var listenConfig net.ListenConfig
	return listenConfig.Listen(ctx, "tcp", addr)
}

func (r *Runtime) listenAddr() string {
	if r.buildConfig.ListenAddr == "" {
		return defaultListenAddr
	}
	return r.buildConfig.ListenAddr
}

func (r *Runtime) tryBeginServing() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.serving {
		return false
	}
	r.serving = true
	return true
}

func (r *Runtime) endServing() {
	r.mu.Lock()
	r.serving = false
	r.mu.Unlock()
}

func (r *Runtime) serveStarted(ctx context.Context, ln net.Listener) error {
	if ctx == nil {
		ctx = context.Background()
	}
	defer r.endServing()
	return serveHTTPWithLifecycle(ctx, ln, r.HTTPHandler(), r.Start, r.Close)
}

func serveHTTPWithLifecycle(ctx context.Context, ln net.Listener, handler http.Handler, start func(context.Context) error, stop func() error) error {
	return serveHTTPServerWithLifecycle(ctx, ln, newServingHTTPServer(handler), start, stop)
}

type lifecycleHTTPServer interface {
	Serve(net.Listener) error
	Shutdown(context.Context) error
}

func serveHTTPServerWithLifecycle(ctx context.Context, ln net.Listener, httpServer lifecycleHTTPServer, start func(context.Context) error, stop func() error) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := start(ctx); err != nil {
		closeErr := ln.Close()
		if closeErr != nil {
			closeErr = fmt.Errorf("close listener after startup failure: %w", closeErr)
		}
		return errors.Join(err, closeErr)
	}

	errCh := make(chan error, 1)
	go func() { errCh <- httpServer.Serve(ln) }()

	select {
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		shutdownErr := httpServer.Shutdown(shutdownCtx)
		closeErr := stop()
		serveErr := <-errCh
		operationalErr := errors.Join(
			wrapHTTPServerError("shutdown HTTP server", shutdownErr),
			wrapHTTPServerError("stop runtime", closeErr),
			wrapHTTPServerError("serve HTTP", serveErr),
		)
		if operationalErr != nil {
			return operationalErr
		}
		return ctx.Err()
	case err := <-errCh:
		closeErr := stop()
		return errors.Join(
			wrapHTTPServerError("serve HTTP", err),
			wrapHTTPServerError("stop runtime", closeErr),
		)
	}
}

func wrapHTTPServerError(operation string, err error) error {
	if err == nil || err == http.ErrServerClosed {
		return nil
	}
	return fmt.Errorf("%s: %w", operation, err)
}

func newServingHTTPServer(handler http.Handler) *http.Server {
	return &http.Server{
		Handler:           handler,
		ReadHeaderTimeout: defaultHTTPReadHeaderTimeout,
		IdleTimeout:       defaultHTTPIdleTimeout,
	}
}

func (r *Runtime) ensureProtocolGraphLocked() error {
	if !r.buildConfig.EnableProtocol {
		return nil
	}
	if r.protocolServer != nil {
		return nil
	}
	if r.executor == nil {
		return ErrRuntimeNotReady
	}
	jwtCfg, mintCfg, err := buildAuthConfig(r.config)
	if err != nil {
		return err
	}
	jwtValidator, err := auth.NewValidator(jwtCfg)
	if err != nil {
		return err
	}
	opts, err := buildProtocolOptions(r.config.Protocol)
	if err != nil {
		return err
	}
	conns := protocol.NewConnManager()
	inbox := executor.NewProtocolInboxAdapter(r.executor)
	clientSender := protocol.NewClientSender(conns, inbox)
	fanOutSender := protocol.NewFanOutSenderAdapter(clientSender, conns)
	if swappable, ok := r.fanOutSender.(*swappableFanOutSender); ok {
		swappable.SetTarget(fanOutSender)
	} else {
		r.fanOutSender = fanOutSender
	}
	r.protocolConns = conns
	r.protocolInbox = inbox
	r.protocolSender = clientSender
	r.protocolServer = &protocol.Server{
		JWT:          jwtCfg,
		JWTValidator: jwtValidator,
		Mint:         mintCfg,
		Options:      opts,
		Executor:     inbox,
		Conns:        conns,
		Schema:       r.registry,
		State:        committedStateAccess{state: r.state},
		SQLQueryLimits: protocol.SQLQueryLimits{
			MaxRows:  r.buildConfig.OneOffQueryMaxRows,
			MaxBytes: r.buildConfig.OneOffQueryMaxBytes,
			MaxWork:  r.buildConfig.OneOffQueryMaxWork,
		},
		SubscriptionLimits: protocol.SubscriptionLimits{
			MaxQueriesPerSet: r.buildConfig.SubscriptionMaxQueriesPerSet,
		},
		DeclaredReads:     r,
		Procedures:        r,
		VisibilityFilters: runtimeProtocolVisibilityFilters(r.module.visibilityFilters),
		Observer:          r.observability,
	}
	return nil
}

func runtimeProtocolVisibilityFilters(filters []VisibilityFilterDescription) []protocol.VisibilityFilter {
	if len(filters) == 0 {
		return nil
	}
	out := make([]protocol.VisibilityFilter, len(filters))
	for i, filter := range filters {
		out[i] = protocol.VisibilityFilter{
			SQL:                filter.SQL,
			ReturnTableID:      filter.ReturnTableID,
			UsesCallerIdentity: filter.UsesCallerIdentity,
		}
	}
	return out
}

func (r *Runtime) closeProtocolGraph(conns *protocol.ConnManager, inbox *executor.ProtocolInboxAdapter) {
	if conns == nil || inbox == nil {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	conns.CloseAll(ctx, inbox)
}

type committedStateAccess struct {
	state *store.CommittedState
}

func (a committedStateAccess) Snapshot() store.CommittedReadView {
	return a.state.Snapshot()
}

type swappableFanOutSender struct {
	mu     sync.RWMutex
	target subscription.FanOutSender
}

func newSwappableFanOutSender(target subscription.FanOutSender) *swappableFanOutSender {
	return &swappableFanOutSender{target: target}
}

func (s *swappableFanOutSender) SetTarget(target subscription.FanOutSender) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.target = target
}

func (s *swappableFanOutSender) Target() subscription.FanOutSender {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.target
}

func (s *swappableFanOutSender) SendTransactionUpdateHeavy(connID types.ConnectionID, outcome subscription.CallerOutcome, updates []subscription.SubscriptionUpdate, memo *subscription.EncodingMemo) error {
	return s.Target().SendTransactionUpdateHeavy(connID, outcome, updates, memo)
}

func (s *swappableFanOutSender) SendTransactionUpdateLight(connID types.ConnectionID, requestID uint32, updates []subscription.SubscriptionUpdate, memo *subscription.EncodingMemo) error {
	return s.Target().SendTransactionUpdateLight(connID, requestID, updates, memo)
}

func (s *swappableFanOutSender) SendSubscriptionError(connID types.ConnectionID, subErr subscription.SubscriptionError) error {
	return s.Target().SendSubscriptionError(connID, subErr)
}
