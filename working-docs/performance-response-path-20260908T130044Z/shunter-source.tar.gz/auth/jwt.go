package auth

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/rsa"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"math"
	"slices"
	"strings"
	"time"
	"unicode"

	"github.com/golang-jwt/jwt/v5"

	"github.com/ponchione/shunter/types"
)

// AuthMode controls whether the engine requires a valid externally
// issued JWT (Strict) or mints a fresh one for callers that connect
// without a token (Anonymous) per SPEC-005 §4.2.
type AuthMode uint8

const (
	AuthModeStrict AuthMode = iota
	AuthModeAnonymous
)

const (
	MaxIssuerBytes  = 1024
	MaxSubjectBytes = 1024

	minHS256KeyBytes           = 32
	minRS256ModulusBits        = 2048
	maxRS256ModulusBits        = 8192
	maxExtraClaims             = 32
	MaxExtraClaimNameBytes     = 256
	maxExtraClaimDepth         = 16
	DefaultMaxExtraClaimBytes  = 4096
	DefaultMaxExtraClaimsBytes = 16384
)

// JWTAlgorithm identifies a JWT signing algorithm Shunter can verify locally.
type JWTAlgorithm string

const (
	JWTAlgorithmHS256 JWTAlgorithm = "HS256"
	JWTAlgorithmRS256 JWTAlgorithm = "RS256"
	JWTAlgorithmES256 JWTAlgorithm = "ES256"
)

// JWTVerificationKey is one locally configured JWT verification key.
//
// Key is an HMAC secret of at least 32 bytes for HS256 and a PEM-encoded public
// key or certificate for RS256/ES256. RS256 moduli must be 2048-8192 bits.
// KeyID optionally matches the token header's `kid` value for overlapping key
// rotation.
type JWTVerificationKey struct {
	Algorithm JWTAlgorithm
	KeyID     string
	Key       []byte
}

// JWKSConfig configures remote JSON Web Key Set verification for one trusted
// issuer. Shunter only uses the JWKS URL for signature verification; issuer
// and audience claim policy is still enforced through JWTConfig.Issuers and
// JWTConfig.Audiences.
type JWKSConfig struct {
	Issuer         string
	JWKSURL        string
	Algorithms     []JWTAlgorithm
	CacheTTL       time.Duration
	RefreshTimeout time.Duration
}

// OIDCDiscoveryConfig configures OpenID Connect discovery-document lookup for
// one issuer. Discovery resolves a jwks_uri into the existing JWKS verification
// path; issuer and audience claim policy is still enforced through
// JWTConfig.Issuers and JWTConfig.Audiences.
type OIDCDiscoveryConfig struct {
	Issuer         string
	DiscoveryURL   string
	Algorithms     []JWTAlgorithm
	CacheTTL       time.Duration
	RefreshTimeout time.Duration
}

// JWTConfig is the engine-level auth configuration. SigningKey
// is the legacy HS256 verification key and remains supported for anonymous
// token minting and existing strict-mode configuration; it must be at least 32
// bytes when present. VerificationKeys adds
// explicit local verification keys for HS256, RS256, and ES256. JWKS adds
// explicit remote RS256/ES256 verification keys. OIDCDiscovery resolves
// discovery documents into JWKS verification sources on demand.
type JWTConfig struct {
	SigningKey          []byte
	VerificationKeys    []JWTVerificationKey
	JWKS                []JWKSConfig
	OIDCDiscovery       []OIDCDiscoveryConfig
	Issuers             []string // empty = skip issuer allowlist validation
	Audiences           []string // empty = skip audience validation (SPEC-005 §4.1)
	AuthMode            AuthMode
	ExtraClaims         []string
	MaxExtraClaimBytes  int
	MaxExtraClaimsBytes int
}

// Claims is the validated, normalized claim set returned from
// ValidateJWT. Fields map onto SPEC-005 §4.1 semantics; `HexIdentity`
// is the optional redundant identity claim carried alongside (iss,
// sub).
type Claims struct {
	Subject     string
	Issuer      string
	Audience    []string
	ExpiresAt   *time.Time // nil when the token omits `exp`
	IssuedAt    time.Time
	HexIdentity string
	// Permissions carries optional caller permission tags from the
	// `permissions` JWT claim.
	Permissions []string
	// Claims carries configured extra JWT claims as compact JSON values.
	Claims types.AuthClaims
}

// DeriveIdentity is a convenience wrapper: identity derivation uses
// the same (iss, sub) pair that this Claims object was validated
// against.
func (c *Claims) DeriveIdentity() types.Identity {
	return DeriveIdentity(c.Issuer, c.Subject)
}

// Principal returns the generic external-auth principal represented by c.
func (c *Claims) Principal() types.AuthPrincipal {
	if c == nil {
		return types.AuthPrincipal{}
	}
	return types.AuthPrincipal{
		Issuer:      c.Issuer,
		Subject:     c.Subject,
		Audience:    append([]string(nil), c.Audience...),
		Permissions: append([]string(nil), c.Permissions...),
		Claims:      c.Claims.Copy(),
	}
}

// Validation error sentinels (SPEC-005 §4.3).
var (
	ErrJWTInvalid             = errors.New("auth: JWT invalid")
	ErrJWTMissingClaim        = errors.New("auth: JWT missing required claim")
	ErrJWTIssuerMismatch      = errors.New("auth: JWT issuer not in configured list")
	ErrJWTHexIdentityMismatch = errors.New("auth: hex_identity does not match derived identity")
	ErrJWTAudienceMismatch    = errors.New("auth: JWT audience not in configured list")
	ErrJWTClaimTooLarge       = errors.New("auth: JWT claim too large")
	ErrJWTUnsupportedAlg      = errors.New("auth: JWT algorithm unsupported")
)

// ValidateJWT parses + verifies tokenString against config and
// normalizes its claims. Signature errors, expiry, future `iat`/`nbf`,
// missing sub/iss, mismatched hex_identity, and audience-policy violations all
// map to dedicated sentinels so the transport layer can produce the right
// authentication rejection (SPEC-005 §4.3).
func ValidateJWT(tokenString string, config *JWTConfig) (*Claims, error) {
	return ValidateJWTContext(context.Background(), tokenString, config)
}

// ValidateJWTContext is the context-aware compatibility entry point for JWT
// validation. Long-lived runtimes should prefer a Validator so remote cache
// ownership follows the runtime lifecycle.
func ValidateJWTContext(ctx context.Context, tokenString string, config *JWTConfig) (*Claims, error) {
	return validateJWT(ctx, tokenString, config, defaultRemoteJWTCaches)
}

func validateJWT(ctx context.Context, tokenString string, config *JWTConfig, caches *remoteJWTCacheSet) (*Claims, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if config == nil {
		return nil, fmt.Errorf("%w: config is required", ErrJWTInvalid)
	}
	extraClaims, err := normalizeExtraClaimConfig(config)
	if err != nil {
		return nil, err
	}
	localKeys, err := resolveLocalJWTVerificationKeys(config)
	if err != nil {
		return nil, err
	}
	alg, keyID, tokenIssuer, err := jwtUnverifiedHeaderAndIssuer(tokenString)
	if err != nil {
		return nil, errors.Join(ErrJWTInvalid, err)
	}
	// Keep configuration validation independent from remote resolution so a
	// locally verified token can skip network access without accepting an
	// invalid remote-source configuration.
	if err := validateJWKSConfig(config); err != nil {
		return nil, err
	}
	if err := validateOIDCDiscoveryConfig(config); err != nil {
		return nil, err
	}
	localCandidates := selectJWTVerificationKeys(localKeys, alg, keyID)
	parsed, lastErr, semanticErr := parseJWTWithCandidates(tokenString, alg, localCandidates)
	if parsed != nil {
		return claimsFromValidatedToken(parsed, config, extraClaims)
	}
	if semanticErr != nil {
		return nil, errors.Join(ErrJWTInvalid, semanticErr)
	}

	remoteKeys, remoteErr := resolveJWKSVerificationKeys(ctx, caches, config, alg, keyID, tokenIssuer)
	if remoteErr != nil && len(localCandidates) == 0 {
		return nil, errors.Join(ErrJWTInvalid, remoteErr)
	}
	remoteCandidates := selectJWTVerificationKeys(remoteKeys, alg, keyID)
	if len(localCandidates) == 0 && len(remoteCandidates) == 0 {
		return nil, fmt.Errorf("%w: %w: alg=%q kid=%q", ErrJWTInvalid, ErrJWTUnsupportedAlg, alg, keyID)
	}

	parsed, remoteLastErr, semanticErr := parseJWTWithCandidates(tokenString, alg, remoteCandidates)
	if parsed != nil {
		return claimsFromValidatedToken(parsed, config, extraClaims)
	}
	if remoteLastErr != nil {
		lastErr = remoteLastErr
	}
	if semanticErr != nil {
		return nil, errors.Join(ErrJWTInvalid, semanticErr)
	}
	if lastErr != nil {
		return nil, errors.Join(ErrJWTInvalid, lastErr)
	}
	return nil, fmt.Errorf("%w: token reported invalid", ErrJWTInvalid)
}

func parseJWTWithCandidates(tokenString string, alg JWTAlgorithm, candidates []resolvedJWTVerificationKey) (*jwt.Token, error, error) {
	var lastErr error
	var semanticErr error
	for _, candidate := range candidates {
		parsed, err := jwt.Parse(tokenString, func(token *jwt.Token) (any, error) {
			if token == nil || token.Method == nil || token.Method.Alg() != string(candidate.algorithm) {
				return nil, fmt.Errorf("%w: %w: alg=%q", ErrJWTInvalid, ErrJWTUnsupportedAlg, alg)
			}
			return candidate.key, nil
		}, jwt.WithValidMethods([]string{string(candidate.algorithm)}), jwt.WithIssuedAt(), jwt.WithJSONNumber())
		if err == nil {
			if !parsed.Valid {
				lastErr = fmt.Errorf("%w: token reported invalid", ErrJWTInvalid)
				continue
			}
			return parsed, nil, nil
		}
		lastErr = err
		if !errors.Is(err, jwt.ErrTokenSignatureInvalid) {
			semanticErr = err
		}
	}
	return nil, lastErr, semanticErr
}

func jwtUnverifiedHeaderAndIssuer(tokenString string) (JWTAlgorithm, string, string, error) {
	parsed, _, err := jwt.NewParser().ParseUnverified(tokenString, jwt.MapClaims{})
	if err != nil {
		return "", "", "", err
	}
	if parsed == nil {
		return "", "", "", fmt.Errorf("token header missing")
	}
	alg, ok := parsed.Header["alg"].(string)
	if !ok || alg == "" {
		return "", "", "", fmt.Errorf("%w: missing alg", ErrJWTUnsupportedAlg)
	}
	var keyID string
	if raw, ok := parsed.Header["kid"]; ok {
		keyID, ok = raw.(string)
		if !ok {
			return "", "", "", fmt.Errorf("kid header must be a string")
		}
	}
	mc, ok := parsed.Claims.(jwt.MapClaims)
	if !ok {
		return "", "", "", fmt.Errorf("unexpected claims type %T", parsed.Claims)
	}
	iss, _ := mc["iss"].(string)
	return JWTAlgorithm(alg), keyID, iss, nil
}

// ValidateJWTConfig validates configured local verification keys without
// requiring a token. Hosts can call it at startup to catch malformed key
// material before serving protocol traffic.
func ValidateJWTConfig(config *JWTConfig) error {
	if err := validateConfiguredJWTIssuers(config); err != nil {
		return err
	}
	if _, err := resolveLocalJWTVerificationKeys(config); err != nil {
		return err
	}
	if err := validateJWKSConfig(config); err != nil {
		return err
	}
	if err := validateOIDCDiscoveryConfig(config); err != nil {
		return err
	}
	if err := ValidateJWTExtraClaimsConfig(config); err != nil {
		return err
	}
	return nil
}

func validateConfiguredJWTIssuers(config *JWTConfig) error {
	if config == nil {
		return fmt.Errorf("%w: config is required", ErrJWTInvalid)
	}
	for i, issuer := range config.Issuers {
		if err := validateConfiguredJWTIssuer(issuer, fmt.Sprintf("issuer allowlist entry %d", i+1)); err != nil {
			return err
		}
	}
	for i, source := range config.JWKS {
		if err := validateConfiguredJWTIssuer(strings.TrimSpace(source.Issuer), fmt.Sprintf("jwks source %d issuer", i+1)); err != nil {
			return err
		}
	}
	for i, source := range config.OIDCDiscovery {
		if err := validateConfiguredJWTIssuer(strings.TrimSpace(source.Issuer), fmt.Sprintf("oidc discovery source %d issuer", i+1)); err != nil {
			return err
		}
	}
	return nil
}

func validateConfiguredJWTIssuer(issuer, label string) error {
	if len(issuer) <= MaxIssuerBytes {
		return nil
	}
	return fmt.Errorf("%w: %s: %w: exceeds %d bytes", ErrJWTInvalid, label, ErrJWTClaimTooLarge, MaxIssuerBytes)
}

// ValidateJWTExtraClaimsConfig validates the bounded extra-claim portion of a
// JWTConfig without requiring verification key material.
func ValidateJWTExtraClaimsConfig(config *JWTConfig) error {
	_, err := normalizeExtraClaimConfig(config)
	return err
}

type resolvedJWTVerificationKey struct {
	algorithm JWTAlgorithm
	keyID     string
	key       any
}

func resolveLocalJWTVerificationKeys(config *JWTConfig) ([]resolvedJWTVerificationKey, error) {
	if config == nil {
		return nil, fmt.Errorf("%w: config is required", ErrJWTInvalid)
	}
	specs := make([]JWTVerificationKey, 0, len(config.VerificationKeys)+1)
	if len(config.SigningKey) != 0 {
		specs = append(specs, JWTVerificationKey{
			Algorithm: JWTAlgorithmHS256,
			Key:       append([]byte(nil), config.SigningKey...),
		})
	}
	specs = append(specs, config.VerificationKeys...)
	if len(specs) == 0 && len(config.JWKS) == 0 && len(config.OIDCDiscovery) == 0 {
		return nil, fmt.Errorf("%w: signing key, verification key, JWKS, or OIDC discovery source is required", ErrJWTInvalid)
	}
	keys := make([]resolvedJWTVerificationKey, 0, len(specs))
	for i, spec := range specs {
		key, err := resolveJWTVerificationKey(spec)
		if err != nil {
			return nil, fmt.Errorf("%w: verification key %d: %w", ErrJWTInvalid, i+1, err)
		}
		keys = append(keys, key)
	}
	return keys, nil
}

func resolveJWTVerificationKey(spec JWTVerificationKey) (resolvedJWTVerificationKey, error) {
	if len(spec.Key) == 0 {
		return resolvedJWTVerificationKey{}, fmt.Errorf("key material is required")
	}
	switch spec.Algorithm {
	case JWTAlgorithmHS256:
		if err := validateHS256Key(spec.Key); err != nil {
			return resolvedJWTVerificationKey{}, err
		}
		return resolvedJWTVerificationKey{
			algorithm: spec.Algorithm,
			keyID:     spec.KeyID,
			key:       append([]byte(nil), spec.Key...),
		}, nil
	case JWTAlgorithmRS256:
		key, err := parseRSAPublicKeyPEM(spec.Key)
		if err != nil {
			return resolvedJWTVerificationKey{}, err
		}
		return resolvedJWTVerificationKey{algorithm: spec.Algorithm, keyID: spec.KeyID, key: key}, nil
	case JWTAlgorithmES256:
		key, err := parseECDSAPublicKeyPEM(spec.Key)
		if err != nil {
			return resolvedJWTVerificationKey{}, err
		}
		return resolvedJWTVerificationKey{algorithm: spec.Algorithm, keyID: spec.KeyID, key: key}, nil
	default:
		if spec.Algorithm == "" {
			return resolvedJWTVerificationKey{}, fmt.Errorf("%w: algorithm is required", ErrJWTUnsupportedAlg)
		}
		return resolvedJWTVerificationKey{}, fmt.Errorf("%w: %s", ErrJWTUnsupportedAlg, spec.Algorithm)
	}
}

func selectJWTVerificationKeys(keys []resolvedJWTVerificationKey, alg JWTAlgorithm, keyID string) []resolvedJWTVerificationKey {
	var algMatches []resolvedJWTVerificationKey
	for _, key := range keys {
		if key.algorithm == alg {
			algMatches = append(algMatches, key)
		}
	}
	if keyID == "" {
		return algMatches
	}
	var keyed []resolvedJWTVerificationKey
	var unkeyed []resolvedJWTVerificationKey
	for _, key := range algMatches {
		switch key.keyID {
		case keyID:
			keyed = append(keyed, key)
		case "":
			unkeyed = append(unkeyed, key)
		}
	}
	if len(keyed) != 0 {
		return keyed
	}
	return unkeyed
}

func parseRSAPublicKeyPEM(data []byte) (*rsa.PublicKey, error) {
	key, err := parsePublicKeyPEM(data)
	if err != nil {
		return nil, err
	}
	rsaKey, ok := key.(*rsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("PEM public key is %T, want *rsa.PublicKey", key)
	}
	if err := validateRSAPublicKey(rsaKey); err != nil {
		return nil, err
	}
	return rsaKey, nil
}

func validateHS256Key(key []byte) error {
	if len(key) < minHS256KeyBytes {
		return fmt.Errorf("HS256 key must be at least %d bytes", minHS256KeyBytes)
	}
	return nil
}

func validateRSAPublicKey(key *rsa.PublicKey) error {
	if key == nil || key.N == nil || key.N.BitLen() < minRS256ModulusBits || key.N.BitLen() > maxRS256ModulusBits {
		return fmt.Errorf("RS256 modulus must be between %d and %d bits", minRS256ModulusBits, maxRS256ModulusBits)
	}
	if key.E <= 1 || key.E&1 == 0 || key.E > 1<<31-1 {
		return fmt.Errorf("RS256 public exponent must be an odd integer between 3 and %d", 1<<31-1)
	}
	return nil
}

func parseECDSAPublicKeyPEM(data []byte) (*ecdsa.PublicKey, error) {
	key, err := parsePublicKeyPEM(data)
	if err != nil {
		return nil, err
	}
	ecdsaKey, ok := key.(*ecdsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("PEM public key is %T, want *ecdsa.PublicKey", key)
	}
	if ecdsaKey.Curve == nil || ecdsaKey.Curve.Params() == nil || ecdsaKey.Curve.Params().BitSize != 256 {
		return nil, fmt.Errorf("ES256 requires a P-256 public key")
	}
	return ecdsaKey, nil
}

func parsePublicKeyPEM(data []byte) (any, error) {
	rest := bytes.TrimSpace(data)
	block, rest := pem.Decode(rest)
	if block == nil {
		return nil, fmt.Errorf("PEM public key is required")
	}
	if len(bytes.TrimSpace(rest)) != 0 {
		return nil, fmt.Errorf("PEM must contain exactly one public key or certificate")
	}
	switch block.Type {
	case "PUBLIC KEY":
		key, err := x509.ParsePKIXPublicKey(block.Bytes)
		if err != nil {
			return nil, err
		}
		return key, nil
	case "RSA PUBLIC KEY":
		return x509.ParsePKCS1PublicKey(block.Bytes)
	case "CERTIFICATE":
		cert, err := x509.ParseCertificate(block.Bytes)
		if err != nil {
			return nil, err
		}
		return cert.PublicKey, nil
	default:
		return nil, fmt.Errorf("unsupported PEM block type %q", block.Type)
	}
}

func claimsFromValidatedToken(parsed *jwt.Token, config *JWTConfig, extraClaims extraClaimConfig) (*Claims, error) {
	if !parsed.Valid {
		return nil, fmt.Errorf("%w: token reported invalid", ErrJWTInvalid)
	}

	mc, ok := parsed.Claims.(jwt.MapClaims)
	if !ok {
		return nil, fmt.Errorf("%w: unexpected claims type %T", ErrJWTInvalid, parsed.Claims)
	}

	c := &Claims{}
	sub, _ := mc["sub"].(string)
	if sub == "" {
		return nil, fmt.Errorf("%w: sub", ErrJWTMissingClaim)
	}
	iss, _ := mc["iss"].(string)
	if iss == "" {
		return nil, fmt.Errorf("%w: iss", ErrJWTMissingClaim)
	}
	if len(sub) > MaxSubjectBytes {
		return nil, fmt.Errorf("%w: sub exceeds %d bytes", ErrJWTClaimTooLarge, MaxSubjectBytes)
	}
	if len(iss) > MaxIssuerBytes {
		return nil, fmt.Errorf("%w: iss exceeds %d bytes", ErrJWTClaimTooLarge, MaxIssuerBytes)
	}
	if len(config.Issuers) > 0 && !slices.Contains(config.Issuers, iss) {
		return nil, fmt.Errorf("%w: got %q, allowed %v", ErrJWTIssuerMismatch, iss, config.Issuers)
	}
	c.Subject = sub
	c.Issuer = iss

	// Optional claims — presence-tolerant.
	if expSeconds, ok, err := numericDateSeconds(mc, "exp"); err != nil {
		return nil, err
	} else if ok {
		t := time.Unix(expSeconds, 0)
		c.ExpiresAt = &t
	}
	if iatSeconds, ok, err := numericDateSeconds(mc, "iat"); err != nil {
		return nil, err
	} else if ok {
		c.IssuedAt = time.Unix(iatSeconds, 0)
	}
	if hex, ok := mc["hex_identity"].(string); ok && hex != "" {
		expected := DeriveIdentity(iss, sub).Hex()
		if hex != expected {
			return nil, fmt.Errorf("%w: got %s, want %s", ErrJWTHexIdentityMismatch, hex, expected)
		}
		c.HexIdentity = hex
	}
	c.Permissions = extractStringListClaim(mc["permissions"], false)

	// Audience: normalize to []string and optionally enforce policy.
	c.Audience = extractStringListClaim(mc["aud"], true)
	if len(config.Audiences) > 0 {
		if !audienceAllowed(c.Audience, config.Audiences) {
			return nil, fmt.Errorf("%w: got %v, allowed %v", ErrJWTAudienceMismatch, c.Audience, config.Audiences)
		}
	}
	claims, err := preserveExtraClaims(mc, extraClaims)
	if err != nil {
		return nil, err
	}
	c.Claims = claims

	return c, nil
}

func numericDateSeconds(claims jwt.MapClaims, name string) (int64, bool, error) {
	raw, ok := claims[name]
	if !ok {
		return 0, false, nil
	}
	switch value := raw.(type) {
	case json.Number:
		seconds, err := value.Int64()
		if err != nil {
			return 0, false, fmt.Errorf("%w: %s must be an integer NumericDate: %v", ErrJWTInvalid, name, err)
		}
		return seconds, true, nil
	case float64:
		if math.IsNaN(value) || math.IsInf(value, 0) || math.Trunc(value) != value || value < math.MinInt64 || value >= -float64(math.MinInt64) {
			return 0, false, fmt.Errorf("%w: %s must be an in-range integer NumericDate", ErrJWTInvalid, name)
		}
		return int64(value), true, nil
	default:
		return 0, false, fmt.Errorf("%w: %s has invalid numeric type %T", ErrJWTInvalid, name, raw)
	}
}

type extraClaimConfig struct {
	names         []string
	maxClaimBytes int
	maxTotalBytes int
}

func normalizeExtraClaimConfig(config *JWTConfig) (extraClaimConfig, error) {
	if config == nil {
		return extraClaimConfig{}, fmt.Errorf("%w: config is required", ErrJWTInvalid)
	}
	maxClaimBytes := config.MaxExtraClaimBytes
	if maxClaimBytes == 0 {
		maxClaimBytes = DefaultMaxExtraClaimBytes
	}
	if maxClaimBytes < 0 {
		return extraClaimConfig{}, fmt.Errorf("%w: max extra claim bytes must not be negative", ErrJWTInvalid)
	}
	maxTotalBytes := config.MaxExtraClaimsBytes
	if maxTotalBytes == 0 {
		maxTotalBytes = DefaultMaxExtraClaimsBytes
	}
	if maxTotalBytes < 0 {
		return extraClaimConfig{}, fmt.Errorf("%w: max extra claims bytes must not be negative", ErrJWTInvalid)
	}

	if len(config.ExtraClaims) == 0 {
		return extraClaimConfig{maxClaimBytes: maxClaimBytes, maxTotalBytes: maxTotalBytes}, nil
	}
	if len(config.ExtraClaims) > maxExtraClaims {
		return extraClaimConfig{}, fmt.Errorf("%w: extra claim count %d exceeds %d", ErrJWTInvalid, len(config.ExtraClaims), maxExtraClaims)
	}
	names := make([]string, 0, len(config.ExtraClaims))
	seen := make(map[string]struct{}, len(config.ExtraClaims))
	for _, raw := range config.ExtraClaims {
		name := strings.TrimSpace(raw)
		if name == "" {
			return extraClaimConfig{}, fmt.Errorf("%w: extra claim name must not be empty", ErrJWTInvalid)
		}
		if len(name) > MaxExtraClaimNameBytes {
			return extraClaimConfig{}, fmt.Errorf("%w: extra claim name %q exceeds %d bytes", ErrJWTInvalid, name, MaxExtraClaimNameBytes)
		}
		if containsControlRune(name) {
			return extraClaimConfig{}, fmt.Errorf("%w: extra claim name %q contains a control character", ErrJWTInvalid, name)
		}
		if isShunterOwnedClaim(name) {
			return extraClaimConfig{}, fmt.Errorf("%w: extra claim name %q is reserved", ErrJWTInvalid, name)
		}
		if _, ok := seen[name]; ok {
			return extraClaimConfig{}, fmt.Errorf("%w: duplicate extra claim name %q", ErrJWTInvalid, name)
		}
		seen[name] = struct{}{}
		names = append(names, name)
	}
	return extraClaimConfig{names: names, maxClaimBytes: maxClaimBytes, maxTotalBytes: maxTotalBytes}, nil
}

func containsControlRune(s string) bool {
	for _, r := range s {
		if unicode.IsControl(r) {
			return true
		}
	}
	return false
}

func isShunterOwnedClaim(name string) bool {
	switch name {
	case "iss", "sub", "aud", "exp", "iat", "nbf", "hex_identity", "permissions":
		return true
	default:
		return false
	}
}

func preserveExtraClaims(mc jwt.MapClaims, config extraClaimConfig) (types.AuthClaims, error) {
	if len(config.names) == 0 {
		return types.AuthClaims{}, nil
	}
	values := make(map[string]json.RawMessage, len(config.names))
	total := 0
	for _, name := range config.names {
		raw, ok := mc[name]
		if !ok {
			continue
		}
		if err := validateExtraClaimValue(raw, 0); err != nil {
			return types.AuthClaims{}, fmt.Errorf("%w: extra claim %q: %v", ErrJWTInvalid, name, err)
		}
		encoded, err := json.Marshal(raw)
		if err != nil {
			return types.AuthClaims{}, fmt.Errorf("%w: extra claim %q: %v", ErrJWTInvalid, name, err)
		}
		if len(encoded) > config.maxClaimBytes {
			return types.AuthClaims{}, fmt.Errorf("%w: extra claim %q exceeds %d bytes", ErrJWTClaimTooLarge, name, config.maxClaimBytes)
		}
		total += len(encoded)
		if total > config.maxTotalBytes {
			return types.AuthClaims{}, fmt.Errorf("%w: extra claims exceed %d bytes", ErrJWTClaimTooLarge, config.maxTotalBytes)
		}
		values[name] = append(json.RawMessage(nil), encoded...)
	}
	if len(values) == 0 {
		return types.AuthClaims{}, nil
	}
	return types.AuthClaims{Values: values}, nil
}

func validateExtraClaimValue(value any, depth int) error {
	if depth > maxExtraClaimDepth {
		return fmt.Errorf("JSON value depth exceeds %d", maxExtraClaimDepth)
	}
	switch v := value.(type) {
	case nil, bool, string, float64, json.Number:
		return nil
	case []any:
		for i, item := range v {
			if err := validateExtraClaimValue(item, depth+1); err != nil {
				return fmt.Errorf("[%d]: %w", i, err)
			}
		}
		return nil
	case map[string]any:
		for key, item := range v {
			if err := validateExtraClaimValue(item, depth+1); err != nil {
				return fmt.Errorf(".%s: %w", key, err)
			}
		}
		return nil
	default:
		return fmt.Errorf("unsupported JSON value type %T", value)
	}
}

// extractStringListClaim normalizes JSON-loose claim shapes: string,
// []any with string elements, or missing. allowEmpty preserves the
// JWT audience behavior while permissions continue to drop empty tags.
func extractStringListClaim(raw any, allowEmpty bool) []string {
	switch v := raw.(type) {
	case nil:
		return nil
	case string:
		if v == "" && !allowEmpty {
			return nil
		}
		return []string{v}
	case []any:
		out := make([]string, 0, len(v))
		for _, item := range v {
			if s, ok := item.(string); ok && (allowEmpty || s != "") {
				out = append(out, s)
			}
		}
		return out
	default:
		return nil
	}
}

// audienceAllowed returns true when at least one audience value in
// tokenAud appears in configuredAllowed.
func audienceAllowed(tokenAud, configuredAllowed []string) bool {
	for _, want := range configuredAllowed {
		if slices.Contains(tokenAud, want) {
			return true
		}
	}
	return false
}
