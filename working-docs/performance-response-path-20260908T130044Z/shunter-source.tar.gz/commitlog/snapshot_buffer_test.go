package commitlog

import (
	"errors"
	"io"
	"os"
	"path/filepath"
	"testing"
)

type snapshotFlushFailureFile struct {
	*os.File
	written         int
	failure         error
	patched, synced bool
}

func (f *snapshotFlushFailureFile) Write(p []byte) (int, error) {
	if f.written >= 52 {
		if f.failure != nil {
			return 0, f.failure
		}
		return len(p) - 1, nil
	}
	n, err := f.File.Write(p)
	f.written += n
	return n, err
}
func (f *snapshotFlushFailureFile) WriteAt(p []byte, off int64) (int, error) {
	f.patched = true
	return f.File.WriteAt(p, off)
}
func (f *snapshotFlushFailureFile) Sync() error { f.synced = true; return f.File.Sync() }

func TestSnapshotBodyFlushFailure(t *testing.T) {
	for _, failure := range []error{errors.New("body flush failed"), nil} {
		t.Run(snapshotFlushFailureName(failure), func(t *testing.T) {
			cs, reg := buildSnapshotCommittedState(t)
			cs.SetCommittedTxID(91)
			dir := t.TempDir()
			writer := NewFileSnapshotWriterWithObserver(dir, reg, nil)
			var file *snapshotFlushFailureFile
			writer.openTemp = func(path string) (snapshotTempFile, error) {
				f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
				file = &snapshotFlushFailureFile{File: f, failure: failure}
				return file, err
			}
			renamed := false
			writer.rename = func(string, string) error { renamed = true; return nil }
			err := writer.CreateSnapshot(cs, 91)
			want := failure
			if want == nil {
				want = io.ErrShortWrite
			}
			var completion *SnapshotCompletionError
			if !errors.Is(err, want) || !errors.As(err, &completion) || completion.Phase != "write-temp" {
				t.Fatalf("got %v, want write-temp wrapping %v", err, want)
			}
			if file.patched || file.synced || renamed {
				t.Fatal("published or patched after flush failure")
			}
			assertSnapshotPayloadArtifactsMissing(t, filepath.Join(dir, "91"))
		})
	}
}

func snapshotFlushFailureName(err error) string {
	if err == nil {
		return "short_write"
	}
	return "write_error"
}
