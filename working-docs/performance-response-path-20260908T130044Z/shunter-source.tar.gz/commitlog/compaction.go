package commitlog

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/ponchione/shunter/internal/atomicfile"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

// SegmentRange describes the covered TxID range for one scanned segment.
type SegmentRange struct {
	Path    string
	MinTxID types.TxID
	MaxTxID types.TxID
	Active  bool
}

var (
	syncDir    = syncDirPath
	removeFile = os.Remove
)

// SegmentCoverage projects recovery-produced SegmentInfo into compaction ranges.
func SegmentCoverage(segments []SegmentInfo) []SegmentRange {
	if len(segments) == 0 {
		return nil
	}

	ranges := make([]SegmentRange, 0, len(segments))
	for i, seg := range segments {
		ranges = append(ranges, SegmentRange{
			Path:    seg.Path,
			MinTxID: seg.StartTx,
			MaxTxID: seg.LastTx,
			Active:  i == len(segments)-1,
		})
	}
	return ranges
}

// Compact decides which segments can be deleted after a snapshot.
func Compact(segments []SegmentRange, snapshotTxID types.TxID) (deleted []string, retained []string) {
	for _, seg := range segments {
		switch {
		case seg.Active:
			retained = append(retained, seg.Path)
		case snapshotTxID == 0:
			retained = append(retained, seg.Path)
		case seg.MaxTxID <= snapshotTxID:
			deleted = append(deleted, seg.Path)
		default:
			retained = append(retained, seg.Path)
		}
	}
	return deleted, retained
}

// RunCompaction validates the exact completed snapshot before deleting any
// covered commit-log or offset-index artifact.
func RunCompaction(dir string, snapshotTxID types.TxID, reg schema.SchemaRegistry) error {
	if err := ValidateSnapshotForCompaction(dir, snapshotTxID, reg); err != nil {
		return fmt.Errorf("commitlog: compact snapshot validation: %w", err)
	}
	return runCompaction(dir, snapshotTxID)
}

// runCompaction is the low-level deletion primitive. Runtime callers
// must use RunCompaction so snapshot validation cannot be bypassed.
func runCompaction(dir string, snapshotTxID types.TxID) error {
	segments, durableHorizon, err := ScanSegments(dir)
	if err != nil {
		return err
	}
	if snapshotTxID != 0 && len(segments) > 0 && snapshotTxID > durableHorizon {
		return fmt.Errorf("commitlog: compact snapshot tx %d beyond durable log horizon %d", snapshotTxID, durableHorizon)
	}
	deleted, _ := Compact(SegmentCoverage(segments), snapshotTxID)
	orphanedIndexes, err := orphanedCoveredOffsetIndexes(dir, segments, snapshotTxID)
	if err != nil {
		return err
	}
	if len(deleted) == 0 && len(orphanedIndexes) == 0 {
		// A prior attempt may have deleted the covered prefix and then failed
		// while syncing the directory. Once the remaining log no longer starts
		// at tx 1, or no segment remains in an existing log directory, a no-op
		// retry still needs to make that cleanup durable.
		if snapshotTxID != 0 && compactionNoopNeedsSync(dir, segments) {
			if err := syncDir(dir); err != nil {
				return fmt.Errorf("commitlog: compact sync directory %s: %w", dir, err)
			}
		}
		return nil
	}
	for _, path := range deleted {
		if err := removeFile(path); err != nil {
			return fmt.Errorf("commitlog: compact remove covered segment %s: %w", path, err)
		}
		if idxPath := offsetIndexPathForSegment(path); idxPath != "" {
			if err := removeFile(idxPath); err != nil && !os.IsNotExist(err) {
				return fmt.Errorf("commitlog: compact remove covered offset index %s: %w", idxPath, err)
			}
		}
	}
	for _, path := range orphanedIndexes {
		if err := removeFile(path); err != nil && !os.IsNotExist(err) {
			return fmt.Errorf("commitlog: compact remove orphaned offset index %s: %w", path, err)
		}
	}
	if err := syncDir(dir); err != nil {
		return fmt.Errorf("commitlog: compact sync directory %s: %w", dir, err)
	}
	return nil
}

func compactionNoopNeedsSync(dir string, segments []SegmentInfo) bool {
	if len(segments) > 0 {
		return segments[0].StartTx > 1
	}
	info, err := os.Stat(dir)
	return err == nil && info.IsDir()
}

func orphanedCoveredOffsetIndexes(dir string, segments []SegmentInfo, snapshotTxID types.TxID) ([]string, error) {
	if snapshotTxID == 0 {
		return nil, nil
	}

	liveIndexes := make(map[string]struct{}, len(segments))
	for _, seg := range segments {
		idxPath := offsetIndexPathForSegment(seg.Path)
		if idxPath == "" {
			continue
		}
		liveIndexes[filepath.Clean(idxPath)] = struct{}{}
	}

	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}

	var orphaned []string
	for _, entry := range entries {
		startTxID, ok := parseOffsetIndexFileStartTx(entry.Name())
		if !ok || types.TxID(startTxID) > snapshotTxID {
			continue
		}
		path := filepath.Join(dir, entry.Name())
		if _, live := liveIndexes[filepath.Clean(path)]; live {
			continue
		}
		orphaned = append(orphaned, path)
	}
	return orphaned, nil
}

func parseOffsetIndexFileStartTx(name string) (uint64, bool) {
	if !strings.HasSuffix(name, ".idx") {
		return 0, false
	}
	startTxID, err := strconv.ParseUint(strings.TrimSuffix(name, ".idx"), 10, 64)
	if err != nil {
		return 0, false
	}
	return startTxID, name == OffsetIndexFileName(startTxID)
}

// offsetIndexPathForSegment returns the sidecar offset index path that pairs
// with a %020d.log segment path. Returns "" when path does not look like a
// segment filename (in which case the caller skips cleanup).
func offsetIndexPathForSegment(segmentPath string) string {
	if !strings.HasSuffix(segmentPath, ".log") {
		return ""
	}
	return strings.TrimSuffix(segmentPath, ".log") + ".idx"
}

func syncDirPath(path string) error {
	return atomicfile.SyncDir(path)
}
