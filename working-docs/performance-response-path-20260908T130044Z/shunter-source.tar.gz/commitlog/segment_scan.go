package commitlog

import (
	"cmp"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"

	"github.com/ponchione/shunter/types"
)

// AppendMode indicates how recovery should resume writing after scanning segments.
type AppendMode uint8

const (
	// AppendInPlace means the active segment ended cleanly and can be reopened.
	AppendInPlace AppendMode = iota
	// AppendByFreshNextSegment means the segment has a valid prefix but a
	// truncated or corrupt tail; future writes must continue in a fresh segment
	// after that valid prefix.
	AppendByFreshNextSegment
	// AppendForbidden means this segment must not be appended to.
	AppendForbidden
)

// SegmentInfo describes one scanned segment file.
type SegmentInfo struct {
	Path       string
	StartTx    types.TxID
	LastTx     types.TxID
	Valid      bool
	AppendMode AppendMode
}

type segmentPath struct {
	path    string
	startTx uint64
}

// segmentScanRecordHook is a test-only instrumentation point fired once per
// record decoded by recovery segment scanning. Always nil in production.
var segmentScanRecordHook func(*Record)

// ScanSegments lists, validates, and orders all segment files in dir.
// It returns the validated segment list, plus the highest contiguous valid TxID.
func ScanSegments(dir string) ([]SegmentInfo, types.TxID, error) {
	paths, err := listSegmentPaths(dir)
	if err != nil {
		return nil, 0, err
	}
	return scanSegmentPaths(paths)
}

func listSegmentPaths(dir string) ([]segmentPath, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}

	paths := make([]segmentPath, 0, len(entries))
	for _, entry := range entries {
		if filepath.Ext(entry.Name()) != ".log" {
			continue
		}
		startTx, err := parseSegmentFileStartTx(entry.Name())
		if err != nil {
			return nil, err
		}
		if err := rejectBootstrapSegmentStart(startTx, filepath.Join(dir, entry.Name())); err != nil {
			return nil, err
		}
		if entry.IsDir() {
			if startTx == 1 {
				return nil, fmt.Errorf("%w: segment file %s is not a regular file", ErrOpen, filepath.Join(dir, entry.Name()))
			}
			continue
		}
		paths = append(paths, segmentPath{
			path:    filepath.Join(dir, entry.Name()),
			startTx: startTx,
		})
	}
	slices.SortFunc(paths, func(a, b segmentPath) int { return cmp.Compare(a.startTx, b.startTx) })
	return paths, nil
}

func scanSegmentPaths(paths []segmentPath) ([]SegmentInfo, types.TxID, error) {
	if len(paths) == 0 {
		return nil, 0, nil
	}

	segments := make([]SegmentInfo, 0, len(paths))
	for i, path := range paths {
		info, err := scanOneSegment(path.path, i == len(paths)-1)
		if err != nil {
			return nil, 0, err
		}
		segments = append(segments, info)
	}

	if err := validateSegmentContinuity(segments); err != nil {
		return nil, 0, err
	}

	return segments, segments[len(segments)-1].LastTx, nil
}

func validateSegmentContinuity(segments []SegmentInfo) error {
	for i := 1; i < len(segments); i++ {
		prev := segments[i-1]
		cur := segments[i]
		expected, err := nextContiguousRecordTxID(uint64(prev.LastTx), uint64(cur.StartTx), cur.Path)
		if err != nil {
			return err
		}
		if uint64(cur.StartTx) != expected {
			return &HistoryGapError{
				Expected: expected,
				Got:      uint64(cur.StartTx),
				Segment:  cur.Path,
			}
		}
	}
	return nil
}

func parseSegmentFileStartTx(name string) (uint64, error) {
	var startTx uint64
	if n, err := fmt.Sscanf(name, "%d.log", &startTx); err != nil || n != 1 {
		return 0, fmt.Errorf("commitlog: invalid segment filename %q", name)
	}
	if name != SegmentFileName(startTx) {
		return 0, fmt.Errorf("commitlog: non-canonical segment filename %q", name)
	}
	return startTx, nil
}

func nextContiguousRecordTxID(lastTx, gotTx uint64, path string) (uint64, error) {
	if lastTx == ^uint64(0) {
		return 0, fmt.Errorf("%w: tx_id %d after maximum tx_id %d in segment %s", ErrOpen, gotTx, lastTx, path)
	}
	return lastTx + 1, nil
}

func scanNextRecord(sr *SegmentReader) (*Record, error) {
	offset, err := sr.file.Seek(0, io.SeekCurrent)
	if err != nil {
		return nil, err
	}
	info, err := sr.file.Stat()
	if err != nil {
		return nil, err
	}
	remaining := info.Size() - offset
	if remaining == 0 {
		return nil, io.EOF
	}
	if remaining < RecordHeaderSize {
		ok, err := remainingBytesAreZero(sr.file, remaining)
		if err != nil {
			return nil, err
		}
		if ok {
			return nil, io.EOF
		}
		return nil, ErrTruncatedRecord
	}

	var header [RecordHeaderSize]byte
	if _, err := io.ReadFull(sr.file, header[:]); err != nil {
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			return nil, ErrTruncatedRecord
		}
		return nil, err
	}
	if isZeroRecordHeader(header) {
		ok, err := remainingBytesAreZero(sr.file, remaining-RecordHeaderSize)
		if err != nil {
			return nil, err
		}
		if !ok {
			return nil, ErrTruncatedRecord
		}
		return nil, io.EOF
	}

	rec := &Record{
		TxID:       binary.LittleEndian.Uint64(header[:8]),
		RecordType: header[8],
		Flags:      header[9],
	}
	dataLen := binary.LittleEndian.Uint32(header[10:14])
	if int64(dataLen)+RecordCRCSize > remaining-RecordHeaderSize {
		return nil, ErrTruncatedRecord
	}
	if maxPayload := DefaultCommitLogOptions().MaxRecordPayloadBytes; maxPayload > 0 && dataLen > maxPayload {
		return nil, &RecordTooLargeError{Size: dataLen, Max: maxPayload}
	}

	payload, err := readRecordPayload(sr.file, dataLen)
	if err != nil {
		return nil, err
	}
	rec.Payload = payload

	var crcBuf [RecordCRCSize]byte
	if _, err := io.ReadFull(sr.file, crcBuf[:]); err != nil {
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			return nil, ErrTruncatedRecord
		}
		return nil, err
	}

	expectedCRC := binary.LittleEndian.Uint32(crcBuf[:])
	actualCRC := ComputeRecordCRC(rec)
	if expectedCRC != actualCRC {
		return nil, &ChecksumMismatchError{Expected: expectedCRC, Got: actualCRC, TxID: rec.TxID}
	}
	if rec.RecordType != RecordTypeChangeset {
		return nil, &UnknownRecordTypeError{Type: rec.RecordType}
	}
	if rec.Flags != 0 {
		return nil, ErrBadFlags
	}

	sr.lastTx = rec.TxID
	return rec, nil
}

func remainingBytesAreZero(r io.Reader, remaining int64) (bool, error) {
	var buf [32 * 1024]byte
	for remaining > 0 {
		n := len(buf)
		if int64(n) > remaining {
			n = int(remaining)
		}
		if _, err := io.ReadFull(r, buf[:n]); err != nil {
			return false, err
		}
		for _, b := range buf[:n] {
			if b != 0 {
				return false, nil
			}
		}
		remaining -= int64(n)
	}
	return true, nil
}

func isDamagedTailError(err error) bool {
	if errors.Is(err, ErrTruncatedRecord) {
		return true
	}
	var checksumErr *ChecksumMismatchError
	return errors.As(err, &checksumErr)
}

func scanOneSegment(path string, isLast bool) (SegmentInfo, error) {
	sr, err := OpenSegment(path)
	if err != nil {
		if isLast && errors.Is(err, io.EOF) {
			startTx, parseErr := parseSegmentFileStartTx(filepath.Base(path))
			if parseErr != nil {
				return SegmentInfo{}, parseErr
			}
			lastTx := types.TxID(0)
			if startTx > 0 {
				lastTx = types.TxID(startTx - 1)
			}
			return SegmentInfo{
				Path:       path,
				StartTx:    types.TxID(startTx),
				LastTx:     lastTx,
				Valid:      true,
				AppendMode: AppendByFreshNextSegment,
			}, nil
		}
		return SegmentInfo{}, err
	}
	defer sr.Close()

	info := SegmentInfo{
		Path:       path,
		StartTx:    types.TxID(sr.StartTxID()),
		Valid:      true,
		AppendMode: AppendForbidden,
	}
	if isLast {
		info.AppendMode = AppendInPlace
	}

	var lastTx uint64
	var recordCount int
	for {
		rec, err := scanNextRecord(sr)
		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}
			if isDamagedTailError(err) && (recordCount > 0 || isLast) {
				info.AppendMode = AppendByFreshNextSegment
				break
			}
			return SegmentInfo{}, err
		}

		if recordCount == 0 {
			if rec.TxID != uint64(info.StartTx) {
				return SegmentInfo{}, &HistoryGapError{
					Expected: uint64(info.StartTx),
					Got:      rec.TxID,
					Segment:  path,
				}
			}
		} else {
			expected, err := nextContiguousRecordTxID(lastTx, rec.TxID, path)
			if err != nil {
				return SegmentInfo{}, err
			}
			if rec.TxID != expected {
				return SegmentInfo{}, &HistoryGapError{
					Expected: expected,
					Got:      rec.TxID,
					Segment:  path,
				}
			}
		}

		if segmentScanRecordHook != nil {
			segmentScanRecordHook(rec)
		}
		lastTx = rec.TxID
		recordCount++
	}

	if recordCount == 0 {
		if uint64(info.StartTx) == 0 {
			info.LastTx = 0
		} else {
			info.LastTx = info.StartTx - 1
		}
		return info, nil
	}

	info.LastTx = types.TxID(lastTx)
	return info, nil
}
