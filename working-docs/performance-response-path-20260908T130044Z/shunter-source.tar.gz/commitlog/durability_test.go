package commitlog

import (
	"bytes"
	"errors"
	"maps"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/types"
)

func TestNewDurabilityWorkerReportsInitialSegmentDirectorySyncFailure(t *testing.T) {
	syncErr := errors.New("injected initial directory sync failure")
	stubSegmentDirectorySync(t, func(string) error { return syncErr })

	dw, err := NewDurabilityWorker(t.TempDir(), 1, DefaultCommitLogOptions())
	if dw != nil {
		_, _ = dw.Close()
		t.Fatal("NewDurabilityWorker returned a worker after directory sync failure")
	}
	if !errors.Is(err, syncErr) {
		t.Fatalf("NewDurabilityWorker error = %v, want injected directory sync failure", err)
	}
}

func TestDurabilityWorkerLatchesRolloverSegmentDirectorySyncFailure(t *testing.T) {
	syncErr := errors.New("injected rollover directory sync failure")
	syncCalls := 0
	stubSegmentDirectorySync(t, func(string) error {
		syncCalls++
		if syncCalls == 2 {
			return syncErr
		}
		return nil
	})

	opts := DefaultCommitLogOptions()
	opts.MaxSegmentSize = 1
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0
	dw, err := NewDurabilityWorker(t.TempDir(), 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	wait := dw.WaitUntilDurable(1)
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	if txID, ok := <-wait; !ok || txID != 1 {
		t.Fatalf("durability waiter = (%d, %v), want (1, true)", txID, ok)
	}
	finalTxID, closeErr := dw.Close()
	if finalTxID != 1 {
		t.Fatalf("final durable tx = %d, want 1", finalTxID)
	}
	if !errors.Is(closeErr, syncErr) {
		t.Fatalf("Close error = %v, want rollover directory sync failure", closeErr)
	}
	if syncCalls != 2 {
		t.Fatalf("directory sync calls = %d, want initial creation and rollover", syncCalls)
	}
}

func TestDurabilityWorkerConcurrentCloseReturnsOneStableResult(t *testing.T) {
	opts := DefaultCommitLogOptions()
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0
	dw, err := NewDurabilityWorker(t.TempDir(), 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))

	const closers = 8
	type closeResult struct {
		txID uint64
		err  error
	}
	results := make(chan closeResult, closers)
	var wg sync.WaitGroup
	for range closers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			txID, err := dw.Close()
			results <- closeResult{txID: txID, err: err}
		}()
	}
	wg.Wait()
	close(results)
	for result := range results {
		if result.txID != 1 || result.err != nil {
			t.Fatalf("concurrent Close result = (%d, %v), want (1, nil)", result.txID, result.err)
		}
	}
}

func makeDurabilityTestChangeset(txID uint64) *store.Changeset {
	return &store.Changeset{
		TxID: types.TxID(txID),
		Tables: map[schema.TableID]*store.TableChangeset{
			0: {
				TableID:   0,
				TableName: "players",
				Inserts: []types.ProductValue{
					{types.NewUint64(txID), types.NewString("p")},
				},
			},
		},
	}
}

func TestNewDurabilityWorkerRejectsNegativeChannelCapacity(t *testing.T) {
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = -1

	_, err := NewDurabilityWorker(t.TempDir(), 1, opts)
	if err == nil {
		t.Fatal("NewDurabilityWorker accepted negative channel capacity")
	}
	if !strings.Contains(err.Error(), "channel capacity must be non-negative") {
		t.Fatalf("error = %v, want channel capacity validation", err)
	}
}

func TestNewDurabilityWorkerRejectsInvalidBatchAndSegmentOptions(t *testing.T) {
	tests := []struct {
		name    string
		mutate  func(*CommitLogOptions)
		wantErr string
	}{
		{
			name: "zero max segment size",
			mutate: func(opts *CommitLogOptions) {
				opts.MaxSegmentSize = 0
			},
			wantErr: "max segment size must be positive",
		},
		{
			name: "negative max segment size",
			mutate: func(opts *CommitLogOptions) {
				opts.MaxSegmentSize = -1
			},
			wantErr: "max segment size must be positive",
		},
		{
			name: "zero max record payload bytes",
			mutate: func(opts *CommitLogOptions) {
				opts.MaxRecordPayloadBytes = 0
			},
			wantErr: "max record payload bytes must be positive",
		},
		{
			name: "zero max row bytes",
			mutate: func(opts *CommitLogOptions) {
				opts.MaxRowBytes = 0
			},
			wantErr: "max row bytes must be positive",
		},
		{
			name: "record payload above fixed format ceiling",
			mutate: func(opts *CommitLogOptions) {
				opts.MaxRecordPayloadBytes = formatMaxRecordPayloadBytes + 1
			},
			wantErr: "exceeds fixed format ceiling",
		},
		{
			name: "row above fixed format ceiling",
			mutate: func(opts *CommitLogOptions) {
				opts.MaxRowBytes = formatMaxRowBytes + 1
			},
			wantErr: "exceeds fixed format ceiling",
		},
		{
			name: "unsupported snapshot interval",
			mutate: func(opts *CommitLogOptions) {
				opts.SnapshotInterval = 1
			},
			wantErr: ErrUnsupportedSnapshotInterval.Error(),
		},
		{
			name: "zero drain batch size",
			mutate: func(opts *CommitLogOptions) {
				opts.DrainBatchSize = 0
			},
			wantErr: "drain batch size must be positive",
		},
		{
			name: "negative drain batch size",
			mutate: func(opts *CommitLogOptions) {
				opts.DrainBatchSize = -1
			},
			wantErr: "drain batch size must be positive",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			opts := DefaultCommitLogOptions()
			tc.mutate(&opts)

			_, err := NewDurabilityWorker(t.TempDir(), 1, opts)
			if err == nil {
				t.Fatal("NewDurabilityWorker accepted invalid options")
			}
			if !strings.Contains(err.Error(), tc.wantErr) {
				t.Fatalf("error = %v, want %q", err, tc.wantErr)
			}
		})
	}
}

func TestNewDurabilityWorkerAcceptsFixedFormatCeilings(t *testing.T) {
	opts := DefaultCommitLogOptions()
	opts.MaxRecordPayloadBytes = formatMaxRecordPayloadBytes
	opts.MaxRowBytes = formatMaxRowBytes

	dw, err := NewDurabilityWorker(t.TempDir(), 1, opts)
	if err != nil {
		t.Fatalf("fixed format ceilings should be accepted: %v", err)
	}
	if _, err := dw.Close(); err != nil {
		t.Fatalf("close worker: %v", err)
	}
}

func TestDefaultCommitLogEncodingLimitsMatchRecoveryCeilings(t *testing.T) {
	opts := DefaultCommitLogOptions()
	if opts.MaxRowBytes != formatMaxRowBytes {
		t.Fatalf("default max row bytes = %d, want recovery ceiling %d", opts.MaxRowBytes, formatMaxRowBytes)
	}
	if opts.MaxRecordPayloadBytes != formatMaxRecordPayloadBytes {
		t.Fatalf("default max record payload bytes = %d, want recovery ceiling %d", opts.MaxRecordPayloadBytes, formatMaxRecordPayloadBytes)
	}
}

func TestDurabilityWorkerValidationRejectsLimitsWithoutPoisoningWorker(t *testing.T) {
	tests := []struct {
		name      string
		configure func(*CommitLogOptions)
		invalid   *store.Changeset
		valid     *store.Changeset
		assertErr func(*testing.T, error)
	}{
		{
			name: "row payload",
			configure: func(opts *CommitLogOptions) {
				opts.MaxRowBytes = 16
			},
			invalid: &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{
				0: {
					TableID: 0,
					Inserts: []types.ProductValue{{types.NewUint64(1), types.NewString(strings.Repeat("x", 17))}},
				},
			}},
			valid: &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{
				0: {
					TableID: 0,
					Inserts: []types.ProductValue{{types.NewUint64(1), types.NewString("ok")}},
				},
			}},
			assertErr: func(t *testing.T, err error) {
				t.Helper()
				var rowErr *RowTooLargeError
				if !errors.As(err, &rowErr) {
					t.Fatalf("validation error = %v, want RowTooLargeError", err)
				}
			},
		},
		{
			name: "record payload",
			configure: func(opts *CommitLogOptions) {
				opts.MaxRecordPayloadBytes = 40
				opts.MaxRowBytes = 1024
			},
			invalid: &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{
				0: {
					TableID: 0,
					Inserts: []types.ProductValue{
						{types.NewUint64(1), types.NewString("payload-a")},
						{types.NewUint64(2), types.NewString("payload-b")},
					},
				},
			}},
			valid: &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{
				0: {
					TableID: 0,
					Inserts: []types.ProductValue{{types.NewUint64(1), types.NewString("ok")}},
				},
			}},
			assertErr: func(t *testing.T, err error) {
				t.Helper()
				var recordErr *RecordTooLargeError
				if !errors.As(err, &recordErr) {
					t.Fatalf("validation error = %v, want RecordTooLargeError", err)
				}
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			opts := DefaultCommitLogOptions()
			tc.configure(&opts)
			opts.OffsetIndexIntervalBytes = 0
			opts.OffsetIndexCap = 0
			dw, err := NewDurabilityWorker(t.TempDir(), 1, opts)
			if err != nil {
				t.Fatal(err)
			}
			tc.assertErr(t, dw.ValidateChangeset(tc.invalid))
			if err := dw.FatalError(); err != nil {
				t.Fatalf("worker fatal after validation rejection: %v", err)
			}
			if err := dw.ValidateChangeset(tc.valid); err != nil {
				t.Fatalf("valid changeset validation: %v", err)
			}
			dw.EnqueueCommitted(1, tc.valid)
			if finalTx, err := dw.Close(); err != nil || finalTx != 1 {
				t.Fatalf("close after valid enqueue = (tx=%d, err=%v), want (1, nil)", finalTx, err)
			}
		})
	}
}

func TestNewDurabilityWorkerRejectsUnsupportedSnapshotIntervalSentinel(t *testing.T) {
	opts := DefaultCommitLogOptions()
	opts.SnapshotInterval = 10

	_, err := NewDurabilityWorker(t.TempDir(), 1, opts)
	if !errors.Is(err, ErrUnsupportedSnapshotInterval) {
		t.Fatalf("error = %v, want ErrUnsupportedSnapshotInterval", err)
	}
}

func TestDurabilityWorkerRejectsRowsLargerThanRecoveryLimitBeforeAppend(t *testing.T) {
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.MaxRowBytes = 16
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0

	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(1, &store.Changeset{
		TxID: 1,
		Tables: map[schema.TableID]*store.TableChangeset{
			0: {
				TableID:   0,
				TableName: "players",
				Inserts: []types.ProductValue{
					{types.NewUint64(1), types.NewString(strings.Repeat("x", int(opts.MaxRowBytes)+1))},
				},
			},
		},
	})

	finalTx, err := dw.Close()
	if finalTx != 0 {
		t.Fatalf("final durable tx = %d, want 0", finalTx)
	}
	var rowErr *RowTooLargeError
	if !errors.As(err, &rowErr) {
		t.Fatalf("Close error = %v, want RowTooLargeError", err)
	}
	if rowErr.Max != opts.MaxRowBytes {
		t.Fatalf("row max = %d, want %d", rowErr.Max, opts.MaxRowBytes)
	}
	info, statErr := os.Stat(filepath.Join(dir, SegmentFileName(1)))
	if statErr != nil {
		t.Fatal(statErr)
	}
	if info.Size() > SegmentHeaderSize {
		t.Fatalf("segment size after rejected row = %d, want no appended record beyond header %d", info.Size(), SegmentHeaderSize)
	}
}

func TestDurabilityWorkerRejectsRecordPayloadLargerThanRecoveryLimitBeforeAppend(t *testing.T) {
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.MaxRecordPayloadBytes = 32
	opts.MaxRowBytes = 1024
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0

	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(1, &store.Changeset{
		TxID: 1,
		Tables: map[schema.TableID]*store.TableChangeset{
			0: {
				TableID:   0,
				TableName: "players",
				Inserts: []types.ProductValue{
					{types.NewUint64(1), types.NewString("payload-a")},
					{types.NewUint64(2), types.NewString("payload-b")},
					{types.NewUint64(3), types.NewString("payload-c")},
				},
			},
		},
	})

	finalTx, err := dw.Close()
	if finalTx != 0 {
		t.Fatalf("final durable tx = %d, want 0", finalTx)
	}
	var recordErr *RecordTooLargeError
	if !errors.As(err, &recordErr) {
		t.Fatalf("Close error = %v, want RecordTooLargeError", err)
	}
	if recordErr.Max != opts.MaxRecordPayloadBytes {
		t.Fatalf("record max = %d, want %d", recordErr.Max, opts.MaxRecordPayloadBytes)
	}
	info, statErr := os.Stat(filepath.Join(dir, SegmentFileName(1)))
	if statErr != nil {
		t.Fatal(statErr)
	}
	if info.Size() > SegmentHeaderSize {
		t.Fatalf("segment size after rejected payload = %d, want no appended record beyond header %d", info.Size(), SegmentHeaderSize)
	}
}

func TestDurabilityWorkerCloseReturnsFinalSegmentCloseError(t *testing.T) {
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0
	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	wait := dw.WaitUntilDurable(1)
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	select {
	case txID := <-wait:
		if txID != 1 {
			t.Fatalf("waiter tx = %d, want 1", txID)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("timeout waiting for durable tx 1")
	}
	if err := dw.seg.file.Close(); err != nil {
		t.Fatal(err)
	}

	finalTx, err := dw.Close()
	if finalTx != 1 {
		t.Fatalf("final durable tx = %d, want 1", finalTx)
	}
	if err == nil {
		t.Fatal("Close error = nil, want final segment close/sync error")
	}
}

// Pin 19.
func TestDurabilityWorkerCreatesAndPopulatesIndexPerSegment(t *testing.T) {
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 16
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 16

	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}

	const n = 5
	for i := uint64(1); i <= n; i++ {
		dw.EnqueueCommitted(i, makeDurabilityTestChangeset(i))
	}
	finalTx, fatal := dw.Close()
	if fatal != nil {
		t.Fatalf("close fatal: %v", fatal)
	}
	if finalTx != n {
		t.Fatalf("finalTx=%d want %d", finalTx, n)
	}

	idxPath := filepath.Join(dir, OffsetIndexFileName(1))
	idx, err := OpenOffsetIndex(idxPath)
	if err != nil {
		t.Fatalf("OpenOffsetIndex: %v", err)
	}
	defer idx.Close()

	ents, err := idx.Entries()
	if err != nil {
		t.Fatalf("Entries: %v", err)
	}
	if len(ents) == 0 {
		t.Fatal("expected at least one index entry")
	}
	for i, e := range ents {
		if e.TxID == 0 {
			t.Fatalf("entry %d: zero txID", i)
		}
		if e.ByteOffset < uint64(SegmentHeaderSize) {
			t.Fatalf("entry %d: byteOffset %d < SegmentHeaderSize %d", i, e.ByteOffset, SegmentHeaderSize)
		}
		if i > 0 && ents[i-1].TxID >= e.TxID {
			t.Fatalf("entries not monotonic at %d: prev=%d cur=%d", i, ents[i-1].TxID, e.TxID)
		}
	}
}

// Pin 20.
func TestDurabilityWorkerRotatesIndexOnSegmentRotation(t *testing.T) {
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 16
	opts.DrainBatchSize = 1
	opts.MaxSegmentSize = 10 // force rotation after each commit
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 16

	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}

	const n = 3
	for i := uint64(1); i <= n; i++ {
		dw.EnqueueCommitted(i, makeDurabilityTestChangeset(i))
	}
	finalTx, fatal := dw.Close()
	if fatal != nil {
		t.Fatalf("close fatal: %v", fatal)
	}
	if finalTx != n {
		t.Fatalf("finalTx=%d want %d", finalTx, n)
	}

	for _, tx := range []uint64{1, 2, 3} {
		logPath := filepath.Join(dir, SegmentFileName(tx))
		if _, err := os.Stat(logPath); err != nil {
			t.Fatalf("missing segment %d: %v", tx, err)
		}
		idxPath := filepath.Join(dir, OffsetIndexFileName(tx))
		if _, err := os.Stat(idxPath); err != nil {
			t.Fatalf("missing idx %d: %v", tx, err)
		}
		idx, err := OpenOffsetIndex(idxPath)
		if err != nil {
			t.Fatalf("OpenOffsetIndex(%d): %v", tx, err)
		}
		ents, err := idx.Entries()
		_ = idx.Close()
		if err != nil {
			t.Fatalf("Entries(%d): %v", tx, err)
		}
		if len(ents) == 0 {
			t.Fatalf("segment %d: index empty", tx)
		}
		if uint64(ents[0].TxID) != tx {
			t.Fatalf("segment %d: first entry tx=%d want %d", tx, ents[0].TxID, tx)
		}
		if ents[0].ByteOffset != uint64(SegmentHeaderSize) {
			t.Fatalf("segment %d: first entry byteOffset=%d want %d (segment-local coord space)",
				tx, ents[0].ByteOffset, SegmentHeaderSize)
		}
	}
}

func TestDurabilityWorkerDoesNotRotateAfterTerminalTxID(t *testing.T) {
	const terminalTxID = ^uint64(0)
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.MaxSegmentSize = SegmentHeaderSize + 1
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0

	dw, err := NewDurabilityWorker(dir, terminalTxID, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(terminalTxID, makeDurabilityTestChangeset(terminalTxID))
	finalTx, fatal := dw.Close()
	if fatal != nil {
		t.Fatalf("Close fatal: %v", fatal)
	}
	if finalTx != terminalTxID {
		t.Fatalf("final durable tx = %d, want %d", finalTx, terminalTxID)
	}
	if _, err := os.Stat(filepath.Join(dir, SegmentFileName(0))); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("wrapped segment stat error = %v, want not exist", err)
	}
}

func TestDurabilityWorkerRolloverRecoveryMetamorphicEquivalence(t *testing.T) {
	const n = uint64(6)
	_, reg := testSchema()
	cases := []struct {
		name             string
		maxSegmentSize   int64
		wantSegmentStart types.TxID
		wantNextTxID     types.TxID
	}{
		{
			name:             "single-segment",
			maxSegmentSize:   DefaultCommitLogOptions().MaxSegmentSize,
			wantSegmentStart: 1,
			wantNextTxID:     types.TxID(n + 1),
		},
		{
			name:             "rollover-each-tx",
			maxSegmentSize:   1,
			wantSegmentStart: types.TxID(n + 1),
			wantNextTxID:     types.TxID(n + 1),
		},
	}

	var baselineRows map[uint64]string
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			opts := DefaultCommitLogOptions()
			opts.ChannelCapacity = int(n)
			opts.DrainBatchSize = 1
			opts.MaxSegmentSize = tc.maxSegmentSize
			opts.OffsetIndexIntervalBytes = 1
			opts.OffsetIndexCap = 16

			dw, err := NewDurabilityWorker(dir, 1, opts)
			if err != nil {
				t.Fatal(err)
			}
			for txID := uint64(1); txID <= n; txID++ {
				dw.EnqueueCommitted(txID, makeDurabilityTestChangeset(txID))
			}
			finalTx, fatalErr := dw.Close()
			if fatalErr != nil {
				t.Fatalf("%s Close fatal: %v", tc.name, fatalErr)
			}
			if finalTx != n {
				t.Fatalf("%s final durable tx = %d, want %d", tc.name, finalTx, n)
			}

			recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
			if err != nil {
				t.Fatalf("%s recovery: %v", tc.name, err)
			}
			if maxTxID != types.TxID(n) {
				t.Fatalf("%s maxTxID = %d, want %d", tc.name, maxTxID, n)
			}
			if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: types.TxID(n)}) {
				t.Fatalf("%s replayed range = %+v, want 1..%d", tc.name, report.ReplayedTxRange, n)
			}
			if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != tc.wantSegmentStart || plan.NextTxID != tc.wantNextTxID {
				t.Fatalf("%s resume plan = %+v, want append-in-place on segment %d at tx %d",
					tc.name, plan, tc.wantSegmentStart, tc.wantNextTxID)
			}
			rows := map[uint64]string{}
			for txID := uint64(1); txID <= n; txID++ {
				rows[txID] = "p"
			}
			assertReplayPlayerRows(t, recovered, rows)
			recoveredRows := collectReplayPlayerRows(t, recovered)
			if baselineRows == nil {
				baselineRows = recoveredRows
				return
			}
			if !maps.Equal(recoveredRows, baselineRows) {
				t.Fatalf("%s recovered rows = %+v, want baseline %+v", tc.name, recoveredRows, baselineRows)
			}
		})
	}
}

func TestDurabilityWorkerSegmentWriteFailureFailsClosedWithoutAdvancingDurable(t *testing.T) {
	dir := t.TempDir()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0

	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	wait := dw.WaitUntilDurable(1)
	if err := dw.seg.file.Close(); err != nil {
		t.Fatal(err)
	}

	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	finalTx, fatalErr := dw.Close()
	if fatalErr == nil {
		t.Fatal("expected segment write failure to be returned on close")
	}
	if finalTx != 0 {
		t.Fatalf("final durable tx = %d, want 0 after failed write", finalTx)
	}
	if got := dw.DurableTxID(); got != 0 {
		t.Fatalf("DurableTxID = %d, want 0 after failed write", got)
	}
	select {
	case txID, ok := <-wait:
		if ok {
			t.Fatalf("waiter released successful tx %d despite failed write", txID)
		}
	case <-time.After(time.Second):
		t.Fatal("waiter did not close after failed write")
	}

	defer func() {
		r := recover()
		if r == nil {
			t.Fatal("expected enqueue after fatal durability failure to panic")
		}
		err, ok := r.(error)
		if !ok {
			t.Fatalf("panic = %T(%v), want error wrapping ErrDurabilityFailed", r, r)
		}
		if !errors.Is(err, ErrDurabilityFailed) {
			t.Fatalf("panic error = %v, want ErrDurabilityFailed", err)
		}
	}()
	dw.EnqueueCommitted(2, makeDurabilityTestChangeset(2))
}

func TestDurabilityWorkerResumeSyncFailureLeavesRecoverableDurablePrefix(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0

	initial, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	initial.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	initial.EnqueueCommitted(2, makeDurabilityTestChangeset(2))
	if finalTx, fatalErr := initial.Close(); fatalErr != nil {
		t.Fatal(fatalErr)
	} else if finalTx != 2 {
		t.Fatalf("initial final durable tx = %d, want 2", finalTx)
	}

	dw, err := NewDurabilityWorkerWithResumePlan(dir, RecoveryResumePlan{
		SegmentStartTx: 1,
		NextTxID:       3,
		AppendMode:     AppendInPlace,
	}, opts)
	if err != nil {
		t.Fatal(err)
	}
	wait := dw.WaitUntilDurable(3)
	if err := dw.seg.file.Close(); err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
	finalTx, fatalErr := dw.Close()
	if fatalErr == nil {
		t.Fatal("expected resumed segment sync failure")
	}
	if finalTx != 2 || dw.DurableTxID() != 2 {
		t.Fatalf("durable tx after resumed sync failure = (%d, %d), want (2, 2)", finalTx, dw.DurableTxID())
	}
	select {
	case txID, ok := <-wait:
		if ok {
			t.Fatalf("waiter released successful tx %d despite sync failure", txID)
		}
	case <-time.After(time.Second):
		t.Fatal("waiter did not close after sync failure")
	}

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 2 {
		t.Fatalf("maxTxID = %d, want 2", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 2}) {
		t.Fatalf("replayed range = %+v, want 1..2", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 3 {
		t.Fatalf("resume plan = %+v, want append-in-place on segment 1 at tx 3", plan)
	}

	resumed, err := NewDurabilityWorkerWithResumePlan(dir, plan, opts)
	if err != nil {
		t.Fatal(err)
	}
	resumed.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
	if finalTx, fatalErr := resumed.Close(); fatalErr != nil {
		t.Fatal(fatalErr)
	} else if finalTx != 3 {
		t.Fatalf("resumed final durable tx = %d, want 3", finalTx)
	}

	recovered, maxTxID, plan, report, err = OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 3 {
		t.Fatalf("second maxTxID = %d, want 3", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p", 3: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 3}) {
		t.Fatalf("second replayed range = %+v, want 1..3", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 4 {
		t.Fatalf("second resume plan = %+v, want append-in-place on segment 1 at tx 4", plan)
	}
}

func TestDurabilityWorkerAppendInPlaceRetryRequiresSegmentDirectorySync(t *testing.T) {
	for _, tc := range []struct {
		name        string
		retryFails  bool
		wantDurable uint64
	}{
		{name: "retry repairs publication before append", wantDurable: 1},
		{name: "retry sync failure rejects worker", retryFails: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			plan := RecoveryResumePlan{
				SegmentStartTx: 1,
				NextTxID:       1,
				AppendMode:     AppendInPlace,
			}
			firstSyncErr := errors.New("injected initial segment directory sync failure")
			retrySyncErr := errors.New("injected retry segment directory sync failure")
			syncCalls := 0
			stubSegmentDirectorySync(t, func(path string) error {
				if path != dir {
					t.Fatalf("segment directory sync path = %q, want %q", path, dir)
				}
				syncCalls++
				if syncCalls == 1 {
					return firstSyncErr
				}
				if tc.retryFails {
					return retrySyncErr
				}
				return nil
			})

			if worker, err := NewDurabilityWorkerWithResumePlan(dir, plan, DefaultCommitLogOptions()); !errors.Is(err, firstSyncErr) {
				if worker != nil {
					_, _ = worker.Close()
				}
				t.Fatalf("first worker creation error = %v, want initial directory sync failure", err)
			}
			if syncCalls != 1 {
				t.Fatalf("directory sync calls after first failure = %d, want 1", syncCalls)
			}

			worker, err := NewDurabilityWorkerWithResumePlan(dir, plan, DefaultCommitLogOptions())
			if tc.retryFails {
				if worker != nil {
					_, _ = worker.Close()
					t.Fatal("retry returned a worker after directory sync failure")
				}
				if !errors.Is(err, retrySyncErr) {
					t.Fatalf("retry worker creation error = %v, want retry directory sync failure", err)
				}
				if syncCalls != 2 {
					t.Fatalf("directory sync calls after rejected retry = %d, want 2", syncCalls)
				}
				info, statErr := os.Stat(filepath.Join(dir, SegmentFileName(1)))
				if statErr != nil {
					t.Fatalf("stat rejected retry segment: %v", statErr)
				}
				if info.Size() != SegmentHeaderSize {
					t.Fatalf("segment size after rejected retry = %d, want header-only size %d with no durable TxID", info.Size(), SegmentHeaderSize)
				}
				return
			}
			if err != nil {
				t.Fatalf("retry worker creation: %v", err)
			}
			if syncCalls != 2 {
				t.Fatalf("directory sync calls after repaired retry = %d, want 2", syncCalls)
			}
			worker.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
			finalTxID, fatalErr := worker.Close()
			if fatalErr != nil {
				t.Fatalf("close repaired worker: %v", fatalErr)
			}
			if finalTxID != tc.wantDurable || worker.DurableTxID() != tc.wantDurable {
				t.Fatalf("durable TxID after repaired retry = (%d, %d), want %d", finalTxID, worker.DurableTxID(), tc.wantDurable)
			}
		})
	}
}

func TestNewDurabilityWorkerRetryRequiresSegmentDirectorySync(t *testing.T) {
	dir := t.TempDir()
	firstSyncErr := errors.New("injected initial segment directory sync failure")
	retrySyncErr := errors.New("injected retry segment directory sync failure")
	syncCalls := 0
	stubSegmentDirectorySync(t, func(path string) error {
		if path != dir {
			t.Fatalf("segment directory sync path = %q, want %q", path, dir)
		}
		syncCalls++
		if syncCalls == 1 {
			return firstSyncErr
		}
		return retrySyncErr
	})

	if worker, err := NewDurabilityWorker(dir, 1, DefaultCommitLogOptions()); !errors.Is(err, firstSyncErr) {
		if worker != nil {
			_, _ = worker.Close()
		}
		t.Fatalf("first worker creation error = %v, want initial directory sync failure", err)
	}
	worker, err := NewDurabilityWorker(dir, 1, DefaultCommitLogOptions())
	if worker != nil {
		_, _ = worker.Close()
		t.Fatal("retry returned a worker after directory sync failure")
	}
	if !errors.Is(err, retrySyncErr) {
		t.Fatalf("retry worker creation error = %v, want retry directory sync failure", err)
	}
	if syncCalls != 2 {
		t.Fatalf("directory sync calls after rejected retry = %d, want 2", syncCalls)
	}
	info, statErr := os.Stat(filepath.Join(dir, SegmentFileName(1)))
	if statErr != nil {
		t.Fatalf("stat rejected retry segment: %v", statErr)
	}
	if info.Size() != SegmentHeaderSize {
		t.Fatalf("segment size after rejected retry = %d, want header-only size %d with no durable TxID", info.Size(), SegmentHeaderSize)
	}
}

func TestDurabilityWorkerResumeFreshSegmentReplacesRolloverArtifacts(t *testing.T) {
	for _, tc := range []struct {
		name  string
		setup func(t *testing.T, dir string)
	}{
		{
			name: "zero-length-rollover",
			setup: func(t *testing.T, dir string) {
				t.Helper()
				createZeroLengthSegment(t, dir, 3)
			},
		},
		{
			name: "truncated-first-record-rollover",
			setup: func(t *testing.T, dir string) {
				t.Helper()
				path := writeReplaySegment(t, dir, 3,
					replayRecord{txID: 3, inserts: []types.ProductValue{{types.NewUint64(3), types.NewString("partial")}}},
				)
				truncateScanTestFileToOffset(t, path, int64(SegmentHeaderSize+RecordHeaderSize-1))
			},
		},
		{
			name: "directory-rollover",
			setup: func(t *testing.T, dir string) {
				t.Helper()
				createRolloverDirectoryArtifact(t, dir, 3)
			},
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			_, reg := testSchema()
			writeFaultSnapshot(t, dir, reg, 2, map[uint64]string{1: "p", 2: "p"})
			tc.setup(t, dir)

			recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
			if err != nil {
				t.Fatal(err)
			}
			if maxTxID != 2 {
				t.Fatalf("maxTxID before resume = %d, want 2", maxTxID)
			}
			assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p"})
			if !report.HasSelectedSnapshot || report.SelectedSnapshotTxID != 2 {
				t.Fatalf("selected snapshot report = (%v, %d), want (true, 2)", report.HasSelectedSnapshot, report.SelectedSnapshotTxID)
			}
			if plan.AppendMode != AppendByFreshNextSegment || plan.SegmentStartTx != 3 || plan.NextTxID != 3 {
				t.Fatalf("resume plan = %+v, want fresh segment at tx 3", plan)
			}

			opts := DefaultCommitLogOptions()
			opts.OffsetIndexIntervalBytes = 0
			opts.OffsetIndexCap = 0
			dw, err := NewDurabilityWorkerWithResumePlan(dir, plan, opts)
			if err != nil {
				t.Fatal(err)
			}
			dw.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
			if finalTx, fatalErr := dw.Close(); fatalErr != nil {
				t.Fatal(fatalErr)
			} else if finalTx != 3 {
				t.Fatalf("final durable tx = %d, want 3", finalTx)
			}

			if info, err := os.Stat(filepath.Join(dir, SegmentFileName(3))); err != nil {
				t.Fatalf("replacement segment missing: %v", err)
			} else if info.IsDir() {
				t.Fatal("replacement segment path is still a directory artifact")
			}

			recovered, maxTxID, plan, report, err = OpenAndRecoverWithReport(dir, reg)
			if err != nil {
				t.Fatal(err)
			}
			if maxTxID != 3 {
				t.Fatalf("maxTxID after resume = %d, want 3", maxTxID)
			}
			assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p", 3: "p"})
			if !report.HasSelectedSnapshot || report.SelectedSnapshotTxID != 2 {
				t.Fatalf("selected snapshot report after resume = (%v, %d), want (true, 2)", report.HasSelectedSnapshot, report.SelectedSnapshotTxID)
			}
			if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 3, End: 3}) {
				t.Fatalf("replayed range after resume = %+v, want 3..3", report.ReplayedTxRange)
			}
			if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 3 || plan.NextTxID != 4 {
				t.Fatalf("post-resume plan = %+v, want append-in-place on segment 3 at tx 4", plan)
			}
		})
	}
}

func TestDurabilityWorkerResumeFreshSegmentTruncatesStaleOffsetIndexSidecar(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	writeFaultSnapshot(t, dir, reg, 2, map[uint64]string{1: "p", 2: "p"})
	path := writeReplaySegment(t, dir, 3,
		replayRecord{txID: 3, inserts: []types.ProductValue{{types.NewUint64(3), types.NewString("discarded")}}},
	)
	truncateScanTestFileToOffset(t, path, int64(SegmentHeaderSize+RecordHeaderSize-1))
	createOrphanOffsetIndex(t, dir, 3,
		OffsetIndexEntry{TxID: 3, ByteOffset: 1 << 32},
	)

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 2 {
		t.Fatalf("maxTxID before resume = %d, want 2", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p"})
	if !report.HasSelectedSnapshot || report.SelectedSnapshotTxID != 2 {
		t.Fatalf("selected snapshot report = (%v, %d), want (true, 2)", report.HasSelectedSnapshot, report.SelectedSnapshotTxID)
	}
	if plan.AppendMode != AppendByFreshNextSegment || plan.SegmentStartTx != 3 || plan.NextTxID != 3 {
		t.Fatalf("resume plan = %+v, want fresh segment at tx 3", plan)
	}

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 8
	dw, err := NewDurabilityWorkerWithResumePlan(dir, plan, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
	if finalTx, fatalErr := dw.Close(); fatalErr != nil {
		t.Fatal(fatalErr)
	} else if finalTx != 3 {
		t.Fatalf("final durable tx = %d, want 3", finalTx)
	}

	idx, err := OpenOffsetIndex(filepath.Join(dir, OffsetIndexFileName(3)))
	if err != nil {
		t.Fatal(err)
	}
	entries, err := idx.Entries()
	if closeErr := idx.Close(); closeErr != nil {
		t.Fatal(closeErr)
	}
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 1 {
		t.Fatalf("offset index entries after fresh resume = %+v, want exactly tx 3", entries)
	}
	if entries[0].TxID != 3 || entries[0].ByteOffset != uint64(SegmentHeaderSize) {
		t.Fatalf("fresh segment offset index entry = %+v, want tx 3 at segment header boundary", entries[0])
	}

	recovered, maxTxID, plan, report, err = OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 3 {
		t.Fatalf("maxTxID after resume = %d, want 3", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p", 3: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 3, End: 3}) {
		t.Fatalf("replayed range after resume = %+v, want 3..3", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 3 || plan.NextTxID != 4 {
		t.Fatalf("post-resume plan = %+v, want append-in-place on segment 3 at tx 4", plan)
	}
}

func TestDurabilityWorkerResumeFreshSegmentRejectsExistingValidSegment(t *testing.T) {
	dir := t.TempDir()
	path := makeScanTestSegment(t, dir, 3, 3)
	before, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	_, err = NewDurabilityWorkerWithResumePlan(dir, RecoveryResumePlan{
		SegmentStartTx: 3,
		NextTxID:       3,
		AppendMode:     AppendByFreshNextSegment,
	}, DefaultCommitLogOptions())
	if err == nil {
		t.Fatal("expected valid existing segment to block fresh resume")
	}
	if !errors.Is(err, ErrOpen) {
		t.Fatalf("resume error = %v, want ErrOpen category", err)
	}
	after, readErr := os.ReadFile(path)
	if readErr != nil {
		t.Fatal(readErr)
	}
	if !bytes.Equal(after, before) {
		t.Fatalf("valid segment changed: got %x want %x", after, before)
	}
}

func TestDurabilityWorkerResumeFreshSegmentReplacesEmptySegmentArtifact(t *testing.T) {
	dir := t.TempDir()
	sw, err := CreateSegment(dir, 3)
	if err != nil {
		t.Fatal(err)
	}
	if err := sw.Close(); err != nil {
		t.Fatal(err)
	}

	opts := DefaultCommitLogOptions()
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0
	dw, err := NewDurabilityWorkerWithResumePlan(dir, RecoveryResumePlan{
		SegmentStartTx: 3,
		NextTxID:       3,
		AppendMode:     AppendByFreshNextSegment,
	}, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
	if finalTx, fatalErr := dw.Close(); fatalErr != nil {
		t.Fatal(fatalErr)
	} else if finalTx != 3 {
		t.Fatalf("final durable tx = %d, want 3", finalTx)
	}
}

func TestDurabilityWorkerResumeFreshSegmentRejectsNonEmptyRolloverDirectoryArtifact(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	writeFaultSnapshot(t, dir, reg, 2, map[uint64]string{1: "p", 2: "p"})
	artifactDir := filepath.Join(dir, SegmentFileName(3))
	if err := os.Mkdir(artifactDir, 0o755); err != nil {
		t.Fatal(err)
	}
	artifactFile := filepath.Join(artifactDir, "leftover")
	if err := os.WriteFile(artifactFile, []byte("unsafe artifact"), 0o644); err != nil {
		t.Fatal(err)
	}

	_, maxTxID, plan, _, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 2 {
		t.Fatalf("maxTxID before resume = %d, want 2", maxTxID)
	}
	if plan.AppendMode != AppendByFreshNextSegment || plan.SegmentStartTx != 3 || plan.NextTxID != 3 {
		t.Fatalf("resume plan = %+v, want fresh segment at tx 3", plan)
	}

	_, err = NewDurabilityWorkerWithResumePlan(dir, plan, DefaultCommitLogOptions())
	if err == nil {
		t.Fatal("expected non-empty rollover directory artifact to block resume")
	}
	if !strings.Contains(err.Error(), "remove rollover segment directory artifact") {
		t.Fatalf("resume error = %v, want artifact removal context", err)
	}
	if _, statErr := os.Stat(artifactFile); statErr != nil {
		t.Fatalf("non-empty artifact contents should be preserved: %v", statErr)
	}
}

func TestDurabilityWorkerResumeIgnoresSymlinkOffsetIndexWithoutMutatingTarget(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	writeFaultSnapshot(t, dir, reg, 2, map[uint64]string{1: "p", 2: "p"})
	writeReplaySegment(t, dir, 1,
		replayRecord{txID: 1, inserts: []types.ProductValue{{types.NewUint64(1), types.NewString("p")}}},
		replayRecord{txID: 2, inserts: []types.ProductValue{{types.NewUint64(2), types.NewString("p")}}},
		replayRecord{txID: 3, inserts: []types.ProductValue{{types.NewUint64(3), types.NewString("p")}}},
	)
	targetDir := t.TempDir()
	targetPath := filepath.Join(targetDir, "external.idx")
	before := []byte("external offset index target")
	if err := os.WriteFile(targetPath, before, 0o644); err != nil {
		t.Fatal(err)
	}
	idxPath := filepath.Join(dir, OffsetIndexFileName(1))
	symlinkOrSkip(t, targetPath, idxPath)

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 3 {
		t.Fatalf("maxTxID before resume = %d, want 3", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p", 3: "p"})
	if !report.HasSelectedSnapshot || report.SelectedSnapshotTxID != 2 {
		t.Fatalf("selected snapshot report = (%v, %d), want (true, 2)", report.HasSelectedSnapshot, report.SelectedSnapshotTxID)
	}
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 3, End: 3}) {
		t.Fatalf("replayed range = %+v, want 3..3", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 4 {
		t.Fatalf("resume plan = %+v, want append-in-place on segment 1 at tx 4", plan)
	}

	dw, err := NewDurabilityWorkerWithResumePlan(dir, plan, DefaultCommitLogOptions())
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(4, makeDurabilityTestChangeset(4))
	if finalTx, fatalErr := dw.Close(); fatalErr != nil {
		t.Fatal(fatalErr)
	} else if finalTx != 4 {
		t.Fatalf("final durable tx = %d, want 4", finalTx)
	}
	after, err := os.ReadFile(targetPath)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(after, before) {
		t.Fatalf("symlink target changed: got %q want %q", after, before)
	}

	recovered, maxTxID, plan, report, err = OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 4 {
		t.Fatalf("maxTxID after resume = %d, want 4", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p", 3: "p", 4: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 3, End: 4}) {
		t.Fatalf("replayed range after resume = %+v, want 3..4", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 5 {
		t.Fatalf("post-resume plan = %+v, want append-in-place on segment 1 at tx 5", plan)
	}
}

func TestDurabilityWorkerRolloverCreateFailureLeavesRecoverableDurablePrefix(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	blockedNextSegment := filepath.Join(dir, SegmentFileName(2))
	if err := os.Mkdir(blockedNextSegment, 0o755); err != nil {
		t.Fatal(err)
	}

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.MaxSegmentSize = 1
	opts.OffsetIndexIntervalBytes = 0
	opts.OffsetIndexCap = 0
	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	wait := dw.WaitUntilDurable(1)
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	finalTx, fatalErr := dw.Close()
	if fatalErr == nil {
		t.Fatal("expected rollover create failure")
	}
	if !strings.Contains(fatalErr.Error(), SegmentFileName(2)) {
		t.Fatalf("rollover failure = %v, want blocked successor segment path", fatalErr)
	}
	if finalTx != 1 || dw.DurableTxID() != 1 {
		t.Fatalf("durable tx after rollover failure = (%d, %d), want (1, 1)", finalTx, dw.DurableTxID())
	}
	select {
	case txID := <-wait:
		if txID != 1 {
			t.Fatalf("waiter tx = %d, want 1", txID)
		}
	default:
		t.Fatal("waiter for synced prefix should be released before rollover failure")
	}

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 1 {
		t.Fatalf("maxTxID = %d, want 1", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 1}) {
		t.Fatalf("replayed range = %+v, want 1..1", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 2 {
		t.Fatalf("resume plan = %+v, want append-in-place on segment 1 at tx 2", plan)
	}
}

func TestDurabilityWorkerAppendInPlaceResumeTruncatesStaleOffsetIndexTail(t *testing.T) {
	dir := t.TempDir()
	makeScanTestSegment(t, dir, 1, 1, 2)

	idxPath := filepath.Join(dir, OffsetIndexFileName(1))
	idx, err := CreateOffsetIndex(idxPath, 8)
	if err != nil {
		t.Fatal(err)
	}
	staleFutureOffset := uint64(1 << 32)
	for _, entry := range []OffsetIndexEntry{
		{TxID: 1, ByteOffset: uint64(SegmentHeaderSize)},
		{TxID: 2, ByteOffset: uint64(SegmentHeaderSize + RecordOverhead + 1)},
		{TxID: 3, ByteOffset: staleFutureOffset},
	} {
		if err := idx.Append(entry.TxID, entry.ByteOffset); err != nil {
			_ = idx.Close()
			t.Fatal(err)
		}
	}
	if err := idx.Sync(); err != nil {
		_ = idx.Close()
		t.Fatal(err)
	}
	if err := idx.Close(); err != nil {
		t.Fatal(err)
	}

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 8
	dw, err := NewDurabilityWorkerWithResumePlan(dir, RecoveryResumePlan{
		SegmentStartTx: 1,
		NextTxID:       3,
		AppendMode:     AppendInPlace,
	}, opts)
	if err != nil {
		t.Fatal(err)
	}
	if got := dw.DurableTxID(); got != 2 {
		t.Fatalf("resumed durable tx = %d, want 2", got)
	}
	dw.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
	finalTx, fatalErr := dw.Close()
	if fatalErr != nil {
		t.Fatal(fatalErr)
	}
	if finalTx != 3 {
		t.Fatalf("final durable tx = %d, want 3", finalTx)
	}

	reopened, err := OpenOffsetIndex(idxPath)
	if err != nil {
		t.Fatal(err)
	}
	defer reopened.Close()
	entries, err := reopened.Entries()
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 3 {
		t.Fatalf("offset index entries = %+v, want tx 1,2 plus rewritten tx 3", entries)
	}
	for i, wantTx := range []types.TxID{1, 2, 3} {
		if entries[i].TxID != wantTx {
			t.Fatalf("offset index entries = %+v, want tx sequence [1 2 3]", entries)
		}
	}
	if entries[2].ByteOffset == staleFutureOffset {
		t.Fatalf("stale future index offset survived resume: %+v", entries)
	}
	if entries[2].ByteOffset <= entries[1].ByteOffset {
		t.Fatalf("rewritten tx 3 offset = %d, want beyond tx 2 offset %d", entries[2].ByteOffset, entries[1].ByteOffset)
	}
}

func TestDurabilityWorkerResumeWithUnopenableOffsetIndexDisablesIndexAndRecovers(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()

	initialOpts := DefaultCommitLogOptions()
	initialOpts.ChannelCapacity = 2
	initialOpts.DrainBatchSize = 1
	initialOpts.OffsetIndexIntervalBytes = 0
	initialOpts.OffsetIndexCap = 0
	initial, err := NewDurabilityWorker(dir, 1, initialOpts)
	if err != nil {
		t.Fatal(err)
	}
	initial.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	initial.EnqueueCommitted(2, makeDurabilityTestChangeset(2))
	if finalTx, fatalErr := initial.Close(); fatalErr != nil {
		t.Fatal(fatalErr)
	} else if finalTx != 2 {
		t.Fatalf("initial final durable tx = %d, want 2", finalTx)
	}

	idxPath := filepath.Join(dir, OffsetIndexFileName(1))
	if err := os.Mkdir(idxPath, 0o755); err != nil {
		t.Fatal(err)
	}

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 8
	dw, err := NewDurabilityWorkerWithResumePlan(dir, RecoveryResumePlan{
		SegmentStartTx: 1,
		NextTxID:       3,
		AppendMode:     AppendInPlace,
	}, opts)
	if err != nil {
		t.Fatal(err)
	}
	if got := dw.DurableTxID(); got != 2 {
		t.Fatalf("resumed durable tx = %d, want 2", got)
	}
	if dw.idx != nil {
		t.Fatal("unopenable advisory offset index should disable indexing")
	}
	dw.EnqueueCommitted(3, makeDurabilityTestChangeset(3))
	finalTx, fatalErr := dw.Close()
	if fatalErr != nil {
		t.Fatal(fatalErr)
	}
	if finalTx != 3 {
		t.Fatalf("final durable tx = %d, want 3", finalTx)
	}
	if info, err := os.Stat(idxPath); err != nil || !info.IsDir() {
		t.Fatalf("unopenable index artifact stat = (%v, %v), want directory still present", info, err)
	}

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 3 {
		t.Fatalf("maxTxID = %d, want 3", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p", 3: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 3}) {
		t.Fatalf("replayed range = %+v, want 1..3", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 4 {
		t.Fatalf("resume plan = %+v, want append-in-place on segment 1 at tx 4", plan)
	}
}

func TestDurabilityWorkerInitialUnopenableOffsetIndexDoesNotBlockRecovery(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	idxPath := filepath.Join(dir, OffsetIndexFileName(1))
	if err := os.Mkdir(idxPath, 0o755); err != nil {
		t.Fatal(err)
	}

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 2
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 8
	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	dw.EnqueueCommitted(2, makeDurabilityTestChangeset(2))
	finalTx, fatalErr := dw.Close()
	if fatalErr != nil {
		t.Fatalf("initial unopenable offset index should not fail durability: %v", fatalErr)
	}
	if finalTx != 2 || dw.DurableTxID() != 2 {
		t.Fatalf("durable tx after unopenable initial index = (%d, %d), want (2, 2)", finalTx, dw.DurableTxID())
	}
	if info, err := os.Stat(idxPath); err != nil || !info.IsDir() {
		t.Fatalf("unopenable initial index artifact stat = (%v, %v), want directory still present", info, err)
	}

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 2 {
		t.Fatalf("maxTxID = %d, want 2", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 2}) {
		t.Fatalf("replayed range = %+v, want 1..2", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 3 {
		t.Fatalf("resume plan = %+v, want append-in-place on segment 1 at tx 3", plan)
	}
}

func TestDurabilityWorkerOffsetIndexFailureDoesNotBlockDurablePrefix(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 1
	opts.DrainBatchSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 8
	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	if dw.idx == nil || dw.idx.head == nil || dw.idx.head.f == nil {
		t.Fatal("expected enabled offset index writer")
	}
	if err := dw.idx.head.f.Close(); err != nil {
		t.Fatal(err)
	}

	wait := dw.WaitUntilDurable(1)
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	finalTx, fatalErr := dw.Close()
	if fatalErr != nil {
		t.Fatalf("offset index failure should not fail durability: %v", fatalErr)
	}
	if finalTx != 1 || dw.DurableTxID() != 1 {
		t.Fatalf("durable tx after offset index failure = (%d, %d), want (1, 1)", finalTx, dw.DurableTxID())
	}
	select {
	case txID := <-wait:
		if txID != 1 {
			t.Fatalf("waiter tx = %d, want 1", txID)
		}
	default:
		t.Fatal("waiter for segment-synced prefix should be released despite index failure")
	}

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 1 {
		t.Fatalf("maxTxID = %d, want 1", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 1}) {
		t.Fatalf("replayed range = %+v, want 1..1", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 1 || plan.NextTxID != 2 {
		t.Fatalf("resume plan = %+v, want append-in-place on segment 1 at tx 2", plan)
	}

	idx, err := OpenOffsetIndex(filepath.Join(dir, OffsetIndexFileName(1)))
	if err != nil {
		t.Fatal(err)
	}
	defer idx.Close()
	entries, err := idx.Entries()
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 0 {
		t.Fatalf("failed advisory index entries = %+v, want empty safe sidecar", entries)
	}
}

func TestDurabilityWorkerRolloverUnopenableOffsetIndexDoesNotBlockRecovery(t *testing.T) {
	dir := t.TempDir()
	_, reg := testSchema()
	idxPath := filepath.Join(dir, OffsetIndexFileName(2))
	if err := os.Mkdir(idxPath, 0o755); err != nil {
		t.Fatal(err)
	}

	opts := DefaultCommitLogOptions()
	opts.ChannelCapacity = 2
	opts.DrainBatchSize = 1
	opts.MaxSegmentSize = 1
	opts.OffsetIndexIntervalBytes = 1
	opts.OffsetIndexCap = 8
	dw, err := NewDurabilityWorker(dir, 1, opts)
	if err != nil {
		t.Fatal(err)
	}
	dw.EnqueueCommitted(1, makeDurabilityTestChangeset(1))
	dw.EnqueueCommitted(2, makeDurabilityTestChangeset(2))
	finalTx, fatalErr := dw.Close()
	if fatalErr != nil {
		t.Fatalf("rollover unopenable offset index should not fail durability: %v", fatalErr)
	}
	if finalTx != 2 || dw.DurableTxID() != 2 {
		t.Fatalf("durable tx after unopenable rollover index = (%d, %d), want (2, 2)", finalTx, dw.DurableTxID())
	}
	if info, err := os.Stat(idxPath); err != nil || !info.IsDir() {
		t.Fatalf("unopenable rollover index artifact stat = (%v, %v), want directory still present", info, err)
	}

	recovered, maxTxID, plan, report, err := OpenAndRecoverWithReport(dir, reg)
	if err != nil {
		t.Fatal(err)
	}
	if maxTxID != 2 {
		t.Fatalf("maxTxID = %d, want 2", maxTxID)
	}
	assertReplayPlayerRows(t, recovered, map[uint64]string{1: "p", 2: "p"})
	if report.ReplayedTxRange != (RecoveryTxIDRange{Start: 1, End: 2}) {
		t.Fatalf("replayed range = %+v, want 1..2", report.ReplayedTxRange)
	}
	if plan.AppendMode != AppendInPlace || plan.SegmentStartTx != 3 || plan.NextTxID != 3 {
		t.Fatalf("resume plan = %+v, want append-in-place on header-only segment 3 at tx 3", plan)
	}
}
