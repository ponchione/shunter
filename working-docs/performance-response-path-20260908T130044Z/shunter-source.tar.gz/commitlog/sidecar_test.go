package commitlog

import (
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"testing"

	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/types"
)

// Drive the actual worker synchronously so failures can be injected between
// append and sync without racing its goroutine.
func sidecarWorker(t testing.TB) *DurabilityWorker {
	t.Helper()
	dir := t.TempDir()
	seg, err := CreateSegment(dir, 1)
	if err != nil {
		t.Fatal(err)
	}
	opts := DefaultCommitLogOptions()
	dw := &DurabilityWorker{dir: dir, seg: seg, opts: opts, waiters: make(map[uint64][]chan types.TxID)}
	dw.idx = initOffsetIndexForSegment(dir, seg, opts)
	if dw.idx == nil {
		t.Fatal("index not initialized")
	}
	t.Cleanup(func() {
		_ = dw.seg.file.Close()
		if dw.idx != nil {
			_ = dw.idx.Close()
		}
	})
	return dw
}

func TestSidecarBatchPreservesCadence(t *testing.T) {
	for _, mode := range []FsyncMode{FsyncBatch, FsyncPerTx} {
		t.Run(map[FsyncMode]string{FsyncBatch: "batch", FsyncPerTx: "per-tx"}[mode], func(t *testing.T) {
			dw := sidecarWorker(t)
			dw.opts.FsyncMode = mode
			for tx := uint64(1); tx <= 3; tx++ {
				wait := dw.WaitUntilDurable(types.TxID(tx))
				if err := dw.processBatch([]durabilityItem{{txID: tx, changeset: sidecarChangeset(tx)}}); err != nil {
					t.Fatal(err)
				}
				if got := <-wait; uint64(got) != tx {
					t.Fatalf("waiter=%d want %d", got, tx)
				}
				if got := dw.idx.head.NumEntries(); got != 0 {
					t.Fatalf("sub-64-KiB batch forced candidate: entries=%d want 0", got)
				}
			}
			if dw.idx.candidateTxID != 1 {
				t.Fatalf("earliest candidate=%d", dw.idx.candidateTxID)
			}
			// Cross the cadence with the next real record; the earliest candidate
			// lands but the new candidate must stay buffered until close/rotation.
			dw.idx.minWriteIntervalBytes = 1
			if err := dw.processBatch([]durabilityItem{{txID: 4, changeset: sidecarChangeset(4)}}); err != nil {
				t.Fatal(err)
			}
			if dw.idx.head.NumEntries() != 1 || dw.idx.candidateTxID != 4 {
				t.Fatal("cadence did not preserve earliest entry and next candidate")
			}
			if err := dw.idx.Sync(); err != nil {
				t.Fatal(err)
			}
			entries, err := dw.idx.head.Entries()
			if err != nil || len(entries) != 2 || entries[0].TxID != 1 || entries[1].TxID != 4 {
				t.Fatalf("final flush=%v %v", entries, err)
			}
		})
	}
}

func TestSidecarSyncFailureBoundaries(t *testing.T) {
	t.Run("segment-fails-before-index-and-publication", func(t *testing.T) {
		dw := sidecarWorker(t)
		if err := dw.idx.AppendAfterCommit(1, SegmentHeaderSize, 1); err != nil {
			t.Fatal(err)
		}
		wait := dw.WaitUntilDurable(1)
		if err := dw.seg.file.Close(); err != nil {
			t.Fatal(err)
		}
		if err := dw.syncBatchTail(1); err == nil {
			t.Fatal("missing segment sync error")
		}
		if dw.DurableTxID() != 0 || dw.idx.head.NumEntries() != 0 {
			t.Fatal("failed segment sync advanced index/horizon")
		}
		select {
		case <-wait:
			t.Fatal("failed sync released waiter")
		default:
		}
	})
	t.Run("index-failure-is-advisory", func(t *testing.T) {
		dw := sidecarWorker(t)
		wait := dw.WaitUntilDurable(1)
		if err := dw.idx.head.f.Close(); err != nil {
			t.Fatal(err)
		}
		// No append candidate: the error must be encountered at backing Sync.
		if err := dw.syncBatchTail(1); err != nil {
			t.Fatal(err)
		}
		if dw.idx != nil || dw.DurableTxID() != 1 || <-wait != 1 {
			t.Fatal("index failure blocked segment durability")
		}
	})
}

func TestSidecarSparseRecoveryAndExhaustion(t *testing.T) {
	for _, shape := range []string{"sparse", "missing", "empty", "stale", "partial", "full"} {
		t.Run(shape, func(t *testing.T) {
			dw := sidecarWorker(t)
			if shape == "sparse" {
				dw.idx.minWriteIntervalBytes = 256
			}
			if shape == "full" {
				dw.idx.head.cap = 1
				dw.idx.minWriteIntervalBytes = 1
			}
			const horizon, final = 20, 30
			committed, reg := buildLargeSnapshotCommittedState(t, horizon)
			createSnapshotAt(t, NewSnapshotWriter(filepath.Join(dw.dir, "snapshots"), reg), committed, horizon)
			for tx := uint64(1); tx <= final; tx++ {
				if err := dw.processBatch([]durabilityItem{{txID: tx, changeset: sidecarChangeset(tx)}}); err != nil {
					t.Fatal(err)
				}
			}
			if shape == "full" && (!dw.idx.full || dw.idx.haveCandidate || dw.idx.head.NumEntries() != 1) {
				t.Fatal("full index not bounded")
			}
			// Abrupt-close model: discard the unflushed candidate, retain only
			// completed batch syncs. Real process exit is covered at runtime level.
			if err := dw.idx.Close(); err != nil {
				t.Fatal(err)
			}
			dw.idx = nil
			if err := dw.seg.file.Close(); err != nil {
				t.Fatal(err)
			}
			path := filepath.Join(dw.dir, OffsetIndexFileName(1))
			switch shape {
			case "missing":
				if err := os.Remove(path); err != nil {
					t.Fatal(err)
				}
			case "empty":
				if err := os.Truncate(path, 0); err != nil {
					t.Fatal(err)
				}
			case "stale":
				writeRawRecoveryOffsetIndex(t, path, []OffsetIndexEntry{{TxID: 21, ByteOffset: 1 << 32}}, 4)
			case "partial":
				if err := os.WriteFile(path, []byte{21, 0, 0}, 0600); err != nil {
					t.Fatal(err)
				}
			}
			recovered, maxTx, plan, _, err := OpenAndRecoverWithReport(dw.dir, reg)
			if err != nil || maxTx != final || plan.NextTxID != final+1 {
				t.Fatalf("recovery=%d %+v %v", maxTx, plan, err)
			}
			sidecarRows(t, recovered, final)
			resumed, err := NewDurabilityWorkerWithResumePlan(dw.dir, plan, dw.opts)
			if err != nil {
				t.Fatal(err)
			}
			resumed.EnqueueCommitted(final+1, sidecarChangeset(final+1))
			if tx, err := resumed.Close(); err != nil || tx != final+1 {
				t.Fatalf("resume=%d %v", tx, err)
			}
			if err := RunCompaction(dw.dir, horizon, reg); err != nil {
				t.Fatal(err)
			}
			recovered, maxTx, err = OpenAndRecover(dw.dir, reg)
			if err != nil || maxTx != final+1 {
				t.Fatalf("post-compaction=%d %v", maxTx, err)
			}
			sidecarRows(t, recovered, final+1)
			if _, err := os.Stat(path); err != nil && !errors.Is(err, os.ErrNotExist) {
				t.Fatal(err)
			}
		})
	}
}

func sidecarChangeset(txID uint64) *store.Changeset {
	cs := makeDurabilityTestChangeset(txID)
	cs.Tables[0].Inserts[0][1] = types.NewString("player-" + strconv.FormatUint(txID, 10))
	return cs
}
func sidecarRows(t testing.TB, state *store.CommittedState, want uint64) {
	t.Helper()
	table, ok := state.Table(0)
	if !ok || table.RowCount() != int(want) {
		t.Fatal("unexpected recovered table or row count")
	}
	for _, row := range table.Scan() {
		id := row[0].AsUint64()
		if id == 0 || id > want || row[1].AsString() != "player-"+strconv.FormatUint(id, 10) {
			t.Fatalf("unexpected recovered row: %v", row)
		}
	}
}
