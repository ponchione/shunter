package schema

import (
	"slices"
	"strings"

	"github.com/ponchione/shunter/types"
)

// SchemaLookup is the narrow read-only schema surface consumed by SPEC-004
// (subscription/validate) and SPEC-005 (protocol/handle_subscribe,
// protocol/upgrade). SchemaRegistry satisfies SchemaLookup; consumer
// packages may also declare narrower local interfaces that SchemaRegistry
// continues to satisfy.
type SchemaLookup interface {
	// Table returns the full schema for the given table ID.
	Table(id TableID) (*TableSchema, bool)

	// TableByName returns the table ID and full schema for the given name.
	// The 3-tuple shape exists so that wire handlers can resolve a name
	// to its TableID without a second lookup.
	TableByName(name string) (TableID, *TableSchema, bool)

	// TableExists reports whether the table ID is registered. Cheaper
	// than Table() when the schema body is not needed.
	TableExists(table TableID) bool

	// TableName returns the declared table name, or empty string if the
	// table ID is unknown. Used for wire/debug output.
	TableName(table TableID) string

	// ColumnExists reports whether the column index is valid for the table.
	ColumnExists(table TableID, col types.ColID) bool

	// ColumnType returns the ValueKind of the column. Behavior is undefined
	// when ColumnExists returns false; callers must check first.
	ColumnType(table TableID, col types.ColID) ValueKind

	// HasIndex reports whether a single-column index on (table, col) exists.
	HasIndex(table TableID, col types.ColID) bool

	// ColumnCount returns the number of declared columns for the table, or
	// zero when the table ID is unknown.
	ColumnCount(table TableID) int
}

// IndexResolver maps (table, column) → index ID when a single-column index
// on that column exists. Used by SPEC-004 Tier-2 candidate collection.
// SchemaRegistry satisfies IndexResolver.
type IndexResolver interface {
	IndexIDForColumn(table TableID, col types.ColID) (IndexID, bool)
}

// SchemaRegistry is a read-only view of all registered tables, indexes, and
// reducers. Safe for concurrent use — immutable after construction.
type SchemaRegistry interface {
	SchemaLookup
	IndexResolver

	Tables() []TableID
	Reducer(name string) (ReducerHandler, bool)
	Reducers() []string
	OnConnect() func(*ReducerContext) error
	OnDisconnect() func(*ReducerContext) error
	Version() uint32
}

type schemaRegistry struct {
	tables        []TableSchema
	byID          map[TableID]int
	byName        map[string]int
	byFoldedName  map[string]int
	indexByColumn map[tableColumn]IndexID
	tableIDs      []TableID // user tables first, then system
	reducers      map[string]ReducerHandler
	reducerNames  []string
	onConnect     func(*ReducerContext) error
	onDisconnect  func(*ReducerContext) error
	version       uint32
}

type tableColumn struct {
	table TableID
	col   types.ColID
}

const ambiguousFoldedTableName = -1

func newSchemaRegistry(schemas []TableSchema, b *Builder) SchemaRegistry {
	r := &schemaRegistry{
		tables:        schemas,
		byID:          make(map[TableID]int, len(schemas)),
		byName:        make(map[string]int, len(schemas)),
		byFoldedName:  make(map[string]int, len(schemas)),
		indexByColumn: make(map[tableColumn]IndexID),
		tableIDs:      make([]TableID, len(schemas)),
		reducers:      make(map[string]ReducerHandler, len(b.reducers)),
		version:       b.version,
	}

	for i := range schemas {
		r.byID[schemas[i].ID] = i
		r.byName[schemas[i].Name] = i
		r.addFoldedTableName(strings.ToLower(schemas[i].Name), i)
		for _, idx := range schemas[i].Indexes {
			if len(idx.Columns) != 1 {
				continue
			}
			key := tableColumn{table: schemas[i].ID, col: types.ColID(idx.Columns[0])}
			if _, exists := r.indexByColumn[key]; !exists {
				r.indexByColumn[key] = idx.ID
			}
		}
		r.tableIDs[i] = schemas[i].ID
	}

	for _, name := range b.reducerOrder {
		entry := b.reducers[name]
		r.reducers[name] = entry.handler
		r.reducerNames = append(r.reducerNames, name)
	}

	r.onConnect = b.onConnect
	r.onDisconnect = b.onDisconnect
	return r
}

func newRemappedRegistry(base SchemaRegistry, schemas []TableSchema) SchemaRegistry {
	r := &schemaRegistry{
		tables:        make([]TableSchema, len(schemas)),
		byID:          make(map[TableID]int, len(schemas)),
		byName:        make(map[string]int, len(schemas)),
		byFoldedName:  make(map[string]int, len(schemas)),
		indexByColumn: make(map[tableColumn]IndexID),
		tableIDs:      make([]TableID, len(schemas)),
		reducers:      make(map[string]ReducerHandler),
		version:       base.Version(),
	}

	for i := range schemas {
		r.tables[i] = cloneTableSchema(schemas[i])
		r.byID[r.tables[i].ID] = i
		r.byName[r.tables[i].Name] = i
		r.addFoldedTableName(strings.ToLower(r.tables[i].Name), i)
		for _, idx := range r.tables[i].Indexes {
			if len(idx.Columns) != 1 {
				continue
			}
			key := tableColumn{table: r.tables[i].ID, col: types.ColID(idx.Columns[0])}
			if _, exists := r.indexByColumn[key]; !exists {
				r.indexByColumn[key] = idx.ID
			}
		}
		r.tableIDs[i] = r.tables[i].ID
	}

	for _, name := range base.Reducers() {
		if handler, ok := base.Reducer(name); ok {
			r.reducers[name] = handler
			r.reducerNames = append(r.reducerNames, name)
		}
	}
	r.onConnect = base.OnConnect()
	r.onDisconnect = base.OnDisconnect()
	return r
}

func (r *schemaRegistry) addFoldedTableName(folded string, i int) {
	if existing, ok := r.byFoldedName[folded]; ok && existing != i {
		r.byFoldedName[folded] = ambiguousFoldedTableName
		return
	}
	r.byFoldedName[folded] = i
}

func (r *schemaRegistry) Table(id TableID) (*TableSchema, bool) {
	if i, ok := r.byID[id]; ok {
		ts := cloneTableSchema(r.tables[i])
		return &ts, true
	}
	return nil, false
}

func (r *schemaRegistry) TableByName(name string) (TableID, *TableSchema, bool) {
	if i, ok := r.byName[name]; ok {
		ts := cloneTableSchema(r.tables[i])
		return ts.ID, &ts, true
	}
	if i, ok := r.byFoldedName[strings.ToLower(name)]; ok && i != ambiguousFoldedTableName {
		ts := cloneTableSchema(r.tables[i])
		return ts.ID, &ts, true
	}
	return 0, nil, false
}

func (r *schemaRegistry) TableExists(id TableID) bool {
	_, ok := r.byID[id]
	return ok
}

func (r *schemaRegistry) TableName(id TableID) string {
	if i, ok := r.byID[id]; ok {
		return r.tables[i].Name
	}
	return ""
}

func (r *schemaRegistry) ColumnExists(table TableID, col types.ColID) bool {
	if i, ok := r.byID[table]; ok {
		return int(col) >= 0 && int(col) < len(r.tables[i].Columns)
	}
	return false
}

func (r *schemaRegistry) ColumnType(table TableID, col types.ColID) ValueKind {
	if i, ok := r.byID[table]; ok && int(col) >= 0 && int(col) < len(r.tables[i].Columns) {
		return r.tables[i].Columns[col].Type
	}
	return 0
}

func (r *schemaRegistry) HasIndex(table TableID, col types.ColID) bool {
	_, ok := r.indexIDForColumn(table, col)
	return ok
}

func (r *schemaRegistry) ColumnCount(table TableID) int {
	if i, ok := r.byID[table]; ok {
		return len(r.tables[i].Columns)
	}
	return 0
}

func (r *schemaRegistry) IndexIDForColumn(table TableID, col types.ColID) (IndexID, bool) {
	return r.indexIDForColumn(table, col)
}

func (r *schemaRegistry) indexIDForColumn(table TableID, col types.ColID) (IndexID, bool) {
	idx, ok := r.indexByColumn[tableColumn{table: table, col: col}]
	return idx, ok
}

func (r *schemaRegistry) Tables() []TableID {
	return slices.Clone(r.tableIDs)
}

func (r *schemaRegistry) Reducer(name string) (ReducerHandler, bool) {
	h, ok := r.reducers[name]
	return h, ok
}

func (r *schemaRegistry) Reducers() []string {
	return slices.Clone(r.reducerNames)
}

func (r *schemaRegistry) OnConnect() func(*ReducerContext) error {
	return r.onConnect
}

func (r *schemaRegistry) OnDisconnect() func(*ReducerContext) error {
	return r.onDisconnect
}

func (r *schemaRegistry) Version() uint32 {
	return r.version
}

func cloneTableSchema(ts TableSchema) TableSchema {
	clone := ts
	clone.Columns = slices.Clone(ts.Columns)
	clone.Indexes = make([]IndexSchema, len(ts.Indexes))
	for i, idx := range ts.Indexes {
		idxClone := idx
		idxClone.Columns = slices.Clone(idx.Columns)
		clone.Indexes[i] = idxClone
	}
	clone.ReadPolicy = copyReadPolicy(ts.ReadPolicy)
	clone.SDK = ts.SDK
	return clone
}
