package schema

// Builder accumulates table definitions, reducers, and engine configuration
// before Build() validates and freezes everything.
type Builder struct {
	tables                    []TableDefinition
	reducers                  map[string]reducerEntry
	reducerOrder              []string
	onConnect                 func(*ReducerContext) error
	onDisconnect              func(*ReducerContext) error
	onConnectRegistrations    int
	onDisconnectRegistrations int
	version                   uint32
	versionSet                bool
	built                     bool
}

type reducerEntry struct {
	handler ReducerHandler
	count   int // registration count for duplicate detection
}

// NewBuilder returns a new empty Builder.
func NewBuilder() *Builder {
	return &Builder{
		reducers: make(map[string]reducerEntry),
	}
}

// TableDefinition describes a table before validation and ID assignment.
type TableDefinition struct {
	Name       string
	IsEvent    bool
	Columns    []ColumnDefinition
	Indexes    []IndexDefinition
	ReadPolicy ReadPolicy
	SDK        TableSDKMetadata
}

// ColumnDefinition describes a column in a table definition.
type ColumnDefinition struct {
	Name          string
	Type          ValueKind
	PrimaryKey    bool
	Nullable      bool
	AutoIncrement bool
}

// IndexDefinition describes a secondary index.
type IndexDefinition struct {
	Name    string
	Columns []string // column names, in key order
	Unique  bool
}

// TableOption configures a table registration.
type TableOption func(*tableOptions)

type tableOptions struct {
	name       string
	readPolicy *ReadPolicy
	isEvent    bool
	sdk        *TableSDKMetadata
}

// WithTableName overrides the table name derived from the Go type name.
func WithTableName(name string) TableOption {
	return func(o *tableOptions) {
		o.name = name
	}
}

// WithEventTable marks a table as transient. Event table rows are visible in
// the transaction and emitted through commit changesets, but they are not
// retained in committed state.
func WithEventTable() TableOption {
	return func(o *tableOptions) {
		o.isEvent = true
	}
}

// WithPrivateRead marks a table private to external raw SQL reads.
func WithPrivateRead() TableOption {
	return func(o *tableOptions) {
		policy := ReadPolicy{Access: TableAccessPrivate}
		o.readPolicy = &policy
	}
}

// WithPublicRead marks a table readable by external raw SQL without
// permission tags.
func WithPublicRead() TableOption {
	return func(o *tableOptions) {
		policy := ReadPolicy{Access: TableAccessPublic}
		o.readPolicy = &policy
	}
}

// WithReadPermissions marks a table readable by external raw SQL only when all
// supplied permission tags are present.
func WithReadPermissions(permissions ...string) TableOption {
	copied := append([]string(nil), permissions...)
	return func(o *tableOptions) {
		policy := ReadPolicy{
			Access:      TableAccessPermissioned,
			Permissions: append([]string(nil), copied...),
		}
		o.readPolicy = &policy
	}
}

// WithTableSDKVisibility records passive SDK visibility metadata for a table.
// It does not change runtime authorization or table read policy behavior.
func WithTableSDKVisibility(visibility TableSDKVisibility) TableOption {
	return func(o *tableOptions) {
		o.sdk = &TableSDKMetadata{Visibility: visibility}
	}
}

// TableDef registers a table definition with the builder.
func (b *Builder) TableDef(def TableDefinition, opts ...TableOption) *Builder {
	var o tableOptions
	for _, opt := range opts {
		opt(&o)
	}
	if o.name != "" {
		def.Name = o.name
	}
	if o.isEvent {
		def.IsEvent = true
	}
	if o.readPolicy != nil {
		def.ReadPolicy = *o.readPolicy
	}
	if o.sdk != nil {
		def.SDK = *o.sdk
	}
	b.tables = append(b.tables, copyTableDefinition(def))
	return b
}

func copyTableDefinition(def TableDefinition) TableDefinition {
	out := def
	out.Columns = append([]ColumnDefinition(nil), def.Columns...)
	out.Indexes = make([]IndexDefinition, len(def.Indexes))
	for i, idx := range def.Indexes {
		idx.Columns = append([]string(nil), idx.Columns...)
		out.Indexes[i] = idx
	}
	out.ReadPolicy = copyReadPolicy(def.ReadPolicy)
	out.SDK = def.SDK
	return out
}

// SchemaVersion sets the schema version used for compatibility checking.
func (b *Builder) SchemaVersion(v uint32) *Builder {
	b.version = v
	b.versionSet = true
	return b
}

// Reducer registers a named reducer handler. Duplicate names are preserved
// for detection during Build() validation.
func (b *Builder) Reducer(name string, h ReducerHandler) *Builder {
	e := b.reducers[name]
	if e.count == 0 {
		b.reducerOrder = append(b.reducerOrder, name)
	}
	e.handler = h
	e.count++
	b.reducers[name] = e
	return b
}

// OnConnect registers the lifecycle handler invoked when a client connects.
// Duplicate registrations are tracked for Build() validation.
func (b *Builder) OnConnect(h func(*ReducerContext) error) *Builder {
	b.onConnect = h
	b.onConnectRegistrations++
	return b
}

// OnDisconnect registers the lifecycle handler invoked when a client disconnects.
// Duplicate registrations are tracked for Build() validation.
func (b *Builder) OnDisconnect(h func(*ReducerContext) error) *Builder {
	b.onDisconnect = h
	b.onDisconnectRegistrations++
	return b
}

// EngineOptions configures runtime engine behavior.
// Zero-value defaults:
//   - DataDir: current working directory / runtime default chosen at Start()
//   - ExecutorQueueCapacity: runtime default chosen at Start()
//   - DurabilityQueueCapacity: runtime default chosen at Start()
//   - EnableProtocol: false
type EngineOptions struct {
	DataDir                 string
	ExecutorQueueCapacity   int
	DurabilityQueueCapacity int
	EnableProtocol          bool
	StartupSnapshotSchema   *SnapshotSchema
}
