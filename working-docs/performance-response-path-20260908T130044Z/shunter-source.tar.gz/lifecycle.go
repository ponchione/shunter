package shunter

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/ponchione/shunter/commitlog"
	"github.com/ponchione/shunter/executor"
	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/subscription"
	"github.com/ponchione/shunter/types"
)

// RuntimeState names the public lifecycle state reported by Runtime.Health.
type RuntimeState string

const (
	// RuntimeStateBuilt means Build completed but Start has not yet made the runtime ready.
	RuntimeStateBuilt RuntimeState = "built"
	// RuntimeStateStarting means one goroutine is currently running Start.
	RuntimeStateStarting RuntimeState = "starting"
	// RuntimeStateReady means Start completed and runtime-owned workers are running.
	RuntimeStateReady RuntimeState = "ready"
	// RuntimeStateClosing means Close is shutting down runtime-owned workers.
	RuntimeStateClosing RuntimeState = "closing"
	// RuntimeStateClosed means the runtime has been closed and cannot be restarted.
	RuntimeStateClosed RuntimeState = "closed"
	// RuntimeStateFailed means the last lifecycle operation failed.
	RuntimeStateFailed RuntimeState = "failed"
)

var (
	// ErrRuntimeStarting reports that another goroutine is already starting the runtime.
	ErrRuntimeStarting = errors.New("shunter: runtime is starting")
	// ErrRuntimeClosed reports that the runtime has already been closed.
	ErrRuntimeClosed = errors.New("shunter: runtime is closed")
	// ErrRuntimeRestartRequired reports that this Runtime cannot be safely
	// restarted after a failed Start. Build a fresh Runtime over the same
	// DataDir to reload durable state before retrying.
	ErrRuntimeRestartRequired = errors.New("shunter: runtime must be rebuilt before restart")
)

var runtimeStartAfterDurabilityHook func(*Runtime) error

var closeStartupDurability = func(worker *commitlog.DurabilityWorker) (uint64, error) {
	return worker.Close()
}

var closeRuntimeDurability = func(worker *commitlog.DurabilityWorker) (uint64, error) {
	return worker.Close()
}

// Ready reports whether Start has completed and runtime-owned workers are running.
func (r *Runtime) Ready() bool {
	return r.ready.Load()
}

// Start performs runtime startup and returns once background ownership is ready.
// The supplied context is a startup/cancellation context only; canceling it
// after Start returns does not stop the runtime. Use Close for shutdown.
func (r *Runtime) Start(ctx context.Context) (startErr error) {
	if ctx == nil {
		ctx = context.Background()
	}
	startedAt := time.Now()

	r.mu.Lock()
	switch r.stateName {
	case RuntimeStateReady:
		r.mu.Unlock()
		return nil
	case RuntimeStateStarting:
		r.mu.Unlock()
		return ErrRuntimeStarting
	case RuntimeStateClosing, RuntimeStateClosed:
		r.mu.Unlock()
		return ErrRuntimeClosed
	case RuntimeStateFailed:
		if r.startRetryBlockedErr != nil {
			err := r.startRetryBlockedErr
			r.mu.Unlock()
			return err
		}
	}
	r.stateName = RuntimeStateStarting
	r.lastErr = nil
	r.ready.Store(false)
	startupCtx, startupCancel := context.WithCancel(ctx)
	startupDone := make(chan struct{})
	r.startupCancel = startupCancel
	r.startupDone = startupDone
	r.mu.Unlock()
	ctx = startupCtx
	defer func() {
		startupCancel()
		r.mu.Lock()
		if r.startupDone == startupDone {
			r.startupCancel = nil
			r.startupDone = nil
		}
		r.mu.Unlock()
		if startErr != nil && r.startInterruptedByClose() && !errors.Is(startErr, ErrRuntimeClosed) {
			startErr = errors.Join(ErrRuntimeClosed, startErr)
		}
		if startErr != nil {
			r.recordStartFailure(ctx, startErr, time.Since(startedAt))
		}
		close(startupDone)
	}()
	r.recordRuntimeMetrics()

	if err := ctx.Err(); err != nil {
		return err
	}
	if err := r.engine.Start(ctx); err != nil {
		err = fmt.Errorf("start schema engine: %w", err)
		return err
	}
	if r.buildConfig.EnableProtocol {
		if _, _, err := buildAuthConfig(r.config); err != nil {
			return err
		}
		if _, err := buildProtocolOptions(r.config.Protocol); err != nil {
			return err
		}
	}

	durabilityOptions := commitlog.DefaultCommitLogOptions()
	durabilityOptions.ChannelCapacity = r.buildConfig.DurabilityQueueCapacity
	durabilityOptions.Observer = r.observability
	durability, err := commitlog.NewDurabilityWorkerWithResumePlan(r.dataDir, r.resumePlan, durabilityOptions)
	if err != nil {
		err = fmt.Errorf("start durability worker: %w", err)
		return err
	}
	cleanupDurability := true
	defer func() {
		if cleanupDurability {
			finalDurableTxID, closeErr := closeStartupDurability(durability)
			if closeErr == nil {
				r.refreshStartupRecoveryAfterDurabilityClose(types.TxID(finalDurableTxID))
			} else {
				startErr = errors.Join(startErr, fmt.Errorf("close durability worker after failed start: %w", closeErr))
			}
		}
	}()

	if runtimeStartAfterDurabilityHook != nil {
		if err := runtimeStartAfterDurabilityHook(r); err != nil {
			err = fmt.Errorf("start runtime lifecycle: %w", err)
			return err
		}
	}

	if err := ctx.Err(); err != nil {
		return err
	}
	if err := r.runMigrationHooks(ctx, durability); err != nil {
		blocksRetry := migrationStateDirty(err)
		err = fmt.Errorf("run migration hooks: %w", err)
		if blocksRetry {
			err = fmt.Errorf("%w: %w", ErrRuntimeRestartRequired, err)
		}
		if blocksRetry {
			r.blockStartRetry(err)
		}
		return err
	}
	if err := ctx.Err(); err != nil {
		return err
	}

	fanOutCapacity := r.buildConfig.ExecutorQueueCapacity
	fanOutInbox := make(chan subscription.FanOutMessage, fanOutCapacity)
	subscriptions := subscription.NewManager(
		r.registry,
		r.registry,
		subscription.WithFanOutInbox(fanOutInbox),
		subscription.WithObserver(r.observability),
		subscription.WithInitialRowLimit(r.buildConfig.SubscriptionInitialRowLimit),
		subscription.WithSnapshotByteLimit(r.buildConfig.SubscriptionSnapshotMaxBytes),
		subscription.WithOrderedWindowMaxRows(r.buildConfig.SubscriptionOrderedWindowMaxRows),
		subscription.WithMaxQueriesPerSet(r.buildConfig.SubscriptionMaxQueriesPerSet),
		subscription.WithMaxActiveSetsPerConnection(r.buildConfig.SubscriptionMaxActiveSetsPerConnection),
		subscription.WithMaxActiveSubscriptionsPerConnection(r.buildConfig.SubscriptionMaxActiveSubscriptionsPerConnection),
		subscription.WithMaxMultiJoinRelations(r.buildConfig.SubscriptionMaxMultiJoinRelations),
		subscription.WithMaxMultiJoinRowsPerRelation(r.buildConfig.SubscriptionMaxMultiJoinRowsPerRelation),
		subscription.WithMaxMultiJoinWork(r.buildConfig.SubscriptionMaxMultiJoinWork),
	)
	exec := executor.NewExecutor(executor.ExecutorConfig{
		InboxCapacity: r.buildConfig.ExecutorQueueCapacity,
		Durability:    durabilityHandle{worker: durability},
		Subscriptions: subscriptions,
		RejectOnFull:  false,
		Observer:      r.observability,
	}, r.reducers, r.state, r.registry, uint64(r.recoveredTxID))
	scheduler := exec.SchedulerFor()
	if err := exec.Startup(ctx, scheduler); err != nil {
		err = fmt.Errorf("startup executor: %w", err)
		return err
	}

	lifecycleCtx, lifecycleCancel := context.WithCancel(context.Background())
	fanOutCtx, fanOutCancel := context.WithCancel(context.Background())
	fanOutSender := newSwappableFanOutSender(noopFanOutSender{})
	fanOutWorker := subscription.NewFanOutWorkerWithObserver(
		fanOutInbox,
		fanOutSender,
		subscriptions.SignalDroppedClient,
		r.observability,
	)

	r.mu.Lock()
	if r.stateName == RuntimeStateClosed || r.stateName == RuntimeStateClosing {
		r.mu.Unlock()
		lifecycleCancel()
		fanOutCancel()
		return ErrRuntimeClosed
	}
	r.lifecycleCancel = lifecycleCancel
	r.fanOutCancel = fanOutCancel
	r.durability = durability
	r.subscriptions = subscriptions
	r.fanOutInbox = fanOutInbox
	r.fanOutWorker = fanOutWorker
	r.fanOutSender = fanOutSender
	r.executor = exec
	r.scheduler = scheduler
	if r.buildConfig.EnableProtocol {
		if err := r.ensureProtocolGraphLocked(); err != nil {
			r.clearRuntimeGraphLocked()
			r.mu.Unlock()
			lifecycleCancel()
			fanOutCancel()
			return err
		}
	}
	r.schedulerWG.Add(1)
	r.fanOutWG.Add(1)
	if r.observability.StoreMemoryUsageEnabled() {
		r.memoryMetricsWG.Add(1)
		go func() {
			defer r.memoryMetricsWG.Done()
			r.runStoreMemoryMetrics(lifecycleCtx)
		}()
	}
	r.stateName = RuntimeStateReady
	r.ready.Store(true)
	r.mu.Unlock()

	go exec.Run(context.Background())
	go func() {
		defer r.schedulerWG.Done()
		scheduler.Run(lifecycleCtx)
	}()
	go func() {
		defer r.fanOutWG.Done()
		fanOutWorker.Run(fanOutCtx)
	}()

	cleanupDurability = false
	r.recordStartReady(ctx, time.Since(startedAt))
	return nil
}

// Close idempotently shuts down runtime-owned background workers.
func (r *Runtime) Close() error {
	startedAt := time.Now()
	r.closeMu.Lock()
	defer r.closeMu.Unlock()

	r.mu.Lock()
	if r.stateName == RuntimeStateClosed {
		r.mu.Unlock()
		return nil
	}
	if (r.stateName == RuntimeStateBuilt || r.stateName == RuntimeStateFailed) && r.startupDone == nil {
		r.stateName = RuntimeStateClosed
		r.ready.Store(false)
		lease := r.dataDirLease
		r.dataDirLease = nil
		r.mu.Unlock()
		closeErr := lease.release()
		if closeErr != nil {
			r.mu.Lock()
			r.lastErr = closeErr
			r.mu.Unlock()
			r.recordCloseFailure(closeErr, time.Since(startedAt))
		} else {
			r.recordClosed(time.Since(startedAt))
		}
		return closeErr
	}
	r.stateName = RuntimeStateClosing
	r.ready.Store(false)
	startupCancel := r.startupCancel
	startupDone := r.startupDone
	lifecycleCancel := r.lifecycleCancel
	fanOutCancel := r.fanOutCancel
	exec := r.executor
	durability := r.durability
	subscriptions := r.subscriptions
	protocolConns := r.protocolConns
	protocolInbox := r.protocolInbox
	lease := r.dataDirLease
	r.dataDirLease = nil
	r.mu.Unlock()
	r.recordRuntimeMetrics()
	if startupCancel != nil {
		startupCancel()
	}
	if startupDone != nil {
		<-startupDone
	}

	if subscriptions != nil {
		subscriptions.CloseFanOut()
	}
	if lifecycleCancel != nil {
		lifecycleCancel()
	}
	r.closeProtocolGraph(protocolConns, protocolInbox)
	r.schedulerWG.Wait()
	r.memoryMetricsWG.Wait()
	executorFatal := false
	if exec != nil {
		exec.Shutdown()
		executorFatal = exec.Fatal()
	}
	if fanOutCancel != nil {
		fanOutCancel()
	}
	r.fanOutWG.Wait()
	var (
		closeErr            error
		finalDurableTxID    uint64
		acceptedConnections uint64
		rejectedConnections uint64
		droppedClients      uint64
	)
	if protocolConns != nil {
		acceptedConnections = protocolConns.AcceptedCount()
		rejectedConnections = protocolConns.RejectedCount()
	}
	if subscriptions != nil {
		droppedClients = subscriptions.DroppedClientCount()
		r.observability.RecordSubscriptionActive(0)
	}
	if durability != nil {
		finalDurableTxID, closeErr = closeRuntimeDurability(durability)
	}
	closeErr = errors.Join(closeErr, lease.release())

	r.mu.Lock()
	if finalDurableTxID > 0 || durability != nil {
		r.durableTxID = types.TxID(finalDurableTxID)
	}
	if closeErr != nil {
		r.durabilityFatalErr = closeErr
	}
	if executorFatal {
		r.executorFatal = true
	}
	if acceptedConnections > r.protocolAcceptedConnections {
		r.protocolAcceptedConnections = acceptedConnections
	}
	if rejectedConnections > r.protocolRejectedConnections {
		r.protocolRejectedConnections = rejectedConnections
	}
	if droppedClients > r.subscriptionDroppedClients {
		r.subscriptionDroppedClients = droppedClients
	}
	r.clearRuntimeGraphLocked()
	r.lastErr = closeErr
	r.stateName = RuntimeStateClosed
	r.ready.Store(false)
	r.mu.Unlock()
	if closeErr != nil {
		r.recordCloseFailure(closeErr, time.Since(startedAt))
	} else {
		r.recordClosed(time.Since(startedAt))
	}
	return closeErr
}

func (r *Runtime) startInterruptedByClose() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.stateName == RuntimeStateClosing || r.stateName == RuntimeStateClosed
}

func (r *Runtime) clearRuntimeGraphLocked() {
	r.lifecycleCancel = nil
	r.fanOutCancel = nil
	r.durability = nil
	r.subscriptions = nil
	r.fanOutInbox = nil
	r.fanOutWorker = nil
	r.fanOutSender = nil
	r.executor = nil
	r.scheduler = nil
	r.protocolConns = nil
	r.protocolInbox = nil
	r.protocolSender = nil
	r.protocolServer = nil
}

func (r *Runtime) recordStartFailure(ctx context.Context, err error, duration time.Duration) {
	transitionedFailed := false
	r.mu.Lock()
	r.lastErr = err
	r.ready.Store(false)
	if r.stateName != RuntimeStateClosed && r.stateName != RuntimeStateClosing {
		r.stateName = RuntimeStateFailed
		transitionedFailed = true
	}
	r.mu.Unlock()
	health := r.Health()
	r.observability.recordRuntimeHealthMetrics(health)
	if transitionedFailed {
		r.observability.recordRuntimeError("start_failed")
	}
	r.observability.recordRuntimeStartFailed(ctx, err, duration)
	r.observability.recordRuntimeHealthDegraded(health, runtimePrimaryDegradedReason(health))
}

func (r *Runtime) blockStartRetry(err error) {
	if err == nil {
		return
	}
	r.mu.Lock()
	if r.stateName == RuntimeStateFailed || r.stateName == RuntimeStateStarting {
		r.startRetryBlockedErr = err
	}
	r.mu.Unlock()
}

func (r *Runtime) refreshStartupRecoveryAfterDurabilityClose(finalDurableTxID types.TxID) {
	if finalDurableTxID == 0 {
		return
	}
	r.mu.Lock()
	previousNextTxID := r.resumePlan.NextTxID
	r.mu.Unlock()
	if previousNextTxID == 0 || finalDurableTxID < previousNextTxID {
		return
	}

	// Startup owns a temporary durability worker before r.durability is
	// installed. If it durably appends migration records and a later startup
	// step fails, a same-runtime retry must resume from the new log horizon.
	state, recoveredTxID, resumePlan, recoveryReport, recoveryRegistry, err := openOrBootstrapState(r.dataDir, r.registry)
	if err != nil {
		return
	}
	state.SetObserver(r.observability)
	state.RecordMemoryUsage()

	r.mu.Lock()
	r.state = state
	r.recoveredTxID = recoveredTxID
	r.durableTxID = recoveredTxID
	r.resumePlan = resumePlan
	r.recovery = newSuccessfulRuntimeRecoveryFacts(recoveryReport)
	r.registry = recoveryRegistry
	r.mu.Unlock()
}

func (r *Runtime) recordStartReady(ctx context.Context, duration time.Duration) {
	health := r.Health()
	r.observability.recordRuntimeHealthMetrics(health)
	r.observability.recordRuntimeReady(ctx, health, duration)
	r.observability.recordRuntimeHealthDegraded(health, runtimePrimaryDegradedReason(health))
}

func (r *Runtime) recordCloseFailure(err error, duration time.Duration) {
	if err == nil {
		return
	}
	health := r.Health()
	r.observability.recordRuntimeHealthMetrics(health)
	r.observability.recordRuntimeError("close_failed")
	r.observability.recordRuntimeCloseFailed(err, duration)
	r.observability.recordRuntimeHealthDegraded(health, runtimePrimaryDegradedReason(health))
}

func (r *Runtime) recordClosed(duration time.Duration) {
	r.recordRuntimeMetrics()
	r.observability.recordRuntimeClosed(RuntimeStateClosed, duration)
}

func (r *Runtime) recordRuntimeMetrics() {
	r.observability.recordRuntimeHealthMetrics(r.Health())
}

type durabilityHandle struct {
	worker *commitlog.DurabilityWorker
}

func (h durabilityHandle) ValidateChangeset(changeset *store.Changeset) error {
	return h.worker.ValidateChangeset(changeset)
}

func (h durabilityHandle) EnqueueCommitted(txID types.TxID, changeset *store.Changeset) {
	h.worker.EnqueueCommitted(uint64(txID), changeset)
}

func (h durabilityHandle) WaitUntilDurable(txID types.TxID) <-chan types.TxID {
	return h.worker.WaitUntilDurable(txID)
}

func (h durabilityHandle) FatalError() error {
	return h.worker.FatalError()
}

// noopFanOutSender is V1-D-only internal delivery plumbing. V1-E replaces or
// wraps this with protocol-backed fan-out delivery when network serving exists.
type noopFanOutSender struct{}

func (noopFanOutSender) SendTransactionUpdateHeavy(types.ConnectionID, subscription.CallerOutcome, []subscription.SubscriptionUpdate, *subscription.EncodingMemo) error {
	return nil
}

func (noopFanOutSender) SendTransactionUpdateLight(types.ConnectionID, uint32, []subscription.SubscriptionUpdate, *subscription.EncodingMemo) error {
	return nil
}

func (noopFanOutSender) SendSubscriptionError(types.ConnectionID, subscription.SubscriptionError) error {
	return nil
}
