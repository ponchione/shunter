package executor

import (
	"testing"

	"github.com/ponchione/shunter/store"
)

func TestReducerTableIDInvocationLifetime(t *testing.T) {
	e, reg := setupExecutor()
	tx := store.NewTransaction(e.committed, reg)
	defer tx.Seal()
	db := e.newReducerDBAdapter(tx)
	if id, ok := db.TableID("players"); !ok || id != 0 {
		t.Fatalf("players=%d,%t", id, ok)
	}
	if _, ok := db.TableID("unknown"); ok {
		t.Fatal("unknown table resolved")
	}
	db.close()
	if _, ok := db.TableID("players"); ok {
		t.Fatal("lookup after close succeeded")
	}
	if _, ok := (&reducerDBAdapter{}).TableID("players"); ok {
		t.Fatal("lookup without transaction succeeded")
	}
}
