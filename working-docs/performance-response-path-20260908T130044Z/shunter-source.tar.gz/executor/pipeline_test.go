package executor

import (
	"context"
	"errors"
	"slices"
	"sync"
	"testing"
	"time"

	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/subscription"
	"github.com/ponchione/shunter/types"
)

// recorder captures the event stream produced by the post-commit pipeline
// so tests can assert ordering without timing games.
type recorder struct {
	mu     sync.Mutex
	events []string
}

func (r *recorder) add(ev string) {
	r.mu.Lock()
	r.events = append(r.events, ev)
	r.mu.Unlock()
}

func (r *recorder) snapshot() []string {
	r.mu.Lock()
	defer r.mu.Unlock()
	return slices.Clone(r.events)
}

// fakeDurability records every EnqueueCommitted call.
type fakeDurability struct {
	rec         *recorder
	txIDs       []types.TxID
	payloads    []*store.Changeset
	block       chan struct{}     // if set, EnqueueCommitted waits on it
	entered     chan struct{}     // optional test signal before blocking
	waitCh      <-chan types.TxID // optional readiness channel returned by WaitUntilDurable
	waitCalled  chan<- types.TxID // optional signal for each durability wait request
	fatalErr    error
	validateErr error
	panicOn     bool // panic when EnqueueCommitted is called
	mu          sync.Mutex
}

func (f *fakeDurability) ValidateChangeset(*store.Changeset) error { return f.validateErr }

func (f *fakeDurability) EnqueueCommitted(txID types.TxID, cs *store.Changeset) {
	if f.block != nil {
		if f.entered != nil {
			close(f.entered)
			f.entered = nil
		}
		<-f.block
	}
	if f.panicOn {
		panic("fake durability panic")
	}
	f.mu.Lock()
	f.txIDs = append(f.txIDs, txID)
	f.payloads = append(f.payloads, cs)
	f.mu.Unlock()
	f.rec.add("durability")
}

func (f *fakeDurability) WaitUntilDurable(txID types.TxID) <-chan types.TxID {
	if f.waitCalled != nil {
		f.waitCalled <- txID
	}
	if f.waitCh != nil {
		return f.waitCh
	}
	ch := make(chan types.TxID, 1)
	ch <- txID
	close(ch)
	return ch
}

func TestCreateSnapshotCommandWaitsForDurableHorizon(t *testing.T) {
	h := newPipelineHarness(t)
	durable := make(chan types.TxID, 1)
	waitCalled := make(chan types.TxID, 2)
	h.dur.waitCh = durable
	h.dur.waitCalled = waitCalled
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted || resp.TxID != 1 {
		t.Fatalf("reducer response = %+v, want committed tx 1", resp)
	}
	if got := <-waitCalled; got != 1 {
		t.Fatalf("post-commit durability wait = %d, want 1", got)
	}

	captureCalled := make(chan struct{})
	snapshotResponse := make(chan CreateSnapshotResult, 1)
	if err := h.exec.Submit(CreateSnapshotCmd{
		Capture: func(committed *store.CommittedState, txID types.TxID) error {
			if txID != 1 || committed.CommittedTxID() != 1 {
				t.Errorf("capture horizon = (%d, %d), want (1, 1)", txID, committed.CommittedTxID())
			}
			close(captureCalled)
			return nil
		},
		ResponseCh: snapshotResponse,
	}); err != nil {
		t.Fatalf("Submit snapshot: %v", err)
	}
	if got := <-waitCalled; got != 1 {
		t.Fatalf("snapshot durability wait = %d, want 1", got)
	}
	select {
	case <-captureCalled:
		t.Fatal("snapshot capture ran before durability readiness")
	default:
	}

	durable <- 1
	select {
	case result := <-snapshotResponse:
		if result.Err != nil || result.TxID != 1 {
			t.Fatalf("snapshot result = %+v, want tx 1", result)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("timeout waiting for snapshot result")
	}
	select {
	case <-captureCalled:
	default:
		t.Fatal("snapshot response arrived before capture")
	}
}

func (f *fakeDurability) FatalError() error { return f.fatalErr }

// fakeSubs records every EvalAndBroadcast call. It optionally inspects the
// view it is handed to prove the view was still live.
type fakeSubs struct {
	rec      *recorder
	txIDs    []types.TxID
	viewSaw  []store.CommittedReadView
	metas    []subscription.PostCommitMeta
	block    chan struct{}
	onEval   func(view store.CommittedReadView)
	mu       sync.Mutex
	dropped  []types.ConnectionID
	disconns []types.ConnectionID // DisconnectClient invocations, in order
	discErr  func(types.ConnectionID) error
	panicOn  bool

	hasPostCommitPlan bool
	needsBroadcast    bool
	needsView         bool
}

func (f *fakeSubs) RegisterSet(subscription.SubscriptionSetRegisterRequest, store.CommittedReadView) (subscription.SubscriptionSetRegisterResult, error) {
	return subscription.SubscriptionSetRegisterResult{}, nil
}

func (f *fakeSubs) UnregisterSet(types.ConnectionID, uint32, store.CommittedReadView) (subscription.SubscriptionSetUnregisterResult, error) {
	return subscription.SubscriptionSetUnregisterResult{}, nil
}

func (f *fakeSubs) EvalAndBroadcast(txID types.TxID, cs *store.Changeset, view store.CommittedReadView, meta subscription.PostCommitMeta) {
	f.rec.add("eval-start")
	if f.onEval != nil {
		f.onEval(view)
	}
	if f.block != nil {
		<-f.block
	}
	if f.panicOn {
		panic("fake subs panic")
	}
	f.mu.Lock()
	f.txIDs = append(f.txIDs, txID)
	f.viewSaw = append(f.viewSaw, view)
	f.metas = append(f.metas, meta)
	f.mu.Unlock()
	f.rec.add("eval-end")
}

func (f *fakeSubs) NeedsPostCommitBroadcast(*store.Changeset, subscription.PostCommitMeta) bool {
	if f.hasPostCommitPlan {
		return f.needsBroadcast
	}
	return true
}

func (f *fakeSubs) NeedsPostCommitView(*store.Changeset, subscription.PostCommitMeta) bool {
	if f.hasPostCommitPlan {
		return f.needsView
	}
	return true
}

func (f *fakeSubs) DrainDroppedClients() []types.ConnectionID {
	out := slices.Clone(f.dropped)
	f.dropped = nil
	return out
}

func (f *fakeSubs) DisconnectClient(connID types.ConnectionID) error {
	f.mu.Lock()
	f.disconns = append(f.disconns, connID)
	f.mu.Unlock()
	f.rec.add("disconnect")
	if f.discErr != nil {
		return f.discErr(connID)
	}
	return nil
}

// trackedView wraps a CommittedReadView so tests can assert when Close ran.
type trackedView struct {
	store.CommittedReadView
	rec    *recorder
	closed bool
}

func (t *trackedView) Close() {
	if !t.closed {
		t.closed = true
		t.CommittedReadView.Close()
		t.rec.add("view-close")
	}
}

// pipelineHarness builds an executor wired with fakes.
type pipelineHarness struct {
	exec *Executor
	dur  *fakeDurability
	subs *fakeSubs
	rec  *recorder
	cs   *store.CommittedState
	reg  schema.SchemaRegistry
}

func newPipelineHarness(t *testing.T) *pipelineHarness {
	t.Helper()
	b := schema.NewBuilder()
	b.SchemaVersion(1)
	b.TableDef(schema.TableDefinition{
		Name: "players",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: types.KindUint64, PrimaryKey: true},
			{Name: "name", Type: types.KindString},
		},
	})
	eng, err := b.Build(schema.EngineOptions{})
	if err != nil {
		t.Fatal(err)
	}
	reg := eng.Registry()
	cs := committedStateForRegistry(reg)

	rr := NewReducerRegistry()
	rr.Register(RegisteredReducer{
		Name: "InsertPlayer",
		Handler: types.ReducerHandler(func(ctx *types.ReducerContext, args []byte) ([]byte, error) {
			_, _ = ctx.DB.Insert(0, types.ProductValue{types.NewUint64(1), types.NewString("alice")})
			return []byte("ret"), nil
		}),
	})
	rr.Register(RegisteredReducer{
		Name: "FailReducer",
		Handler: types.ReducerHandler(func(*types.ReducerContext, []byte) ([]byte, error) {
			return nil, errTestUserFail
		}),
	})
	rr.Freeze()

	rec := &recorder{}
	dur := &fakeDurability{rec: rec}
	subs := &fakeSubs{rec: rec}
	cfg := ExecutorConfig{
		InboxCapacity: 16,
		Durability:    dur,
		Subscriptions: subs,
	}
	exec := NewExecutor(cfg, rr, cs, reg, 0)
	return &pipelineHarness{exec: exec, dur: dur, subs: subs, rec: rec, cs: cs, reg: reg}
}

var errTestUserFail = &userErr{msg: "test-user-fail"}

type userErr struct{ msg string }

func (u *userErr) Error() string { return u.msg }

func submit(t *testing.T, exec *Executor, name string) ReducerResponse {
	t.Helper()
	ch := make(chan ReducerResponse, 1)
	if err := exec.Submit(CallReducerCmd{
		Request: ReducerRequest{
			ReducerName: name,
			Source:      CallSourceExternal,
			RequestID:   77,
			Caller: types.CallerContext{
				ConnectionID: types.ConnectionID{9},
			},
		},
		ResponseCh: ch,
	}); err != nil {
		t.Fatal(err)
	}
	select {
	case resp := <-ch:
		return resp
	case <-time.After(2 * time.Second):
		t.Fatal("timeout waiting for response")
		return ReducerResponse{}
	}
}

// AC 1 + AC 5 + AC 7: durability before eval, response after eval,
// pipeline called on every successful commit.
func TestPostCommitDurabilityBeforeEvalBeforeResponse(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}
	events := h.rec.snapshot()
	want := []string{"durability", "eval-start", "eval-end"}
	if len(events) < len(want) {
		t.Fatalf("events = %v, want prefix %v", events, want)
	}
	for i, w := range want {
		if events[i] != w {
			t.Fatalf("events[%d] = %s, want %s (full=%v)", i, events[i], w, events)
		}
	}
}

func TestExecutorRejectsReducerWithoutCommitWhenDurabilityFatal(t *testing.T) {
	h := newPipelineHarness(t)
	h.dur.fatalErr = errors.New("disk failed")
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	ch := make(chan ReducerResponse, 1)
	err := h.exec.Submit(CallReducerCmd{
		Request: ReducerRequest{
			ReducerName: "InsertPlayer",
			Source:      CallSourceExternal,
		},
		ResponseCh: ch,
	})
	if !errors.Is(err, ErrExecutorFatal) {
		t.Fatalf("Submit error = %v, want ErrExecutorFatal", err)
	}
	if got := h.cs.CommittedTxID(); got != 0 {
		t.Fatalf("committed tx id = %d, want 0", got)
	}
	table, ok := h.cs.Table(0)
	if !ok {
		t.Fatal("missing players table")
	}
	if got := table.RowCount(); got != 0 {
		t.Fatalf("row count = %d, want 0", got)
	}
}

func TestExecutorRejectsDurabilityValidationBeforeCommitAndRecovers(t *testing.T) {
	h := newPipelineHarness(t)
	validationErr := errors.New("changeset exceeds durability limit")
	h.dur.validateErr = validationErr
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusFailedInternal || !errors.Is(resp.Error, validationErr) {
		t.Fatalf("rejected response = %+v, want failed internal validation error", resp)
	}
	if resp.TxID != 0 {
		t.Fatalf("rejected tx id = %d, want 0", resp.TxID)
	}
	if got := h.cs.CommittedTxID(); got != 0 {
		t.Fatalf("committed tx id after rejection = %d, want 0", got)
	}
	table, ok := h.cs.Table(0)
	if !ok {
		t.Fatal("missing players table")
	}
	if got := table.RowCount(); got != 0 {
		t.Fatalf("row count after rejection = %d, want 0", got)
	}
	if got := len(h.dur.txIDs); got != 0 {
		t.Fatalf("durability enqueues after rejection = %d, want 0", got)
	}
	if got := len(h.subs.txIDs); got != 0 {
		t.Fatalf("subscription evaluations after rejection = %d, want 0", got)
	}

	h.dur.validateErr = nil
	resp = submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted || resp.TxID != 1 {
		t.Fatalf("recovery response = %+v, want committed tx 1", resp)
	}
	if got := table.RowCount(); got != 1 {
		t.Fatalf("row count after recovery commit = %d, want 1", got)
	}
	if got := len(h.dur.txIDs); got != 1 || h.dur.txIDs[0] != 1 {
		t.Fatalf("durability tx ids after recovery = %v, want [1]", h.dur.txIDs)
	}
}

// AC 2 + AC 3 + AC 4: snapshot acquired after durability, passed to eval,
// closed after eval and before response delivery.
func TestPostCommitSnapshotLifetime(t *testing.T) {
	h := newPipelineHarness(t)
	// Track the view Close() via a wrapper injected by the snapshot hook.
	h.exec.snapshotFn = func() store.CommittedReadView {
		raw := h.cs.Snapshot()
		return &trackedView{CommittedReadView: raw, rec: h.rec}
	}
	h.subs.onEval = func(view store.CommittedReadView) {
		if view == nil {
			t.Error("EvalAndBroadcast received nil view")
			return
		}
		// Prove the view is live during eval.
		_ = view.RowCount(0)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	if got := submit(t, h.exec, "InsertPlayer"); got.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", got.Status, got.Error)
	}
	events := h.rec.snapshot()
	want := []string{"durability", "eval-start", "eval-end", "view-close"}
	if len(events) != len(want) {
		t.Fatalf("events = %v, want %v", events, want)
	}
	for i, w := range want {
		if events[i] != w {
			t.Fatalf("events[%d] = %s, want %s (full=%v)", i, events[i], w, events)
		}
	}
}

func TestPostCommitSkipsSnapshotAndEvalWhenSubscriptionsHaveNoWork(t *testing.T) {
	h := newPipelineHarness(t)
	h.subs.hasPostCommitPlan = true
	h.subs.needsBroadcast = false
	h.subs.needsView = false
	h.exec.snapshotFn = func() store.CommittedReadView {
		t.Fatal("snapshot should not be acquired when subscription post-commit work is skipped")
		return nil
	}
	changeset := &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{}}

	status := h.exec.postCommit(types.TxID(88), changeset, nil, CallReducerCmd{}, postCommitOptions{source: CallSourceLifecycle})
	if status != StatusCommitted {
		t.Fatalf("status = %d, want StatusCommitted", status)
	}
	h.subs.mu.Lock()
	got := len(h.subs.txIDs)
	h.subs.mu.Unlock()
	if got != 0 {
		t.Fatalf("EvalAndBroadcast calls = %d, want 0", got)
	}
}

func TestPostCommitCallerOnlyFanoutSkipsSnapshot(t *testing.T) {
	h := newPipelineHarness(t)
	h.subs.hasPostCommitPlan = true
	h.subs.needsBroadcast = true
	h.subs.needsView = false
	h.exec.snapshotFn = func() store.CommittedReadView {
		t.Fatal("caller-only fanout should not need a committed read view")
		return nil
	}
	connID := types.ConnectionID{9}
	changeset := &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{}}

	status := h.exec.postCommit(types.TxID(89), changeset, nil, CallReducerCmd{}, postCommitOptions{
		source:          CallSourceExternal,
		callerConnID:    &connID,
		callerRequestID: 7,
		startTime:       time.Now(),
	})
	if status != StatusCommitted {
		t.Fatalf("status = %d, want StatusCommitted", status)
	}
	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas = %d, want 1", len(h.subs.metas))
	}
	if h.subs.viewSaw[0] != nil {
		t.Fatal("caller-only EvalAndBroadcast received non-nil view")
	}
	if h.subs.metas[0].CallerOutcome == nil {
		t.Fatal("CallerOutcome = nil, want populated outcome")
	}
}

// AC 8: pipeline is called for every successful commit (once per commit),
// regardless of how many commits happen in a run.
func TestPostCommitCalledPerCommit(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	commits := 0
	for i := 0; i < 3; i++ {
		resp := submit(t, h.exec, "InsertPlayer")
		if resp.Status == StatusCommitted {
			commits++
		}
	}
	if commits == 0 {
		t.Fatal("expected at least one successful commit in harness")
	}
	h.dur.mu.Lock()
	gotDur := len(h.dur.txIDs)
	h.dur.mu.Unlock()
	h.subs.mu.Lock()
	gotSubs := len(h.subs.txIDs)
	h.subs.mu.Unlock()
	if gotDur != commits || gotSubs != commits {
		t.Fatalf("dur=%d subs=%d, commits=%d (dur/subs must equal commits)", gotDur, gotSubs, commits)
	}
}

// AC 6: durability backpressure stalls the pipeline, does not skip.
// Blocking durability → no eval-start, no response until durability returns.
func TestPostCommitDurabilityBackpressureStalls(t *testing.T) {
	h := newPipelineHarness(t)
	release := make(chan struct{})
	h.dur.block = release
	enteredDurability := make(chan struct{})
	h.dur.entered = enteredDurability
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	ch := make(chan ReducerResponse, 1)
	if err := h.exec.Submit(CallReducerCmd{
		Request: ReducerRequest{
			ReducerName: "InsertPlayer",
			Source:      CallSourceExternal,
			RequestID:   88,
			Caller:      types.CallerContext{ConnectionID: types.ConnectionID{7}},
		},
		ResponseCh: ch,
	}); err != nil {
		t.Fatal(err)
	}

	select {
	case <-enteredDurability:
	case <-time.After(2 * time.Second):
		t.Fatal("executor did not reach durability")
	}
	select {
	case r := <-ch:
		t.Fatalf("response arrived before durability unblocked: %+v", r)
	default:
	}
	if got := h.rec.snapshot(); len(got) != 0 {
		t.Fatalf("events before durability returned: %v", got)
	}

	close(release)
	select {
	case r := <-ch:
		if r.Status != StatusCommitted {
			t.Fatalf("status = %d err=%v", r.Status, r.Error)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("timeout after durability released")
	}
}

// Pipeline does not run when reducer returns a user error (no commit happened).
func TestPostCommitSkippedOnReducerUserError(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "FailReducer")
	if resp.Status != StatusFailedUser {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}
	h.dur.mu.Lock()
	gotDur := len(h.dur.txIDs)
	h.dur.mu.Unlock()
	h.subs.mu.Lock()
	gotSubs := len(h.subs.txIDs)
	h.subs.mu.Unlock()
	if gotDur != 0 || gotSubs != 0 {
		t.Fatalf("dur=%d subs=%d, want 0/0", gotDur, gotSubs)
	}
}

// Story 5.2 AC: drain happens after response, each drop → DisconnectClient,
// multiple drops drained in one pass.
func TestPostCommitDrainsDroppedClients(t *testing.T) {
	h := newPipelineHarness(t)
	h.subs.dropped = []types.ConnectionID{{1}, {2}, {3}}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}
	// Drain runs inside the executor goroutine AFTER response send but
	// BEFORE next dequeue. Issue a second command as a serial barrier —
	// by the time its response arrives, the first commit's drain is done.
	_ = submit(t, h.exec, "InsertPlayer")

	h.subs.mu.Lock()
	got := slices.Clone(h.subs.disconns)
	h.subs.mu.Unlock()
	want := []types.ConnectionID{{1}, {2}, {3}}
	if len(got) != len(want) {
		t.Fatalf("disconns=%v want=%v", got, want)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("disconns[%d]=%v want=%v", i, got[i], want[i])
		}
	}

	events := h.rec.snapshot()
	// For the first commit the sub-sequence must be eval-end then disconnect×3.
	idxEvalEnd := -1
	for i, e := range events {
		if e == "eval-end" {
			idxEvalEnd = i
			break
		}
	}
	if idxEvalEnd < 0 {
		t.Fatalf("no eval-end in events %v", events)
	}
	// The 3 disconnects must follow the first eval-end before the second eval.
	disconnCount := 0
	for _, e := range events[idxEvalEnd+1:] {
		if e == "eval-start" {
			break
		}
		if e == "disconnect" {
			disconnCount++
		}
	}
	if disconnCount != 3 {
		t.Fatalf("disconnects between first and second commit = %d, want 3 (events=%v)", disconnCount, events)
	}
}

// Story 5.2 AC: empty drain is a no-op, does not block.
func TestPostCommitDrainNoopWhenEmpty(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}
	h.subs.mu.Lock()
	n := len(h.subs.disconns)
	h.subs.mu.Unlock()
	if n != 0 {
		t.Fatalf("disconns=%d, want 0 with empty drain", n)
	}
}

// Story 5.2 design note: error from DisconnectClient does not halt further
// drains. All three disconnects must be attempted even if the first errors.
func TestPostCommitDrainContinuesAfterDisconnectError(t *testing.T) {
	h := newPipelineHarness(t)
	h.subs.dropped = []types.ConnectionID{{1}, {2}, {3}}
	h.subs.discErr = func(c types.ConnectionID) error {
		if c == (types.ConnectionID{1}) {
			return errTestDisconnect
		}
		return nil
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	_ = submit(t, h.exec, "InsertPlayer")
	_ = submit(t, h.exec, "InsertPlayer") // serial barrier

	h.subs.mu.Lock()
	gotN := len(h.subs.disconns)
	h.subs.mu.Unlock()
	if gotN != 3 {
		t.Fatalf("disconns=%d, want 3 (errors must not halt drain)", gotN)
	}
}

var errTestDisconnect = &userErr{msg: "disconnect-failed"}

func TestPostCommitExternalReducerPropagatesCallerMetadata(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}

	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas=%d want 1", len(h.subs.metas))
	}
	meta := h.subs.metas[0]
	if meta.CallerConnID == nil || *meta.CallerConnID != (types.ConnectionID{9}) {
		t.Fatalf("CallerConnID=%v want %v", meta.CallerConnID, types.ConnectionID{9})
	}
	if meta.CallerOutcome == nil {
		t.Fatal("CallerOutcome = nil, want populated outcome")
	}
	if meta.CallerOutcome.RequestID != 77 {
		t.Fatalf("CallerOutcome.RequestID=%d want 77", meta.CallerOutcome.RequestID)
	}
	if meta.CallerOutcome.Kind != subscription.CallerOutcomeCommitted {
		t.Fatalf("CallerOutcome.Kind=%d want CallerOutcomeCommitted", meta.CallerOutcome.Kind)
	}
	_ = resp
}

func TestPostCommitExternalReducerZeroConnectionDoesNotExportCallerFanout(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	ch := make(chan ReducerResponse, 1)
	if err := h.exec.Submit(CallReducerCmd{
		Request: ReducerRequest{
			ReducerName: "InsertPlayer",
			Source:      CallSourceExternal,
			RequestID:   77,
		},
		ResponseCh: ch,
	}); err != nil {
		t.Fatal(err)
	}
	var resp ReducerResponse
	select {
	case resp = <-ch:
	case <-time.After(2 * time.Second):
		t.Fatal("timeout waiting for response")
	}
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}

	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas=%d want 1", len(h.subs.metas))
	}
	meta := h.subs.metas[0]
	if meta.CallerConnID != nil || meta.CallerOutcome != nil {
		t.Fatalf("zero connection should not produce caller fanout metadata: %+v", meta)
	}
}

// TestPostCommitPropagatesCallerFlags pins the outcome-model contract:
// an external reducer call carrying CallReducerFlags::NoSuccessNotify
// (byte = 1) must surface that flag on CallerOutcome.Flags so the
// fan-out worker can skip the caller's heavy echo on successful commits.
func TestPostCommitPropagatesCallerFlags(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	ch := make(chan ReducerResponse, 1)
	if err := h.exec.Submit(CallReducerCmd{
		Request: ReducerRequest{
			ReducerName: "InsertPlayer",
			Source:      CallSourceExternal,
			RequestID:   88,
			Flags:       1, // CallReducerFlagsNoSuccessNotify
			Caller:      types.CallerContext{ConnectionID: types.ConnectionID{9}},
		},
		ResponseCh: ch,
	}); err != nil {
		t.Fatal(err)
	}
	resp := <-ch
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}

	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas=%d want 1", len(h.subs.metas))
	}
	meta := h.subs.metas[0]
	if meta.CallerOutcome == nil {
		t.Fatal("CallerOutcome = nil")
	}
	if meta.CallerOutcome.Flags != 1 {
		t.Fatalf("CallerOutcome.Flags=%d want 1 (NoSuccessNotify)", meta.CallerOutcome.Flags)
	}
}

func TestPostCommit_ProtocolRepliesUseOrderedCallerFanout(t *testing.T) {
	for _, flags := range []byte{subscription.CallerOutcomeFlagFullUpdate, subscription.CallerOutcomeFlagDurableSuccess} {
		h := newPipelineHarness(t)
		h.dur.waitCh = make(chan types.TxID)
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		go h.exec.Run(ctx)

		respCh := make(chan ProtocolCallReducerResponse, 1)
		if err := h.exec.Submit(CallReducerCmd{
			Request: ReducerRequest{
				ReducerName: "InsertPlayer",
				Source:      CallSourceExternal,
				RequestID:   90,
				Flags:       flags,
				Caller:      types.CallerContext{ConnectionID: types.ConnectionID{9}},
			},
			ProtocolResponseCh: respCh,
		}); err != nil {
			t.Fatal(err)
		}
		var resp ProtocolCallReducerResponse
		select {
		case resp = <-respCh:
		case <-time.After(time.Second):
			t.Fatal("executor blocked on durability")
		}
		if !resp.FanoutOwned {
			t.Fatal("protocol reply must be owned by fanout")
		}

		h.subs.mu.Lock()
		defer h.subs.mu.Unlock()
		if len(h.subs.metas) != 1 {
			t.Fatalf("metas=%d want 1", len(h.subs.metas))
		}
		meta := h.subs.metas[0]
		if meta.CallerConnID == nil {
			t.Fatal("CallerConnID = nil")
		}
		if meta.CallerOutcome == nil || meta.CallerOutcome.RequestID != 90 || !meta.CallerOutcome.FastReply || meta.CallerOutcome.Flags != flags || meta.TxDurable != h.dur.waitCh {
			t.Fatalf("CallerOutcome = %+v, want ordered fast reply for request 90", meta.CallerOutcome)
		}
	}
}

func TestPostCommitLifecycleLeavesCallerMetadataNil(t *testing.T) {
	h := newPipelineHarness(t)
	changeset := &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{}}
	h.exec.postCommit(types.TxID(55), changeset, nil, CallReducerCmd{}, postCommitOptions{source: CallSourceLifecycle})

	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas=%d want 1", len(h.subs.metas))
	}
	meta := h.subs.metas[0]
	if meta.CallerConnID != nil || meta.CallerOutcome != nil {
		t.Fatalf("lifecycle meta should not fabricate caller fields: %+v", meta)
	}
}

func TestPostCommitPropagatesDurabilityReadinessChannel(t *testing.T) {
	h := newPipelineHarness(t)
	waitCh := make(chan types.TxID)
	h.dur.waitCh = waitCh
	changeset := &store.Changeset{Tables: map[schema.TableID]*store.TableChangeset{}}
	h.exec.postCommit(types.TxID(66), changeset, nil, CallReducerCmd{}, postCommitOptions{source: CallSourceLifecycle})

	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas=%d want 1", len(h.subs.metas))
	}
	if h.subs.metas[0].TxDurable != waitCh {
		t.Fatal("TxDurable channel was not propagated from durability handle")
	}
}

func TestPostCommitResponseDoesNotWaitForDurabilityReadiness(t *testing.T) {
	h := newPipelineHarness(t)
	waitCh := make(chan types.TxID)
	h.dur.waitCh = waitCh
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	respCh := make(chan ReducerResponse, 1)
	if err := h.exec.Submit(CallReducerCmd{
		Request: ReducerRequest{
			ReducerName: "InsertPlayer",
			Source:      CallSourceExternal,
		},
		ResponseCh: respCh,
	}); err != nil {
		t.Fatal(err)
	}

	select {
	case resp := <-respCh:
		if resp.Status != StatusCommitted {
			t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("response waited for durability readiness channel")
	}

	h.subs.mu.Lock()
	defer h.subs.mu.Unlock()
	if len(h.subs.metas) != 1 {
		t.Fatalf("metas=%d want 1", len(h.subs.metas))
	}
	if h.subs.metas[0].TxDurable != waitCh {
		t.Fatal("TxDurable channel was not propagated while response remained non-durable")
	}
}

// Story 5.3 AC: panic in EnqueueCommitted sets fatal and delivers an error
// response (transaction already committed in memory but pipeline broke).
func TestPostCommitPanicInDurabilitySetsFatal(t *testing.T) {
	h := newPipelineHarness(t)
	h.dur.panicOn = true
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusFailedInternal {
		t.Fatalf("status=%d, want StatusFailedInternal", resp.Status)
	}
	if !errors.Is(resp.Error, ErrExecutorFatal) {
		t.Fatalf("err=%v, want wraps ErrExecutorFatal", resp.Error)
	}
	if !h.exec.fatal.Load() {
		t.Fatal("executor.fatal not set after post-commit panic")
	}
}

// Story 5.3 AC: panic in EvalAndBroadcast sets fatal and closes the
// post-commit snapshot acquired for evaluation.
func TestPostCommitPanicInEvalSetsFatal(t *testing.T) {
	h := newPipelineHarness(t)
	h.exec.snapshotFn = func() store.CommittedReadView {
		raw := h.cs.Snapshot()
		return &trackedView{CommittedReadView: raw, rec: h.rec}
	}
	h.subs.panicOn = true
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusFailedInternal {
		t.Fatalf("status=%d, want StatusFailedInternal", resp.Status)
	}
	if !errors.Is(resp.Error, ErrExecutorFatal) {
		t.Fatalf("err=%v, want wraps ErrExecutorFatal", resp.Error)
	}
	if !h.exec.fatal.Load() {
		t.Fatal("executor.fatal not set after eval panic")
	}
	events := h.rec.snapshot()
	want := []string{"durability", "eval-start", "view-close"}
	if len(events) != len(want) {
		t.Fatalf("events=%v, want %v", events, want)
	}
	for i, w := range want {
		if events[i] != w {
			t.Fatalf("events[%d]=%s, want %s (full=%v)", i, events[i], w, events)
		}
	}
}

// Story 5.3 AC: panic during snapshot acquisition sets fatal.
func TestPostCommitPanicInSnapshotSetsFatal(t *testing.T) {
	h := newPipelineHarness(t)
	h.exec.snapshotFn = func() store.CommittedReadView { panic("snapshot boom") }
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusFailedInternal {
		t.Fatalf("status=%d, want StatusFailedInternal", resp.Status)
	}
	if !errors.Is(resp.Error, ErrExecutorFatal) {
		t.Fatalf("err=%v, want wraps ErrExecutorFatal", resp.Error)
	}
	if !h.exec.fatal.Load() {
		t.Fatal("executor.fatal not set after snapshot panic")
	}
}

// Story 5.3 AC: after fatal, Submit of a write-affecting command returns
// ErrExecutorFatal without even enqueueing.
func TestPostCommitSubmitAfterFatalRejected(t *testing.T) {
	h := newPipelineHarness(t)
	h.dur.panicOn = true
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	_ = submit(t, h.exec, "InsertPlayer") // triggers fatal

	ch := make(chan ReducerResponse, 1)
	err := h.exec.Submit(CallReducerCmd{
		Request:    ReducerRequest{ReducerName: "InsertPlayer", Source: CallSourceExternal},
		ResponseCh: ch,
	})
	if !errors.Is(err, ErrExecutorFatal) {
		t.Fatalf("Submit err=%v, want ErrExecutorFatal", err)
	}
}

// Story 5.3 AC: commands already in-flight when fatal transitions must
// receive ErrExecutorFatal rather than executing.
func TestPostCommitInFlightCommandGetsFatalResponse(t *testing.T) {
	h := newPipelineHarness(t)
	// Block durability so the first commit pauses inside postCommit; the
	// second command reaches the inbox before fatal triggers.
	release := make(chan struct{})
	h.dur.block = release
	enteredDurability := make(chan struct{})
	h.dur.entered = enteredDurability
	h.dur.panicOn = true

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	ch1 := make(chan ReducerResponse, 1)
	if err := h.exec.Submit(CallReducerCmd{
		Request:    ReducerRequest{ReducerName: "InsertPlayer", Source: CallSourceExternal},
		ResponseCh: ch1,
	}); err != nil {
		t.Fatal(err)
	}
	ch2 := make(chan ReducerResponse, 1)
	if err := h.exec.Submit(CallReducerCmd{
		Request:    ReducerRequest{ReducerName: "InsertPlayer", Source: CallSourceExternal},
		ResponseCh: ch2,
	}); err != nil {
		t.Fatal(err)
	}
	registerErr := make(chan error, 1)
	if err := h.exec.Submit(RegisterSubscriptionSetCmd{
		Request: subscription.SubscriptionSetRegisterRequest{
			ConnID:     types.ConnectionID{1},
			QueryID:    10,
			Predicates: []subscription.Predicate{subscription.AllRows{Table: 0}},
		},
		Reply: func(_ subscription.SubscriptionSetRegisterResult, err error) {
			registerErr <- err
		},
	}); err != nil {
		t.Fatal(err)
	}
	unregisterErr := make(chan error, 1)
	if err := h.exec.Submit(UnregisterSubscriptionSetCmd{
		ConnID:  types.ConnectionID{1},
		QueryID: 10,
		Reply: func(_ subscription.SubscriptionSetUnregisterResult, err error) {
			unregisterErr <- err
		},
	}); err != nil {
		t.Fatal(err)
	}
	disconnectErr := make(chan error, 1)
	if err := h.exec.Submit(DisconnectClientSubscriptionsCmd{
		ConnID:     types.ConnectionID{1},
		ResponseCh: disconnectErr,
	}); err != nil {
		t.Fatal(err)
	}

	go h.exec.Run(ctx)
	select {
	case <-enteredDurability:
	case <-time.After(2 * time.Second):
		t.Fatal("first command did not reach postCommit durability")
	}
	close(release)

	select {
	case r := <-ch1:
		if r.Status != StatusFailedInternal || !errors.Is(r.Error, ErrExecutorFatal) {
			t.Fatalf("ch1 resp=%+v, want fatal internal", r)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("ch1 timeout")
	}
	select {
	case r := <-ch2:
		if r.Status != StatusFailedInternal || !errors.Is(r.Error, ErrExecutorFatal) {
			t.Fatalf("ch2 resp=%+v, want in-flight fatal response", r)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("ch2 timeout")
	}
	expectFatalError(t, "register", registerErr)
	expectFatalError(t, "unregister", unregisterErr)
	select {
	case err := <-disconnectErr:
		if err != nil {
			t.Fatalf("disconnect err=%v, want terminal cleanup admitted", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("disconnect timeout")
	}
	h.subs.mu.Lock()
	disconns := slices.Clone(h.subs.disconns)
	h.subs.mu.Unlock()
	if len(disconns) != 1 || disconns[0] != (types.ConnectionID{1}) {
		t.Fatalf("disconnect calls=%v, want connection 01 cleanup", disconns)
	}
}

func expectFatalError(t *testing.T, label string, ch <-chan error) {
	t.Helper()
	select {
	case err := <-ch:
		if !errors.Is(err, ErrExecutorFatal) {
			t.Fatalf("%s err=%v, want ErrExecutorFatal", label, err)
		}
	case <-time.After(2 * time.Second):
		t.Fatalf("%s timeout", label)
	}
}

// Story 5.3 AC: pre-commit reducer panic is NOT a post-commit fatal. Story 4.4
// rules apply (StatusFailedPanic, executor continues).
func TestReducerPanicDoesNotSetFatal(t *testing.T) {
	h := newPipelineHarness(t)
	rr := NewReducerRegistry()
	rr.Register(RegisteredReducer{
		Name: "BoomReducer",
		Handler: types.ReducerHandler(func(*types.ReducerContext, []byte) ([]byte, error) {
			panic("reducer boom")
		}),
	})
	rr.Freeze()
	// Swap the registry on the harness executor. Simpler: rebuild with fresh
	// reducer set.
	cs := committedStateForRegistry(h.reg)
	exec := NewExecutor(ExecutorConfig{
		InboxCapacity: 8,
		Durability:    h.dur,
		Subscriptions: h.subs,
	}, rr, cs, h.reg, 0)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go exec.Run(ctx)

	resp := submit(t, exec, "BoomReducer")
	if resp.Status != StatusFailedPanic {
		t.Fatalf("status=%d, want StatusFailedPanic", resp.Status)
	}
	if exec.fatal.Load() {
		t.Fatal("executor.fatal should NOT be set for pre-commit reducer panic")
	}
	// Further calls still work.
	rr2 := NewReducerRegistry()
	rr2.Register(RegisteredReducer{
		Name: "InsertPlayer",
		Handler: types.ReducerHandler(func(ctx *types.ReducerContext, _ []byte) ([]byte, error) {
			return nil, nil
		}),
	})
	rr2.Freeze()
	_ = rr2 // not used further; the check above already proves non-fatal state.
}

// TxID carried by changeset is the TxID handed to durability and subs.
func TestPostCommitTxIDPropagation(t *testing.T) {
	h := newPipelineHarness(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.exec.Run(ctx)

	resp := submit(t, h.exec, "InsertPlayer")
	if resp.Status != StatusCommitted {
		t.Fatalf("status = %d err=%v", resp.Status, resp.Error)
	}
	h.dur.mu.Lock()
	durTxs := slices.Clone(h.dur.txIDs)
	durPayloads := slices.Clone(h.dur.payloads)
	h.dur.mu.Unlock()
	h.subs.mu.Lock()
	subsTxs := slices.Clone(h.subs.txIDs)
	h.subs.mu.Unlock()

	if len(durTxs) != 1 || durTxs[0] != resp.TxID {
		t.Fatalf("durability txIDs = %v, resp.TxID = %d", durTxs, resp.TxID)
	}
	if len(subsTxs) != 1 || subsTxs[0] != resp.TxID {
		t.Fatalf("subs txIDs = %v, resp.TxID = %d", subsTxs, resp.TxID)
	}
	if len(durPayloads) != 1 || durPayloads[0].TxID != resp.TxID {
		t.Fatalf("durability changeset TxID = %v, want %d", durPayloads, resp.TxID)
	}
}
