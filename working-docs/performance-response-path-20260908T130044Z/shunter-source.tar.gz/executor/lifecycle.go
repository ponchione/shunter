package executor

import (
	"context"
	"fmt"
	"time"

	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/types"
)

// handleOnConnect inserts sys_clients, runs OnConnect when registered, and
// commits only on success.
func (e *Executor) handleOnConnect(cmd OnConnectCmd) string {
	sysID, ok := e.sysClientsTableID()
	if !ok {
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, fmt.Errorf("sys_clients table missing"))
		return "internal_error"
	}

	tx := store.NewTransaction(e.committed, e.schemaReg)
	row := types.ProductValue{
		types.NewBytes(cmd.ConnID[:]),
		types.NewBytes(cmd.Identity[:]),
		types.NewInt64(time.Now().UnixNano()),
	}
	if _, err := tx.Insert(sysID, row); err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, fmt.Errorf("sys_clients insert: %w", err))
		return "internal_error"
	}

	if rr, hasReducer := e.registry.LookupLifecycle(LifecycleOnConnect); hasReducer {
		status, err := e.runLifecycleReducer(rr, tx, cmd.ConnID, cmd.Identity, cmd.Principal)
		if status != StatusCommitted {
			store.Rollback(tx)
			respondLifecycle(cmd.ResponseCh, status, 0, err)
			return executorCommandResultFromStatus(status)
		}
	}

	if err := e.latchDurabilityFatal(0); err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, err)
		return "internal_error"
	}
	txID, err := e.nextCommitTxID()
	if err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, err)
		return "internal_error"
	}
	tx.Seal()
	changeset, err := e.commitTransaction(tx, txID)
	if err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, fmt.Errorf("commit: %w", err))
		return "internal_error"
	}
	e.consumeCommitTxID()

	return executorCommandResultFromStatus(e.postCommit(txID, changeset, nil, CallReducerCmd{ResponseCh: cmd.ResponseCh}, postCommitOptions{source: CallSourceLifecycle}))
}

// handleOnDisconnect runs OnDisconnect when registered and always removes the
// sys_clients row.
func (e *Executor) handleOnDisconnect(cmd OnDisconnectCmd) string {
	sysID, ok := e.sysClientsTableID()
	if !ok {
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, fmt.Errorf("sys_clients table missing"))
		return "internal_error"
	}

	tx := store.NewTransaction(e.committed, e.schemaReg)
	reducerStatus := StatusCommitted
	if rr, hasReducer := e.registry.LookupLifecycle(LifecycleOnDisconnect); hasReducer {
		reducerStatus, _ = e.runLifecycleReducer(rr, tx, cmd.ConnID, cmd.Identity, cmd.Principal)
	}

	if reducerStatus != StatusCommitted {
		store.Rollback(tx)
		// Fresh cleanup transaction that only removes the sys_clients row.
		tx = store.NewTransaction(e.committed, e.schemaReg)
	}

	if err := deleteSysClientsRow(tx, sysID, cmd.ConnID); err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, fmt.Errorf("sys_clients delete: %w", err))
		return "internal_error"
	}

	// Fatal state rejects ordinary writes, but disconnect cleanup is terminal
	// maintenance: make the sys_clients delete visible in memory even when the
	// durability pipeline is already unhealthy. Preserve the fatal condition
	// so it can be reported after the cleanup commit is attempted.
	fatalErr := e.latchDurabilityFatal(0)
	if fatalErr == nil && e.fatal.Load() {
		fatalErr = ErrExecutorFatal
	}
	txID, err := e.nextCommitTxID()
	if err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, err)
		return "internal_error"
	}
	tx.Seal()
	changeset, err := e.commitTransaction(tx, txID)
	if err != nil {
		store.Rollback(tx)
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, 0, fmt.Errorf("commit: %w", err))
		return "internal_error"
	}
	e.consumeCommitTxID()

	// Even when the reducer failed, the cleanup commit still runs the
	// post-commit pipeline so subscribers see the sys_clients delete. Lifecycle
	// response delivery is deferred until afterward so a pre-existing fatal
	// condition cannot be mistaken for a successful durable cleanup.
	status := e.postCommit(txID, changeset, nil, CallReducerCmd{}, postCommitOptions{source: CallSourceLifecycle})
	if status != StatusCommitted {
		if fatalErr == nil {
			fatalErr = fmt.Errorf("%w: OnDisconnect cleanup post-commit failed", ErrExecutorFatal)
		}
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, txID, fatalErr)
		return "internal_error"
	}
	if fatalErr != nil {
		respondLifecycle(cmd.ResponseCh, StatusFailedInternal, txID, fatalErr)
		return "internal_error"
	}
	respondLifecycle(cmd.ResponseCh, StatusCommitted, txID, nil)
	return "ok"
}

// sweepDanglingClients deletes recovered sys_clients rows without running
// OnDisconnect. A fatal post-commit error stops the sweep.
func (e *Executor) sweepDanglingClients(ctx context.Context) error {
	sysID, ok := e.sysClientsTableID()
	if !ok {
		return fmt.Errorf("sys_clients table missing")
	}

	type sysClientsTarget struct {
		conn     types.ConnectionID
		identity types.Identity
	}

	var targets []sysClientsTarget
	view := e.committed.Snapshot()
	for _, row := range view.TableScan(sysID) {
		if int(SysClientsColIdentity) >= len(row) {
			continue
		}
		var t sysClientsTarget
		copy(t.conn[:], row[SysClientsColConnectionID].BytesView())
		copy(t.identity[:], row[SysClientsColIdentity].BytesView())
		targets = append(targets, t)
	}
	view.Close()

	for _, t := range targets {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := e.latchDurabilityFatal(0); err != nil {
			return err
		}
		tx := store.NewTransaction(e.committed, e.schemaReg)
		if err := deleteSysClientsRow(tx, sysID, t.conn); err != nil {
			store.Rollback(tx)
			return fmt.Errorf("sweep sys_clients delete conn=%x: %w", t.conn[:], err)
		}
		txID, err := e.nextCommitTxID()
		if err != nil {
			store.Rollback(tx)
			return err
		}
		tx.Seal()
		changeset, err := e.commitTransaction(tx, txID)
		if err != nil {
			store.Rollback(tx)
			return fmt.Errorf("sweep commit conn=%x: %w", t.conn[:], err)
		}
		e.consumeCommitTxID()
		e.postCommit(txID, changeset, nil, CallReducerCmd{}, postCommitOptions{source: CallSourceLifecycle})
		if e.fatal.Load() {
			return fmt.Errorf("sweep aborted: %w", ErrExecutorFatal)
		}
	}
	return nil
}

// runLifecycleReducer invokes a lifecycle reducer with panic recovery and
// returns the outcome status plus the underlying error (if any). The caller
// decides how to integrate the result into the surrounding pipeline.
func (e *Executor) runLifecycleReducer(
	rr *RegisteredReducer,
	tx *store.Transaction,
	conn types.ConnectionID,
	identity types.Identity,
	principal types.AuthPrincipal,
) (ReducerStatus, error) {
	caller := types.CallerContext{
		Identity:     identity,
		ConnectionID: conn,
		Principal:    principal.Copy(),
		Timestamp:    time.Now().UTC(),
	}
	db := e.newReducerDBAdapter(tx)
	scheduler := e.newSchedulerHandle(tx)
	rctx := &types.ReducerContext{
		ReducerName: rr.Name,
		Caller:      caller,
		DB:          db,
		Scheduler:   scheduler,
	}

	var reducerErr error
	var panicked any
	var panicStack string
	handlerStart := time.Now()
	func() {
		defer func() {
			if r := recover(); r != nil {
				panicked = r
				panicStack = capturePanicStack(e.observer)
			}
		}()
		_, reducerErr = rr.Handler(rctx, nil)
	}()
	handlerDuration := time.Since(handlerStart)
	db.close()
	scheduler.close()

	switch {
	case panicked != nil:
		err := fmt.Errorf("%v: %w", panicked, ErrReducerPanic)
		e.recordReducerPanic(rr.Name, err, 0, panicStack)
		e.recordLifecycleReducerFailed(rr.Name, "panic", err)
		e.recordReducerMetric(rr.Name, "failed_panic", handlerDuration, true)
		return StatusFailedPanic, err
	case reducerErr != nil:
		e.recordLifecycleReducerFailed(rr.Name, "user_error", reducerErr)
		e.recordReducerMetric(rr.Name, "failed_user", handlerDuration, true)
		return StatusFailedUser, reducerErr
	default:
		e.recordReducerMetric(rr.Name, "committed", handlerDuration, true)
		return StatusCommitted, nil
	}
}

// deleteSysClientsRow removes the row for this connection if present. It is
// not an error for the row to be absent — the disconnect path must tolerate
// the case where OnConnect never successfully inserted (e.g. auth failure
// followed by a belt-and-suspenders disconnect from the protocol layer).
func deleteSysClientsRow(tx *store.Transaction, sysID schema.TableID, conn types.ConnectionID) error {
	_, err := deleteSystemTableRowByPrimaryKey(tx, sysID, types.NewBytes(conn[:]))
	return err
}

// sysClientsTableID resolves the sys_clients TableID via the executor's
// schema registry. It is resolved per-call rather than cached because the
// executor may be constructed without a call through schema.Build in unit
// tests; a false return indicates a harness error.
func (e *Executor) sysClientsTableID() (schema.TableID, bool) {
	ts, ok := SysClientsTable(e.schemaReg)
	if !ok {
		return 0, false
	}
	return ts.ID, true
}

// respondLifecycle delivers a lifecycle-command response on the optional
// ResponseCh. Lifecycle commands may be fire-and-forget (nil channel).
func respondLifecycle(ch chan<- ReducerResponse, status ReducerStatus, txID types.TxID, err error) {
	sendResponse(ch, ReducerResponse{Status: status, Error: err, TxID: txID})
}
