package executor

import (
	"context"
	"time"

	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/subscription"
	"github.com/ponchione/shunter/types"
)

// ExecutorCommand is the interface for all executor inbox commands.
type ExecutorCommand interface {
	isExecutorCommand()
}

// CallReducerCmd requests a reducer invocation.
// Non-nil reply channels receive at most one nonblocking response before the
// next command.
type CallReducerCmd struct {
	Request            ReducerRequest
	ResponseCh         chan<- ReducerResponse
	ProtocolResponseCh chan<- ProtocolCallReducerResponse
	// SuppressCallerOutcome keeps an externally authorized reducer call from
	// synthesizing a direct CallReducer result. Procedures use this while still
	// allowing ordinary light subscription delivery to their caller.
	SuppressCallerOutcome bool
}

func (CallReducerCmd) isExecutorCommand() {}

// ProtocolCallReducerResponse complements ReducerResponse for the protocol
// adapter path. FanoutOwned means the ordered fan-out path owns the caller
// response, including success suppression; the adapter must not send a reply.
type ProtocolCallReducerResponse struct {
	Reducer     ReducerResponse
	FanoutOwned bool
}

// RegisterSubscriptionSetCmd atomically registers a subscription set.
// Reply runs synchronously on the executor goroutine before the next command.
type RegisterSubscriptionSetCmd struct {
	Request subscription.SubscriptionSetRegisterRequest
	Reply   func(subscription.SubscriptionSetRegisterResult, error)
	// ReplyWithError is the delivery-aware form of Reply. When registration
	// succeeds but this callback reports a delivery failure, the executor
	// removes the newly published set before dequeuing another command. Only
	// one of Reply or ReplyWithError should be set.
	ReplyWithError func(subscription.SubscriptionSetRegisterResult, error) error
	// Receipt is the protocol-handler receipt timestamp. When non-zero the
	// executor computes `TotalHostExecutionDurationMicros` as
	// `time.Since(Receipt)` at reply time so the wire duration reflects the
	// full admission path rather than only the subs-manager call.
	Receipt time.Time
}

func (RegisterSubscriptionSetCmd) isExecutorCommand() {}

// UnregisterSubscriptionSetCmd removes every subscription under one
// (ConnID, QueryID) key.
type UnregisterSubscriptionSetCmd struct {
	ConnID  types.ConnectionID
	QueryID uint32
	Reply   func(subscription.SubscriptionSetUnregisterResult, error)
	Context context.Context
	// Receipt mirrors RegisterSubscriptionSetCmd.Receipt for the unsubscribe
	// admission path.
	Receipt time.Time
}

func (UnregisterSubscriptionSetCmd) isExecutorCommand() {}

// DisconnectClientSubscriptionsCmd removes all subscriptions for one client.
//
// ResponseCh follows the same executor-owned reply contract as CallReducerCmd:
// public Submit/SubmitWithContext calls reject unbuffered channels, while
// commands admitted to the inbox use best-effort nonblocking reply sends.
type DisconnectClientSubscriptionsCmd struct {
	ConnID     types.ConnectionID
	ResponseCh chan<- error
}

func (DisconnectClientSubscriptionsCmd) isExecutorCommand() {}

// OnConnectCmd is an internal command delivered by the protocol layer when a
// client connection is being admitted (SPEC-003 §10.3). It inserts the
// `sys_clients` row and runs the optional OnConnect lifecycle reducer inside
// a single transaction. A failed reducer rolls back the entire transaction.
// ResponseCh follows the same Submit-time rejection / in-inbox nonblocking
// send contract as CallReducerCmd.
type OnConnectCmd struct {
	ConnID     types.ConnectionID
	Identity   types.Identity
	Principal  types.AuthPrincipal
	ResponseCh chan<- ReducerResponse
}

func (OnConnectCmd) isExecutorCommand() {}

// OnDisconnectCmd is an internal command delivered by the protocol layer after
// the client is considered gone (SPEC-003 §10.4). Disconnect cannot be
// vetoed: if the OnDisconnect reducer fails, a cleanup transaction still
// deletes the `sys_clients` row. ResponseCh follows the same Submit-time
// rejection / in-inbox nonblocking send contract as CallReducerCmd.
type OnDisconnectCmd struct {
	ConnID     types.ConnectionID
	Identity   types.Identity
	Principal  types.AuthPrincipal
	ResponseCh chan<- ReducerResponse
}

func (OnDisconnectCmd) isExecutorCommand() {}

// CreateSnapshotCmd establishes a serialized maintenance point. The executor
// waits for the current committed horizon to become durable before invoking
// Capture and does not begin a later command until Capture returns.
// Capture should detach state only; the submitter owns subsequent publication.
type CreateSnapshotCmd struct {
	Capture    func(*store.CommittedState, types.TxID) error
	ResponseCh chan<- CreateSnapshotResult
}

func (CreateSnapshotCmd) isExecutorCommand() {}

// CreateSnapshotResult reports the durable transaction horizon captured at the
// maintenance point, or the error that prevented capture. Publication is separate.
type CreateSnapshotResult struct {
	TxID types.TxID
	Err  error
}
