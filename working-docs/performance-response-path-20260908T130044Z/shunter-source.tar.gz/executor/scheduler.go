package executor

import (
	"context"
	"fmt"
	"math"
	"sync"
	"time"

	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/store"
	"github.com/ponchione/shunter/types"
)

// maxScheduleID scans sys_scheduled for the largest schedule_id value.
// Used by NewExecutor to seed the schedule-sequence counter above any
// schedule_id that survived from a prior process (Story 6.5). Returns
// 0 when the table is empty.
func maxScheduleID(cs *store.CommittedState, tableID schema.TableID) ScheduleID {
	view := cs.Snapshot()
	defer view.Close()
	var maxID ScheduleID
	for _, row := range view.TableScan(tableID) {
		if id := ScheduleID(row[SysScheduledColScheduleID].AsUint64()); id > maxID {
			maxID = id
		}
	}
	return maxID
}

// advanceOrDeleteSchedule updates the due schedule row in the reducer commit.
// A missing row is allowed when Cancel races an already-queued firing.
func (e *Executor) advanceOrDeleteSchedule(tx *store.Transaction, id ScheduleID, intendedNs int64) error {
	rowID, row, found := systemTableRowByPrimaryKey(tx, e.schedTableID, types.NewUint64(uint64(id)))
	if !found {
		return nil
	}
	repeatNs := row[SysScheduledColRepeatNs].AsInt64()
	if repeatNs == 0 {
		return tx.Delete(e.schedTableID, rowID)
	}
	nextRunAtNs, ok := nextScheduleRepeatRunAt(intendedNs, repeatNs)
	if !ok {
		return tx.Delete(e.schedTableID, rowID)
	}
	newRow := row.Copy()
	newRow[SysScheduledColNextRunAtNs] = types.NewInt64(nextRunAtNs)
	_, err := tx.Update(e.schedTableID, rowID, newRow)
	return err
}

// SchedulerFor returns a Scheduler wired to this executor.
// Callers own Scheduler.Run and must stop it before Executor.Shutdown.
func (e *Executor) SchedulerFor() *Scheduler {
	scheduler := NewScheduler(e.inbox, e.committed, e.schedTableID)
	e.attachScheduler(scheduler)
	return scheduler
}

func (e *Executor) attachScheduler(scheduler *Scheduler) {
	e.schedulerNotify = scheduler.Notify
	e.schedulerAttemptComplete = scheduler.completeInFlight
}

// newSchedulerHandle builds a fresh SchedulerHandle bound to a reducer's
// transaction. Each reducer call gets its own handle so that mutations
// on sys_scheduled roll back with the reducer.
func (e *Executor) newSchedulerHandle(tx *store.Transaction) *schedulerHandle {
	return &schedulerHandle{
		tx:      tx,
		tableID: e.schedTableID,
		seq:     e.schedSeq,
		reg:     e.registry,
	}
}

// schedulerHandle mutates sys_scheduled through the active reducer transaction.
type schedulerHandle struct {
	mu      sync.Mutex
	closed  bool
	tx      *store.Transaction
	tableID schema.TableID
	seq     *store.Sequence
	reg     *ReducerRegistry
}

func (h *schedulerHandle) close() {
	h.mu.Lock()
	h.closed = true
	h.mu.Unlock()
}

func (h *schedulerHandle) checkOpenLocked() error {
	if h.closed || h.tx == nil {
		return store.ErrTransactionClosed
	}
	return nil
}

// Schedule inserts a one-shot scheduled-reducer row into sys_scheduled.
func (h *schedulerHandle) Schedule(reducerName string, args []byte, at time.Time) (ScheduleID, error) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if err := h.checkOpenLocked(); err != nil {
		return 0, err
	}
	nextRunAtNs, ok := unixNanoWithinScheduleRange(at)
	if !ok {
		return 0, ErrInvalidScheduleTime
	}
	return h.insertScheduleLocked(reducerName, args, nextRunAtNs, 0)
}

// ScheduleRepeat inserts a repeating scheduled-reducer row. The first
// fire is one interval from now; subsequent fires advance by
// interval.Nanoseconds() using fixed-rate semantics (Story 6.4, §9.5).
func (h *schedulerHandle) ScheduleRepeat(reducerName string, args []byte, interval time.Duration) (ScheduleID, error) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if err := h.checkOpenLocked(); err != nil {
		return 0, err
	}
	repeatNs := interval.Nanoseconds()
	if repeatNs <= 0 {
		return 0, ErrInvalidScheduleInterval
	}
	nowNs := time.Now().UnixNano()
	first, ok := nextScheduleRepeatRunAt(nowNs, repeatNs)
	if !ok {
		return 0, ErrInvalidScheduleTime
	}
	return h.insertScheduleLocked(reducerName, args, first, repeatNs)
}

func (h *schedulerHandle) insertScheduleLocked(reducerName string, args []byte, nextRunAtNs, repeatNs int64) (ScheduleID, error) {
	if err := validateScheduledReducerTarget(h.reg, reducerName); err != nil {
		return 0, err
	}
	idValue, ok := h.seq.NextNonZero()
	if !ok {
		return 0, ErrScheduleIDExhausted
	}
	id := ScheduleID(idValue)
	row := types.ProductValue{
		SysScheduledColScheduleID:  types.NewUint64(uint64(id)),
		SysScheduledColReducerName: types.NewString(reducerName),
		SysScheduledColArgs:        types.NewBytes(args),
		SysScheduledColNextRunAtNs: types.NewInt64(nextRunAtNs),
		SysScheduledColRepeatNs:    types.NewInt64(repeatNs),
	}
	if _, err := h.tx.Insert(h.tableID, row); err != nil {
		return 0, err
	}
	return id, nil
}

func validateScheduledReducerTarget(reg *ReducerRegistry, reducerName string) error {
	if reg == nil {
		return fmt.Errorf("%w: %s", ErrReducerNotFound, reducerName)
	}
	rr, ok := reg.Lookup(reducerName)
	if !ok {
		return fmt.Errorf("%w: %s", ErrReducerNotFound, reducerName)
	}
	if rr.Lifecycle != LifecycleNone {
		return fmt.Errorf("%w: %s", ErrLifecycleReducer, reducerName)
	}
	return nil
}

func nextScheduleRepeatRunAt(intendedNs, repeatNs int64) (int64, bool) {
	if repeatNs <= 0 || intendedNs > math.MaxInt64-repeatNs {
		return 0, false
	}
	return intendedNs + repeatNs, true
}

func unixNanoWithinScheduleRange(t time.Time) (int64, bool) {
	if t.Before(time.Unix(0, math.MinInt64)) || t.After(time.Unix(0, math.MaxInt64)) {
		return 0, false
	}
	return t.UnixNano(), true
}

func (e *Executor) sweepInvalidSchedules(ctx context.Context) error {
	type invalidSchedule struct {
		id          ScheduleID
		reducerName string
	}

	var targets []invalidSchedule
	view := e.committed.Snapshot()
	for _, row := range view.TableScan(e.schedTableID) {
		id := ScheduleID(row[SysScheduledColScheduleID].AsUint64())
		reducerName := row[SysScheduledColReducerName].AsString()
		if err := validateScheduledReducerTarget(e.registry, reducerName); err != nil {
			targets = append(targets, invalidSchedule{id: id, reducerName: reducerName})
		}
	}
	view.Close()

	for _, target := range targets {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := e.latchDurabilityFatal(0); err != nil {
			return err
		}
		tx := store.NewTransaction(e.committed, e.schemaReg)
		if err := deleteSysScheduledRow(tx, e.schedTableID, target.id); err != nil {
			store.Rollback(tx)
			return fmt.Errorf("sweep sys_scheduled delete schedule_id=%d reducer=%q: %w", target.id, target.reducerName, err)
		}
		txID, err := e.nextCommitTxID()
		if err != nil {
			store.Rollback(tx)
			return err
		}
		tx.Seal()
		changeset, err := e.commitTransaction(tx, txID)
		if err != nil {
			store.Rollback(tx)
			return fmt.Errorf("sweep invalid schedule schedule_id=%d reducer=%q: %w", target.id, target.reducerName, err)
		}
		e.consumeCommitTxID()
		e.postCommit(txID, changeset, nil, CallReducerCmd{}, postCommitOptions{source: CallSourceLifecycle})
		if e.fatal.Load() {
			return fmt.Errorf("sweep invalid schedule aborted: %w", ErrExecutorFatal)
		}
	}
	return nil
}

func deleteSysScheduledRow(tx *store.Transaction, tableID schema.TableID, id ScheduleID) error {
	_, err := deleteSystemTableRowByPrimaryKey(tx, tableID, types.NewUint64(uint64(id)))
	return err
}

// Cancel removes the schedule row for id. Returns (true, nil) if a row was
// found and marked for deletion, (false, nil) if no row matched, and a
// non-nil error if the delete failed after a matching row was found.
func (h *schedulerHandle) Cancel(id ScheduleID) (bool, error) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if err := h.checkOpenLocked(); err != nil {
		return false, err
	}
	return deleteSystemTableRowByPrimaryKey(h.tx, h.tableID, types.NewUint64(uint64(id)))
}
