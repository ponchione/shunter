#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

rtk go test ./internal/gauntlettests -run '^TestStaticHostedBinaryGauntletHostedChat' -count=1
rtk bash scripts/hosted-chat-gate.sh
