package shunter

import (
	"context"
	"errors"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/ponchione/websocket"

	"github.com/ponchione/shunter/commitlog"
	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/schema"
)

func TestRuntimeInitialHealthIsBuiltAndNotReady(t *testing.T) {
	rt := buildValidTestRuntime(t)

	if rt.Ready() {
		t.Fatal("new runtime is ready before Start")
	}
	health := rt.Health()
	if health.State != RuntimeStateBuilt {
		t.Fatalf("state = %q, want %q", health.State, RuntimeStateBuilt)
	}
	if health.Ready {
		t.Fatal("health reports ready before Start")
	}
	if health.LastError != "" {
		t.Fatalf("unexpected last error: %v", health.LastError)
	}
}

func TestRuntimeStartAndCloseOwnLifecycle(t *testing.T) {
	rt := buildValidTestRuntime(t)
	ctx, cancel := context.WithCancel(context.Background())

	if err := rt.Start(ctx); err != nil {
		t.Fatalf("Start returned error: %v", err)
	}
	cancel()
	if !rt.Ready() {
		t.Fatal("runtime not ready after Start")
	}
	health := rt.Health()
	if health.State != RuntimeStateReady || !health.Ready {
		t.Fatalf("health after Start = %+v", health)
	}
	if rt.durability == nil {
		t.Fatal("durability worker not created")
	}
	if rt.executor == nil {
		t.Fatal("executor not created")
	}
	if rt.scheduler == nil {
		t.Fatal("scheduler not created")
	}
	if rt.subscriptions == nil {
		t.Fatal("subscription manager not created")
	}
	if rt.fanOutWorker == nil {
		t.Fatal("fan-out worker not created")
	}
	if !rt.Ready() {
		t.Fatal("canceling Start context after readiness stopped runtime; want startup-only context")
	}

	if err := rt.Close(); err != nil {
		t.Fatalf("Close returned error: %v", err)
	}
	if rt.Ready() {
		t.Fatal("runtime ready after Close")
	}
	if got := rt.Health().State; got != RuntimeStateClosed {
		t.Fatalf("state after Close = %q, want %q", got, RuntimeStateClosed)
	}
}

func TestRuntimeStartNilContextUsesBackground(t *testing.T) {
	rt := buildValidTestRuntime(t)
	//lint:ignore SA1012 This test pins Runtime.Start nil context compatibility.
	if err := rt.Start(nil); err != nil {
		t.Fatalf("Start(nil) returned error: %v", err)
	}
	if !rt.Ready() {
		t.Fatal("runtime not ready after Start(nil)")
	}
	if got := rt.Health().State; got != RuntimeStateReady {
		t.Fatalf("state after Start(nil) = %q, want %q", got, RuntimeStateReady)
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("Close after Start(nil): %v", err)
	}
}

func TestRuntimeStartIsIdempotentAfterReady(t *testing.T) {
	rt := buildValidTestRuntime(t)
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("first Start: %v", err)
	}
	t.Cleanup(func() { _ = rt.Close() })

	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("second Start on ready runtime: %v", err)
	}
}

func TestRuntimeCloseIsIdempotent(t *testing.T) {
	rt := buildValidTestRuntime(t)
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("Start: %v", err)
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("first Close: %v", err)
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("second Close: %v", err)
	}
}

func TestRuntimeCloseWaitsForAndCompensatesBlockedProtocolAdmission(t *testing.T) {
	onConnectEntered := make(chan struct{})
	releaseOnConnect := make(chan struct{})
	rt, err := Build(validChatModule().OnConnect(func(*schema.ReducerContext) error {
		close(onConnectEntered)
		<-releaseOnConnect
		return nil
	}), Config{DataDir: t.TempDir(), EnableProtocol: true})
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("Start: %v", err)
	}
	state := rt.state
	sysClientsID, _, ok := rt.registry.TableByName("sys_clients")
	if !ok {
		t.Fatal("sys_clients table missing")
	}

	server := httptest.NewServer(rt.HTTPHandler())
	defer server.Close()
	dialCtx, cancelDial := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancelDial()
	client, _, err := websocket.Dial(dialCtx, "ws"+strings.TrimPrefix(server.URL, "http")+"/subscribe", &websocket.DialOptions{
		Subprotocols: []string{protocol.SubprotocolV2},
	})
	if err != nil {
		t.Fatalf("dial protocol: %v", err)
	}
	defer client.CloseNow()
	select {
	case <-onConnectEntered:
	case <-time.After(time.Second):
		t.Fatal("protocol admission did not enter OnConnect")
	}

	closeDone := make(chan error, 1)
	go func() { closeDone <- rt.Close() }()
	readCtx, cancelRead := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancelRead()
	if _, _, err := client.Read(readCtx); err == nil {
		t.Fatal("admitting connection received a frame instead of closing at the runtime barrier")
	}
	select {
	case err := <-closeDone:
		t.Fatalf("Runtime.Close returned before OnConnect completed: %v", err)
	default:
	}

	close(releaseOnConnect)
	select {
	case err := <-closeDone:
		if err != nil {
			t.Fatalf("Runtime.Close: %v", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("Runtime.Close did not wait for admission compensation")
	}
	if got := rt.Health().State; got != RuntimeStateClosed {
		t.Fatalf("runtime state = %q, want closed", got)
	}
	snapshot := state.Snapshot()
	defer snapshot.Close()
	if got := snapshot.RowCount(sysClientsID); got != 0 {
		t.Fatalf("sys_clients rows after runtime shutdown = %d, want 0", got)
	}
}

func TestRuntimeConcurrentDuplicateStartIsStable(t *testing.T) {
	rt := buildValidTestRuntime(t)
	startedHook := make(chan struct{})
	releaseHook := make(chan struct{})
	oldHook := runtimeStartAfterDurabilityHook
	runtimeStartAfterDurabilityHook = func(*Runtime) error {
		close(startedHook)
		<-releaseHook
		return nil
	}
	defer func() { runtimeStartAfterDurabilityHook = oldHook }()

	firstErr := make(chan error, 1)
	go func() {
		firstErr <- rt.Start(context.Background())
	}()
	<-startedHook

	const duplicateStarts = 8
	errs := make(chan error, duplicateStarts)
	for range duplicateStarts {
		go func() {
			errs <- rt.Start(context.Background())
		}()
	}
	for range duplicateStarts {
		if err := <-errs; !errors.Is(err, ErrRuntimeStarting) {
			t.Fatalf("duplicate Start error = %v, want ErrRuntimeStarting", err)
		}
	}

	close(releaseHook)
	if err := <-firstErr; err != nil {
		t.Fatalf("first Start returned error: %v", err)
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("Close after concurrent Start: %v", err)
	}
}

func TestRuntimeConcurrentDuplicateCloseIsStable(t *testing.T) {
	rt := buildValidTestRuntime(t)
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("Start: %v", err)
	}

	const closers = 8
	var wg sync.WaitGroup
	errs := make(chan error, closers)
	for range closers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			errs <- rt.Close()
		}()
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		if err != nil {
			t.Fatalf("concurrent Close returned error: %v", err)
		}
	}
	if rt.Ready() {
		t.Fatal("runtime ready after concurrent Close")
	}
	if got := rt.Health().State; got != RuntimeStateClosed {
		t.Fatalf("state after concurrent Close = %q, want %q", got, RuntimeStateClosed)
	}
}

func TestRuntimeCloseBeforeStartClosesRuntime(t *testing.T) {
	rt := buildValidTestRuntime(t)
	if err := rt.Close(); err != nil {
		t.Fatalf("Close before Start: %v", err)
	}
	if rt.Ready() {
		t.Fatal("runtime ready after Close before Start")
	}
	if got := rt.Health().State; got != RuntimeStateClosed {
		t.Fatalf("state after Close before Start = %q, want %q", got, RuntimeStateClosed)
	}
	if err := rt.Start(context.Background()); !errors.Is(err, ErrRuntimeClosed) {
		t.Fatalf("Start after Close error = %v, want ErrRuntimeClosed", err)
	}
}

func TestRuntimeStartWithCanceledContextFailsWithoutReadiness(t *testing.T) {
	rt := buildValidTestRuntime(t)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	err := rt.Start(ctx)
	if err == nil || !errors.Is(err, context.Canceled) {
		t.Fatalf("Start error = %v, want context.Canceled", err)
	}
	if rt.Ready() {
		t.Fatal("runtime ready after canceled Start")
	}
	health := rt.Health()
	if health.State == RuntimeStateReady {
		t.Fatalf("state after canceled Start = ready")
	}
	if health.LastError == "" {
		t.Fatal("LastError not recorded after canceled Start")
	}

	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("retry Start after canceled startup: %v", err)
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("Close after retry: %v", err)
	}
}

func TestRuntimeStartFailureCleansPartialResources(t *testing.T) {
	rt := buildValidTestRuntime(t)
	injected := errors.New("injected lifecycle failure")
	oldHook := runtimeStartAfterDurabilityHook
	runtimeStartAfterDurabilityHook = func(*Runtime) error { return injected }
	defer func() { runtimeStartAfterDurabilityHook = oldHook }()

	err := rt.Start(context.Background())
	if err == nil || !errors.Is(err, injected) {
		t.Fatalf("Start error = %v, want injected failure", err)
	}
	if rt.Ready() {
		t.Fatal("runtime ready after failed Start")
	}
	if rt.durability != nil || rt.executor != nil || rt.scheduler != nil || rt.fanOutWorker != nil || rt.subscriptions != nil {
		t.Fatalf("partial resources not cleaned up: health=%+v", rt.Health())
	}
	if rt.Health().LastError == "" {
		t.Fatal("LastError not recorded after failed Start")
	}

	runtimeStartAfterDurabilityHook = oldHook
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("retry Start after injected failure: %v", err)
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("Close after retry: %v", err)
	}
}

func TestRuntimeStartJoinsDurabilityCleanupFailureBeforeTelemetry(t *testing.T) {
	logs := &recordingLogState{}
	rt, err := Build(validChatModule(), Config{
		DataDir: t.TempDir(),
		Observability: ObservabilityConfig{
			Logger: logs.logger(),
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	startFailure := errors.New("post-durability startup failure")
	cleanupFailure := errors.New("durability cleanup failure")
	oldStartHook := runtimeStartAfterDurabilityHook
	oldCloseHook := closeStartupDurability
	runtimeStartAfterDurabilityHook = func(*Runtime) error { return startFailure }
	closeStartupDurability = func(worker *commitlog.DurabilityWorker) (uint64, error) {
		finalTxID, closeErr := worker.Close()
		return finalTxID, errors.Join(closeErr, cleanupFailure)
	}
	t.Cleanup(func() {
		runtimeStartAfterDurabilityHook = oldStartHook
		closeStartupDurability = oldCloseHook
	})

	err = rt.Start(context.Background())
	if !errors.Is(err, startFailure) || !errors.Is(err, cleanupFailure) {
		t.Fatalf("Start error = %v, want startup and durability cleanup failures", err)
	}
	if got := rt.Health().LastError; !strings.Contains(got, startFailure.Error()) || !strings.Contains(got, cleanupFailure.Error()) {
		t.Fatalf("health LastError = %q, want both failures", got)
	}
	record := requireRecordedLog(t, logs, "runtime.start_failed")
	loggedError, _ := record.attrs["error"].(string)
	if !strings.Contains(loggedError, startFailure.Error()) || !strings.Contains(loggedError, cleanupFailure.Error()) {
		t.Fatalf("runtime.start_failed error = %q, want both failures", loggedError)
	}
}

func TestRuntimeStartInterruptedByClosePreservesAllFailures(t *testing.T) {
	rt := buildValidTestRuntime(t)
	startFailure := errors.New("startup hook failure")
	cleanupFailure := errors.New("durability cleanup failure")
	started := make(chan struct{})
	release := make(chan struct{})
	oldStartHook := runtimeStartAfterDurabilityHook
	oldCloseHook := closeStartupDurability
	runtimeStartAfterDurabilityHook = func(*Runtime) error {
		close(started)
		<-release
		return startFailure
	}
	closeStartupDurability = func(worker *commitlog.DurabilityWorker) (uint64, error) {
		finalTxID, closeErr := worker.Close()
		return finalTxID, errors.Join(closeErr, cleanupFailure)
	}
	t.Cleanup(func() {
		runtimeStartAfterDurabilityHook = oldStartHook
		closeStartupDurability = oldCloseHook
	})

	startErrCh := make(chan error, 1)
	go func() { startErrCh <- rt.Start(context.Background()) }()
	<-started
	closeErrCh := make(chan error, 1)
	go func() { closeErrCh <- rt.Close() }()
	eventually(t, func() bool { return rt.startInterruptedByClose() })
	close(release)

	startErr := <-startErrCh
	for _, want := range []error{ErrRuntimeClosed, startFailure, cleanupFailure} {
		if !errors.Is(startErr, want) {
			t.Fatalf("Start error = %v, want errors.Is(..., %v)", startErr, want)
		}
	}
	if err := <-closeErrCh; err != nil {
		t.Fatalf("Close error = %v, want nil", err)
	}
}

func buildValidTestRuntime(t *testing.T) *Runtime {
	t.Helper()
	rt, err := Build(validChatModule(), Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	return rt
}
