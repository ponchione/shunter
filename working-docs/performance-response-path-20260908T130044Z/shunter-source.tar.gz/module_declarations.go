package shunter

import (
	"errors"
	"fmt"
	"slices"
	"strings"

	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/schema"
)

var (
	ErrEmptyDeclarationName     = errors.New("declaration name must not be empty")
	ErrDuplicateDeclarationName = errors.New("duplicate declaration name")
	ErrInvalidModuleMetadata    = errors.New("invalid module metadata")
	ErrUnknownTableMigration    = errors.New("table migration metadata references unknown table")

	// ErrInvalidDeclarationSQL reports SQL metadata that cannot be compiled
	// against the built module schema.
	ErrInvalidDeclarationSQL = errors.New("invalid declaration SQL")
)

const (
	// ReadModelSurfaceQuery identifies read-model metadata attached to a query.
	ReadModelSurfaceQuery = "query"

	// ReadModelSurfaceView identifies read-model metadata attached to a view.
	ReadModelSurfaceView = "view"

	// PermissionSurfaceProcedure identifies permission metadata attached to a procedure.
	PermissionSurfaceProcedure = "procedure"

	// MigrationSurfaceTable identifies migration metadata attached to a table.
	MigrationSurfaceTable = "table"

	// MigrationSurfaceQuery identifies migration metadata attached to a query.
	MigrationSurfaceQuery = "query"

	// MigrationSurfaceView identifies migration metadata attached to a view.
	MigrationSurfaceView = "view"
)

// MigrationCompatibility describes author-declared migration compatibility.
type MigrationCompatibility string

const (
	MigrationCompatibilityCompatible MigrationCompatibility = "compatible"
	MigrationCompatibilityBreaking   MigrationCompatibility = "breaking"
	MigrationCompatibilityUnknown    MigrationCompatibility = "unknown"
)

// MigrationClassification describes an author-declared migration change class.
type MigrationClassification string

const (
	MigrationClassificationAdditive           MigrationClassification = "additive"
	MigrationClassificationDeprecated         MigrationClassification = "deprecated"
	MigrationClassificationDataRewriteNeeded  MigrationClassification = "data-rewrite-needed"
	MigrationClassificationManualReviewNeeded MigrationClassification = "manual-review-needed"
)

// MigrationMetadata describes schema/module evolution for review tooling.
type MigrationMetadata struct {
	ModuleVersion   string                    `json:"module_version"`
	SchemaVersion   uint32                    `json:"schema_version"`
	ContractVersion uint32                    `json:"contract_version"`
	PreviousVersion string                    `json:"previous_version"`
	Compatibility   MigrationCompatibility    `json:"compatibility"`
	Classifications []MigrationClassification `json:"classifications"`
	Notes           string                    `json:"notes"`
}

// PermissionMetadata describes passive permission tags required to access an
// exported reducer, query, or view.
type PermissionMetadata struct {
	Required []string
}

// ReadModelMetadata describes passive read-model tags for an exported query or
// view.
type ReadModelMetadata struct {
	Tables []string
	Tags   []string
}

// ReducerDeclaration records module-owned metadata for a named reducer.
type ReducerDeclaration struct {
	Name        string
	Permissions PermissionMetadata
	Args        *ProductSchema
	Result      *ProductSchema
}

// ProcedureHandler is the raw runtime signature for client-callable
// procedures. Procedures may block on external I/O and are not executed on the
// reducer executor.
type ProcedureHandler func(ctx *ProcedureContext, argBSATN []byte) ([]byte, error)

// ProcedureDeclaration records module-owned metadata and handler for a named procedure.
type ProcedureDeclaration struct {
	Name        string
	Handler     ProcedureHandler `json:"-"`
	Permissions PermissionMetadata
	Args        *ProductSchema
	Result      *ProductSchema
}

type procedureOptions struct {
	permissions PermissionMetadata
	args        *ProductSchema
	result      *ProductSchema
}

// ProcedureOption configures procedure declaration metadata.
type ProcedureOption func(*procedureOptions)

// WithProcedurePermissions attaches passive permission metadata to a procedure.
func WithProcedurePermissions(metadata PermissionMetadata) ProcedureOption {
	return func(o *procedureOptions) {
		o.permissions = copyPermissionMetadata(metadata)
	}
}

// WithProcedureArgs attaches the procedure argument product schema exported for typed clients.
func WithProcedureArgs(product ProductSchema) ProcedureOption {
	return func(o *procedureOptions) {
		o.args = copyProductSchemaPtr(&product)
	}
}

// WithProcedureResult attaches the procedure result product schema exported for typed clients.
func WithProcedureResult(product ProductSchema) ProcedureOption {
	return func(o *procedureOptions) {
		o.result = copyProductSchemaPtr(&product)
	}
}

type reducerOptions struct {
	permissions PermissionMetadata
	args        *ProductSchema
	result      *ProductSchema
}

// ReducerOption configures reducer declaration metadata.
type ReducerOption func(*reducerOptions)

// WithReducerPermissions attaches passive permission metadata to a reducer.
func WithReducerPermissions(metadata PermissionMetadata) ReducerOption {
	return func(o *reducerOptions) {
		o.permissions = copyPermissionMetadata(metadata)
	}
}

// WithReducerArgs attaches the reducer argument product schema exported for
// typed clients. Omit this option to keep the reducer raw-Uint8Array only.
func WithReducerArgs(product ProductSchema) ReducerOption {
	return func(o *reducerOptions) {
		o.args = copyProductSchemaPtr(&product)
	}
}

// WithReducerResult attaches the reducer result product schema exported for
// typed clients. Omit this option to keep the reducer result raw-Uint8Array
// only.
func WithReducerResult(product ProductSchema) ReducerOption {
	return func(o *reducerOptions) {
		o.result = copyProductSchemaPtr(&product)
	}
}

// QueryDeclaration declares a named request/response-style read surface owned
// by a module.
type QueryDeclaration struct {
	Name string
	// SQL optionally binds the declaration to an executable OneOffQuery SQL
	// string. Empty SQL leaves the declaration metadata-only.
	SQL         string
	Permissions PermissionMetadata
	ReadModel   ReadModelMetadata
	Migration   MigrationMetadata
}

// ViewDeclaration declares a named live view/subscription surface owned by a
// module.
type ViewDeclaration struct {
	Name string
	// SQL optionally binds the declaration to an executable subscription SQL
	// string. Empty SQL leaves the declaration metadata-only.
	SQL         string
	Permissions PermissionMetadata
	ReadModel   ReadModelMetadata
	Migration   MigrationMetadata
}

type queryDeclaration struct {
	Name        string
	SQL         string
	Parameters  *ProductSchema
	Permissions PermissionMetadata
	ReadModel   ReadModelMetadata
	Migration   MigrationMetadata
}

type viewDeclaration struct {
	Name        string
	SQL         string
	Parameters  *ProductSchema
	Permissions PermissionMetadata
	ReadModel   ReadModelMetadata
	Migration   MigrationMetadata
}

type queryDeclarationOptions struct {
	parameters *ProductSchema
}

// QueryDeclarationOption configures query declaration metadata without changing
// the source-compatible QueryDeclaration literal shape.
type QueryDeclarationOption func(*queryDeclarationOptions)

// WithQueryParameters attaches the declared-read parameter product schema used
// by SQL placeholders such as :topic.
func WithQueryParameters(product ProductSchema) QueryDeclarationOption {
	return func(o *queryDeclarationOptions) {
		o.parameters = copyProductSchemaPtr(&product)
	}
}

type viewDeclarationOptions struct {
	parameters *ProductSchema
}

// ViewDeclarationOption configures view declaration metadata without changing
// the source-compatible ViewDeclaration literal shape.
type ViewDeclarationOption func(*viewDeclarationOptions)

// WithViewParameters attaches the declared-read parameter product schema used
// by SQL placeholders such as :topic.
func WithViewParameters(product ProductSchema) ViewDeclarationOption {
	return func(o *viewDeclarationOptions) {
		o.parameters = copyProductSchemaPtr(&product)
	}
}

// Query registers a named read query declaration and returns the receiver for
// fluent module declarations.
func (m *Module) Query(decl QueryDeclaration, opts ...QueryDeclarationOption) *Module {
	m.queries = append(m.queries, newQueryDeclaration(decl, opts...))
	return m
}

// View registers a named live view/subscription declaration and returns the
// receiver for fluent module declarations.
func (m *Module) View(decl ViewDeclaration, opts ...ViewDeclarationOption) *Module {
	m.views = append(m.views, newViewDeclaration(decl, opts...))
	return m
}

func validateModuleDeclarations(m *Module) error {
	names := make(map[string]struct{}, len(m.queries)+len(m.views)+len(m.procedures))
	for _, procedure := range m.procedures {
		if err := validateDeclarationName(names, "procedure", procedure.Name); err != nil {
			return err
		}
	}

	for _, query := range m.queries {
		if err := validateDeclarationName(names, "query", query.Name); err != nil {
			return err
		}
	}

	for _, view := range m.views {
		if err := validateDeclarationName(names, "view", view.Name); err != nil {
			return err
		}
	}

	return validateModuleVisibilityFilterNames(m)
}

func validateDeclarationName(names map[string]struct{}, kind, raw string) error {
	name := strings.TrimSpace(raw)
	if name == "" {
		return fmt.Errorf("%w: %s", ErrEmptyDeclarationName, kind)
	}
	if _, ok := names[name]; ok {
		return fmt.Errorf("%w: %s %q", ErrDuplicateDeclarationName, kind, raw)
	}
	names[name] = struct{}{}
	return nil
}

func validateModuleDeclarationSQL(m *Module, sl protocol.SchemaLookup) error {
	for _, spec := range declaredReadSpecs(m.queries, m.views) {
		if strings.TrimSpace(spec.SQL) == "" {
			continue
		}
		parameters, parameterErr := declaredReadSQLParameters(spec.Parameters)
		if parameterErr != nil {
			continue
		}
		err := protocol.ValidateSQLQueryTemplateString(spec.SQL, sl, spec.Validation, parameters)
		if err != nil {
			return fmt.Errorf("%w: %s %q: %v", ErrInvalidDeclarationSQL, spec.Kind, spec.Name, err)
		}
	}
	return nil
}

func validateModuleMetadata(m *Module, reg schema.SchemaRegistry) error {
	var errs []error
	for key := range m.metadata {
		if strings.TrimSpace(key) == "" {
			errs = append(errs, fmt.Errorf("module.metadata key must not be empty"))
		}
	}

	validateMigrationMetadata("migrations.module", m.migration, &errs)
	for tableName, metadata := range m.tableMigrations {
		validateMigrationMetadata("migrations.table."+tableName, metadata, &errs)
	}
	for _, reducer := range m.reducers {
		validateAuthoredPermissionMetadata("permissions.reducer."+reducer.Name, reducer.Permissions, &errs)
		validateProductSchema("reducers."+reducer.Name+".args", reducer.Args, &errs)
		validateProductSchema("reducers."+reducer.Name+".result", reducer.Result, &errs)
	}
	for _, procedure := range m.procedures {
		validateAuthoredPermissionMetadata("permissions.procedure."+procedure.Name, procedure.Permissions, &errs)
		validateProductSchema("procedures."+procedure.Name+".args", procedure.Args, &errs)
		validateProductSchema("procedures."+procedure.Name+".result", procedure.Result, &errs)
	}
	for _, query := range m.queries {
		validateAuthoredPermissionMetadata("permissions.query."+query.Name, query.Permissions, &errs)
		validateParameterProductSchema("queries."+query.Name+".parameters", query.Parameters, &errs)
		validateAuthoredReadModelMetadata("read_model.query."+query.Name, query.ReadModel, reg, &errs)
		validateMigrationMetadata("migrations.query."+query.Name, query.Migration, &errs)
	}
	for _, view := range m.views {
		validateAuthoredPermissionMetadata("permissions.view."+view.Name, view.Permissions, &errs)
		validateParameterProductSchema("views."+view.Name+".parameters", view.Parameters, &errs)
		validateAuthoredReadModelMetadata("read_model.view."+view.Name, view.ReadModel, reg, &errs)
		validateMigrationMetadata("migrations.view."+view.Name, view.Migration, &errs)
	}
	if len(errs) > 0 {
		return fmt.Errorf("%w: %v", ErrInvalidModuleMetadata, errors.Join(errs...))
	}
	return nil
}

func validateAuthoredPermissionMetadata(path string, metadata PermissionMetadata, errs *[]error) {
	validatePermissionRequirements(path, metadata.Required, isReadPermissionMetadataPath(path), errs)
}

func validatePermissionRequirements(path string, required []string, rejectDuplicates bool, errs *[]error) {
	seen := make(map[string]struct{}, len(required))
	for _, required := range required {
		if strings.TrimSpace(required) == "" {
			*errs = append(*errs, fmt.Errorf("%s requirement must not be empty", path))
			continue
		}
		if rejectDuplicates {
			if _, exists := seen[required]; exists {
				*errs = append(*errs, fmt.Errorf("%s requirement %q is duplicated", path, required))
				continue
			}
		}
		seen[required] = struct{}{}
	}
}

func isReadPermissionMetadataPath(path string) bool {
	return strings.Contains(path, "permissions.query.") ||
		strings.Contains(path, "permissions.view.")
}

func validateAuthoredReadModelMetadata(path string, metadata ReadModelMetadata, reg schema.SchemaRegistry, errs *[]error) {
	for _, table := range metadata.Tables {
		if strings.TrimSpace(table) == "" {
			*errs = append(*errs, fmt.Errorf("%s table must not be empty", path))
			continue
		}
		if reg == nil {
			continue
		}
		_, tableSchema, ok := reg.TableByName(table)
		if !ok || tableSchema == nil || tableSchema.Name != table {
			*errs = append(*errs, fmt.Errorf("%s references unknown table %q", path, table))
		}
	}
	for _, tag := range metadata.Tags {
		if strings.TrimSpace(tag) == "" {
			*errs = append(*errs, fmt.Errorf("%s tag must not be empty", path))
		}
	}
}

func validateModuleTableMigrations(m *Module, reg schema.SchemaRegistry) error {
	for tableName := range m.tableMigrations {
		if strings.TrimSpace(tableName) == "" {
			return fmt.Errorf("%w: empty table name", ErrUnknownTableMigration)
		}
		_, table, ok := reg.TableByName(tableName)
		if !ok || table == nil || table.Name != tableName {
			return fmt.Errorf("%w: %q", ErrUnknownTableMigration, tableName)
		}
	}
	return nil
}

func newQueryDeclaration(decl QueryDeclaration, opts ...QueryDeclarationOption) queryDeclaration {
	var options queryDeclarationOptions
	for _, opt := range opts {
		if opt != nil {
			opt(&options)
		}
	}
	return queryDeclaration{
		Name:        decl.Name,
		SQL:         decl.SQL,
		Parameters:  copyProductSchemaPtr(options.parameters),
		Permissions: copyPermissionMetadata(decl.Permissions),
		ReadModel:   copyReadModelMetadata(decl.ReadModel),
		Migration:   copyMigrationMetadata(decl.Migration),
	}
}

func newViewDeclaration(decl ViewDeclaration, opts ...ViewDeclarationOption) viewDeclaration {
	var options viewDeclarationOptions
	for _, opt := range opts {
		if opt != nil {
			opt(&options)
		}
	}
	return viewDeclaration{
		Name:        decl.Name,
		SQL:         decl.SQL,
		Parameters:  copyProductSchemaPtr(options.parameters),
		Permissions: copyPermissionMetadata(decl.Permissions),
		ReadModel:   copyReadModelMetadata(decl.ReadModel),
		Migration:   copyMigrationMetadata(decl.Migration),
	}
}

func copyQueryDeclaration(query queryDeclaration) queryDeclaration {
	return queryDeclaration{
		Name:        query.Name,
		SQL:         query.SQL,
		Parameters:  copyProductSchemaPtr(query.Parameters),
		Permissions: copyPermissionMetadata(query.Permissions),
		ReadModel:   copyReadModelMetadata(query.ReadModel),
		Migration:   copyMigrationMetadata(query.Migration),
	}
}

func copyViewDeclaration(view viewDeclaration) viewDeclaration {
	return viewDeclaration{
		Name:        view.Name,
		SQL:         view.SQL,
		Parameters:  copyProductSchemaPtr(view.Parameters),
		Permissions: copyPermissionMetadata(view.Permissions),
		ReadModel:   copyReadModelMetadata(view.ReadModel),
		Migration:   copyMigrationMetadata(view.Migration),
	}
}

func copyQueryDeclarations(in []queryDeclaration) []queryDeclaration {
	return mapNonEmptySlice(in, copyQueryDeclaration)
}

func copyViewDeclarations(in []viewDeclaration) []viewDeclaration {
	return mapNonEmptySlice(in, copyViewDeclaration)
}

func describeQueryDeclarations(in []queryDeclaration) []QueryDescription {
	return mapNonEmptySlice(in, describeQueryDeclaration)
}

func describeQueryDeclaration(query queryDeclaration) QueryDescription {
	return QueryDescription{
		Name:        query.Name,
		SQL:         query.SQL,
		Parameters:  copyProductSchemaPtr(query.Parameters),
		Permissions: copyPermissionMetadata(query.Permissions),
		ReadModel:   copyReadModelMetadata(query.ReadModel),
		Migration:   copyMigrationMetadata(query.Migration),
	}
}

func describeViewDeclarations(in []viewDeclaration) []ViewDescription {
	return mapNonEmptySlice(in, describeViewDeclaration)
}

func describeViewDeclaration(view viewDeclaration) ViewDescription {
	return ViewDescription{
		Name:        view.Name,
		SQL:         view.SQL,
		Parameters:  copyProductSchemaPtr(view.Parameters),
		Permissions: copyPermissionMetadata(view.Permissions),
		ReadModel:   copyReadModelMetadata(view.ReadModel),
		Migration:   copyMigrationMetadata(view.Migration),
	}
}

func describeProcedureDeclarations(in []ProcedureDeclaration) []ProcedureDescription {
	return mapNonEmptySlice(in, describeProcedureDeclaration)
}

func describeProcedureDeclaration(procedure ProcedureDeclaration) ProcedureDescription {
	return ProcedureDescription{
		Name:        procedure.Name,
		Args:        copyProductSchemaPtr(procedure.Args),
		Result:      copyProductSchemaPtr(procedure.Result),
		Permissions: copyPermissionMetadata(procedure.Permissions),
	}
}

func copyReducerDeclarations(in []ReducerDeclaration) []ReducerDeclaration {
	return mapNonEmptySlice(in, copyReducerDeclaration)
}

func copyReducerDeclaration(reducer ReducerDeclaration) ReducerDeclaration {
	return ReducerDeclaration{
		Name:        reducer.Name,
		Permissions: copyPermissionMetadata(reducer.Permissions),
		Args:        copyProductSchemaPtr(reducer.Args),
		Result:      copyProductSchemaPtr(reducer.Result),
	}
}

func copyProcedureDeclaration(in ProcedureDeclaration) ProcedureDeclaration {
	return ProcedureDeclaration{
		Name:        in.Name,
		Handler:     in.Handler,
		Permissions: copyPermissionMetadata(in.Permissions),
		Args:        copyProductSchemaPtr(in.Args),
		Result:      copyProductSchemaPtr(in.Result),
	}
}

func copyProcedureDeclarations(in []ProcedureDeclaration) []ProcedureDeclaration {
	return mapNonEmptySlice(in, copyProcedureDeclaration)
}

func copyProductSchemaPtr(in *ProductSchema) *ProductSchema {
	if in == nil {
		return nil
	}
	out := ProductSchema{Columns: append([]ProductColumn{}, in.Columns...)}
	return &out
}

func copyPermissionMetadata(in PermissionMetadata) PermissionMetadata {
	return PermissionMetadata{Required: copySlice(in.Required)}
}

func copyReadModelMetadata(in ReadModelMetadata) ReadModelMetadata {
	return ReadModelMetadata{
		Tables: copySlice(in.Tables),
		Tags:   copySlice(in.Tags),
	}
}

func copyMigrationMetadata(in MigrationMetadata) MigrationMetadata {
	return MigrationMetadata{
		ModuleVersion:   in.ModuleVersion,
		SchemaVersion:   in.SchemaVersion,
		ContractVersion: in.ContractVersion,
		PreviousVersion: in.PreviousVersion,
		Compatibility:   in.Compatibility,
		Classifications: copySlice(in.Classifications),
		Notes:           in.Notes,
	}
}

func copyMigrationMetadataMap(in map[string]MigrationMetadata) map[string]MigrationMetadata {
	if len(in) == 0 {
		return map[string]MigrationMetadata{}
	}
	out := make(map[string]MigrationMetadata, len(in))
	for k, v := range in {
		out[k] = copyMigrationMetadata(v)
	}
	return out
}

func hasPermissionMetadata(in PermissionMetadata) bool {
	return len(in.Required) > 0
}

func hasReadModelMetadata(in ReadModelMetadata) bool {
	return len(in.Tables) > 0 || len(in.Tags) > 0
}

func hasMigrationMetadata(in MigrationMetadata) bool {
	return in.ModuleVersion != "" ||
		in.SchemaVersion != 0 ||
		in.ContractVersion != 0 ||
		in.PreviousVersion != "" ||
		in.Compatibility != "" ||
		len(in.Classifications) > 0 ||
		in.Notes != ""
}

func copySlice[T any](in []T) []T {
	if len(in) == 0 {
		return nil
	}
	return slices.Clone(in)
}

func normalizeSlice[T any](in []T) []T {
	if len(in) == 0 {
		return []T{}
	}
	return copySlice(in)
}

func mapSlice[T, U any](in []T, f func(T) U) []U {
	out := make([]U, len(in))
	for i, item := range in {
		out[i] = f(item)
	}
	return out
}

func mapNonEmptySlice[T, U any](in []T, f func(T) U) []U {
	if len(in) == 0 {
		return nil
	}
	return mapSlice(in, f)
}
