package protocol

import (
	"context"
	"strings"
	"testing"
	"time"

	"github.com/ponchione/shunter/types"
)

// testConnDirect builds a *Conn without a real WebSocket, suitable for
// handler unit tests that only inspect OutboundCh.
func testConnDirect(opts *ProtocolOptions) *Conn {
	if opts == nil {
		o := DefaultProtocolOptions()
		opts = &o
	}
	readCtx, cancelRead := context.WithCancel(context.Background())
	return &Conn{
		ID:                  GenerateConnectionID(),
		Identity:            [32]byte{1},
		AllowAllPermissions: true,
		OutboundCh:          make(chan []byte, opts.OutgoingBufferMessages),
		inflightSem:         make(chan struct{}, opts.IncomingQueueMessages),
		opts:                opts,
		readCtx:             readCtx,
		cancelRead:          cancelRead,
		inboundStopCh:       make(chan struct{}),
		closed:              make(chan struct{}),
		disconnectRequested: make(chan struct{}),
	}
}

// drainServerMsg reads one frame from conn.OutboundCh and decodes it,
// returning the tag and decoded server message. Fatals if nothing is
// queued or decode fails.
func drainServerMsg(t *testing.T, conn *Conn) (uint8, any) {
	t.Helper()
	select {
	case frame := <-conn.OutboundCh:
		conn.releaseOutboundBytes(len(frame))
		return decodeOutboundServerFrame(t, conn, frame)
	default:
		t.Fatal("expected a message on OutboundCh but channel was empty")
		return 0, nil
	}
}

func drainServerMsgEventually(t *testing.T, conn *Conn) (uint8, any) {
	t.Helper()
	select {
	case frame := <-conn.OutboundCh:
		conn.releaseOutboundBytes(len(frame))
		return decodeOutboundServerFrame(t, conn, frame)
	case <-time.After(2 * time.Second):
		t.Fatal("expected a message on OutboundCh but channel stayed empty")
		return 0, nil
	}
}

func decodeOutboundServerFrame(t *testing.T, conn *Conn, frame []byte) (uint8, any) {
	t.Helper()
	if conn != nil && conn.Compression {
		tag, body, err := UnwrapCompressed(frame)
		if err != nil {
			t.Fatalf("UnwrapCompressed: %v", err)
		}
		wire := make([]byte, 1+len(body))
		wire[0] = tag
		copy(wire[1:], body)
		frame = wire
	}
	tag, msg, err := DecodeServerMessage(frame)
	if err != nil {
		t.Fatalf("DecodeServerMessage: %v", err)
	}
	return tag, msg
}

func requireSubscriptionError(t *testing.T, conn *Conn, requestID, queryID uint32, want string) SubscriptionError {
	t.Helper()
	tag, decoded := drainServerMsgEventually(t, conn)
	if tag != TagSubscriptionError {
		t.Fatalf("tag = %d, want %d (TagSubscriptionError)", tag, TagSubscriptionError)
	}
	se := decoded.(SubscriptionError)
	if se.RequestID == nil || *se.RequestID != requestID {
		t.Fatalf("RequestID = %v, want %d", se.RequestID, requestID)
	}
	if se.QueryID == nil || *se.QueryID != queryID {
		t.Fatalf("QueryID = %v, want %d", se.QueryID, queryID)
	}
	if se.Error != want {
		t.Fatalf("Error = %q, want %q", se.Error, want)
	}
	return se
}

func overlongSQLQuery() string {
	const maxSQLLength = 50_000
	const base = "SELECT * FROM users WHERE id = 1"
	const suffix = " OR id = 1"
	if len(base) > maxSQLLength {
		return base
	}
	var b strings.Builder
	b.Grow(maxSQLLength + len(suffix))
	b.WriteString(base)
	for b.Len() <= maxSQLLength {
		b.WriteString(suffix)
	}
	return b.String()
}

// uint256TenToFortieth is a fixed independent oracle for the scientific SQL
// literal 1e40. In hexadecimal, 10^40 is
// 0x1d6329f1c35ca4bfabb9f5610000000000.
func uint256TenToFortieth() types.Value {
	return types.NewUint256(0, 0x1d, 0x6329f1c35ca4bfab, 0xb9f5610000000000)
}

// runRequestedDisconnectOwner supplies the lifecycle coordinator for loop-level
// tests that intentionally exercise fatal paths outside HandleSubscribe.
func runRequestedDisconnectOwner(c *Conn) <-chan struct{} {
	return runRequestedDisconnectOwnerWithLifecycle(c, nil, nil)
}

func runRequestedDisconnectOwnerWithLifecycle(c *Conn, inbox ExecutorInbox, mgr *ConnManager) <-chan struct{} {
	done := make(chan struct{})
	go func() {
		defer close(done)
		<-c.disconnectRequested
		termination := c.disconnectRequest
		ctx, cancel := context.WithTimeout(context.Background(), c.disconnectTimeout())
		defer cancel()
		c.Disconnect(ctx, termination.code, termination.reason, inbox, mgr)
	}()
	return done
}
