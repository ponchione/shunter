package protocol

import (
	"context"
	"strings"
	"testing"

	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

func TestV1UnsupportedSQLNonGoalsReturnProtocolErrors(t *testing.T) {
	for i, tc := range v1UnsupportedSQLProtocolRepresentatives() {
		t.Run(tc.name+"/one_off", func(t *testing.T) {
			conn := testConnDirect(nil)
			msg := &OneOffQueryMsg{
				MessageID:   []byte{0xA0, byte(i)},
				QueryString: tc.sql,
			}
			stateAccess := &mockStateAccess{snap: &mockSnapshot{
				rows: map[schema.TableID][]types.ProductValue{},
			}}

			handleOneOffQuery(context.Background(), conn, msg, stateAccess, v1UnsupportedSQLSchemaLookup(t))

			result := drainOneOff(t, conn)
			if result.Error == nil || *result.Error == "" {
				t.Fatalf("OneOff error = %v, want non-empty validation error", result.Error)
			}
			requireV1UnsupportedSQLDiagnostic(t, "OneOffQueryResponse.Error", *result.Error)
			if len(result.Tables) != 0 {
				t.Fatalf("OneOff tables = %d, want 0 on unsupported SQL", len(result.Tables))
			}
		})

		t.Run(tc.name+"/subscribe_single", func(t *testing.T) {
			conn := testConnDirect(nil)
			executor := &mockSubExecutor{}
			requestID := uint32(900 + i*2)
			queryID := requestID + 1
			msg := &SubscribeSingleMsg{
				RequestID:   requestID,
				QueryID:     queryID,
				QueryString: tc.sql,
			}

			handleSubscribeSingle(context.Background(), conn, msg, executor, v1UnsupportedSQLSchemaLookup(t))

			tag, decoded := drainServerMsgEventually(t, conn)
			if tag != TagSubscriptionError {
				t.Fatalf("tag = %d, want %d (TagSubscriptionError)", tag, TagSubscriptionError)
			}
			se := decoded.(SubscriptionError)
			requireOptionalUint32(t, se.RequestID, requestID, "SubscriptionError.RequestID")
			requireOptionalUint32(t, se.QueryID, queryID, "SubscriptionError.QueryID")
			if se.Error == "" {
				t.Fatal("SubscriptionError.Error = empty, want validation error")
			}
			requireV1UnsupportedSQLDiagnostic(t, "SubscribeSingle SubscriptionError.Error", se.Error)
			requireV1ExecutingSQLSuffix(t, se.Error, tc.sql)
			if req := executor.getRegisterSetReq(); req != nil {
				t.Fatal("executor should not be called for unsupported SQL")
			}
		})

		t.Run(tc.name+"/subscribe_multi", func(t *testing.T) {
			conn := testConnDirect(nil)
			executor := &mockSubExecutor{}
			requestID := uint32(1900 + i*2)
			queryID := requestID + 1
			msg := &SubscribeMultiMsg{
				RequestID: requestID,
				QueryID:   queryID,
				QueryStrings: []string{
					"SELECT * FROM t",
					tc.sql,
				},
			}

			handleSubscribeMulti(context.Background(), conn, msg, executor, v1UnsupportedSQLSchemaLookup(t))

			tag, decoded := drainServerMsgEventually(t, conn)
			if tag != TagSubscriptionError {
				t.Fatalf("tag = %d, want %d (TagSubscriptionError)", tag, TagSubscriptionError)
			}
			se := decoded.(SubscriptionError)
			requireOptionalUint32(t, se.RequestID, requestID, "SubscriptionError.RequestID")
			requireOptionalUint32(t, se.QueryID, queryID, "SubscriptionError.QueryID")
			if se.Error == "" {
				t.Fatal("SubscriptionError.Error = empty, want validation error")
			}
			requireV1UnsupportedSQLDiagnostic(t, "SubscribeMulti SubscriptionError.Error", se.Error)
			requireV1ExecutingSQLSuffix(t, se.Error, tc.sql)
			if req := executor.getRegisterSetReq(); req != nil {
				t.Fatal("executor should not be called for unsupported SQL")
			}
		})
	}
}

func requireV1UnsupportedSQLDiagnostic(t *testing.T, field, got string) {
	t.Helper()
	lower := strings.ToLower(got)
	if !strings.Contains(lower, "unsupported") && !strings.Contains(lower, "not supported") {
		t.Fatalf("%s = %q, want unsupported-SQL diagnostic text", field, got)
	}
}

func requireV1ExecutingSQLSuffix(t *testing.T, got, sqlText string) {
	t.Helper()
	want := ", executing: `" + sqlText + "`"
	if !strings.Contains(got, want) {
		t.Fatalf("SubscriptionError.Error = %q, want offending SQL suffix %q", got, want)
	}
}

// v1UnsupportedSQLProtocolRepresentatives samples distinct parser-error
// families to pin protocol response mapping, correlation, SQL suffixes, and
// atomic executor rejection. query/sql.TestV1UnsupportedSQLNonGoalsRejected is
// the authoritative exhaustive unsupported-syntax matrix.
func v1UnsupportedSQLProtocolRepresentatives() []struct {
	name string
	sql  string
} {
	return []struct {
		name string
		sql  string
	}{
		{name: "insert", sql: "INSERT INTO t (id) VALUES (1)"},
		{name: "arithmetic_expression", sql: "SELECT * FROM t WHERE id + 1 = 2"},
		{name: "subquery", sql: "SELECT * FROM (SELECT * FROM t) AS nested"},
		{name: "union", sql: "SELECT * FROM t UNION SELECT * FROM s"},
		{name: "outer_join", sql: "SELECT t.* FROM t LEFT OUTER JOIN s ON t.id = s.id"},
		{name: "transaction_control_begin", sql: "BEGIN"},
		{name: "procedure_call", sql: "CALL refresh_tasks()"},
	}
}

func v1UnsupportedSQLSchemaLookup(t *testing.T) SchemaLookup {
	t.Helper()
	b := schema.NewBuilder().SchemaVersion(1)
	b.TableDef(schema.TableDefinition{
		Name: "t",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint32},
			{Name: "body", Type: schema.KindString},
			{Name: "metadata", Type: schema.KindJSON},
		},
	})
	b.TableDef(schema.TableDefinition{
		Name: "s",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint32},
			{Name: "body", Type: schema.KindString},
			{Name: "metadata", Type: schema.KindJSON},
		},
	})
	eng, err := b.Build(schema.EngineOptions{})
	if err != nil {
		t.Fatalf("Build schema: %v", err)
	}
	return registrySchemaLookup{reg: eng.Registry()}
}
