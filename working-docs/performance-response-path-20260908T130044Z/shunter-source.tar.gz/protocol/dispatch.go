package protocol

import (
	"context"
	"errors"
	"fmt"

	"github.com/ponchione/websocket"
)

// MessageHandlers holds the per-message-type handler functions wired by
// the host. A nil field means the message type is not supported on this
// connection -- the dispatch loop closes with 1002 if it encounters one.
type MessageHandlers struct {
	OnSubscribeSingle                     func(ctx context.Context, conn *Conn, msg *SubscribeSingleMsg)
	OnSubscribeMulti                      func(ctx context.Context, conn *Conn, msg *SubscribeMultiMsg)
	OnUnsubscribeSingle                   func(ctx context.Context, conn *Conn, msg *UnsubscribeSingleMsg)
	OnUnsubscribeMulti                    func(ctx context.Context, conn *Conn, msg *UnsubscribeMultiMsg)
	OnCallReducer                         func(ctx context.Context, conn *Conn, msg *CallReducerMsg)
	OnOneOffQuery                         func(ctx context.Context, conn *Conn, msg *OneOffQueryMsg)
	OnDeclaredQuery                       func(ctx context.Context, conn *Conn, msg *DeclaredQueryMsg)
	OnDeclaredQueryWithParameters         func(ctx context.Context, conn *Conn, msg *DeclaredQueryWithParametersMsg)
	OnCallProcedure                       func(ctx context.Context, conn *Conn, msg *CallProcedureMsg)
	OnSubscribeDeclaredView               func(ctx context.Context, conn *Conn, msg *SubscribeDeclaredViewMsg)
	OnSubscribeDeclaredViewWithParameters func(ctx context.Context, conn *Conn, msg *SubscribeDeclaredViewWithParametersMsg)
}

// sendError encodes a server message, wraps it in the connection's
// compression envelope, and pushes it to the outbound queue. On outbound
// overflow it uses the same lifecycle-bound disconnect policy as the other
// local response paths.
func sendError(conn *Conn, msg any) error {
	if err := (connOnlySender{conn: conn}).Send(conn.ID, msg); err != nil {
		if errors.Is(err, ErrClientBufferFull) || errors.Is(err, ErrConnNotFound) {
			return err
		}
		logProtocolError(conn.Observer, "unknown", "encode_failed", err)
		return err
	}
	return nil
}

// closeProtocolError requests a status-1002 teardown from the lifecycle
// supervisor. Disconnect remains the sole owner of the close handshake.
func closeProtocolError(conn *Conn, reason string) {
	logProtocolError(conn.Observer, "unknown", protocolErrorReason(reason), errorFromText(reason))
	conn.requestDisconnect(CloseProtocol, reason)
}

// runDispatchLoop reads frames, decodes messages, and dispatches handlers.
// Handler contexts cancel at the inbound barrier, before executor cleanup,
// while c.closed remains the later writer/socket shutdown signal.
func (c *Conn) runDispatchLoop(ctx context.Context, handlers *MessageHandlers) {
	if handlers == nil {
		handlers = &MessageHandlers{}
	}

	readCtx := ctx
	if c.readCtx != nil {
		combinedCtx, cancel := context.WithCancel(ctx)
		defer cancel()
		go func() {
			select {
			case <-c.readCtx.Done():
				cancel()
			case <-combinedCtx.Done():
			}
		}()
		readCtx = combinedCtx
	}
	handlerCtx, handlerCancel := context.WithCancel(ctx)
	defer handlerCancel()
	go func() {
		select {
		case <-c.inboundDone():
			handlerCancel()
		case <-c.closed:
			handlerCancel()
		case <-handlerCtx.Done():
		}
	}()

	for {
		select {
		case <-ctx.Done():
			return
		case <-c.inboundDone():
			return
		case <-c.closed:
			return
		default:
		}

		typ, frame, err := c.ws.Read(readCtx)
		if err != nil {
			return
		}
		select {
		case <-c.inboundDone():
			return
		default:
		}

		// Reject text frames per SPEC-005 S3.2.
		if typ == websocket.MessageText {
			recordProtocolMessage(c.Observer, "unknown", "malformed")
			closeProtocolError(c, CloseReasonTextFrameUnsupported)
			return
		}
		c.MarkActivity()

		var (
			msg       any
			decodeErr error
			kind      = "unknown"
		)
		if len(frame) > 0 {
			kind = protocolKindFromTag(frame[0])
		}
		_, msg, decodeErr = DecodeClientMessageForVersion(c.ProtocolVersion, frame)
		if decodeErr != nil {
			reason := decodeErr.Error()
			recordProtocolMessage(c.Observer, kind, "malformed")
			closeProtocolError(c, reason)
			return
		}
		kind = protocolKindFromMessage(msg)

		var run func()
		switch m := msg.(type) {
		case SubscribeSingleMsg:
			if h := handlers.OnSubscribeSingle; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case SubscribeMultiMsg:
			if h := handlers.OnSubscribeMulti; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case UnsubscribeSingleMsg:
			if h := handlers.OnUnsubscribeSingle; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case UnsubscribeMultiMsg:
			if h := handlers.OnUnsubscribeMulti; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case CallReducerMsg:
			if h := handlers.OnCallReducer; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case OneOffQueryMsg:
			if h := handlers.OnOneOffQuery; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case DeclaredQueryMsg:
			if h := handlers.OnDeclaredQuery; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case DeclaredQueryWithParametersMsg:
			if h := handlers.OnDeclaredQueryWithParameters; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case CallProcedureMsg:
			if h := handlers.OnCallProcedure; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case SubscribeDeclaredViewMsg:
			if h := handlers.OnSubscribeDeclaredView; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		case SubscribeDeclaredViewWithParametersMsg:
			if h := handlers.OnSubscribeDeclaredViewWithParameters; h != nil {
				run = func() { h(handlerCtx, c, &m) }
			}
		}
		if run == nil {
			recordProtocolMessage(c.Observer, kind, "internal_error")
			closeProtocolError(c, CloseReasonUnsupportedMessage)
			return
		}

		// Incoming backpressure (SPEC-005 §10.2, Story 6.2):
		// non-blocking acquire on the inflight semaphore. If full,
		// the client is flooding faster than we can process —
		// close with 1008.
		select {
		case <-c.inboundDone():
			return
		case c.inflightSem <- struct{}{}:
		default:
			logProtocolBackpressure(c.Observer, "inbound", "buffer_full")
			c.requestDisconnect(ClosePolicy, CloseReasonTooManyRequests)
			return
		}
		if !c.beginInboundHandler() {
			<-c.inflightSem
			return
		}

		go c.runMessageHandler(kind, run)
	}
}

func (c *Conn) runMessageHandler(kind string, run func()) {
	defer c.finishInboundHandler()
	defer func() { <-c.inflightSem }()
	defer func() {
		if recovered := recover(); recovered != nil {
			err := fmt.Errorf("protocol handler panic: %v", recovered)
			recordProtocolMessage(c.Observer, kind, "internal_error")
			logProtocolError(c.Observer, kind, "handler_panic", err)
			c.requestDisconnect(CloseInternal, "internal error")
		}
	}()
	run()
}
