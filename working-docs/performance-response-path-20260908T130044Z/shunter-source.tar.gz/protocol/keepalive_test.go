package protocol

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/ponchione/websocket"

	"github.com/ponchione/shunter/types"
)

// loopbackConn pairs a server-side *Conn with a client-side
// *websocket.Conn via an httptest.Server. The returned cleanup immediately
// closes both ends; tests whose oracle includes a graceful close handshake
// perform that handshake explicitly before cleanup.
func loopbackConn(t testing.TB, opts ProtocolOptions) (*Conn, *websocket.Conn, func()) {
	t.Helper()
	serverReady := make(chan *websocket.Conn, 1)
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ws, err := websocket.Accept(w, r, nil)
		if err != nil {
			t.Errorf("accept: %v", err)
			return
		}
		serverReady <- ws
	})
	srv := httptest.NewServer(handler)
	t.Cleanup(srv.Close)

	u := strings.Replace(srv.URL, "http://", "ws://", 1)
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	clientWS, _, err := websocket.Dial(ctx, u, nil)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}

	var serverWS *websocket.Conn
	select {
	case serverWS = <-serverReady:
	case <-time.After(2 * time.Second):
		t.Fatal("server-side ws not ready")
	}

	id := GenerateConnectionID()
	conn := NewConn(id, types.Identity{}, "", false, serverWS, &opts)
	var cleanupOnce sync.Once
	cleanup := func() {
		cleanupOnce.Do(func() {
			_ = clientWS.CloseNow()
			_ = serverWS.CloseNow()
		})
	}
	return conn, clientWS, cleanup
}

// runKeepaliveAsync starts runKeepalive on a background goroutine and
// returns a done-signal channel the caller can wait on.
func runKeepaliveAsync(c *Conn, ctx context.Context) chan struct{} {
	done := make(chan struct{})
	go func() {
		c.runKeepalive(ctx)
		close(done)
	}()
	return done
}

func waitForActivityAfter(t *testing.T, c *Conn, after int64, label string) int64 {
	t.Helper()
	tick := time.NewTicker(time.Millisecond)
	defer tick.Stop()
	deadline := time.After(2 * time.Second)
	for {
		got := c.lastActivity.Load()
		if got > after {
			return got
		}
		select {
		case <-tick.C:
		case <-deadline:
			t.Fatalf("%s: lastActivity = %d, want > %d", label, got, after)
		}
	}
}

func TestKeepaliveReturnsOnCtxCancel(t *testing.T) {
	opts := DefaultProtocolOptions()
	opts.PingInterval = 2 * time.Second // so no tick fires during the test
	opts.IdleTimeout = 4 * time.Second
	c, _, cleanup := loopbackConn(t, opts)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	done := runKeepaliveAsync(c, ctx)

	cancel()
	select {
	case <-done:
	case <-time.After(500 * time.Millisecond):
		t.Fatal("runKeepalive did not return on ctx cancel")
	}
}

func TestKeepaliveReturnsOnClosedChan(t *testing.T) {
	opts := DefaultProtocolOptions()
	opts.PingInterval = 2 * time.Second
	opts.IdleTimeout = 4 * time.Second
	c, _, cleanup := loopbackConn(t, opts)
	defer cleanup()

	done := runKeepaliveAsync(c, context.Background())
	close(c.closed)

	select {
	case <-done:
	case <-time.After(500 * time.Millisecond):
		t.Fatal("runKeepalive did not return on closed channel")
	}
}

func TestKeepaliveMarksActivityOnPongFromResponsiveClient(t *testing.T) {
	opts := DefaultProtocolOptions()
	opts.PingInterval = 30 * time.Millisecond
	opts.IdleTimeout = 150 * time.Millisecond
	c, clientWS, cleanup := loopbackConn(t, opts)
	defer cleanup()

	// Drive the client's read side so coder/websocket internal
	// bookkeeping processes Ping frames and answers with Pong. The
	// read goroutine stops once we cancel the ctx at test end.
	clientReadCtx, clientReadCancel := context.WithCancel(context.Background())
	var readerWG sync.WaitGroup
	readerWG.Add(1)
	go func() {
		defer readerWG.Done()
		for {
			if _, _, err := clientWS.Read(clientReadCtx); err != nil {
				return
			}
		}
	}()

	start := time.Now().UnixNano()

	ctx, cancel := context.WithCancel(context.Background())
	// Story 3.5 needs BOTH goroutines: runDispatchLoop consumes control
	// frames so Ping(ctx) can complete; runKeepalive fires the Ping.
	handlers := &MessageHandlers{}
	pumpDone := runDispatchAsync(c, ctx, handlers)
	kaDone := runKeepaliveAsync(c, ctx)

	waitForActivityAfter(t, c, start, "Pong-driven activity")
	select {
	case <-kaDone:
		t.Fatal("runKeepalive closed a responsive connection after its initial idle deadline")
	case <-time.After(3 * opts.IdleTimeout):
	}

	cancel()
	clientReadCancel()
	<-kaDone
	<-pumpDone
	readerWG.Wait()
}

func TestKeepaliveIdleTimeoutIsIndependentOfPingInterval(t *testing.T) {
	opts := DefaultProtocolOptions()
	opts.PingInterval = 500 * time.Millisecond
	opts.IdleTimeout = 50 * time.Millisecond
	c, _, cleanup := loopbackConn(t, opts)
	defer cleanup()

	done := runKeepaliveAsync(c, context.Background())
	select {
	case <-done:
	case <-time.After(250 * time.Millisecond):
		t.Fatal("idle timeout did not fire before the later ping tick")
	}
}

func TestKeepaliveActivityBetweenPingTicksMovesIdleDeadline(t *testing.T) {
	opts := DefaultProtocolOptions()
	opts.PingInterval = time.Second
	opts.IdleTimeout = 200 * time.Millisecond
	c, _, cleanup := loopbackConn(t, opts)
	defer cleanup()

	done := runKeepaliveAsync(c, context.Background())
	time.Sleep(75 * time.Millisecond)
	c.MarkActivity()

	select {
	case <-done:
		t.Fatal("idle timeout ignored activity observed between ping ticks")
	case <-time.After(150 * time.Millisecond):
	}
	select {
	case <-done:
	case <-time.After(250 * time.Millisecond):
		t.Fatal("idle timeout did not fire at the activity-adjusted deadline")
	}
}

func TestKeepaliveClosesIdleConnection(t *testing.T) {
	opts := DefaultProtocolOptions()
	opts.PingInterval = 30 * time.Millisecond
	opts.IdleTimeout = 120 * time.Millisecond
	c, clientWS, cleanup := loopbackConn(t, opts)
	defer cleanup()
	runRequestedDisconnectOwner(c)

	// Client does NOT read. With coder/websocket, Pong replies flow
	// through the peer's read loop — if the client never reads, Pings
	// pile up unanswered and the server's Ping(ctx) times out. After
	// IdleTimeout elapses with no activity, runKeepalive must close.

	ctx := context.Background()
	done := runKeepaliveAsync(c, ctx)

	select {
	case <-done:
	case <-time.After(1 * time.Second):
		t.Fatal("runKeepalive did not close idle connection within the expected window")
	}

	// Client observes the policy-violation close.
	readCtx, readCancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer readCancel()
	_, _, err := clientWS.Read(readCtx)
	if err == nil {
		t.Fatal("client expected a close frame on idle timeout")
	}
	if code := websocket.CloseStatus(err); code != websocket.StatusPolicyViolation {
		t.Errorf("close code = %d, want %d (StatusPolicyViolation)", code, websocket.StatusPolicyViolation)
	}
}

func TestDispatchLoopMarksActivityOnInboundFrame(t *testing.T) {
	opts := DefaultProtocolOptions()
	c, clientWS, cleanup := loopbackConn(t, opts)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	handled := make(chan struct{})
	handlers := &MessageHandlers{
		OnSubscribeSingle: func(_ context.Context, _ *Conn, _ *SubscribeSingleMsg) {
			close(handled)
		},
	}
	pumpDone := runDispatchAsync(c, ctx, handlers)

	c.lastActivity.Store(1)
	before := c.lastActivity.Load()

	// Client sends a valid Subscribe frame. The dispatch loop routes it
	// and must still MarkActivity before handler dispatch.
	frame, err := EncodeClientMessage(SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     1,
		QueryString: "SELECT * FROM events",
	})
	if err != nil {
		t.Fatalf("encode subscribe: %v", err)
	}
	writeCtx, writeCancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer writeCancel()
	if err := clientWS.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-handled:
	case <-time.After(500 * time.Millisecond):
		t.Fatal("dispatch loop did not invoke subscribe handler")
	}
	if c.lastActivity.Load() <= before {
		t.Errorf("MarkActivity was not called on inbound frame (before=%d, after=%d)",
			before, c.lastActivity.Load())
	}

	cancel()
	<-pumpDone
}

func TestDispatchLoopExitsOnReadError(t *testing.T) {
	opts := DefaultProtocolOptions()
	c, clientWS, cleanup := loopbackConn(t, opts)
	defer cleanup()

	handlers := &MessageHandlers{}
	pumpDone := runDispatchAsync(c, context.Background(), handlers)

	// Client closes. Server Read returns an error; dispatch loop must exit.
	_ = clientWS.Close(websocket.StatusNormalClosure, "")

	select {
	case <-pumpDone:
	case <-time.After(1 * time.Second):
		t.Fatal("runDispatchLoop did not exit on peer close")
	}
}

func TestMarkActivityUpdatesTimestamp(t *testing.T) {
	opts := DefaultProtocolOptions()
	c, _, cleanup := loopbackConn(t, opts)
	defer cleanup()

	c.lastActivity.Store(1)
	c.MarkActivity()
	if got := c.lastActivity.Load(); got < time.Now().Add(-time.Second).UnixNano() {
		t.Errorf("MarkActivity did not update lastActivity (got %d)", got)
	}
}
