package protocol

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/ponchione/websocket"

	"github.com/ponchione/shunter/types"
)

// testConnPair creates a httptest server with websocket.Accept, dials
// from the client side, and wraps the server conn in a *Conn. Returns
// the server *Conn and client *websocket.Conn.
func testConnPair(t *testing.T, opts *ProtocolOptions) (*Conn, *websocket.Conn) {
	t.Helper()
	if opts == nil {
		o := DefaultProtocolOptions()
		opts = &o
	}
	var serverConn *websocket.Conn
	ready := make(chan struct{})
	release := make(chan struct{})
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, err := websocket.Accept(w, r, nil)
		if err != nil {
			t.Errorf("accept: %v", err)
			return
		}
		defer c.CloseNow()
		serverConn = c
		close(ready)
		<-release
	}))
	t.Cleanup(srv.Close)
	t.Cleanup(func() { close(release) })

	ctx := context.Background()
	client, _, err := websocket.Dial(ctx, srv.URL, nil)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	t.Cleanup(func() { client.CloseNow() })

	select {
	case <-ready:
	case <-time.After(2 * time.Second):
		t.Fatal("timed out waiting for server accept")
	}

	conn := NewConn(GenerateConnectionID(), [32]byte{1}, "test-token", false, serverConn, opts)
	return conn, client
}

// runDispatchAsync starts runDispatchLoop in a background goroutine and
// returns a channel that closes when the loop exits.
func runDispatchAsync(c *Conn, ctx context.Context, handlers *MessageHandlers) chan struct{} {
	done := make(chan struct{})
	go func() {
		c.runDispatchLoop(ctx, handlers)
		close(done)
	}()
	return done
}

func TestDispatchLoop_ValidSubscribe(t *testing.T) {
	conn, client := testConnPair(t, nil)

	var mu sync.Mutex
	var gotQueryID uint32
	called := make(chan struct{})

	handlers := &MessageHandlers{
		OnSubscribeSingle: func(ctx context.Context, c *Conn, msg *SubscribeSingleMsg) {
			mu.Lock()
			gotQueryID = msg.QueryID
			mu.Unlock()
			close(called)
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	// Build and send a valid Subscribe frame.
	subMsg := SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     42,
		QueryString: "SELECT * FROM users",
	}
	frame, err := EncodeClientMessage(subMsg)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-called:
	case <-time.After(2 * time.Second):
		t.Fatal("OnSubscribe was not called within timeout")
	}

	mu.Lock()
	if gotQueryID != 42 {
		t.Errorf("QueryID = %d, want 42", gotQueryID)
	}
	mu.Unlock()

	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("dispatch loop did not exit after cancel")
	}
}

func TestDispatchLoop_HandlerPanicClosesInternal(t *testing.T) {
	conn, client := testConnPair(t, nil)
	runRequestedDisconnectOwner(conn)

	handlers := &MessageHandlers{
		OnSubscribeSingle: func(context.Context, *Conn, *SubscribeSingleMsg) {
			panic("handler boom")
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	frame, err := EncodeClientMessage(SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     42,
		QueryString: "SELECT * FROM users",
	})
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit after handler panic")
	}

	readCtx, readCancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer readCancel()
	_, _, readErr := client.Read(readCtx)
	if code := websocket.CloseStatus(readErr); code != CloseInternal {
		t.Errorf("close code = %d, want %d (CloseInternal)", code, CloseInternal)
	}
}

func TestDispatchLoop_V2DeclaredQueryWithParameters(t *testing.T) {
	conn, client := testConnPair(t, nil)
	conn.ProtocolVersion = ProtocolVersionV2

	called := make(chan DeclaredQueryWithParametersMsg, 1)
	handlers := &MessageHandlers{
		OnDeclaredQueryWithParameters: func(ctx context.Context, c *Conn, msg *DeclaredQueryWithParametersMsg) {
			called <- *msg
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	want := DeclaredQueryWithParametersMsg{
		MessageID: []byte{0x01},
		Name:      "messages_by_body",
		Params:    []byte{0x0b, 0x05, 0, 0, 0, 'a', 'l', 'p', 'h', 'a'},
	}
	frame, err := EncodeClientMessage(want)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case got := <-called:
		if got.Name != want.Name || string(got.MessageID) != string(want.MessageID) || string(got.Params) != string(want.Params) {
			t.Fatalf("handler msg = %+v, want %+v", got, want)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("OnDeclaredQueryWithParameters was not called within timeout")
	}

	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("dispatch loop did not exit after cancel")
	}
}

func TestDispatchLoop_V1RejectsV2DeclaredReadTag(t *testing.T) {
	conn, client := testConnPair(t, nil)
	conn.ProtocolVersion = ProtocolVersionV1

	called := make(chan struct{}, 1)
	handlers := &MessageHandlers{
		OnDeclaredQueryWithParameters: func(ctx context.Context, c *Conn, msg *DeclaredQueryWithParametersMsg) {
			called <- struct{}{}
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	frame, err := EncodeClientMessage(DeclaredQueryWithParametersMsg{
		MessageID: []byte{0x01},
		Name:      "messages_by_body",
		Params:    []byte{0x01},
	})
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-called:
		t.Fatal("V1 dispatch called V2-only handler")
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on V2-only tag for V1 connection")
	}
}

func TestDispatchLoop_CompressionNegotiatedAcceptsPlainClientMessage(t *testing.T) {
	conn, client := testConnPair(t, nil)
	conn.Compression = true

	called := make(chan struct{})
	handlers := &MessageHandlers{
		OnSubscribeSingle: func(ctx context.Context, c *Conn, msg *SubscribeSingleMsg) {
			if msg.QueryID != 42 {
				t.Errorf("QueryID = %d, want 42", msg.QueryID)
			}
			close(called)
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	frame, err := EncodeClientMessage(SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     42,
		QueryString: "SELECT * FROM users",
	})
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-called:
	case <-time.After(2 * time.Second):
		t.Fatal("OnSubscribe was not called for plain client frame")
	}

	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("dispatch loop did not exit after cancel")
	}
}

func TestDispatchLoop_TextFrameCloses(t *testing.T) {
	conn, client := testConnPair(t, nil)
	runRequestedDisconnectOwner(conn)

	handlers := &MessageHandlers{
		OnSubscribeSingle: func(ctx context.Context, c *Conn, msg *SubscribeSingleMsg) {
			t.Error("OnSubscribe should not be called for text frame")
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	// Send a text frame; dispatch should close with 1002.
	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageText, []byte("hello")); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on text frame")
	}

	// Verify client received 1002 close code.
	readCtx, rCancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer rCancel()
	_, _, readErr := client.Read(readCtx)
	if code := websocket.CloseStatus(readErr); code != websocket.StatusProtocolError {
		t.Errorf("close code = %d, want %d (StatusProtocolError)", code, websocket.StatusProtocolError)
	}
}

func TestDispatchLoop_UnknownTagCloses(t *testing.T) {
	conn, client := testConnPair(t, nil)
	runRequestedDisconnectOwner(conn)

	handlers := &MessageHandlers{}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	// Send a binary frame with unknown tag 0xFF.
	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, []byte{0xFF, 0x00, 0x00}); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on unknown tag")
	}
}

func TestDispatchLoop_UnknownTagLogsDetail(t *testing.T) {
	conn, client := testConnPair(t, nil)
	observer := &recordingProtocolObserver{}
	conn.Observer = observer

	handlers := &MessageHandlers{}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, []byte{0xFF, 0x00, 0x00}); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on unknown tag")
	}

	if len(observer.protocolErrors) != 1 {
		t.Fatalf("protocol errors = %+v, want one", observer.protocolErrors)
	}
	got := observer.protocolErrors[0]
	if got.kind != "unknown" || got.reason != "malformed" {
		t.Fatalf("protocol error = %+v, want unknown/malformed", got)
	}
	if got.err == nil || !strings.Contains(got.err.Error(), "unknown message tag") {
		t.Fatalf("protocol error = %+v, want unknown message tag error", got)
	}
}

type protocolErrorRecord struct {
	kind   string
	reason string
	err    error
}

type recordingProtocolObserver struct {
	protocolErrors []protocolErrorRecord
}

func (o *recordingProtocolObserver) RecordProtocolConnections(int)                          {}
func (o *recordingProtocolObserver) RecordProtocolMessage(string, string)                   {}
func (o *recordingProtocolObserver) LogProtocolConnectionRejected(string, error)            {}
func (o *recordingProtocolObserver) LogProtocolConnectionOpened(types.ConnectionID)         {}
func (o *recordingProtocolObserver) LogProtocolConnectionClosed(types.ConnectionID, string) {}
func (o *recordingProtocolObserver) LogProtocolProtocolError(kind, reason string, err error) {
	o.protocolErrors = append(o.protocolErrors, protocolErrorRecord{kind: kind, reason: reason, err: err})
}
func (o *recordingProtocolObserver) LogProtocolAuthFailed(string, error)    {}
func (o *recordingProtocolObserver) LogProtocolBackpressure(string, string) {}

func TestDispatchLoop_NilHandlerCloses(t *testing.T) {
	conn, client := testConnPair(t, nil)
	runRequestedDisconnectOwner(conn)

	// All handler fields are nil.
	handlers := &MessageHandlers{}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	// Send a valid Subscribe frame — but OnSubscribe is nil.
	subMsg := SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     10,
		QueryString: "SELECT * FROM items",
	}
	frame, err := EncodeClientMessage(subMsg)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on nil handler")
	}
}

func TestDispatchLoop_NilHandlersCloses(t *testing.T) {
	conn, client := testConnPair(t, nil)
	runRequestedDisconnectOwner(conn)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, nil)

	frame, err := EncodeClientMessage(SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     10,
		QueryString: "SELECT * FROM items",
	})
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on nil handlers")
	}
}

func TestDispatchLoop_MalformedBodyCloses(t *testing.T) {
	conn, client := testConnPair(t, nil)
	runRequestedDisconnectOwner(conn)

	handlers := &MessageHandlers{
		OnSubscribeSingle: func(ctx context.Context, c *Conn, msg *SubscribeSingleMsg) {
			t.Error("OnSubscribe should not be called for malformed body")
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := runDispatchAsync(conn, ctx, handlers)

	// Valid Subscribe tag but truncated body (only 2 bytes after tag).
	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, []byte{TagSubscribeSingle, 0x01, 0x02}); err != nil {
		t.Fatalf("client write: %v", err)
	}

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("dispatch loop did not exit on malformed body")
	}
}

func TestDispatchLoop_MarksActivity(t *testing.T) {
	conn, client := testConnPair(t, nil)

	handled := make(chan struct{})
	handlers := &MessageHandlers{
		OnSubscribeSingle: func(ctx context.Context, c *Conn, msg *SubscribeSingleMsg) {
			close(handled)
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	conn.lastActivity.Store(1)
	before := conn.lastActivity.Load()

	done := runDispatchAsync(conn, ctx, handlers)

	subMsg := SubscribeSingleMsg{
		RequestID:   1,
		QueryID:     7,
		QueryString: "SELECT * FROM events",
	}
	frame, err := EncodeClientMessage(subMsg)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	writeCtx, writeCancel := context.WithTimeout(context.Background(), time.Second)
	defer writeCancel()
	if err := client.Write(writeCtx, websocket.MessageBinary, frame); err != nil {
		t.Fatalf("client write: %v", err)
	}

	// Wait for handler to fire so we know Read completed.
	select {
	case <-handled:
	case <-time.After(2 * time.Second):
		t.Fatal("handler not called within timeout")
	}

	after := conn.lastActivity.Load()
	if after <= before {
		t.Errorf("lastActivity not updated: before=%d after=%d", before, after)
	}

	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("dispatch loop did not exit after cancel")
	}
}
