package protocol

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/ponchione/websocket"

	"github.com/ponchione/shunter/auth"
	"github.com/ponchione/shunter/types"
)

// Server is the HTTP-level entry point for WebSocket upgrades. One
// Server serves many concurrent connections; HandleSubscribe is
// routed from `/subscribe` by the host application.
type Server struct {
	// JWT configures token validation. Required. AuthMode determines
	// whether missing tokens are rejected during protocol admission
	// (Strict) or converted to a fresh anonymous identity (Anonymous).
	JWT *auth.JWTConfig
	// JWTValidator optionally supplies lifecycle-owned remote auth caches. When
	// nil, HandleSubscribe uses auth.ValidateJWTContext with its bounded
	// compatibility cache.
	JWTValidator *auth.Validator
	// Mint is required only when JWT.AuthMode == AuthModeAnonymous.
	// Its fields control the issuer/audience/expiry of tokens the
	// server generates for anonymous connections.
	Mint *auth.MintConfig
	// Options tunes transport-layer behavior. DefaultProtocolOptions()
	// supplies SPEC-005 §12 defaults.
	Options ProtocolOptions
	// Executor is the lifecycle seam used by the default Upgraded
	// handler to run OnConnect and emit IdentityToken (Story 3.4).
	// When non-nil AND Conns is non-nil AND Upgraded is nil, the
	// handler drives Conn.RunLifecycle for every admitted upgrade.
	Executor ExecutorInbox
	// Conns tracks currently admitted connections. Required whenever
	// Executor is set so RunLifecycle can register the admitted
	// connection before the first server message is sent.
	Conns *ConnManager
	// Schema provides table name→ID resolution for Subscribe and
	// OneOffQuery handlers. Required for dispatch to work.
	Schema SchemaLookup
	// State provides read-only snapshot access for OneOffQuery.
	// Required for OneOffQuery to work.
	State CommittedStateAccess
	// SQLQueryLimits bounds raw one-off query results and multi-way-join work.
	// Zero values use hosted defaults. Declared-read implementations own their
	// corresponding limits.
	SQLQueryLimits SQLQueryLimits
	// SubscriptionLimits bounds protocol-edge subscription request work.
	SubscriptionLimits SubscriptionLimits
	// DeclaredReads handles named QueryDeclaration and ViewDeclaration
	// protocol messages. Raw SQL handlers remain wired through Schema/State
	// and Executor; declared reads use this explicit name-based surface.
	DeclaredReads DeclaredReadHandler
	// Procedures handles named Procedure declarations.
	Procedures ProcedureHandler
	// VisibilityFilters are row-level filters expanded into raw external SQL
	// predicates after table-read admission and before execution/registration.
	VisibilityFilters []VisibilityFilter
	// Upgraded, when non-nil, overrides the built-in lifecycle and is
	// called immediately after the WebSocket handshake completes. It
	// is the extension point for tests that want to bypass OnConnect
	// and for advanced hosts that want custom admission semantics.
	Upgraded func(ctx context.Context, uc *UpgradeContext)
	// Observer receives runtime-scoped protocol observations.
	Observer Observer
}

// DeclaredReadHandler is the protocol/server seam for module-owned declared
// reads. Implementations receive the declaration name from the client message.
type DeclaredReadHandler interface {
	HandleDeclaredQuery(ctx context.Context, conn *Conn, msg *DeclaredQueryMsg)
	HandleDeclaredQueryWithParameters(ctx context.Context, conn *Conn, msg *DeclaredQueryWithParametersMsg)
	HandleSubscribeDeclaredView(ctx context.Context, conn *Conn, msg *SubscribeDeclaredViewMsg)
	HandleSubscribeDeclaredViewWithParameters(ctx context.Context, conn *Conn, msg *SubscribeDeclaredViewWithParametersMsg)
}

// UpgradeContext is the per-connection package that the upgrade
// handler hands to the lifecycle layer. Stories 3.3/3.4 consume
// the Identity + ConnectionID + Token + Compression mode.
type UpgradeContext struct {
	Conn                *websocket.Conn
	ProtocolVersion     ProtocolVersion
	Identity            types.Identity
	ConnectionID        types.ConnectionID
	Principal           types.AuthPrincipal
	Permissions         []string
	AllowAllPermissions bool
	// Token is the minted anonymous JWT when the server minted one
	// during upgrade. Empty for strict-mode connections that
	// presented a token.
	Token       string
	Compression uint8
	// Claims is the validated claim set when the client presented a
	// token. nil when the server minted anonymously.
	Claims *auth.Claims
}

const (
	authRejectedUnavailable  = "authentication unavailable"
	authRejectedInvalidToken = "invalid token"
	authRejectedMissingToken = "missing token"
)

var errMalformedAuthorizationHeader = errors.New("malformed Authorization header")

// HandleSubscribe is the net/http handler for the `/subscribe`
// endpoint (SPEC-005 §2.3). It authenticates, validates request
// parameters, upgrades the connection, and hands control to s.Upgraded.
func (s *Server) HandleSubscribe(w http.ResponseWriter, r *http.Request) {
	if s == nil || s.JWT == nil {
		err := errors.New("server misconfigured: JWT config is required")
		s.writeAuthRejected(w, authRejectedUnavailable, http.StatusInternalServerError, "jwt_misconfigured", err)
		return
	}
	options, err := NormalizeProtocolOptions(s.Options)
	if err != nil {
		s.writeRejected(w, "invalid protocol options: "+err.Error(), http.StatusInternalServerError, "rejected_internal", err)
		return
	}
	queryLimits, err := NormalizeSQLQueryLimits(s.SQLQueryLimits)
	if err != nil {
		s.writeRejected(w, "invalid SQL query limits: "+err.Error(), http.StatusInternalServerError, "rejected_internal", err)
		return
	}
	subscriptionLimits, err := NormalizeSubscriptionLimits(s.SubscriptionLimits)
	if err != nil {
		s.writeRejected(w, "invalid subscription limits: "+err.Error(), http.StatusInternalServerError, "rejected_internal", err)
		return
	}

	// 1. Auth — strict requires a token, anonymous mints on absence.
	var authRejectionReason string
	var authRejectionErr error
	token, hasToken, err := extractToken(r)
	if err != nil {
		s.writeAuthRejected(w, authRejectedInvalidToken, http.StatusUnauthorized, "invalid_token", err)
		return
	}
	var claims *auth.Claims
	var mintedToken string
	var identity types.Identity
	var principal types.AuthPrincipal
	var permissions []string
	if hasToken {
		var c *auth.Claims
		var err error
		if s.JWTValidator != nil {
			c, err = s.JWTValidator.ValidateJWT(r.Context(), token)
		} else {
			c, err = auth.ValidateJWTContext(r.Context(), token, s.JWT)
		}
		if err != nil {
			authRejectionReason = "invalid_token"
			authRejectionErr = err
		} else {
			claims = c
			identity = c.DeriveIdentity()
			principal = c.Principal()
			permissions = append([]string(nil), c.Permissions...)
		}
	} else {
		if s.JWT.AuthMode != auth.AuthModeAnonymous {
			err := errors.New("no token and strict auth enabled")
			authRejectionReason = "missing_token"
			authRejectionErr = err
		} else {
			if s.Mint == nil {
				err := errors.New("server misconfigured: anonymous mode requires Mint config")
				s.writeAuthRejected(w, authRejectedUnavailable, http.StatusInternalServerError, "mint_misconfigured", err)
				return
			}
			mt, id, err := auth.MintAnonymousToken(s.Mint)
			if err != nil {
				s.writeAuthRejected(w, authRejectedUnavailable, http.StatusInternalServerError, "mint_failed", err)
				return
			}
			mintedToken = mt
			identity = id
		}
	}
	allowAllPermissions := !hasToken && s.JWT.AuthMode == auth.AuthModeAnonymous

	if authRejectionErr != nil {
		selected, _, ok := negotiateSubprotocol(r, SupportedSubprotocols())
		if !ok {
			s.writeRejected(w,
				"Sec-WebSocket-Protocol must include one of "+strings.Join(SupportedSubprotocols(), ", "),
				http.StatusBadRequest,
				"rejected_upgrade",
				errors.New("missing required subprotocol"))
			return
		}
		conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
			Subprotocols: []string{selected},
		})
		if err != nil {
			s.recordRejected("rejected_upgrade", err)
			return
		}
		s.closeAuthRejected(conn, authRejectionReason, authRejectionErr, options.CloseHandshakeTimeout)
		return
	}

	// 2. connection_id: parse / generate / reject zero.
	connID, err := resolveConnectionID(r.URL.Query().Get("connection_id"))
	if err != nil {
		if errors.Is(err, ErrZeroConnectionID) {
			s.writeRejected(w, err.Error(), http.StatusBadRequest, "rejected_upgrade", err)
			return
		}
		s.writeRejected(w, "invalid connection_id: "+err.Error(), http.StatusBadRequest, "rejected_upgrade", err)
		return
	}

	// 3. compression mode: default none; reject unknown values.
	compression, err := parseCompressionParam(r.URL.Query().Get("compression"))
	if err != nil {
		s.writeRejected(w, err.Error(), http.StatusBadRequest, "rejected_upgrade", err)
		return
	}

	// 4. subprotocol check — client MUST offer a supported Shunter token.
	selected, version, ok := negotiateSubprotocol(r, SupportedSubprotocols())
	if !ok {
		s.writeRejected(w,
			"Sec-WebSocket-Protocol must include one of "+strings.Join(SupportedSubprotocols(), ", "),
			http.StatusBadRequest,
			"rejected_upgrade",
			errors.New("missing required subprotocol"))
		return
	}

	// 5. Upgrade.
	conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
		Subprotocols: []string{selected},
	})
	if err != nil {
		// websocket.Accept has already written an HTTP response at
		// this point; nothing further to emit.
		s.recordRejected("rejected_upgrade", err)
		return
	}
	if options.MaxMessageSize > 0 {
		conn.SetReadLimit(options.MaxMessageSize)
	}

	// 6. Hand off.
	uc := &UpgradeContext{
		Conn:                conn,
		ProtocolVersion:     version,
		Identity:            identity,
		ConnectionID:        connID,
		Principal:           principal.Copy(),
		Permissions:         append([]string(nil), permissions...),
		AllowAllPermissions: allowAllPermissions,
		Token:               mintedToken,
		Compression:         compression,
		Claims:              claims,
	}
	if s.Upgraded != nil {
		s.Upgraded(r.Context(), uc)
		return
	}
	if s.Executor != nil && s.Conns != nil {
		c := NewConn(
			uc.ConnectionID,
			uc.Identity,
			uc.Token,
			uc.Compression == CompressionGzip,
			uc.Conn,
			&options,
		)
		c.ProtocolVersion = uc.ProtocolVersion
		c.Principal = uc.Principal.Copy()
		c.Permissions = append([]string(nil), uc.Permissions...)
		c.AllowAllPermissions = uc.AllowAllPermissions
		c.Observer = s.Observer
		// RunLifecycle closes the socket on its own failure paths; on
		// success it leaves the socket open for the background
		// goroutines below. Story 3.6 (Disconnect) closes c.closed,
		// unblocking them all; until 3.6 lands, the goroutines exit
		// naturally on ws error when the peer closes.
		if err := c.RunLifecycle(r.Context(), s.Executor, s.Conns); err != nil {
			result := "rejected_internal"
			if errors.Is(err, ErrExecutorAdmissionRejected) {
				result = "rejected_executor"
			} else if errors.Is(err, ErrConnectionIDInUse) {
				result = "rejected_connection_id"
			}
			s.recordRejected(result, err)
			return
		}
		// Spawn per-connection lifecycle goroutines. They outlive
		// this HTTP handler; the supervisor invokes Disconnect when
		// the first of them exits (peer close, idle timeout, ws
		// error), which drives the SPEC-005 §5.3 teardown once.
		dispatchDone := make(chan struct{})
		keepaliveDone := make(chan struct{})
		handlers := s.buildMessageHandlersWithLimits(queryLimits, subscriptionLimits)
		go func() {
			c.runDispatchLoop(context.Background(), handlers)
			close(dispatchDone)
		}()
		go func() {
			c.runKeepalive(context.Background())
			close(keepaliveDone)
		}()
		// Outbound writer goroutine drains OutboundCh → WebSocket.
		// It exits when Disconnect closes c.closed.
		outboundDone := make(chan struct{})
		go func() {
			c.runOutboundWriter(context.Background())
			close(outboundDone)
		}()
		go c.superviseLifecycle(context.Background(), websocket.StatusNormalClosure, "", s.Executor, s.Conns, dispatchDone, keepaliveDone, outboundDone)
		return
	}
	// No Upgraded hook and no Executor wiring — close the connection
	// so the client does not hang. Preserves pre-3.4 bring-up behavior
	// when the embedder is still assembling its executor graph.
	s.recordRejected("rejected_internal", errors.New("protocol server missing executor wiring"))
	_ = conn.Close(websocket.StatusNormalClosure, "")
}

func (s *Server) writeAuthRejected(w http.ResponseWriter, message string, status int, reason string, err error) {
	if s != nil && s.Observer != nil {
		s.Observer.LogProtocolAuthFailed(reason, err)
	}
	s.writeRejected(w, message, status, "rejected_auth", err)
}

func (s *Server) closeAuthRejected(conn *websocket.Conn, reason string, err error, closeTimeout time.Duration) {
	if s != nil && s.Observer != nil {
		s.Observer.LogProtocolAuthFailed(reason, err)
	}
	s.recordRejected("rejected_auth", err)
	closeWithHandshake(conn, ClosePolicy, CloseReasonAuthRejected, closeTimeout)
}

func (s *Server) writeRejected(w http.ResponseWriter, message string, status int, result string, err error) {
	s.recordRejected(result, err)
	http.Error(w, message, status)
}

func (s *Server) recordRejected(result string, err error) {
	if s != nil && s.Conns != nil {
		s.Conns.RecordRejected()
	}
	if s != nil {
		logProtocolConnectionRejected(s.Observer, result, err)
	}
}

func (s *Server) buildMessageHandlersWithLimits(queryLimits SQLQueryLimits, subLimits SubscriptionLimits) *MessageHandlers {
	handlers := &MessageHandlers{}
	if s.Executor != nil && s.Schema != nil {
		handlers.OnSubscribeSingle = func(ctx context.Context, conn *Conn, msg *SubscribeSingleMsg) {
			handleSubscribeSingleWithVisibilityAndLimit(ctx, conn, msg, s.Executor, s.Schema, s.VisibilityFilters, subLimits.MaxQueriesPerSet)
		}
		handlers.OnSubscribeMulti = func(ctx context.Context, conn *Conn, msg *SubscribeMultiMsg) {
			handleSubscribeMultiWithVisibilityAndLimit(ctx, conn, msg, s.Executor, s.Schema, s.VisibilityFilters, subLimits.MaxQueriesPerSet)
		}
	}
	if s.Executor != nil {
		handlers.OnUnsubscribeSingle = func(ctx context.Context, conn *Conn, msg *UnsubscribeSingleMsg) {
			handleUnsubscribeSingle(ctx, conn, msg, s.Executor)
		}
		handlers.OnUnsubscribeMulti = func(ctx context.Context, conn *Conn, msg *UnsubscribeMultiMsg) {
			handleUnsubscribeMulti(ctx, conn, msg, s.Executor)
		}
		handlers.OnCallReducer = func(ctx context.Context, conn *Conn, msg *CallReducerMsg) {
			handleCallReducer(ctx, conn, msg, s.Executor)
		}
	}
	if s.Schema != nil && s.State != nil {
		handlers.OnOneOffQuery = func(ctx context.Context, conn *Conn, msg *OneOffQueryMsg) {
			handleOneOffQueryWithVisibilityAndLimits(ctx, conn, msg, s.State, s.Schema, s.VisibilityFilters, queryLimits)
		}
	}
	if s.DeclaredReads != nil {
		handlers.OnDeclaredQuery = s.DeclaredReads.HandleDeclaredQuery
		handlers.OnDeclaredQueryWithParameters = s.DeclaredReads.HandleDeclaredQueryWithParameters
		handlers.OnSubscribeDeclaredView = s.DeclaredReads.HandleSubscribeDeclaredView
		handlers.OnSubscribeDeclaredViewWithParameters = s.DeclaredReads.HandleSubscribeDeclaredViewWithParameters
	}
	if s.Procedures != nil {
		handlers.OnCallProcedure = s.Procedures.HandleCallProcedure
	}
	return handlers
}

// extractToken pulls a JWT from either the Authorization: Bearer
// header (preferred, SPEC-005 §2.3) or the ?token= query parameter.
// Returns the token and whether one was found.
func extractToken(r *http.Request) (string, bool, error) {
	if values := r.Header.Values("Authorization"); len(values) != 0 {
		if len(values) != 1 {
			return "", false, errMalformedAuthorizationHeader
		}
		fields := strings.Fields(values[0])
		if len(fields) != 2 || !strings.EqualFold(fields[0], "Bearer") {
			return "", false, errMalformedAuthorizationHeader
		}
		return fields[1], true, nil
	}
	if q := r.URL.Query().Get("token"); q != "" {
		return q, true, nil
	}
	return "", false, nil
}

// resolveConnectionID returns the client-supplied ConnectionID if
// present, or a freshly generated one if not. All-zero client values
// produce ErrZeroConnectionID (SPEC-005 §4.3).
func resolveConnectionID(raw string) (types.ConnectionID, error) {
	if raw == "" {
		return GenerateConnectionID(), nil
	}
	c, err := types.ParseConnectionIDHex(raw)
	if err != nil {
		return types.ConnectionID{}, err
	}
	if c.IsZero() {
		return types.ConnectionID{}, ErrZeroConnectionID
	}
	return c, nil
}

// parseCompressionParam maps the ?compression= query param into a
// CompressionNone / CompressionGzip value. Missing or empty means
// CompressionNone. Anything else is a 400.
func parseCompressionParam(raw string) (uint8, error) {
	switch raw {
	case "", "none":
		return CompressionNone, nil
	case "gzip":
		return CompressionGzip, nil
	default:
		return 0, errors.New("unknown compression mode: " + raw)
	}
}

// negotiateSubprotocol inspects Sec-WebSocket-Protocol and returns the
// first supported token from preferred that the client also offered. Falls
// back to false when no overlap exists.
func negotiateSubprotocol(r *http.Request, preferred []string) (string, ProtocolVersion, bool) {
	header := r.Header.Values("Sec-WebSocket-Protocol")
	offered := make(map[string]struct{}, len(header))
	for _, line := range header {
		for raw := range strings.SplitSeq(line, ",") {
			tok := strings.TrimSpace(raw)
			if tok != "" {
				offered[tok] = struct{}{}
			}
		}
	}
	for _, want := range preferred {
		if _, ok := offered[want]; !ok {
			continue
		}
		version, ok := ProtocolVersionForSubprotocol(want)
		if ok {
			return want, version, true
		}
	}
	return "", ProtocolVersionUnknown, false
}
