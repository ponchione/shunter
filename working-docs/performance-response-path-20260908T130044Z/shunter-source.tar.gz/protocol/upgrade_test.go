package protocol

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/ponchione/websocket"

	"github.com/ponchione/shunter/auth"
)

var testSigningKey = []byte("upgrade-test-key-0123456789abcdef0")

func newTestServer(t *testing.T, s *Server) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(s.HandleSubscribe))
	t.Cleanup(srv.Close)
	return srv
}

func mintValidToken(t *testing.T) string {
	t.Helper()
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub":   "alice",
		"iss":   "test-issuer",
		"iat":   time.Now().Unix(),
		"email": "alice@example.com",
	})
	s, err := tok.SignedString(testSigningKey)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// strictServer returns a Server configured for strict auth. Upgraded
// callback signals when a connection has been handed off so tests can
// assert it happened (or did not).
func strictServer(t *testing.T) (*Server, *upgradeRecorder) {
	t.Helper()
	rec := &upgradeRecorder{}
	return &Server{
		JWT: &auth.JWTConfig{
			SigningKey: testSigningKey,
			AuthMode:   auth.AuthModeStrict,
		},
		Options:  DefaultProtocolOptions(),
		Upgraded: rec.record,
	}, rec
}

// anonymousServer returns a Server configured for anonymous-mode mint.
func anonymousServer(t *testing.T) (*Server, *upgradeRecorder) {
	t.Helper()
	rec := &upgradeRecorder{}
	return &Server{
		JWT: &auth.JWTConfig{
			SigningKey: testSigningKey,
			AuthMode:   auth.AuthModeAnonymous,
		},
		Mint: &auth.MintConfig{
			Issuer:     "https://shunter.local/anonymous",
			Audience:   "shunter-local",
			SigningKey: testSigningKey,
			Expiry:     time.Hour,
		},
		Options:  DefaultProtocolOptions(),
		Upgraded: rec.record,
	}, rec
}

type upgradeRecorder struct {
	mu      sync.Mutex
	changed chan struct{}
	seen    []UpgradeContext
}

func (r *upgradeRecorder) record(ctx context.Context, uc *UpgradeContext) {
	r.mu.Lock()
	r.seen = append(r.seen, *uc)
	if r.changed != nil {
		close(r.changed)
		r.changed = make(chan struct{})
	}
	r.mu.Unlock()
	// Tests don't exercise the upgraded-conn read/write path here —
	// close cleanly to let the server-side goroutine exit.
	_ = uc.Conn.Close(websocket.StatusNormalClosure, "")
}

func (r *upgradeRecorder) waitLast(t *testing.T) UpgradeContext {
	t.Helper()
	deadline := time.After(2 * time.Second)
	for {
		r.mu.Lock()
		if len(r.seen) != 0 {
			uc := r.seen[len(r.seen)-1]
			r.mu.Unlock()
			return uc
		}
		if r.changed == nil {
			r.changed = make(chan struct{})
		}
		ch := r.changed
		r.mu.Unlock()

		select {
		case <-ch:
		case <-deadline:
			t.Fatal("Upgraded callback not invoked")
		}
	}
}

// dialWS opens a ws:// upgrade against httptestServer's /subscribe
// endpoint with the given header + query modifications applied.
func dialWS(t *testing.T, srv *httptest.Server, opts wsDialOpts) (*websocket.Conn, *http.Response, error) {
	t.Helper()
	u := strings.Replace(srv.URL, "http://", "ws://", 1)
	if opts.query != "" {
		u += "?" + opts.query
	}
	dialOpts := &websocket.DialOptions{
		Subprotocols: opts.subprotocols,
	}
	if opts.authHeader != "" {
		dialOpts.HTTPHeader = http.Header{"Authorization": []string{opts.authHeader}}
	}
	if opts.skipSubprotocol {
		dialOpts.Subprotocols = nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	return websocket.Dial(ctx, u, dialOpts)
}

type wsDialOpts struct {
	authHeader      string
	query           string
	subprotocols    []string
	skipSubprotocol bool
}

func TestUpgradeValidTokenHeaderSucceeds(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial failed: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Errorf("status = %d, want 101", resp.StatusCode)
	}
	if got := resp.Header.Get("Sec-WebSocket-Protocol"); got != "v1.bsatn.shunter" {
		t.Errorf("Sec-WebSocket-Protocol echoed = %q, want v1.bsatn.shunter", got)
	}

	uc := rec.waitLast(t)
	if uc.Identity != auth.DeriveIdentity("test-issuer", "alice") {
		t.Errorf("Identity mismatch: got %x", uc.Identity)
	}
	if uc.ProtocolVersion != ProtocolVersionV1 {
		t.Errorf("ProtocolVersion = %s, want v1", uc.ProtocolVersion)
	}
}

func TestUpgradeValidRS256TokenHeaderSucceeds(t *testing.T) {
	privateKey, publicPEM := generateUpgradeRS256Key(t)
	rec := &upgradeRecorder{}
	s := &Server{
		JWT: &auth.JWTConfig{
			VerificationKeys: []auth.JWTVerificationKey{
				{Algorithm: auth.JWTAlgorithmRS256, KeyID: "rsa-1", Key: publicPEM},
			},
			AuthMode: auth.AuthModeStrict,
		},
		Options:  DefaultProtocolOptions(),
		Upgraded: rec.record,
	}
	srv := newTestServer(t, s)
	tok := jwt.NewWithClaims(jwt.SigningMethodRS256, jwt.MapClaims{
		"sub": "alice",
		"iss": "test-issuer",
		"iat": time.Now().Unix(),
	})
	tok.Header["kid"] = "rsa-1"
	token, err := tok.SignedString(privateKey)
	if err != nil {
		t.Fatal(err)
	}

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + token,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial failed: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Errorf("status = %d, want 101", resp.StatusCode)
	}
	uc := rec.waitLast(t)
	if uc.Identity != auth.DeriveIdentity("test-issuer", "alice") {
		t.Errorf("Identity mismatch: got %x", uc.Identity)
	}
}

func TestUpgradeRequestCancellationStopsRemoteJWTValidation(t *testing.T) {
	privateKey, _ := generateUpgradeRS256Key(t)
	tok := jwt.NewWithClaims(jwt.SigningMethodRS256, jwt.MapClaims{
		"sub": "alice",
		"iss": "remote-issuer",
		"iat": time.Now().Unix(),
	})
	tok.Header["kid"] = "remote-key"
	token, err := tok.SignedString(privateKey)
	if err != nil {
		t.Fatalf("sign remote token: %v", err)
	}

	entered := make(chan struct{})
	remoteCanceled := make(chan struct{})
	remote := httptest.NewServer(http.HandlerFunc(func(_ http.ResponseWriter, req *http.Request) {
		close(entered)
		<-req.Context().Done()
		close(remoteCanceled)
	}))
	t.Cleanup(remote.Close)
	server := &Server{
		JWT: &auth.JWTConfig{
			JWKS: []auth.JWKSConfig{{
				Issuer:         "remote-issuer",
				JWKSURL:        remote.URL,
				RefreshTimeout: 10 * time.Second,
			}},
			Issuers:  []string{"remote-issuer"},
			AuthMode: auth.AuthModeStrict,
		},
		Options: DefaultProtocolOptions(),
	}
	ctx, cancel := context.WithCancel(context.Background())
	req := httptest.NewRequest(http.MethodGet, "/subscribe?token="+token, nil).WithContext(ctx)
	rec := httptest.NewRecorder()
	done := make(chan struct{})
	go func() {
		server.HandleSubscribe(rec, req)
		close(done)
	}()
	<-entered
	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("upgrade handler did not return after request cancellation")
	}
	select {
	case <-remoteCanceled:
	case <-time.After(time.Second):
		t.Fatal("remote JWKS request did not observe upgrade cancellation")
	}
}

func TestUpgradePrefersProtocolV2WhenOffered(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		subprotocols: []string{SubprotocolV1, SubprotocolV2},
	})
	if err != nil {
		t.Fatalf("dial failed: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	if got := resp.Header.Get("Sec-WebSocket-Protocol"); got != SubprotocolV2 {
		t.Errorf("Sec-WebSocket-Protocol echoed = %q, want %s", got, SubprotocolV2)
	}

	uc := rec.waitLast(t)
	if uc.ProtocolVersion != ProtocolVersionV2 {
		t.Errorf("ProtocolVersion = %s, want v2", uc.ProtocolVersion)
	}
}

func TestUpgradeValidTokenHeaderSchemeCaseInsensitive(t *testing.T) {
	for _, scheme := range []string{"bearer", "BEARER"} {
		t.Run(scheme, func(t *testing.T) {
			s, rec := strictServer(t)
			srv := newTestServer(t, s)

			conn, resp, err := dialWS(t, srv, wsDialOpts{
				authHeader:   scheme + " " + mintValidToken(t),
				subprotocols: []string{"v1.bsatn.shunter"},
			})
			if err != nil {
				t.Fatalf("dial failed: %v (resp=%v)", err, resp)
			}
			defer conn.Close(websocket.StatusNormalClosure, "")
			if resp.StatusCode != http.StatusSwitchingProtocols {
				t.Errorf("status = %d, want 101", resp.StatusCode)
			}

			uc := rec.waitLast(t)
			if uc.Identity != auth.DeriveIdentity("test-issuer", "alice") {
				t.Errorf("Identity mismatch: got %x", uc.Identity)
			}
		})
	}
}

func TestUpgradeValidTokenCarriesPermissions(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub":         "alice",
		"iss":         "test-issuer",
		"iat":         time.Now().Unix(),
		"permissions": []string{"messages:send", "messages:read"},
	})
	token, err := tok.SignedString(testSigningKey)
	if err != nil {
		t.Fatal(err)
	}

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + token,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial failed: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.Claims == nil {
		t.Fatal("Claims = nil, want validated claims")
	}
	if got := uc.Claims.Permissions; len(got) != 2 || got[0] != "messages:send" || got[1] != "messages:read" {
		t.Fatalf("Claims.Permissions = %#v, want send/read tags", got)
	}
	if got := uc.Permissions; len(got) != 2 || got[0] != "messages:send" || got[1] != "messages:read" {
		t.Fatalf("UpgradeContext.Permissions = %#v, want send/read tags", got)
	}
	if uc.AllowAllPermissions {
		t.Fatal("AllowAllPermissions = true in strict auth, want false")
	}
}

func TestUpgradeValidTokenPopulatesPrincipal(t *testing.T) {
	s, rec := strictServer(t)
	s.JWT.Audiences = []string{"shunter-api"}
	s.JWT.ExtraClaims = []string{"email", "role"}
	srv := newTestServer(t, s)
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub":         "alice",
		"iss":         "https://issuer.example",
		"aud":         []string{"mobile", "shunter-api"},
		"iat":         time.Now().Unix(),
		"email":       "alice@example.com",
		"role":        "authenticated",
		"permissions": []string{"messages:send", "messages:read"},
	})
	token, err := tok.SignedString(testSigningKey)
	if err != nil {
		t.Fatal(err)
	}

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + token,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial failed: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.Identity != auth.DeriveIdentity("https://issuer.example", "alice") {
		t.Fatalf("Identity = %x, want derived issuer/subject identity", uc.Identity)
	}
	if uc.Principal.Issuer != "https://issuer.example" || uc.Principal.Subject != "alice" {
		t.Fatalf("Principal = %+v, want issuer/subject", uc.Principal)
	}
	if got := uc.Principal.Audience; len(got) != 2 || got[0] != "mobile" || got[1] != "shunter-api" {
		t.Fatalf("Principal.Audience = %#v, want mobile/shunter-api", got)
	}
	if got := uc.Principal.Permissions; len(got) != 2 || got[0] != "messages:send" || got[1] != "messages:read" {
		t.Fatalf("Principal.Permissions = %#v, want send/read tags", got)
	}
	if got, ok := uc.Principal.Claims.Get("email"); !ok || string(got) != `"alice@example.com"` {
		t.Fatalf("Principal.Claims[email] = %s, %v; want copied email", got, ok)
	}
	if got, ok := uc.Claims.Claims.Get("role"); !ok || string(got) != `"authenticated"` {
		t.Fatalf("Claims.Claims[role] = %s, %v; want copied role", got, ok)
	}
	if got := uc.Permissions; len(got) != 2 || got[0] != "messages:send" || got[1] != "messages:read" {
		t.Fatalf("UpgradeContext.Permissions = %#v, want send/read tags", got)
	}
}

func TestUpgradeAnonymousPresentedTokenDoesNotAllowAllPermissions(t *testing.T) {
	s, rec := anonymousServer(t)
	srv := newTestServer(t, s)
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub":         "alice",
		"iss":         "test-issuer",
		"iat":         time.Now().Unix(),
		"permissions": []string{"messages:read"},
	})
	token, err := tok.SignedString(testSigningKey)
	if err != nil {
		t.Fatal(err)
	}

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + token,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial failed: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.Token != "" {
		t.Fatal("UpgradeContext.Token set for presented token, want empty")
	}
	if uc.Claims == nil {
		t.Fatal("Claims = nil, want validated presented-token claims")
	}
	if got := uc.Permissions; len(got) != 1 || got[0] != "messages:read" {
		t.Fatalf("UpgradeContext.Permissions = %#v, want messages:read", got)
	}
	if uc.AllowAllPermissions {
		t.Fatal("AllowAllPermissions = true for presented token in anonymous mode, want false")
	}
}

func TestUpgradeValidTokenQueryParamSucceeds(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		query:        "token=" + mintValidToken(t),
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Errorf("status = %d, want 101", resp.StatusCode)
	}
}

func TestUpgradeMalformedAuthorizationHeaderRejectsQueryTokenFallback(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Basic credentials",
		query:        "token=" + mintValidToken(t),
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail when Authorization is malformed")
	}
	if resp == nil || resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("status = %v, want 401", resp)
	}
	if body := responseBodyString(t, resp); body != authRejectedInvalidToken+"\n" {
		t.Fatalf("response body = %q, want sanitized invalid-token body", body)
	}
}

func TestUpgradeStrictNoTokenRejected(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial should upgrade before strict-auth close: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("status = %d, want 101", resp.StatusCode)
	}
	requireAuthRejectedClose(t, conn)
}

func TestUpgradeInvalidTokenRejected(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer not-a-jwt",
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial should upgrade before strict-auth close: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("status = %d, want 101", resp.StatusCode)
	}
	requireAuthRejectedClose(t, conn)
}

func TestUpgradeInvalidTokenCloseReasonIsSanitized(t *testing.T) {
	s, _ := strictServer(t)
	s.JWT.Issuers = []string{"trusted-issuer"}
	s.JWT.Audiences = []string{"trusted-audience"}
	srv := newTestServer(t, s)
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub": "alice",
		"iss": "attacker-issuer",
		"aud": "attacker-audience",
		"iat": time.Now().Unix(),
	})
	token, err := tok.SignedString(testSigningKey)
	if err != nil {
		t.Fatal(err)
	}

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + token,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("dial should upgrade before strict-auth close: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("status = %d, want 101", resp.StatusCode)
	}
	closeErr := requireAuthRejectedClose(t, conn)
	if closeErr.Reason != CloseReasonAuthRejected {
		t.Fatalf("close reason = %q, want %q", closeErr.Reason, CloseReasonAuthRejected)
	}
	for _, leaked := range []string{"trusted-issuer", "trusted-audience", "attacker-issuer", "attacker-audience", "issuer not", "audience not"} {
		if strings.Contains(closeErr.Reason, leaked) {
			t.Fatalf("close reason leaked %q: %q", leaked, closeErr.Reason)
		}
	}
}

func TestUpgradeMissingJWTConfigRejected(t *testing.T) {
	s := &Server{Options: DefaultProtocolOptions()}
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail when JWT config is missing")
	}
	if resp == nil || resp.StatusCode != http.StatusInternalServerError {
		t.Errorf("status = %v, want 500", resp)
	}
}

func TestUpgradeAuthMisconfigurationResponseIsSanitized(t *testing.T) {
	s := &Server{Options: DefaultProtocolOptions()}
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail when JWT config is missing")
	}
	if resp == nil || resp.StatusCode != http.StatusInternalServerError {
		t.Fatalf("status = %v, want 500", resp)
	}
	body := responseBodyString(t, resp)
	if body != authRejectedUnavailable+"\n" {
		t.Fatalf("response body = %q, want sanitized auth-unavailable body", body)
	}
	if strings.Contains(body, "JWT") || strings.Contains(body, "misconfigured") {
		t.Fatalf("response body leaked internal auth configuration detail: %q", body)
	}
}

func TestUpgradeInvalidProtocolOptionsRejected(t *testing.T) {
	s, _ := strictServer(t)
	s.Options.OutgoingBufferMessages = -1
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail when protocol options are invalid")
	}
	if resp == nil || resp.StatusCode != http.StatusInternalServerError {
		t.Errorf("status = %v, want 500", resp)
	}
}

func TestUpgradeAnonymousMalformedAuthorizationHeaderDoesNotMint(t *testing.T) {
	s, _ := anonymousServer(t)
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Basic credentials",
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail when Authorization is malformed")
	}
	if resp == nil || resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("status = %v, want 401", resp)
	}
	if body := responseBodyString(t, resp); body != authRejectedInvalidToken+"\n" {
		t.Fatalf("response body = %q, want sanitized invalid-token body", body)
	}
}

func TestUpgradeAnonymousNoTokenMints(t *testing.T) {
	s, rec := anonymousServer(t)
	srv := newTestServer(t, s)

	conn, resp, err := dialWS(t, srv, wsDialOpts{
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("anonymous dial: %v (resp=%v)", err, resp)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Errorf("status = %d, want 101", resp.StatusCode)
	}

	uc := rec.waitLast(t)
	if uc.Token == "" {
		t.Error("anonymous upgrade should produce a minted token in UpgradeContext.Token")
	}
	if uc.Identity.IsZero() {
		t.Error("anonymous identity must be non-zero")
	}
	if !uc.AllowAllPermissions {
		t.Error("anonymous dev upgrade should allow all permissions")
	}
}

func TestUpgradeAnonymousMaximumIssuerTokenReconnect(t *testing.T) {
	issuer := strings.Repeat("i", auth.MaxIssuerBytes)
	initialServer, initialRecorder := anonymousServer(t)
	initialServer.JWT.Issuers = []string{issuer}
	initialServer.Mint.Issuer = issuer
	initialHTTPServer := newTestServer(t, initialServer)

	initialConn, resp, err := dialWS(t, initialHTTPServer, wsDialOpts{
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("anonymous initial dial: %v (resp=%v)", err, resp)
	}
	defer initialConn.Close(websocket.StatusNormalClosure, "")
	initial := initialRecorder.waitLast(t)
	if initial.Token == "" || initial.Identity.IsZero() {
		t.Fatalf("anonymous initial upgrade = %+v, want minted token and identity", initial)
	}

	reconnectServer, reconnectRecorder := anonymousServer(t)
	reconnectServer.JWT.Issuers = []string{issuer}
	reconnectServer.Mint.Issuer = issuer
	reconnectHTTPServer := newTestServer(t, reconnectServer)
	reconnectConn, resp, err := dialWS(t, reconnectHTTPServer, wsDialOpts{
		authHeader:   "Bearer " + initial.Token,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatalf("anonymous token reconnect: %v (resp=%v)", err, resp)
	}
	defer reconnectConn.Close(websocket.StatusNormalClosure, "")
	reconnected := reconnectRecorder.waitLast(t)
	if reconnected.Token != "" || reconnected.Claims == nil {
		t.Fatalf("reconnect upgrade = %+v, want validated presented token", reconnected)
	}
	if reconnected.Claims.Issuer != issuer || reconnected.Identity != initial.Identity {
		t.Fatalf("reconnect issuer/identity did not round trip at exact boundary")
	}
}

func TestUpgradeAnonymousOversizedIssuerRejectsBeforeTokenRoundTrip(t *testing.T) {
	issuer := strings.Repeat("i", auth.MaxIssuerBytes+1)
	server, _ := anonymousServer(t)
	server.JWT.Issuers = []string{issuer}
	server.Mint.Issuer = issuer
	httpServer := newTestServer(t, server)

	_, resp, err := dialWS(t, httpServer, wsDialOpts{
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("anonymous initial dial succeeded with oversized mint issuer")
	}
	if resp == nil || resp.StatusCode != http.StatusInternalServerError {
		t.Fatalf("anonymous initial dial status = %v, want 500", resp)
	}
	if body := responseBodyString(t, resp); body != authRejectedUnavailable+"\n" {
		t.Fatalf("response body = %q, want sanitized auth-unavailable body", body)
	}
}

func TestUpgradeZeroConnectionIDRejected(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		query:        "connection_id=00000000000000000000000000000000",
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail with zero connection_id")
	}
	if resp == nil || resp.StatusCode != http.StatusBadRequest {
		t.Errorf("status = %v, want 400", resp)
	}
}

func TestUpgradeGeneratesConnectionIDWhenAbsent(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)

	conn, _, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.ConnectionID.IsZero() {
		t.Error("server should have generated a non-zero connection_id")
	}
}

func TestUpgradeClientSuppliedConnectionIDUsed(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)

	clientID := "0102030405060708090a0b0c0d0e0f10"
	conn, _, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		query:        "connection_id=" + clientID,
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.ConnectionID.Hex() != clientID {
		t.Errorf("ConnectionID.Hex = %q, want %q", uc.ConnectionID.Hex(), clientID)
	}
}

func TestUpgradeMissingSubprotocolRejected(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:      "Bearer " + mintValidToken(t),
		skipSubprotocol: true,
	})
	if err == nil {
		t.Fatal("dial should fail without Sec-WebSocket-Protocol")
	}
	if resp == nil || resp.StatusCode != http.StatusBadRequest {
		t.Errorf("status = %v, want 400", resp)
	}
}

func TestUpgradeCompressionGzip(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)

	conn, _, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		query:        "compression=gzip",
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.Compression != CompressionGzip {
		t.Errorf("Compression = %d, want CompressionGzip", uc.Compression)
	}
}

func TestUpgradeCompressionNone(t *testing.T) {
	s, rec := strictServer(t)
	srv := newTestServer(t, s)

	conn, _, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		query:        "compression=none",
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close(websocket.StatusNormalClosure, "")

	uc := rec.waitLast(t)
	if uc.Compression != CompressionNone {
		t.Errorf("Compression = %d, want CompressionNone", uc.Compression)
	}
}

func TestUpgradeCompressionUnknownRejected(t *testing.T) {
	s, _ := strictServer(t)
	srv := newTestServer(t, s)

	_, resp, err := dialWS(t, srv, wsDialOpts{
		authHeader:   "Bearer " + mintValidToken(t),
		query:        "compression=zstd",
		subprotocols: []string{"v1.bsatn.shunter"},
	})
	if err == nil {
		t.Fatal("dial should fail with unknown compression mode")
	}
	if resp == nil || resp.StatusCode != http.StatusBadRequest {
		t.Errorf("status = %v, want 400", resp)
	}
}

func TestBuildMessageHandlers_NilWhenDependenciesMissing(t *testing.T) {
	s := &Server{}
	h := buildValidatedMessageHandlers(t, s)
	if h.OnSubscribeSingle != nil {
		t.Fatal("OnSubscribeSingle should be nil when schema/executor are missing")
	}
	if h.OnSubscribeMulti != nil {
		t.Fatal("OnSubscribeMulti should be nil when schema/executor are missing")
	}
	if h.OnUnsubscribeSingle != nil {
		t.Fatal("OnUnsubscribeSingle should be nil when executor is missing")
	}
	if h.OnUnsubscribeMulti != nil {
		t.Fatal("OnUnsubscribeMulti should be nil when executor is missing")
	}
	if h.OnCallReducer != nil {
		t.Fatal("OnCallReducer should be nil when executor is missing")
	}
	if h.OnOneOffQuery != nil {
		t.Fatal("OnOneOffQuery should be nil when schema/state are missing")
	}
}

func TestBuildMessageHandlers_WiresOnlySatisfiedDependencies(t *testing.T) {
	s := &Server{Executor: &fakeInbox{}}
	h := buildValidatedMessageHandlers(t, s)
	if h.OnSubscribeSingle != nil {
		t.Fatal("OnSubscribeSingle should stay nil until schema is wired")
	}
	if h.OnSubscribeMulti != nil {
		t.Fatal("OnSubscribeMulti should stay nil until schema is wired")
	}
	if h.OnUnsubscribeSingle == nil {
		t.Fatal("OnUnsubscribeSingle should be wired when executor is present")
	}
	if h.OnUnsubscribeMulti == nil {
		t.Fatal("OnUnsubscribeMulti should be wired when executor is present")
	}
	if h.OnCallReducer == nil {
		t.Fatal("OnCallReducer should be wired when executor is present")
	}
	if h.OnOneOffQuery != nil {
		t.Fatal("OnOneOffQuery should stay nil until schema and state are both wired")
	}
}

func buildValidatedMessageHandlers(t *testing.T, s *Server) *MessageHandlers {
	t.Helper()
	queryLimits, err := NormalizeSQLQueryLimits(s.SQLQueryLimits)
	if err != nil {
		t.Fatalf("NormalizeSQLQueryLimits: %v", err)
	}
	subscriptionLimits, err := NormalizeSubscriptionLimits(s.SubscriptionLimits)
	if err != nil {
		t.Fatalf("NormalizeSubscriptionLimits: %v", err)
	}
	return s.buildMessageHandlersWithLimits(queryLimits, subscriptionLimits)
}

func responseBodyString(t *testing.T, resp *http.Response) string {
	t.Helper()
	if resp == nil || resp.Body == nil {
		return ""
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read response body: %v", err)
	}
	return string(body)
}

func requireAuthRejectedClose(t *testing.T, conn *websocket.Conn) websocket.CloseError {
	t.Helper()
	_, err := readOneBinary(t, conn, 2*time.Second)
	if err == nil {
		t.Fatal("expected strict-auth close frame; got a data frame instead")
	}
	if got := websocket.CloseStatus(err); got != ClosePolicy {
		t.Fatalf("close code = %d, want %d", got, ClosePolicy)
	}
	var closeErr websocket.CloseError
	if !errors.As(err, &closeErr) {
		t.Fatalf("read error = %T %[1]v, want websocket.CloseError", err)
	}
	if closeErr.Reason != CloseReasonAuthRejected {
		t.Fatalf("close reason = %q, want %q", closeErr.Reason, CloseReasonAuthRejected)
	}
	return closeErr
}

func generateUpgradeRS256Key(t *testing.T) (*rsa.PrivateKey, []byte) {
	t.Helper()
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	der, err := x509.MarshalPKIXPublicKey(&privateKey.PublicKey)
	if err != nil {
		t.Fatal(err)
	}
	return privateKey, pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: der})
}
