# Serve Protocol Traffic

Enable protocol serving when external clients should talk to Shunter over its
WebSocket protocol. Keep using local runtime APIs for in-process workers,
tests, admin tools, and app-owned HTTP handlers that do not need the protocol.

## Runtime-Owned Server

For a standard hosted-backend app, prefer the root convenience API:

```go
cfg := shunter.ConfigFromEnv()
cfg.EnableProtocol = true
if err := shunter.Run(ctx, app.Module(), cfg); err != nil {
	return err
}
```

`Run` builds the runtime, serves the runtime-owned HTTP/protocol lifecycle, and
returns nil for normal context-canceled shutdown.

Use `Runtime.ListenAndServe` when Shunter should own the HTTP server lifecycle.

```go
rt, err := shunter.Build(app.Module(), shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
	ListenAddr:     "127.0.0.1:3000",
})
if err != nil {
	return err
}

if err := rt.ListenAndServe(ctx); err != nil && !errors.Is(err, context.Canceled) {
	return err
}
```

`ListenAndServe` starts the runtime if needed, serves `Runtime.HTTPHandler()`,
and closes runtime ownership when the context is canceled.
Runtime-owned HTTP serving uses defensive read-header and idle timeouts.

## App-Owned HTTP Server

Use `Runtime.HTTPHandler` when your application owns the HTTP server or wants
to mount Shunter beside other routes.

```go
rt, err := shunter.Build(app.Module(), shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
})
if err != nil {
	return err
}
defer rt.Close()

if err := rt.Start(ctx); err != nil {
	return err
}

server := &http.Server{
	Addr:              "127.0.0.1:3000",
	Handler:           rt.HTTPHandler(),
	ReadHeaderTimeout: 5 * time.Second,
	IdleTimeout:       60 * time.Second,
}
return server.ListenAndServe()
```

`HTTPHandler` does not start lifecycle by itself. Call `Start` before serving
traffic.

If the app-owned server needs its own middleware, route `rt.HTTPHandler()` under
the desired mount point after the runtime has started. Keep using local
`CallReducer`, `Read`, `CallQuery`, and `SubscribeView` for trusted in-process
work that does not need WebSocket protocol behavior.

For WebSocket write backpressure tuning, use `Config.Protocol.WriteTimeout`.
Zero values use Shunter's protocol defaults.

## Protocol Endpoint

With protocol enabled, the runtime mounts the WebSocket protocol endpoint at
`/subscribe`.

The v1 protocol is Shunter-native. Document compatibility against Shunter's own
WebSocket and BSATN frame contracts.

## Wire Compatibility

Supported WebSocket subprotocol tokens are:

- `v2.bsatn.shunter`: current/default protocol. V2 adds parameterized
  declared-query and declared-view requests plus module procedure calls.
- `v1.bsatn.shunter`: minimum supported protocol for existing v1 clients and
  no-parameter declared reads.

Frames are Shunter-native binary frames: one tag byte followed by a BSATN body,
inside the runtime compression envelope when compression is negotiated.
Unknown, unassigned, reserved, malformed, or trailing-byte messages are fatal
protocol errors within the negotiated version. V1 connections reject v2-only
tags instead of widening v1 semantics.

Stable client-to-server message families are `SubscribeSingle`,
`UnsubscribeSingle`, `SubscribeMulti`, `UnsubscribeMulti`, `CallReducer`,
`OneOffQuery`, `DeclaredQuery`, and `SubscribeDeclaredView`. V2 also supports
`DeclaredQueryWithParameters` and `SubscribeDeclaredViewWithParameters`; their
`params` field is a BSATN product row encoded according to the declaration's
parameter schema. V2 also supports `CallProcedure`, correlated by an opaque
`message_id`.

Stable server-to-client message families are `IdentityToken`,
`SubscribeSingleApplied`, `UnsubscribeSingleApplied`,
`SubscribeMultiApplied`, `UnsubscribeMultiApplied`, `SubscriptionError`,
`TransactionUpdate`, `TransactionUpdateLight`, and `OneOffQueryResponse`. V2
also supports `ProcedureResponse`.

Tag `0` and tags `128` through `255` are reserved in supported protocol
versions. Server tag `7` is reserved for the retired reducer-call result
envelope.

Row batches and subscription updates use Shunter row-list and flat update
payloads. Fields, wrapper formats, or transport semantics not defined by
Shunter's v1 protocol are out of scope.

## Auth Mode

Development mode is the zero-value `AuthMode` and allows missing-token protocol
connections by minting anonymous development tokens.

Strict mode requires token validation for protocol connections:

```go
cfg := shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
	AuthMode:       shunter.AuthModeStrict,
	AuthSigningKey: signingKey,
	AuthIssuers:    []string{"https://issuer.example"},
	AuthAudiences:  []string{"chat"},
}
```

Use `AuthVerificationKeys` instead of `AuthSigningKey` when validating local
RS256 or ES256 public key material. Use `AuthOIDCIssuers` when validating
RS256 or ES256 tokens from an external issuer's JWKS endpoint.

See [Configure auth](configure-auth.md) for the app-author setup path and
[Authentication](../authentication.md) for the full strict-mode contract and
production checklist.

## Diagnostics

Runtime diagnostics are configured through `Config.Observability.Diagnostics`.
The mounts are independent and disabled by default:

- `MountHealthHTTP` adds `/healthz` and `/readyz`. The deprecated `MountHTTP`
  field is a compatibility alias for this health-only behavior.
- `MountDebugHTTP` adds `/debug/shunter/runtime`.
- `MountMetricsHTTP` adds `/metrics` when `MetricsHandler` is non-nil.
- `DetailedHTTPMiddleware` wraps only the debug and metrics handlers so the app
  can authenticate and authorize them.

Strict protocol auth protects `/subscribe` only; it does not protect any
diagnostics route. Health/readiness responses include runtime state, subsystem
status and bounded/redacted operational errors. The runtime debug response also
includes authored module metadata, schemas, declared query/view SQL and health
details. App-supplied metrics determine their own data exposure. Enable debug
and metrics only on loopback or a private network, or protect them with
`DetailedHTTPMiddleware` or authenticated ingress.

`RuntimeDiagnosticsHandler` is the app-owned composition helper and includes
health, readiness, debug, and configured metrics regardless of mount flags.
Wrap it before exposing it publicly. `HostDiagnosticsHandler` likewise exposes
host debug details, including module DataDir paths, and must be protected by the
app.

```go
cfg.Observability.Diagnostics.MountHealthHTTP = true
cfg.Observability.Diagnostics.MountDebugHTTP = true
cfg.Observability.Diagnostics.DetailedHTTPMiddleware = requireOperatorAuth
```

For in-process checks, use:

```go
inspection := shunter.InspectRuntimeHealth(rt)
statusCode := shunter.ReadyzStatusCode(inspection.Status)
_ = statusCode
```

## Multi-Module Host

`Host` can serve multiple built runtimes under explicit route prefixes:

```go
host, err := shunter.NewHost(
	shunter.HostRuntime{Name: "chat", RoutePrefix: "/chat", Runtime: chatRuntime},
	shunter.HostRuntime{Name: "ops", RoutePrefix: "/ops", Runtime: opsRuntime},
)
if err != nil {
	return err
}

return host.ListenAndServe(ctx, "127.0.0.1:3000")
```

Use this only when you intentionally want multiple independent runtimes in one
process. A host does not merge schemas, transactions, data directories, or
contracts.

Host route prefixes are explicit and must not overlap. Each registered module
name must match the built runtime, and hosted runtimes must not share a
`DataDir`.

Cross-module transactions, cross-module SQL or subscriptions, merged schema or
contract artifacts, global reducer/query namespaces, and dynamic module upload
are out of scope for v1.

## Serving Checklist

- Set `EnableProtocol: true`.
- Choose `ListenAndServe` or app-owned `HTTPHandler` mounting.
- Set HTTP read-header and idle timeouts when using an app-owned server.
- Use a durable `DataDir`.
- Use strict auth for public services.
- Call `Start` before serving when using `HTTPHandler` directly.
- Call `Close` during shutdown.
- Verify readiness before admitting traffic.
