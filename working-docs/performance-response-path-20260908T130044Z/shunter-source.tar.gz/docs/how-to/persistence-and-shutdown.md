# Persistence And Shutdown

Shunter persists runtime-owned state under `Config.DataDir`. Treat that
directory as an implementation-owned unit: copy it as a whole, restore it as a
whole, and never edit selected files by hand.

## Choose A DataDir

```go
rt, err := shunter.Build(app.Module(), shunter.Config{
	DataDir: "./data/chat",
})
```

Use separate data directories for separate applications, modules, tenants, or
incompatible schema lines.

A blank `DataDir` uses the runtime default `./shunter-data`. Set an explicit
directory for real services and tests that need predictable ownership. `Build`
acquires an exclusive lease on the canonical directory path before recovery or
bootstrap. Another runtime, process, or offline operation that conflicts with
that lease fails with `ErrDataDirInUse`; lexical and symlink aliases do not
bypass ownership.

The crash-safe advisory lock is held on an empty sibling file named by appending
`.shunter-lock` to the canonical `DataDir`. It contains no runtime data, is not
part of a backup, and may remain after shutdown. Do not remove it while a
runtime or maintenance operation may be using the directory.

## Startup

At startup, `Build` validates the module, opens or initializes durable state,
checks schema compatibility, and constructs runtime catalogs. `Start` begins
runtime-owned workers and lifecycle.

```go
rt, err := shunter.Build(mod, cfg)
if err != nil {
	return err
}
defer rt.Close()

if err := rt.Start(ctx); err != nil {
	return err
}
```

If startup recovery or schema validation fails, preserve the data directory and
investigate. Do not delete selected log or snapshot files to force startup. A
built runtime retains its lease after a failed `Start`, including retryable
failures; call `Close` before building a replacement runtime.

## Graceful Shutdown

For a planned stop:

1. Stop admitting reducer calls and protocol traffic.
2. Wait for important transaction durability if the app needs that boundary.
3. Call `Runtime.Close`.
4. Run offline backup, restore, or migration tools only after `Close` returns.

```go
if err := rt.WaitUntilDurable(ctx, txID); err != nil {
	return err
}
if err := rt.Close(); err != nil {
	return err
}
```

`Close` shuts down runtime-owned lifecycle, durability, executor,
subscription, and protocol resources, then releases the DataDir lease. If
called during `Start`, it cancels and waits for startup before returning, so
offline tooling may safely use `Close` as the data-directory ownership boundary.

## Snapshot And Compaction

Create a snapshot when the app wants a full durable state image at the current
committed transaction horizon.

```go
snapshotTxID, err := rt.CreateSnapshot()
if err != nil {
	return err
}
if err := rt.CompactCommitLog(snapshotTxID); err != nil {
	return err
}
```

Snapshot creation returns after publication completes. Reducers pause for the
durability wait and detached state capture, then proceed during serialization
and disk I/O. Concurrent snapshot requests and compaction serialize; `Close`
waits for active storage maintenance before releasing the DataDir lease.

Snapshot serialization buffers file writes while feeding the hash with the
original write sizes. A failed buffer flush stops before hash-header patching,
fsync, or publication, preserving cleanup and atomic publication. The measured
benefit is limited to snapshot publication; it does not establish lower process
memory or a general hosted throughput gain. See [performance evidence](../performance-envelopes.md).

Commit-log offset indexes are advisory sparse recovery hints. Durable batches
fsync the segment, then the backing index, before publishing the durable horizon.
Batch tails retain the pending hint and byte cadence; rotation and graceful
close flush the final hint. Public `OffsetIndexWriter.Sync` still flushes its
pending hint and syncs the index. Index errors retain log-based recovery fallback.
There is still an index sync per batch.

Sparser hints can increase recovery scanning. Historical larger native-index
recovery rose from 3.267 to 3.645 ms and 0.860 to 1.015 MiB allocated. Existing
full indexes are not resampled; exhausted capacity removes the normal sparse
hint scan bound. Reopening the active segment still scans it to validate append
position. These are storage-phase costs, not complete HTTP readiness. Segment
defaults and app-owned compaction scheduling remain unchanged.

`CompactCommitLog` only deletes sealed commit log segments fully covered by the
completed snapshot TX ID.

## Backup

Current v1 backup is offline-only.

Supported maintenance/recovery flow:

1. Stop accepting traffic.
2. Wait for required transactions to become durable, then stop the serving
   runtime cleanly.
3. In an app-owned maintenance process, recover the existing DataDir without
   starting normal runtime services, schedulers, startup migration hooks, or
   protocol serving. Create a snapshot, wait for its returned TX ID to be
   durable, and compact only with that completed snapshot TX ID.
4. Close the recovered maintenance state and require success before continuing.
5. Copy the entire `DataDir` offline.
6. Restore into a fresh DataDir, run module-linked compatibility preflight,
   start the compatible app, and verify application-visible reads before
   admitting traffic.
7. Retain the complete DataDir copy, matching module contract and module
   version, Shunter version/commit, backup timestamp, and build metadata.

The hosted-chat `prepare-backup` command and `TestMaintenanceRecoveryDrill`
provide the repository-local example. Preparation requires an existing
DataDir; a missing path or invalid output format fails before mutation.
Snapshot, compaction, close, backup, restore, or preflight errors stop the
sequence; preserve the source DataDir and the error for investigation rather
than deleting individual artifacts.

```go
if err := shunter.BackupDataDir("./data/chat", "./backups/chat-2026-05-04"); err != nil {
	return err
}
```

```bash
rtk go run ./cmd/shunter backup --data-dir ./data/chat --out ./backups/chat-2026-05-04
```

Backup stages and durably syncs the complete tree beside the requested output,
then publishes it with a rename and parent-directory sync. Any failed attempt
removes its staging tree and leaves the output path absent, so it cannot be
consumed as a backup and the same command can be retried. Backup refuses
symlink sources, existing output paths, nested
destinations inside the source `DataDir`, symlink entries, unsupported special
files, and source entries that change while being copied, including the source
root's identity or mode. Staged directories stay owner-private and writable
until copying and source verification finish; source directory permission bits
are then applied deepest-first before publication, so readable, read-only
directories are preserved without blocking their children.
Backup takes a transient shared lease and returns `ErrDataDirInUse` rather than
copying from a live runtime owner.

## Restore

Restore is also offline-only.

Recommended flow:

1. Stop the runtime that owns the destination directory.
2. Restore the complete backup into a missing or empty `DataDir`.
3. Start a compatible app binary against the restored directory.
4. Verify health and app-level smoke checks before admitting traffic.

```go
if err := shunter.RestoreDataDir("./backups/chat-2026-05-04", "./data/chat"); err != nil {
	return err
}
```

Restore uses the same staged publication. Failures leave a missing destination
missing or an existing empty destination empty; no partial DataDir is exposed.
Restore takes a transient shared lease on the backup and an exclusive lease on
the destination, so it cannot replace a live runtime's directory.

```bash
rtk go run ./cmd/shunter restore --backup ./backups/chat-2026-05-04 --data-dir ./data/chat
```

Restore refuses symlink backup sources, symlink or non-directory destinations,
nested destinations inside the backup source, symlink entries, unsupported
special files, and non-empty destinations.

## Compatibility Preflight

Use `CheckDataDirCompatibility` in app-owned maintenance tools when you want a
schema compatibility check before starting normal runtime services. Missing or
empty directories are compatible because `Build` can initialize fresh state
there.

```go
if err := shunter.CheckDataDirCompatibility(mod, shunter.Config{DataDir: "./data/chat"}); err != nil {
	return err
}
```

Use `CheckDataDirCompatibilityReport` when deployment tooling needs a
machine-readable preflight result. The report classifies exact matches, fresh
directories, safe additive changes, and blocked changes. Safe additive startup
currently covers schema-version-only drift, added tables, and appended
non-unique/non-primary indexes. Recovery preserves existing table IDs by name
and assigns new tables fresh IDs above the recovered snapshot maximum.
Row-shape changes, table drops, and new unique or primary constraints require
an app-owned migration plan. If recovery has durable log data but cannot select
a snapshot, schema-version drift is blocked because there is no persisted schema
map to reconcile table IDs safely.
Compatibility inspection takes a transient shared lease and returns
`ErrDataDirInUse` when an exclusive runtime or migration owner is active.

Preflight CLIs must be app-owned binaries because they need to link the module
declarations directly:

```go
report, err := shunter.CheckDataDirCompatibilityReport(mod, shunter.Config{
	DataDir: "./data/chat",
})
if err != nil {
	return err
}
_ = report.Status
```

The hosted-chat example includes this shape under
`examples/hosted-chat/cmd/maintain`.

## Migrations

Migration hooks are app-owned code, not a general SQL migration engine.

Registered module hooks run during runtime startup after recovery and
durability are available, but before normal reducer, subscription, and protocol
readiness.

Offline tools can run registered hooks explicitly:

```go
result, err := shunter.RunModuleDataDirMigrations(ctx, mod, shunter.Config{
	DataDir: "./data/chat",
})
if err != nil {
	return err
}
_ = result.DurableTxID
```

Take an offline backup before data-rewrite migrations.
Offline migration runners take a transient exclusive DataDir lease.

## More Detail

See [Operations](../operations.md) for the operator runbook and release
checklist.
