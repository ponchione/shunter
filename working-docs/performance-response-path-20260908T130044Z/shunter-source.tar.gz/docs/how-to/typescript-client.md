# Use Generated TypeScript Clients

Shunter's TypeScript path has two pieces:

- the SDK runtime package in `typescript/client`, resolved by generated apps as
  `@shunter/client`
- generated module bindings from `shunter contract codegen --language
  typescript`

The generated file imports shared runtime types and helpers from
`@shunter/client` by default. Keep those two pieces versioned together with the
contract they were generated from.

## Install The Runtime Package

Current v1 development supports a local package path, workspace package, or
packed tarball. The package remains `"private": true`; do not treat
`npm install @shunter/client` as a supported path until a public npm promotion
slice explicitly removes that guardrail.

The supported package identity is still `@shunter/client`. Generated bindings
import that name by default, and current local installs should resolve that
same name through the app's package manager unless the app intentionally
vendors or renames the runtime and generates bindings with the matching
`--runtime-import` value.

Current release policy:

- Shunter source versions use `VERSION` with a leading `v`.
- The TypeScript runtime package version mirrors that Shunter version without
  the leading `v`; for example `v1.1.1-dev` maps to `1.1.1-dev`.
- `dist/` is a checked-in package artifact and must match `src/` before a
  release candidate is qualified.
- `npm pack --dry-run` plus the package smoke gate are the package-shape
  release checks for the private/local workflow. The smoke gate enforces the
  package version mirror of root `VERSION`.
- Public npm publishing is blocked until the project records package ownership,
  release authority, npm access policy, publish command policy, package
  metadata including licensing, and the final `dist/` artifact rule.

App `package.json` with a `file:` dependency:

```json
{
  "dependencies": {
    "@shunter/client": "file:../shunter/typescript/client"
  }
}
```

Workspace root:

```json
{
  "private": true,
  "workspaces": ["vendor/shunter-client", "app"]
}
```

Workspace app:

```json
{
  "dependencies": {
    "@shunter/client": "1.1.1-dev"
  }
}
```

Packed tarball dependency:

```json
{
  "dependencies": {
    "@shunter/client": "file:./vendor/shunter-client-1.1.1-dev.tgz"
  }
}
```

Workspace installs should still resolve the package name as `@shunter/client`
unless the app intentionally vendors it under its own package name.

Build the runtime package before consuming it through a local path or tarball:

```bash
rtk npm --prefix typescript/client run build
rtk npm --prefix typescript/client run pack:dry-run
rtk npm --prefix typescript/client run smoke:package
```

`pack:dry-run` and the package smoke gate validate local package contents and
packed installs; they are not npm publish commands.

## Generate Bindings

Generate bindings from a reviewed contract artifact:

```bash
rtk go run ./cmd/shunter contract codegen --contract shunter.contract.json --language typescript --out src/shunter.gen.ts
```

Use `--profile internal`, `--profile full`, or `--profile public` to make the
generation profile explicit. Blank, `internal`, and `full` emit the complete
TypeScript surface. The `public` profile hides table-facing generated helpers
for tables whose exported `schema.tables[].sdk.visibility` is `internal`,
`private`, or `system`; declared query/view helpers, permissions, read-model
metadata, and declared-read-specific row codecs remain available.

If the app renames or vendors the runtime package, generate with the same import
specifier. For example, with an explicit public profile:

```bash
rtk go run ./cmd/shunter contract codegen --contract shunter.contract.json --language typescript --profile public --runtime-import @app/shunter-runtime --out src/shunter.gen.ts
```

The Go API equivalent is:

```go
codegen.Options{
	Language:                codegen.LanguageTypeScript,
	TypeScriptRuntimeImport: "@app/shunter-runtime",
	Profile:                 codegen.ProfilePublic,
}
```

Generated identifier normalization is stable for v1 output. Names are emitted
as TypeScript-safe identifiers by splitting on non-letter and non-digit
separators, applying the category's camel-case or Pascal-case style, prefixing
leading digits with `_`, suffixing reserved words with `_`, and appending
numeric collision suffixes in contract order.

Generated bindings export `shunterContract` with machine-readable provenance:
contract format/version, module name/version, protocol metadata, normalized
`generationProfile`, and normalized `runtimeImport`. Blank profile values are
recorded as `internal`; explicit `full` and `public` values are recorded with
those names.

Generated TypeScript is intended for browsers and Electron renderers with
standard Web APIs. Non-browser hosts must provide a compatible
`webSocketFactory`. Server-side SDK APIs, framework cache adapters, generated
writes that bypass reducers, and third-party client API compatibility are out
of scope for v1.

## Connect

Pass the generated protocol and contract metadata into the runtime client. When
`contract` is supplied, `createShunterClient` checks the generated contract
format/version and protocol metadata before opening the WebSocket.

```ts
import {
  assertGeneratedContractCompatible,
  createShunterClient,
} from "@shunter/client";
import {
  createModuleClient,
  shunterContract,
  shunterProtocol,
} from "./shunter.gen";

assertGeneratedContractCompatible(shunterContract, {
  moduleName: "chat",
  moduleVersion: "v0.1.0",
});

const client = createShunterClient({
  url: "ws://127.0.0.1:3000/subscribe",
  protocol: shunterProtocol,
  contract: shunterContract,
  token: () => authToken,
});

await client.connect();
const app = createModuleClient(client);
```

The default browser path uses global `WebSocket`.

For browser apps that can run in development without strict auth, install a
token provider only when the browser session already has a token. This keeps
local anonymous development from sending an empty bearer value while still
letting reconnect fetch a fresh token for each strict-auth attempt.

```ts
const hasToken = (globalThis.localStorage?.getItem("my-app-token") ?? "") !== "";

const client = createShunterClient({
  url: "ws://127.0.0.1:3000/subscribe",
  protocol: shunterProtocol,
  contract: shunterContract,
  ...(hasToken
    ? {
        token: () => {
          const token = globalThis.localStorage?.getItem("my-app-token");
          if (!token) {
            throw new Error("my-app-token is not configured");
          }
          return token;
        },
      }
    : {}),
});
```

Generated protocol metadata defaults to `v2.bsatn.shunter` while still listing
`v1.bsatn.shunter` as supported. Parameterized declared reads require a
negotiated v2 connection; no-parameter declared reads remain compatible with
v1.

## Browser And SSR Lifecycles

Generated TypeScript clients are browser and Electron-renderer clients. In
SSR-capable frameworks such as Nuxt, Next, SvelteKit, or Remix, import
generated metadata and types wherever the framework needs them, but create the
runtime WebSocket client only in browser code. Do not call
`createShunterClient`, `connect`, or generated subscription helpers during
server render, server data loading, or request-scoped middleware.

Use a browser-only plugin, route-level client hook, or component mount callback
as the lifecycle owner. The same rule applies to Nuxt: keep Shunter connection
setup in a `.client.ts` plugin or another browser-only entrypoint, not in a
universal plugin or server route. A runtime client is session state for one
browser context; do not store it in SSR globals or framework caches shared
across users.

```ts
import { createShunterClient } from "@shunter/client";
import {
  createModuleClient,
  shunterContract,
  shunterProtocol,
} from "./shunter.gen";

export async function connectBrowserShunter() {
  if (typeof window === "undefined") {
    throw new Error("Shunter WebSocket clients must be created in the browser");
  }

  const hasToken = (window.localStorage.getItem("my-app-token") ?? "") !== "";
  const client = createShunterClient({
    url: "wss://api.example.com/subscribe",
    protocol: shunterProtocol,
    contract: shunterContract,
    ...(hasToken
      ? {
          token: () => {
            const token = window.localStorage.getItem("my-app-token");
            if (!token) {
              throw new Error("my-app-token is not configured");
            }
            return token;
          },
        }
      : {}),
    reconnect: {
      enabled: true,
      maxAttempts: 3,
      initialDelayMs: 250,
      maxDelayMs: 5000,
    },
  });

  await client.connect();
  return { client, app: createModuleClient(client) };
}
```

Token providers should read browser session state at connection-attempt time
instead of closing over the token value seen during app startup. They are called
before the first WebSocket is created and before each reconnect attempt. If a
strict-auth browser session loses its token, throw from the provider and let the
app's auth flow decide whether to reauthenticate, clear local state, or retry
later. For dev-auth sessions that intentionally run anonymously, omit the token
provider instead of returning an empty string.

Reconnect replays active subscriptions after a fresh identity handshake, but a
disconnected interval is still an authority boundary. Managed handles report
`resynchronizing` while retained rows are non-authoritative. After the new
identity handshake, inspect `client.state.synchronization` or await
`client.whenSynchronized()`; the latter resolves only after every replayed
subscription receives an applied/error response. Active handle state carries
the epoch that made its rows authoritative. Close route-scoped clients and
subscriptions when their owner is disposed.

Regenerate and rebuild in this order when the Go module contract or local
runtime package changes:

1. Build and smoke-check the local `@shunter/client` package if
   `typescript/client` changed.
2. Export and review the app `shunter.contract.json`.
3. Run `shunter contract codegen --language typescript` from that reviewed
   contract.
4. Reinstall or refresh the workspace, `file:`, or packed-tarball dependency
   if the runtime package version or package contents changed.
5. Run the app frontend typecheck or browser gate.

## Call Reducers

Generated bindings always keep raw `Uint8Array` reducer helpers. When a
contract exports reducer argument product schemas, generated bindings also
include schema-aware argument encoders, typed helper wrappers, and the
module-bound facade returned by `createModuleClient`.

```ts
import {
  callSendMessage,
  callSendMessageResult,
  callSendMessageTyped,
} from "./shunter.gen";

await callSendMessage(client.callReducer, rawArgs);

await callSendMessageTyped(client.callReducer, {
  channel: "general",
  body: "hello",
});

await app.reducers.sendMessage.call({
  channel: "general",
  body: "hello",
});

const result = await callSendMessageResult(client.callReducer, rawArgs);
if (result.status === "failed") {
  throw result.error;
}
```

If a reducer or procedure request was sent but connection loss, explicit client
close, or post-send cancellation prevents an authoritative response, the
promise rejects with
`ShunterCallInterruptedError`. Its outcome is `unknown`: the operation may
have executed, so this is distinct from a server-confirmed validation failure.
Do not retry automatically unless the application has an explicit idempotency
policy. Shunter does not queue mutations offline.

If a reducer does not export product schemas, keep the app's byte encoding
documented near the reducer and pass encoded `Uint8Array` values through the
raw helper.

## Call Procedures

Generated bindings expose raw procedure helpers and typed procedure helpers
when a contract exports procedure argument product schemas. Procedures run
outside the reducer executor and may call reducers from the server side.

```ts
import {
  callSendSystemMessageProcedure,
  callSendSystemMessageProcedureTyped,
} from "./shunter.gen";

await callSendSystemMessageProcedure(client.callProcedure, rawArgs);

await callSendSystemMessageProcedureTyped(client.callProcedure, {
  body: "hello from a service adapter",
});

await app.procedures.sendSystemMessage.call({
  body: "hello from a service adapter",
});
```

Use procedures for client-callable workflows that need service work before
requesting reducer commits. Use reducers directly when the call is already a
single durable state transition.

## Read Queries

Executable declared queries get raw helpers. When exported declared-read row
metadata is available, generated bindings also expose decoded result helpers
that use generated row decoders by default. Parameterized declared queries get
typed params interfaces and helpers that encode those params before calling the
runtime.

```ts
import {
  queryMessagesByTopicDecoded,
  queryRecentMessages,
  queryRecentMessagesDecoded,
} from "./shunter.gen";

const rawFrame = await queryRecentMessages(client.runDeclaredQuery);
void rawFrame;

const decoded = await queryRecentMessagesDecoded(client.runDeclaredQuery);
for (const row of decoded.tables[0]?.rows ?? []) {
  console.log(row.body);
}

const byTopic = await queryMessagesByTopicDecoded(
  client.runDeclaredQuery,
  { topic: "general", afterId: 1n },
);
for (const row of byTopic.tables[0]?.rows ?? []) {
  console.log(row.body);
}

const recent = await app.queries.recentMessages.decoded();
void recent;
```

Use raw helpers when the app wants bytes or custom decoding. Use decoded helpers
when the generated contract row schema is the client-facing shape. Generated
parameterized helpers hide BSATN encoding; the lower-level runtime
`DeclaredQueryOptions.params` field is an already encoded `Uint8Array`.
Supplying `params` on a v1 connection raises a protocol mismatch before sending.
No-parameter helper signatures are unchanged.

## Subscribe To Tables And Views

Generated table helpers install generated table row decoders by default, so
their callbacks receive typed rows. Raw table subscribers without a decoder
receive cloned row bytes.

```ts
import {
  subscribeLiveMessagesByTopic,
  subscribeLiveMessages,
  subscribeLiveMessagesHandle,
  subscribeMessages,
} from "./shunter.gen";

const unsubscribeMessages = await subscribeMessages(
  client.subscribeTable,
  (rows) => {
    console.log(rows.length);
  },
);

const liveHandle = await subscribeLiveMessagesHandle(
  client.subscribeDeclaredView,
  { returnHandle: true },
);

const unsubscribeByTopic = await subscribeLiveMessagesByTopic(
  client.subscribeDeclaredView,
  { topic: "general" },
  {
    onUpdate: (update) => {
      console.log(update.inserts.length);
    },
  },
);

await unsubscribeMessages();
await unsubscribeByTopic();
await liveHandle.unsubscribe();

const facadeHandle = await app.views.liveMessages.handle({ returnHandle: true });
await facadeHandle.unsubscribe();
```

Generated event-table helpers use the `subscribe<Name>Inserts` shape. They pass
`eventTable: true` to the runtime so managed handles do not accumulate
transient rows as cache state.

```ts
const unsubscribeEvents = await subscribeNotificationsInserts(
  client.subscribeTable,
  ({ row }) => {
    console.log(row.message);
  },
);

await unsubscribeEvents();

const unsubscribeFacadeEvents = await app.events.notifications.onInsert(({ row }) => {
  console.log(row.message);
});
await unsubscribeFacadeEvents();
```

Managed handles track `subscribing`, `active`, `resynchronizing`,
`unsubscribing`, and `closed` states. `handle.epoch` names the connection epoch
that supplied the authoritative rows. `resynchronizing` retains the previous
rows for display but explicitly marks them non-authoritative. Unsubscribe paths
wait for the matching server acknowledgement or a matching subscription error.
If disposal begins while replay is pending, the client first waits for that
replay response and then sends the unsubscribe, so subscribe and unsubscribe
operations for one query ID never overlap.

## Reconnect

Reconnect is explicit opt-in:

```ts
const client = createShunterClient({
  url: "ws://127.0.0.1:3000/subscribe",
  protocol: shunterProtocol,
  contract: shunterContract,
  token: () => refreshToken(),
  reconnect: {
    enabled: true,
    maxAttempts: 3,
    initialDelayMs: 250,
    maxDelayMs: 5000,
  },
});
```

When reconnect is enabled, token providers are called for each connection
attempt. Resubscription is enabled by default after a fresh identity handshake.
A disconnected interval is an authority boundary. `connect()` resolves at the
identity handshake; replay may still be pending. Await synchronization when the
caller needs authoritative managed rows:

```ts
await client.connect();
const synchronization = await client.whenSynchronized();
console.log(synchronization.epoch);
```

If `resubscribe: false`, existing managed handles close on connection loss
instead of silently retaining authoritative-looking rows. Auth/token rejection
does not consume the bounded transport retry loop, and retry exhaustion closes
all remaining handles and rejects synchronization waiters. Explicit close or
any other terminal failure also rejects replay waiters; aborted replay never
reports a synchronized state.

## Verify SDK Changes

Run the SDK checks from the Shunter checkout when touching the runtime package
or generated TypeScript surface:

```bash
rtk npm --prefix typescript/client run test
rtk npm --prefix typescript/client run build
rtk npm --prefix typescript/client run smoke:package
```
