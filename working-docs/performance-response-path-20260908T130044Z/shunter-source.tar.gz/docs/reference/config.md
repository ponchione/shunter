# Config Reference

Use Go doc for exact field types. This page explains practical app-author
intent for the root runtime config.

## Core Fields

| Field | Purpose | Normal guidance |
| --- | --- | --- |
| `DataDir` | Runtime-owned durable state directory. | Set explicitly for real apps. Use `t.TempDir()` in tests. |
| `ExecutorQueueCapacity` | Reducer executor queue capacity. | Leave zero unless load testing shows a need. |
| `DurabilityQueueCapacity` | Durability worker queue capacity. | Leave zero unless load testing shows a need. |
| `EnableProtocol` | Enables WebSocket protocol serving. | Set true for external protocol clients. |
| `ListenAddr` | Address used by `Runtime.ListenAndServe`. | Set when Shunter owns the HTTP server lifecycle. |
| `AuthMode` | Development or strict auth behavior. | Use zero-value dev mode for local work, strict mode for public serving. |
| `OneOffQueryMaxRows` | Hosted raw and declared query result-row limit. | Zero uses 100,000 rows. Set lower for public or memory-constrained services. |
| `OneOffQueryMaxBytes` | Hosted raw and declared query encoded row-list limit. | Zero uses 64 MiB. Unordered rows are checked before retention; ordered queries apply it to retained top-window row payloads. It does not bound all query working memory. |
| `OneOffQueryMaxWork` | Candidate-row, index-probe, and join-pair budget for one-off and declared queries, including aggregate input. | Zero uses 1,000,000 work units for each query execution. |
| `ProcedureResultMaxBytes` | Raw application procedure result limit. | Zero uses 64 MiB. Results above the limit become procedure errors before protocol delivery. |
| `SubscriptionInitialRowLimit` | Aggregate initial/final rows across one subscription set and materialized row slots per live query delta. | Zero uses 100,000 rows. Set from the largest measured legitimate snapshot or delta. |
| `SubscriptionSnapshotMaxBytes` | Aggregate encoded RowList bytes across one initial/final subscription set and conservative materialized bytes per live query delta. | Zero uses 64 MiB. Initial/final snapshots are checked before registry publication; live deltas fail atomically. |
| `SubscriptionOrderedWindowMaxRows` | Working rows retained for `ORDER BY`, computed as `OFFSET + effective LIMIT`. | Zero uses 100,000 rows. Unsafe or overflowing windows fail before snapshot allocation. |
| `SubscriptionMaxQueriesPerSet` | Raw query strings admitted and compiled for one subscription set. | Zero uses 256. The decoder hard ceiling is 4,096. |
| `SubscriptionMaxActiveSetsPerConnection` | Live client query IDs retained for one connection. | Zero uses 128. Unregister and disconnect release capacity. |
| `SubscriptionMaxActiveSubscriptionsPerConnection` | Deduplicated internal live subscriptions retained for one connection. | Zero uses 1,024. Repeated predicates within one set consume one slot. |
| `SubscriptionMaxMultiJoinRelations` | Live multi-way join relation-count limit checked at admission and delta evaluation. | Zero uses 8 relations. |
| `SubscriptionMaxMultiJoinRowsPerRelation` | Committed input-row limit per live multi-way join relation, checked for initial snapshots and before/after delta state. | Zero uses 100,000 rows. |
| `SubscriptionMaxMultiJoinWork` | Compatibility-named candidate-row, index-probe, and join-pair budget for every live snapshot or delta evaluation, including aggregate input. | Zero uses 1,000,000 work units per evaluation. |

Zero queue capacities are normalized to conservative non-zero defaults by the
runtime. Zero query and subscription limits use the defaults above, including
all multi-way join limits. Negative resource limits are rejected during
`Build`.

## Auth Fields

| Field | Purpose |
| --- | --- |
| `AuthSigningKey` | Legacy HS256 token signing/verification key of at least 32 bytes. Required for strict protocol serving unless `AuthVerificationKeys`, `AuthOIDCIssuers`, or `AuthOIDCDiscoveryIssuers` is configured. |
| `AuthVerificationKeys` | Local JWT verification keys for HS256, RS256, or ES256, with optional `KeyID`/`kid` matching for rotation. HS256 secrets require at least 32 bytes; RS256 moduli require 2048–8192 bits. |
| `AuthOIDCIssuers` | Explicit remote JWKS verification sources for RS256 or ES256 JWTs. This config supplies keys, not issuer/audience policy. |
| `AuthOIDCDiscoveryIssuers` | Generic OIDC discovery-document sources that resolve to JWKS verification sources. This config supplies keys, not issuer/audience policy. |
| `AuthIssuers` | Accepted JWT issuer values when non-empty. |
| `AuthAudiences` | Accepted JWT audience values when non-empty. |
| `AuthExtraClaims` | Optional allowlist of extra JWT claim names copied into reducer/procedure caller principals as compact JSON. |
| `AuthMaxExtraClaimBytes` | Per-extra-claim compact JSON byte limit. Zero defaults to 4096. |
| `AuthMaxExtraClaimsBytes` | Total compact JSON byte limit for all preserved extra claims. Zero defaults to 16384. |
| `AnonymousTokenIssuer` | Development anonymous-token issuer override. |
| `AnonymousTokenAudience` | Development anonymous-token audience override. |
| `AnonymousTokenTTL` | Development anonymous-token lifetime override. |

See [Authentication](../authentication.md) and
[Configure auth](../how-to/configure-auth.md) before using strict mode in a
public service.

Extra claim names are trimmed and validated at startup. At most 32 names can be
configured. They may use provider or URI-style names, but cannot be empty,
duplicated, over 256 bytes, contain control characters, or name Shunter-owned
claims: `iss`, `sub`, `aud`, `exp`, `iat`, `nbf`, `hex_identity`, or
`permissions`. Preserved values must be JSON scalar, object, or array values
with nesting no deeper than 16 levels. Extra claims are caller context only;
they do not grant permissions.

`ConfigFromEnv` maps these auth variables:

| Environment variable | Config field |
| --- | --- |
| `SHUNTER_AUTH_MODE` | `AuthMode` |
| `SHUNTER_AUTH_SIGNING_KEY` | `AuthSigningKey` |
| `SHUNTER_AUTH_ISSUERS` | `AuthIssuers` |
| `SHUNTER_AUTH_AUDIENCES` | `AuthAudiences` |
| `SHUNTER_AUTH_OIDC_ISSUERS` | `AuthOIDCIssuers` as `issuer,jwks-url;issuer,jwks-url` |
| `SHUNTER_AUTH_OIDC_DISCOVERY_ISSUERS` | `AuthOIDCDiscoveryIssuers` as `issuer;issuer,discovery-url` |
| `SHUNTER_AUTH_EXTRA_CLAIMS` | `AuthExtraClaims` |
| `SHUNTER_AUTH_MAX_EXTRA_CLAIM_BYTES` | `AuthMaxExtraClaimBytes` |
| `SHUNTER_AUTH_MAX_EXTRA_CLAIMS_BYTES` | `AuthMaxExtraClaimsBytes` |

OIDC discovery env entries configure key discovery only. They do not add
issuer or audience policy; keep `SHUNTER_AUTH_ISSUERS` and
`SHUNTER_AUTH_AUDIENCES` explicit for strict deployments.

Extra-claim byte-limit env vars are decimal integers. Unset or zero values use
the 4096-byte per-claim and 16384-byte total defaults; negative values fail
`ConfigFromEnvE`.

## Protocol Field

`Protocol` contains WebSocket tuning:

- `PingInterval`
- `IdleTimeout`
- `CloseHandshakeTimeout`
- `WriteTimeout`
- `DisconnectTimeout`
- `OutgoingBufferMessages`
- `MaxOutboundQueuedBytes`
- `IncomingQueueMessages`
- `MaxMessageSize`
- `MaxOutboundMessageSize`

Zero values use protocol package defaults. Set these only when you are tuning a
measured serving workload or enforcing an application-specific message limit.
`WriteTimeout` bounds each server-to-client WebSocket data write, which keeps a
slow reader from blocking unrelated outbound delivery indefinitely.
`OutgoingBufferMessages` defaults to 1,024 and `MaxOutboundQueuedBytes`
defaults to 65 MiB. Exceeding either queue ceiling disconnects the slow client
before another encoded application frame is retained.
These ceilings include frames held while a procedure is running. Procedure
responses precede held frames; overflow disconnects only that connection.
`MaxOutboundMessageSize` defaults to 64 MiB and caps the uncompressed encoded
server message before final-frame allocation or optional compression. Direct
query, procedure, and reducer replies account for their complete response
envelopes; an oversized success becomes a correlated error when that smaller
reply fits, otherwise the connection is terminated.

## Observability Field

`Observability` configures runtime-scoped logs, metrics, diagnostics, and
tracing. The zero value is a no-op for external observations.

Use this field when the app wants structured runtime logs, custom metrics
recording, diagnostic HTTP endpoints, or tracing integration.

With metrics enabled and a recorder configured, `store_memory_bytes` is sampled
at build, after startup, and 30 seconds after each completed sample. Gauges can
lag writes by that interval plus collection time. Sampling scans tables and
indexes under a store read lock outside reducer and migration commits; a sample
can briefly delay writers. One sample runs at a time, and `Close` cancels the
timer and waits for any in-flight sample. Custom recorders must support concurrent
calls and return promptly.

`Diagnostics.MountHealthHTTP` mounts health and readiness only.
`MountDebugHTTP` and `MountMetricsHTTP` are separate detailed-route opt-ins;
`DetailedHTTPMiddleware` can authenticate those two routes. `MountHTTP` remains
a deprecated health-only alias. Strict protocol auth does not protect any
diagnostics route. See [Serve protocol traffic](../how-to/serve-protocol-traffic.md#diagnostics)
for route contents and deployment guidance.

## Common Configs

Local embedded runtime:

```go
cfg := shunter.Config{
	DataDir: "./data/dev",
}
```

Protocol-serving development runtime:

```go
cfg := shunter.Config{
	DataDir:        "./data/dev",
	EnableProtocol: true,
	ListenAddr:     "127.0.0.1:3000",
}
```

Strict protocol runtime with HS256:

```go
cfg := shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
	ListenAddr:     "127.0.0.1:3000",
	AuthMode:       shunter.AuthModeStrict,
	AuthSigningKey: signingKey,
	AuthIssuers:    []string{"https://issuer.example"},
	AuthAudiences:  []string{"chat"},
}
```

Strict protocol runtime with RS256:

```go
cfg := shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
	ListenAddr:     "127.0.0.1:3000",
	AuthMode:       shunter.AuthModeStrict,
	AuthVerificationKeys: []shunter.AuthVerificationKey{
		{
			Algorithm: shunter.AuthAlgorithmRS256,
			KeyID:     "issuer-key-2026-05",
			Key:       issuerPublicKeyPEM,
		},
	},
	AuthIssuers:   []string{"https://issuer.example"},
	AuthAudiences: []string{"chat"},
}
```

Strict protocol runtime with Supabase asymmetric signing keys:

```go
cfg := shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
	ListenAddr:     "127.0.0.1:3000",
	AuthMode:       shunter.AuthModeStrict,
	AuthOIDCIssuers: []shunter.AuthOIDCIssuer{
		{
			Issuer:  "https://<project-ref>.supabase.co/auth/v1",
			JWKSURL: "https://<project-ref>.supabase.co/auth/v1/.well-known/jwks.json",
		},
	},
	AuthIssuers:             []string{"https://<project-ref>.supabase.co/auth/v1"},
	AuthAudiences:           []string{"authenticated"},
	AuthExtraClaims:         []string{"email", "role", "session_id", "aal", "is_anonymous"},
	AuthMaxExtraClaimBytes:  4096,
	AuthMaxExtraClaimsBytes: 16384,
}
```

Supabase remains the delegated auth provider. Shunter validates the externally
issued JWT, enforces `AuthIssuers` and `AuthAudiences`, and does not map
Supabase `role` into Shunter permissions.

Strict protocol runtime with generic OIDC discovery:

```go
cfg := shunter.Config{
	DataDir:        "./data/chat",
	EnableProtocol: true,
	ListenAddr:     "127.0.0.1:3000",
	AuthMode:       shunter.AuthModeStrict,
	AuthOIDCDiscoveryIssuers: []shunter.AuthOIDCDiscoveryIssuer{
		{
			Issuer: "https://issuer.example",
		},
	},
	AuthIssuers:   []string{"https://issuer.example"},
	AuthAudiences: []string{"chat"},
}
```

When `DiscoveryURL` is blank, the default is
`<issuer>/.well-known/openid-configuration` for URL issuers. Non-URL issuers
require an explicit discovery URL. Explicit JWKS remains supported and is the
preferred Supabase asymmetric-signing-key configuration path. Discovery does
not add provider SDK behavior; Shunter still does not manage login/logout,
sessions, refresh tokens, or provider user lifecycle.
