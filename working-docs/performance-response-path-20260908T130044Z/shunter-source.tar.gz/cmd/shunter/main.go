package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"

	shunter "github.com/ponchione/shunter"
	"github.com/ponchione/shunter/codegen"
	"github.com/ponchione/shunter/contractdiff"
	"github.com/ponchione/shunter/contractworkflow"
)

func main() {
	os.Exit(run(os.Stdout, os.Stderr, os.Args[1:]))
}

func run(stdout, stderr io.Writer, args []string) int {
	if len(args) == 0 || isHelpArg(args[0]) {
		printRootHelp(stdout)
		return 0
	}
	if isVersionArg(args[0]) {
		return writeVersion(stdout, stderr)
	}

	switch args[0] {
	case "version":
		return writeVersion(stdout, stderr)
	case "call":
		return runCall(stdout, stderr, args[1:])
	case "procedure":
		return runProcedure(stdout, stderr, args[1:])
	case "query":
		return runQuery(stdout, stderr, args[1:])
	case "describe":
		return runDescribe(stdout, stderr, args[1:])
	case "health":
		return runHealth(stdout, stderr, args[1:])
	case "contract":
		return runContract(stdout, stderr, args[1:])
	case "backup":
		return runBackup(stdout, stderr, args[1:])
	case "restore":
		return runRestore(stdout, stderr, args[1:])
	default:
		writeCLIErrorf(stderr, "unknown command %q\n\n", args[0])
		printRootHelp(stderr)
		return 2
	}
}

func runContract(stdout, stderr io.Writer, args []string) int {
	if len(args) == 0 || isHelpArg(args[0]) {
		printContractHelp(stdout)
		return 0
	}

	switch args[0] {
	case "diff":
		return runContractDiff(stdout, stderr, args[1:])
	case "policy":
		return runContractPolicy(stdout, stderr, args[1:])
	case "plan":
		return runContractPlan(stdout, stderr, args[1:])
	case "codegen":
		return runContractCodegen(stdout, stderr, args[1:])
	case "validate":
		return runContractValidate(stdout, stderr, args[1:])
	case "assert":
		return runContractAssert(stdout, stderr, args[1:])
	default:
		writeCLIErrorf(stderr, "unknown contract command %q\n\n", args[0])
		printContractHelp(stderr)
		return 2
	}
}

func runContractDiff(stdout, stderr io.Writer, args []string) int {
	fs := newFlagSet(stderr, "shunter contract diff")
	previousPath := fs.String("previous", "", "previous contract JSON path")
	currentPath := fs.String("current", "", "current contract JSON path")
	format := fs.String("format", contractworkflow.FormatText, "output format: text or json")
	if code, stop := parseFlags(fs, args); stop {
		return code
	}
	if code := validateContractReadFlags(stderr, fs, *previousPath, *currentPath, *format); code != 0 {
		return code
	}

	report, err := contractworkflow.CompareFiles(*previousPath, *currentPath)
	if err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	out, err := contractworkflow.FormatDiff(report, *format)
	if err != nil {
		writeCLIError(stderr, err)
		return 2
	}
	return writeCLIOutput(stdout, stderr, out)
}

func runContractPolicy(stdout, stderr io.Writer, args []string) int {
	fs := newFlagSet(stderr, "shunter contract policy")
	previousPath := fs.String("previous", "", "previous contract JSON path")
	currentPath := fs.String("current", "", "current contract JSON path")
	strict := fs.Bool("strict", false, "exit with failure when warnings are present")
	requirePreviousVersion := fs.Bool("require-previous-version", false, "warn when module migration metadata omits previous_version")
	format := fs.String("format", contractworkflow.FormatText, "output format: text or json")
	if code, stop := parseFlags(fs, args); stop {
		return code
	}
	if code := validateContractReadFlags(stderr, fs, *previousPath, *currentPath, *format); code != 0 {
		return code
	}

	result, err := contractworkflow.CheckPolicyFiles(*previousPath, *currentPath, contractdiff.PolicyOptions{
		RequirePreviousVersion: *requirePreviousVersion,
		Strict:                 *strict,
	})
	if err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	out, err := contractworkflow.FormatPolicy(result, *format)
	if err != nil {
		writeCLIError(stderr, err)
		return 2
	}
	if code := writeCLIOutput(stdout, stderr, out); code != 0 {
		return code
	}
	if result.Failed {
		return 1
	}
	return 0
}

func runContractPlan(stdout, stderr io.Writer, args []string) int {
	fs := newFlagSet(stderr, "shunter contract plan")
	previousPath := fs.String("previous", "", "previous contract JSON path")
	currentPath := fs.String("current", "", "current contract JSON path")
	strict := fs.Bool("strict", false, "exit with failure when policy warnings are present")
	requirePreviousVersion := fs.Bool("require-previous-version", false, "warn when module migration metadata omits previous_version")
	validateContracts := fs.Bool("validate", false, "include read-only contract consistency validation warnings")
	format := fs.String("format", contractworkflow.FormatText, "output format: text or json")
	if code, stop := parseFlags(fs, args); stop {
		return code
	}
	if code := validateContractReadFlags(stderr, fs, *previousPath, *currentPath, *format); code != 0 {
		return code
	}

	plan, err := contractworkflow.PlanFiles(*previousPath, *currentPath, contractdiff.PlanOptions{
		Policy: contractdiff.PolicyOptions{
			RequirePreviousVersion: *requirePreviousVersion,
			Strict:                 *strict,
		},
		ValidateContracts: *validateContracts,
	})
	if err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	out, err := contractworkflow.FormatPlan(plan, *format)
	if err != nil {
		writeCLIError(stderr, err)
		return 2
	}
	if code := writeCLIOutput(stdout, stderr, out); code != 0 {
		return code
	}
	if plan.Summary.PolicyFailed {
		return 1
	}
	return 0
}

func runContractCodegen(stdout, stderr io.Writer, args []string) int {
	fs := newFlagSet(stderr, "shunter contract codegen")
	contractPath := fs.String("contract", "", "contract JSON path")
	language := fs.String("language", codegen.LanguageTypeScript, "generator target language")
	profile := fs.String("profile", codegen.ProfileDefault, "TypeScript generation profile: internal, full, or public")
	runtimeImport := fs.String("runtime-import", "", "TypeScript runtime import specifier")
	outputPath := fs.String("out", "", "generated output path")
	if code, stop := parseFlags(fs, args); stop {
		return code
	}
	if code := requireNoArgs(stderr, fs); code != 0 {
		return code
	}
	if code := requirePath(stderr, "contract", *contractPath); code != 0 {
		return code
	}
	if code := requirePath(stderr, "out", *outputPath); code != 0 {
		return code
	}

	if err := contractworkflow.GenerateFile(*contractPath, *outputPath, codegen.Options{
		Language:                *language,
		TypeScriptRuntimeImport: *runtimeImport,
		Profile:                 *profile,
	}); err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	if err := writeCLIStatusf(stdout, "wrote %s\n", *outputPath); err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	return 0
}

func newFlagSet(stderr io.Writer, name string) *flag.FlagSet {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(stderr)
	return fs
}

func parseFlags(fs *flag.FlagSet, args []string) (int, bool) {
	if err := fs.Parse(interspersedFlagArgs(fs, args)); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return 0, true
		}
		return 2, true
	}
	return 0, false
}

// interspersedFlagArgs preserves positional order while moving recognized
// flags (and their values) ahead of positionals for the standard library flag
// parser. A literal -- ends flag recognition and keeps every following token
// positional.
func interspersedFlagArgs(fs *flag.FlagSet, args []string) []string {
	flags := make([]string, 0, len(args))
	positionals := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--" {
			positionals = append(positionals, args[i+1:]...)
			break
		}
		name, hasValue, isFlag := commandLineFlagName(arg)
		if !isFlag {
			positionals = append(positionals, arg)
			continue
		}
		flags = append(flags, arg)
		definition := fs.Lookup(name)
		if definition == nil || hasValue || isBooleanFlag(definition) {
			continue
		}
		if i+1 < len(args) {
			i++
			flags = append(flags, args[i])
		}
	}
	out := make([]string, 0, len(flags)+1+len(positionals))
	out = append(out, flags...)
	if len(positionals) != 0 {
		out = append(out, "--")
		out = append(out, positionals...)
	}
	return out
}

func commandLineFlagName(arg string) (name string, hasValue, ok bool) {
	if len(arg) < 2 || arg[0] != '-' || arg == "-" {
		return "", false, false
	}
	trimmed := strings.TrimLeft(arg, "-")
	if trimmed == "" {
		return "", false, true
	}
	if before, _, found := strings.Cut(trimmed, "="); found {
		return before, true, true
	}
	return trimmed, false, true
}

func isBooleanFlag(definition *flag.Flag) bool {
	boolean, ok := definition.Value.(interface{ IsBoolFlag() bool })
	return ok && boolean.IsBoolFlag()
}

func requireNoArgs(stderr io.Writer, fs *flag.FlagSet) int {
	if fs.NArg() == 0 {
		return 0
	}
	writeCLIErrorf(stderr, "%s: unexpected argument %q\n", fs.Name(), fs.Arg(0))
	return 2
}

func requirePath(stderr io.Writer, name, value string) int {
	if strings.TrimSpace(value) != "" {
		return 0
	}
	writeCLIErrorf(stderr, "--%s is required\n", name)
	return 2
}

func writeCLIOutput(stdout, stderr io.Writer, out []byte) int {
	if _, err := stdout.Write(out); err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	return 0
}

func validateContractReadFlags(stderr io.Writer, fs *flag.FlagSet, previousPath, currentPath, format string) int {
	if code := requireNoArgs(stderr, fs); code != 0 {
		return code
	}
	if code := requirePath(stderr, "previous", previousPath); code != 0 {
		return code
	}
	if code := requirePath(stderr, "current", currentPath); code != 0 {
		return code
	}
	if err := contractworkflow.ValidateFormat(format); err != nil {
		writeCLIError(stderr, err)
		return 2
	}
	return 0
}

func writeCLIError(stderr io.Writer, err error) {
	if err == nil {
		return
	}
	writeCLIErrorf(stderr, "%v\n", err)
}

// writeCLIErrorf and writeCLIStatusf are user-facing command output helpers.
// They use injected writers only; runtime diagnostics must go through
// ObservabilityConfig.Logger and runtimeObservability instead.
func writeCLIErrorf(stderr io.Writer, format string, args ...any) {
	_, _ = fmt.Fprintf(stderr, format, args...)
}

func writeCLIStatusf(stdout io.Writer, format string, args ...any) error {
	_, err := fmt.Fprintf(stdout, format, args...)
	return err
}

func isHelpArg(arg string) bool {
	return arg == "-h" || arg == "--help" || arg == "help"
}

func isVersionArg(arg string) bool {
	return arg == "-version" || arg == "--version"
}

func writeVersion(stdout, stderr io.Writer) int {
	if err := printVersion(stdout); err != nil {
		writeCLIError(stderr, err)
		return 1
	}
	return 0
}

func printVersion(w io.Writer) error {
	info := shunter.CurrentBuildInfo()
	var out strings.Builder
	fmt.Fprintf(&out, "shunter %s\n", info.Version)
	if info.Commit != "" {
		fmt.Fprintf(&out, "commit %s\n", info.Commit)
	}
	if info.Date != "" {
		fmt.Fprintf(&out, "date %s\n", info.Date)
	}
	if info.Dirty {
		fmt.Fprintln(&out, "dirty true")
	}
	if info.GoVersion != "" {
		fmt.Fprintf(&out, "go %s\n", info.GoVersion)
	}
	_, err := io.WriteString(w, out.String())
	return err
}

func printRootHelp(w io.Writer) {
	fmt.Fprint(w, `Shunter contract artifact workflows.

Usage:
  shunter version
  shunter call --url http://127.0.0.1:3000 --contract shunter.contract.json --token "$TOKEN" reducer_name '{"field":"value"}' [--format text|json]
  shunter procedure --url http://127.0.0.1:3000 --contract shunter.contract.json --token "$TOKEN" procedure_name '{"field":"value"}' [--format text|json]
  shunter query --url http://127.0.0.1:3000 --contract shunter.contract.json --token "$TOKEN" query_name ['{"field":"value"}'] [--format text|json]
  shunter query --url http://127.0.0.1:3000 --contract shunter.contract.json --token "$TOKEN" --sql "SELECT * FROM table" [--format text|json]
  shunter describe --contract shunter.contract.json [--section all|tables|reducers|procedures|queries|views|visibility] [--format text|json]
  shunter describe --url http://127.0.0.1:3000 [--format text|json]
  shunter health --contract shunter.contract.json [--format text|json]
  shunter health --url http://127.0.0.1:3000 [--format text|json]
  shunter contract diff --previous old.json --current current.json [--format text|json]
  shunter contract policy --previous old.json --current current.json [--strict] [--require-previous-version] [--format text|json]
  shunter contract plan --previous old.json --current current.json [--strict] [--require-previous-version] [--validate] [--format text|json]
  shunter contract validate --contract shunter.contract.json [--format text|json]
  shunter contract assert --contract shunter.contract.json [--module name] [--module-version v] [--contract-version n] [--schema-version n] [--tables n] [--columns n] [--indexes n] [--reducers n] [--procedures n] [--queries n] [--views n] [--visibility-filters n] [--format text|json]
  shunter contract codegen --contract shunter.contract.json --language typescript [--profile internal|full|public] --out client.ts
  shunter backup --data-dir ./data --out ./backup
  shunter restore --backup ./backup --data-dir ./data

This generic CLI operates on running app servers, existing ModuleContract JSON
files, and offline DataDir directories; offline DataDir commands are backup and
restore only.
It does not export an app module contract; export from an
app-owned binary with Runtime.ExportContractJSON so the binary links the module.
No dynamic module loading is provided.
`)
}

func printContractHelp(w io.Writer) {
	fmt.Fprint(w, `Usage:
  shunter contract diff --previous old.json --current current.json [--format text|json]
  shunter contract policy --previous old.json --current current.json [--strict] [--require-previous-version] [--format text|json]
  shunter contract plan --previous old.json --current current.json [--strict] [--require-previous-version] [--validate] [--format text|json]
  shunter contract validate --contract shunter.contract.json [--format text|json]
  shunter contract assert --contract shunter.contract.json [--module name] [--module-version v] [--contract-version n] [--schema-version n] [--tables n] [--columns n] [--indexes n] [--reducers n] [--procedures n] [--queries n] [--views n] [--visibility-filters n] [--format text|json]
  shunter contract codegen --contract shunter.contract.json --language typescript [--profile internal|full|public] --out client.ts

Contract commands operate on canonical ModuleContract JSON files only.
Export app module contracts from an app-owned binary with Runtime.ExportContractJSON.

Examples:
  shunter contract assert --contract shunter.contract.json --module chat --module-version v0.1.0 --contract-version 1 --tables 1 --reducers 1 --format json
  shunter contract assert --contract shunter.contract.json
`)
}
