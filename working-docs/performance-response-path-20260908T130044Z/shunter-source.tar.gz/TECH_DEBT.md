# Technical debt

Open findings only, updated 2026-09-08. Completed implementations and validation
remain in the [adoption record](working-docs/performance-implementation-data/README.md)
and [completed checklist](working-docs/performance-implementation-progress.md).
Broader deferred work lives in [working-docs/tech-debt.md](working-docs/tech-debt.md).
The [implementation plan](working-docs/performance-implementation-plan.md#work-to-defer-or-reject)
retains all deferred and rejected decisions.

These findings concern Shunter's own guarantees. They are development
opportunities, not release blockers or production capacity claims.

## PERF-03 — Reducer scans materialize rows more than once

- **Status:** Open; optimization deferred until a necessary scan is a measured
  bottleneck.
- **Location:** `store/table.go` (`Scan`), `store/state_view.go` (`ScanTable`),
  `executor/executor.go` (`snapshotReducerRows`).
- **Evidence:** full-row copies occur before application iteration, so early
  return cannot avoid them. Adapter slice growth contributed about 8% of the
  original canary's allocation, alongside larger product-row copies. After
  removing unnecessary ticket and audit scans, adapter slice growth is a small
  cost in that workload. See the
  [investigation](working-docs/performance-investigation.md).
- **Next:** measure a required scan in a representative application path before
  changing iteration. Any optimization must preserve row isolation,
  transaction-local insert/update/delete visibility, mutation during iteration,
  and invocation lifetime. A broad iterator rewrite has no established benefit
  for the adopted canary workload.

## PERF-07 — Opening for append rescans the entire active segment

- **Status:** Open; further optimization deferred pending an actual startup
  requirement.
- **Location:** `commitlog/segment.go` (`OpenSegmentForAppend`),
  `commitlog/durability.go` (`NewDurabilityWorkerWithResumePlan`),
  `lifecycle.go` (durability construction during `Runtime.Start`).
- **Evidence:** opening a 64-MiB active segment validates all 402,048 records
  after snapshot recovery. Historical baseline/candidate reopen medians were
  363.521/372.155 ms, allocating about 173.3 MiB; their timing difference was
  inconclusive. This is existing behavior, not a sidecar-cadence regression.
  See the [larger-history study](working-docs/performance-investigation-data/recovery-history-20260907/README.md).
- **Existing mitigations and limits:** smaller segments and compaction reduce
  some storage-phase costs, but complete hosted startup gains are mixed.
  Direct 16-to-4-MiB HTTP readiness was 2.52% slower before compaction and 4.88%
  faster afterward. Cleanup cost about 77 ms; its overall startup savings were
  inconclusive. Neither changed defaults nor automatic compaction is justified.
  See the [hosted-startup study](working-docs/performance-investigation-data/hosted-start-20260907/README.md).
- **Next:** establish the required complete startup time and representative
  history before another bounded experiment. The scan validates continuity,
  integrity and append position; the resume plan contains no validated byte
  position. Advisory offsets or file size cannot replace that validation.
  Preserve atomic recovery publication, retention, safe append and integrity.
  Recovery API timing excludes this later startup phase; allocation volume is
  distinct from retained memory.
