package codegen

import (
	"bytes"
	"errors"
	"fmt"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	shunter "github.com/ponchione/shunter"
	"github.com/ponchione/shunter/schema"
)

func TestGeneratorAcceptsCanonicalContractJSON(t *testing.T) {
	data, err := contractFixture().MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	out, err := GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("GenerateFromJSON returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export interface MessagesRow {`)
	assertContains(t, ts, `id: bigint;`)
	assertContains(t, ts, `body: string;`)
	assertContains(t, ts, `sentAt: bigint;`)
	assertContains(t, ts, `payload: Uint8Array;`)
	assertContains(t, ts, `tags: string[];`)
	assertContains(t, ts, `export type TableRow<Name extends TableName> = TableRows[Name];`)
	assertContains(t, ts, `export type TableSubscriber<Row = never> = ShunterTableSubscriber<TableName, TableRows, Row>;`)
	assertContains(t, ts, `export type TableRows = {`)
	assertContains(t, ts, `"messages": MessagesRow;`)
	assertContains(t, ts, `export const reducers = {`)
	assertContains(t, ts, `sendMessage: "send_message",`)
	assertContains(t, ts, `export type ReducerCaller = ShunterReducerCaller<ReducerName, Uint8Array, Uint8Array>;`)
	assertContains(t, ts, `export type EncodedReducerCallOptions<Args = unknown> = ShunterEncodedReducerCallOptions<Args>;`)
	assertContains(t, ts, `export type EncodedReducerCallResultOptions<Args = unknown, Result = Uint8Array> = ShunterEncodedReducerCallResultOptions<Args, Result>;`)
	assertContains(t, ts, `export type ReducerCallResult<Name extends ReducerName = ReducerName, Result = Uint8Array> = ShunterReducerCallResult<Name, Result>;`)
	assertContains(t, ts, `export type ReducerCallResultOptions = ShunterReducerCallResultRequestOptions<Uint8Array>;`)
	assertContains(t, ts, `export function callSendMessage(callReducer: ReducerCaller, args: Uint8Array): Promise<Uint8Array> {`)
	assertContains(t, ts, `export function callSendMessageResult(callReducer: ReducerCaller, args: Uint8Array, options: ReducerCallResultOptions = {}): Promise<ReducerCallResult<typeof reducers.sendMessage>> {`)
	assertContains(t, ts, `return shunterCallReducerWithResult(callReducer, "send_message", args, options);`)
	assertContains(t, ts, `export const lifecycleReducers = {`)
	assertContains(t, ts, `OnConnect: "OnConnect",`)
	assertContains(t, ts, `export type QueryRunner = ShunterQueryRunner<Uint8Array>;`)
	assertContains(t, ts, `export type ViewSubscriber = ShunterViewSubscriber;`)
	assertContains(t, ts, `export type DeclaredQueryRunner = ShunterDeclaredQueryRunner<ExecutableQueryName, Uint8Array>;`)
	assertContains(t, ts, `export type DeclaredQueryRunOptions = Omit<DeclaredQueryOptions, "params">;`)
	assertContains(t, ts, `export type RawDeclaredQueryResult<Name extends ExecutableQueryName = ExecutableQueryName> = ShunterRawDeclaredQueryResult<Name>;`)
	assertContains(t, ts, `export type DeclaredQueryDecodeOptions<RowsByName extends object = TableRows> = ShunterDeclaredQueryDecodeOptions<RowsByName>;`)
	assertContains(t, ts, `export type DecodedDeclaredQueryResult<Name extends ExecutableQueryName = ExecutableQueryName, RowsByName extends object = TableRows> = ShunterDecodedDeclaredQueryResult<Name, RowsByName>;`)
	assertContains(t, ts, `export type DeclaredViewSubscriber = ShunterDeclaredViewSubscriber<ExecutableViewName>;`)
	assertContains(t, ts, `export type DeclaredViewHandleSubscriber = ShunterDeclaredViewHandleSubscriber<ExecutableViewName>;`)
	assertContains(t, ts, `export type DeclaredViewSubscriptionOptions<Row = unknown> = Omit<ShunterDeclaredViewSubscriptionOptions<Row>, "params">;`)
	assertContains(t, ts, `export type SubscriptionUnsubscribe = ShunterSubscriptionUnsubscribe;`)
	assertContains(t, ts, `export type SubscriptionHandle<Row = unknown> = ShunterSubscriptionHandle<Row>;`)
	assertContains(t, ts, `export type SubscriptionHandleReturnOptions = ShunterSubscriptionHandleReturnOptions;`)
	assertContains(t, ts, `export type SubscriptionRowEvent<Row = unknown> = ShunterSubscriptionRowEvent<Row>;`)
	assertContains(t, ts, `export type DeclaredViewSubscribeOptions<Row = unknown> = Omit<DeclaredViewSubscriptionOptions<Row>, "returnHandle"> & { readonly returnHandle?: false | undefined };`)
	assertContains(t, ts, `export type TableSubscriptionOptions<Row = unknown> = ShunterTableSubscriptionOptions<Row>;`)
	assertContains(t, ts, `export type TableSubscribeOptions<Row = unknown> = Omit<TableSubscriptionOptions<Row>, "returnHandle"> & { readonly returnHandle?: false | undefined };`)
	assertContains(t, ts, `export type TableSubscribeCaller<Row = never> = <Table extends TableName>(table: Table, onRows?: (rows: ([Row] extends [never] ? TableRows[Table] : Row)[]) => void, options?: TableSubscribeOptions<[Row] extends [never] ? TableRows[Table] : Row>) => Promise<SubscriptionUnsubscribe>;`)
	assertContains(t, ts, `export type TableRowDecoder<Name extends TableName> = ShunterTableRowDecoder<TableRows[Name]>;`)
	assertContains(t, ts, `export type TableRowDecoders<RowsByName extends object = TableRows> = ShunterTableRowDecoders<RowsByName>;`)
	assertContains(t, ts, `BsatnColumn as ShunterBsatnColumn,`)
	assertContains(t, ts, `decodeBsatnProduct as shunterDecodeBsatnProduct,`)
	assertContains(t, ts, `export function decodeMessagesRow(row: Uint8Array): MessagesRow {`)
	assertNotContains(t, ts, `callReducerWithEncodedArgs as shunterCallReducerWithEncodedArgs,`)
	assertNotContains(t, ts, `encodeBsatnProduct as shunterEncodeBsatnProduct,`)
	assertContains(t, ts, `return shunterDecodeBsatnProduct(row, messagesColumns, (values) => ({`)
	assertContains(t, ts, `body: values[1] as string,`)
	assertContains(t, ts, `export const tableRowDecoders = {`)
	assertContains(t, ts, `"messages": decodeMessagesRow,`)
	assertContains(t, ts, `const subscribeOptions: TableSubscribeOptions<MessagesRow> = options.decodeRow === undefined ? { ...options, decodeRow: tableRowDecoders["messages"] } : { ...options };`)
	assertContains(t, ts, `return subscribeTable("messages", onRows, subscribeOptions);`)
	assertContains(t, ts, `export const tableReadPolicies = {`)
	assertContains(t, ts, `messages: { access: "private", permissions: [] },`)
	assertContains(t, ts, `export const queries = {`)
	assertContains(t, ts, `recentMessages: "recent_messages",`)
	assertContains(t, ts, `export const querySQL = {`)
	assertContains(t, ts, `recentMessages: "SELECT * FROM messages",`)
	assertContains(t, ts, `export type ExecutableQueryName = (typeof queries)[keyof typeof querySQL];`)
	assertContains(t, ts, `export function queryRecentMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("recent_messages");`)
	assertContains(t, ts, `export function queryRecentMessagesResult<RowsByName extends object = TableRows>(data: unknown, options: DeclaredQueryDecodeOptions<RowsByName>): DecodedDeclaredQueryResult<typeof queries.recentMessages, RowsByName> {`)
	assertContains(t, ts, `return shunterDecodeDeclaredQueryResult("recent_messages", data, options);`)
	assertContains(t, ts, `export const views = {`)
	assertContains(t, ts, `liveMessages: "live_messages",`)
	assertContains(t, ts, `export const viewSQL = {`)
	assertContains(t, ts, `liveMessages: "SELECT * FROM messages",`)
	assertContains(t, ts, `export type ExecutableViewName = (typeof views)[keyof typeof viewSQL];`)
	assertContains(t, ts, `export function subscribeLiveMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_messages");`)
	assertNotContains(t, ts, `return runQuery("SELECT * FROM messages");`)
	assertNotContains(t, ts, `return subscribeView("SELECT * FROM messages");`)
	assertContains(t, ts, `export const permissions = {`)
	assertContains(t, ts, `reducers: {`)
	assertContains(t, ts, `sendMessage: { required: ["messages:send"] },`)
	assertContains(t, ts, `queries: {`)
	assertContains(t, ts, `recentMessages: { required: ["messages:read"] },`)
	assertContains(t, ts, `views: {`)
	assertContains(t, ts, `liveMessages: { required: ["messages:subscribe"] },`)
	assertContains(t, ts, `export const shunterContract = {`)
	assertContains(t, ts, `generationProfile: "internal",`)
	assertContains(t, ts, `runtimeImport: "@shunter/client",`)
	assertContains(t, ts, `export const readModels = {`)
	assertContains(t, ts, `recentMessages: { tables: ["messages"], tags: ["history"] },`)
	assertContains(t, ts, `liveMessages: { tables: ["messages"], tags: ["realtime"] },`)
	assertContains(t, ts, `export interface ModuleClientBindings {`)
	assertContains(t, ts, `export function createModuleClient(bindings: ModuleClientBindings) {`)
	assertContains(t, ts, `reducers: {`)
	assertContains(t, ts, `sendMessage: {`)
	assertContains(t, ts, `call: (args: Uint8Array) => callSendMessage(bindings.callReducer, args),`)
	assertContains(t, ts, `result: (args: Uint8Array, options: ReducerCallResultOptions = {}) => callSendMessageResult(bindings.callReducer, args, options),`)
	assertContains(t, ts, `queries: {`)
	assertContains(t, ts, `recentMessages: {`)
	assertContains(t, ts, `run: (options: DeclaredQueryRunOptions = {}) => bindings.runDeclaredQuery("recent_messages", options),`)
	assertContains(t, ts, `views: {`)
	assertContains(t, ts, `liveMessages: {`)
	assertContains(t, ts, `subscribe: () => subscribeLiveMessages(bindings.subscribeDeclaredView),`)
	assertContains(t, ts, `tables: {`)
	assertContains(t, ts, `messages: {`)
	assertContains(t, ts, `subscribe: (onRows?: (rows: MessagesRow[]) => void, options: TableSubscribeOptions<MessagesRow> = {}) => subscribeMessages(bindings.subscribeTable, onRows, options),`)
	assertContains(t, ts, `events: {`)
}

func TestGeneratorMapsNullableColumnsToUnionNull(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].Columns[1].Nullable = true
	out, err := GenerateTypeScript(contract)
	if err != nil {
		t.Fatalf("GenerateTypeScript returned error: %v", err)
	}
	assertContains(t, string(out), `body: string | null;`)
	assertContains(t, string(out), `{ name: "body", kind: "string", nullable: true },`)
	assertContains(t, string(out), `body: values[1] as string | null,`)
}

func TestGeneratorAcceptsModuleContractWithoutRuntime(t *testing.T) {
	out, err := Generate(contractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}

	assertContains(t, string(out), `export interface MessagesRow {`)
	assertContains(t, string(out), `export function subscribeMessages(subscribeTable: TableSubscribeCaller<MessagesRow>, onRows?: (rows: MessagesRow[]) => void, options: TableSubscribeOptions<MessagesRow> = {}): Promise<SubscriptionUnsubscribe> {`)
}

func TestTypeScriptGeneratorMapsUUIDColumns(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].Columns = append(contract.Schema.Tables[0].Columns, schema.ColumnExport{
		Name: "external_id",
		Type: "uuid",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export type UUID = string;`)
	assertContains(t, ts, `externalId: UUID;`)
}

func TestTypeScriptGeneratorMapsDurationColumns(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].Columns = append(contract.Schema.Tables[0].Columns, schema.ColumnExport{
		Name: "ttl",
		Type: "duration",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `ttl: bigint;`)
}

func TestTypeScriptGeneratorMapsJSONColumns(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].Columns = append(contract.Schema.Tables[0].Columns, schema.ColumnExport{
		Name: "metadata",
		Type: "json",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}

	assertContains(t, string(out), `metadata: unknown;`)
}

func TestTypeScriptGeneratorExportsCountDistinctDeclaredQuerySQL(t *testing.T) {
	contract := contractFixture()
	contract.Queries = append(contract.Queries, shunter.QueryDescription{
		Name: "distinct_message_bodies",
		SQL:  "SELECT COUNT(DISTINCT body) AS n FROM messages",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `distinctMessageBodies: "distinct_message_bodies",`)
	assertContains(t, ts, `distinctMessageBodies: "SELECT COUNT(DISTINCT body) AS n FROM messages",`)
	assertContains(t, ts, `export function queryDistinctMessageBodies(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("distinct_message_bodies");`)
}

func TestTypeScriptGeneratorExportsAggregateOrderByDeclaredQuerySQL(t *testing.T) {
	contract := contractFixture()
	contract.Queries = append(contract.Queries, shunter.QueryDescription{
		Name: "message_count",
		SQL:  "SELECT COUNT(*) AS n FROM messages ORDER BY n",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `messageCount: "message_count",`)
	assertContains(t, ts, `messageCount: "SELECT COUNT(*) AS n FROM messages ORDER BY n",`)
	assertContains(t, ts, `export function queryMessageCount(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("message_count");`)
}

func TestTypeScriptGeneratorExportsJoinWhereColumnComparisonDeclaredQuerySQL(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables, schema.TableExport{
		Name: "s",
		Columns: []schema.ColumnExport{
			{Name: "id", Type: "uint64"},
			{Name: "u32", Type: "uint64"},
		},
	})
	contract.Queries = append(contract.Queries, shunter.QueryDescription{
		Name: "matching_messages",
		SQL:  "SELECT messages.id FROM messages JOIN s ON messages.id = s.u32 WHERE messages.id = s.id",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `matchingMessages: "matching_messages",`)
	assertContains(t, ts, `matchingMessages: "SELECT messages.id FROM messages JOIN s ON messages.id = s.u32 WHERE messages.id = s.id",`)
	assertContains(t, ts, `export function queryMatchingMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("matching_messages");`)
}

func TestTypeScriptGeneratorExportsJoinWhereColumnComparisonDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables, schema.TableExport{
		Name: "s",
		Columns: []schema.ColumnExport{
			{Name: "id", Type: "uint64"},
			{Name: "u32", Type: "uint64"},
		},
		Indexes: []schema.IndexExport{{Name: "idx_s_u32", Columns: []string{"u32"}}},
	})
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_matching_messages",
		SQL:  "SELECT messages.* FROM messages JOIN s ON messages.id = s.u32 WHERE messages.id = s.id",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveMatchingMessages: "live_matching_messages",`)
	assertContains(t, ts, `liveMatchingMessages: "SELECT messages.* FROM messages JOIN s ON messages.id = s.u32 WHERE messages.id = s.id",`)
	assertContains(t, ts, `export function subscribeLiveMatchingMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_matching_messages");`)
}

func TestTypeScriptGeneratorExportsProjectedDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_message_bodies",
		SQL:  "SELECT body AS text FROM messages",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveMessageBodies: "live_message_bodies",`)
	assertContains(t, ts, `liveMessageBodies: "SELECT body AS text FROM messages",`)
	assertContains(t, ts, `export function subscribeLiveMessageBodies(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_message_bodies");`)
}

func TestTypeScriptGeneratorExportsOrderedDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_ordered_messages",
		SQL:  "SELECT id, body AS text FROM messages ORDER BY text DESC, id ASC",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveOrderedMessages: "live_ordered_messages",`)
	assertContains(t, ts, `liveOrderedMessages: "SELECT id, body AS text FROM messages ORDER BY text DESC, id ASC",`)
	assertContains(t, ts, `export function subscribeLiveOrderedMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_ordered_messages");`)
}

func TestTypeScriptGeneratorExportsLimitedDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_limited_messages",
		SQL:  "SELECT id, body AS text FROM messages ORDER BY text DESC, id ASC LIMIT 2",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveLimitedMessages: "live_limited_messages",`)
	assertContains(t, ts, `liveLimitedMessages: "SELECT id, body AS text FROM messages ORDER BY text DESC, id ASC LIMIT 2",`)
	assertContains(t, ts, `export function subscribeLiveLimitedMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_limited_messages");`)
}

func TestTypeScriptGeneratorExportsOffsetDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_offset_messages",
		SQL:  "SELECT id, body AS text FROM messages ORDER BY text DESC, id ASC LIMIT 2 OFFSET 1",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveOffsetMessages: "live_offset_messages",`)
	assertContains(t, ts, `liveOffsetMessages: "SELECT id, body AS text FROM messages ORDER BY text DESC, id ASC LIMIT 2 OFFSET 1",`)
	assertContains(t, ts, `export function subscribeLiveOffsetMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_offset_messages");`)
}

func TestTypeScriptGeneratorExportsAggregateDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_message_count",
		SQL:  "SELECT COUNT(*) AS n FROM messages",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveMessageCount: "live_message_count",`)
	assertContains(t, ts, `liveMessageCount: "SELECT COUNT(*) AS n FROM messages",`)
	assertContains(t, ts, `export function subscribeLiveMessageCount(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_message_count");`)
}

func TestTypeScriptGeneratorExportsJoinAggregateDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_self_join_count",
		SQL:  "SELECT COUNT(*) AS n FROM messages AS a JOIN messages AS b ON a.id = b.id",
	}, shunter.ViewDescription{
		Name: "live_self_join_distinct_bodies",
		SQL:  "SELECT COUNT(DISTINCT a.body) AS n FROM messages AS a JOIN messages AS b ON a.id = b.id",
	}, shunter.ViewDescription{
		Name: "live_self_join_total",
		SQL:  "SELECT SUM(a.id) AS total FROM messages AS a JOIN messages AS b ON a.id = b.id",
	}, shunter.ViewDescription{
		Name: "live_self_cross_join_count",
		SQL:  "SELECT COUNT(*) AS n FROM messages AS a JOIN messages AS b",
	}, shunter.ViewDescription{
		Name: "live_self_cross_join_total",
		SQL:  "SELECT SUM(a.id) AS total FROM messages AS a JOIN messages AS b",
	}, shunter.ViewDescription{
		Name: "live_self_multi_join_total",
		SQL:  "SELECT SUM(a.id) AS total FROM messages AS a JOIN messages AS b ON a.id = b.id JOIN messages AS c ON b.id = c.id",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveSelfJoinCount: "live_self_join_count",`)
	assertContains(t, ts, `liveSelfJoinCount: "SELECT COUNT(*) AS n FROM messages AS a JOIN messages AS b ON a.id = b.id",`)
	assertContains(t, ts, `export function subscribeLiveSelfJoinCount(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_self_join_count");`)
	assertContains(t, ts, `liveSelfJoinDistinctBodies: "live_self_join_distinct_bodies",`)
	assertContains(t, ts, `liveSelfJoinDistinctBodies: "SELECT COUNT(DISTINCT a.body) AS n FROM messages AS a JOIN messages AS b ON a.id = b.id",`)
	assertContains(t, ts, `export function subscribeLiveSelfJoinDistinctBodies(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_self_join_distinct_bodies");`)
	assertContains(t, ts, `liveSelfJoinTotal: "live_self_join_total",`)
	assertContains(t, ts, `liveSelfJoinTotal: "SELECT SUM(a.id) AS total FROM messages AS a JOIN messages AS b ON a.id = b.id",`)
	assertContains(t, ts, `export function subscribeLiveSelfJoinTotal(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_self_join_total");`)
	assertContains(t, ts, `liveSelfCrossJoinCount: "live_self_cross_join_count",`)
	assertContains(t, ts, `liveSelfCrossJoinCount: "SELECT COUNT(*) AS n FROM messages AS a JOIN messages AS b",`)
	assertContains(t, ts, `export function subscribeLiveSelfCrossJoinCount(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_self_cross_join_count");`)
	assertContains(t, ts, `liveSelfCrossJoinTotal: "live_self_cross_join_total",`)
	assertContains(t, ts, `liveSelfCrossJoinTotal: "SELECT SUM(a.id) AS total FROM messages AS a JOIN messages AS b",`)
	assertContains(t, ts, `export function subscribeLiveSelfCrossJoinTotal(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_self_cross_join_total");`)
	assertContains(t, ts, `liveSelfMultiJoinTotal: "live_self_multi_join_total",`)
	assertContains(t, ts, `liveSelfMultiJoinTotal: "SELECT SUM(a.id) AS total FROM messages AS a JOIN messages AS b ON a.id = b.id JOIN messages AS c ON b.id = c.id",`)
	assertContains(t, ts, `export function subscribeLiveSelfMultiJoinTotal(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_self_multi_join_total");`)
}

func TestTypeScriptGeneratorExportsCountDistinctAggregateDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_distinct_message_bodies",
		SQL:  "SELECT COUNT(DISTINCT body) AS n FROM messages",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveDistinctMessageBodies: "live_distinct_message_bodies",`)
	assertContains(t, ts, `liveDistinctMessageBodies: "SELECT COUNT(DISTINCT body) AS n FROM messages",`)
	assertContains(t, ts, `export function subscribeLiveDistinctMessageBodies(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_distinct_message_bodies");`)
}

func TestTypeScriptGeneratorExportsSumAggregateDeclaredViewSQL(t *testing.T) {
	contract := contractFixture()
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_message_total",
		SQL:  "SELECT SUM(id) AS total FROM messages",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `liveMessageTotal: "live_message_total",`)
	assertContains(t, ts, `liveMessageTotal: "SELECT SUM(id) AS total FROM messages",`)
	assertContains(t, ts, `export function subscribeLiveMessageTotal(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_message_total");`)
}

func TestTypeScriptGeneratorExportsMultiJoinDeclaredQuerySQL(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables,
		schema.TableExport{
			Name: "s",
			Columns: []schema.ColumnExport{
				{Name: "id", Type: "uint64"},
				{Name: "u32", Type: "uint64"},
			},
		},
		schema.TableExport{
			Name: "r",
			Columns: []schema.ColumnExport{
				{Name: "id", Type: "uint64"},
				{Name: "u32", Type: "uint64"},
			},
		},
	)
	contract.Queries = append(contract.Queries, shunter.QueryDescription{
		Name: "multi_join_messages",
		SQL:  "SELECT r.id FROM messages JOIN s ON messages.id = s.u32 JOIN r ON s.u32 = r.u32",
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `multiJoinMessages: "multi_join_messages",`)
	assertContains(t, ts, `multiJoinMessages: "SELECT r.id FROM messages JOIN s ON messages.id = s.u32 JOIN r ON s.u32 = r.u32",`)
	assertContains(t, ts, `export function queryMultiJoinMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("multi_join_messages");`)
}

func TestGeneratorRejectsUnsupportedLanguage(t *testing.T) {
	_, err := Generate(contractFixture(), Options{Language: "go"})
	if err == nil {
		t.Fatal("Generate returned nil error, want unsupported language error")
	}
	if !strings.Contains(err.Error(), `unsupported language "go"`) {
		t.Fatalf("Generate error = %v, want unsupported language", err)
	}
}

func TestGeneratorRejectsUnsupportedLanguageBeforeDecodingContractJSON(t *testing.T) {
	_, err := GenerateFromJSON([]byte(`{`), Options{Language: "go"})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want unsupported language error")
	}
	if !errors.Is(err, ErrUnsupportedLanguage) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrUnsupportedLanguage", err)
	}
	if errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON decoded contract before rejecting language: %v", err)
	}
}

func TestGeneratorRejectsInvalidTypeScriptRuntimeImportBeforeDecodingContractJSON(t *testing.T) {
	_, err := GenerateFromJSON([]byte(`{`), Options{
		Language:                LanguageTypeScript,
		TypeScriptRuntimeImport: "@app/runtime\nnext",
	})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid runtime import error")
	}
	if !strings.Contains(err.Error(), "invalid TypeScript runtime import specifier") {
		t.Fatalf("GenerateFromJSON error = %v, want runtime import context", err)
	}
	if errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON decoded contract before rejecting runtime import: %v", err)
	}
}

func TestGeneratorRejectsInvalidProfileBeforeDecodingContractJSON(t *testing.T) {
	_, err := GenerateFromJSON([]byte(`{`), Options{
		Language: LanguageTypeScript,
		Profile:  "private",
	})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid profile error")
	}
	if !errors.Is(err, ErrUnsupportedProfile) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrUnsupportedProfile", err)
	}
	if errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON decoded contract before rejecting profile: %v", err)
	}
}

func TestTypeScriptProfilesPreserveDefaultOutput(t *testing.T) {
	contract := contractFixture()
	want, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate default returned error: %v", err)
	}

	for _, tc := range []struct {
		name    string
		profile string
		want    string
	}{
		{name: "blank", profile: ProfileDefault, want: ProfileInternal},
		{name: "internal", profile: ProfileInternal, want: ProfileInternal},
		{name: "full", profile: ProfileFull, want: ProfileFull},
		{name: "trimmed case", profile: " FULL ", want: ProfileFull},
	} {
		t.Run("Generate/"+tc.name, func(t *testing.T) {
			got, err := Generate(contract, Options{
				Language: LanguageTypeScript,
				Profile:  tc.profile,
			})
			if err != nil {
				t.Fatalf("Generate returned error: %v", err)
			}
			if tc.want == ProfileInternal && !bytes.Equal(got, want) {
				t.Fatalf("profile %q changed generated output\n--- got ---\n%s\n--- want ---\n%s", tc.profile, got, want)
			}
			assertTypeScriptOutputDiffersOnlyByProvenance(t, got, want)
			assertContains(t, string(got), `generationProfile: `+strconv.Quote(tc.want)+`,`)
			assertContains(t, string(got), `runtimeImport: "@shunter/client",`)
		})

		t.Run("GenerateTypeScriptWithOptions/"+tc.name, func(t *testing.T) {
			got, err := GenerateTypeScriptWithOptions(contract, TypeScriptOptions{Profile: tc.profile})
			if err != nil {
				t.Fatalf("GenerateTypeScriptWithOptions returned error: %v", err)
			}
			if tc.want == ProfileInternal && !bytes.Equal(got, want) {
				t.Fatalf("profile %q changed TypeScript output\n--- got ---\n%s\n--- want ---\n%s", tc.profile, got, want)
			}
			assertTypeScriptOutputDiffersOnlyByProvenance(t, got, want)
			assertContains(t, string(got), `generationProfile: `+strconv.Quote(tc.want)+`,`)
			assertContains(t, string(got), `runtimeImport: "@shunter/client",`)
		})
	}
}

func TestTypeScriptGeneratorEmitsNormalizedProvenance(t *testing.T) {
	out, err := Generate(contractFixture(), Options{
		Language:                LanguageTypeScript,
		TypeScriptRuntimeImport: " @app/shunter-runtime ",
		Profile:                 " FULL ",
	})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `} from "@app/shunter-runtime";`)
	assertContains(t, ts, `generationProfile: "full",`)
	assertContains(t, ts, `runtimeImport: "@app/shunter-runtime",`)
	assertNotContains(t, ts, `runtimeImport: " @app/shunter-runtime ",`)
}

func TestTypeScriptPublicProfileGolden(t *testing.T) {
	got, err := Generate(publicProfileContractFixture(), Options{
		Language: LanguageTypeScript,
		Profile:  ProfilePublic,
	})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	assertContains(t, string(got), `generationProfile: "public",`)
	assertContains(t, string(got), `runtimeImport: "@shunter/client",`)

	assertCodegenGoldenBytes(t, filepath.Join("testdata", "typescript_public_profile.ts"), got)
}

func TestTypeScriptPublicProfileHidesSystemTablesBySDKVisibility(t *testing.T) {
	out, err := Generate(publicProfileContractFixture(), Options{
		Language: LanguageTypeScript,
		Profile:  ProfilePublic,
	})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `sysVisible: "sys_visible",`)
	assertContains(t, ts, `export interface SysVisibleRow {`)
	assertContains(t, ts, `export function subscribeSysVisible(subscribeTable: TableSubscribeCaller<SysVisibleRow>, onRows?: (rows: SysVisibleRow[]) => void, options: TableSubscribeOptions<SysVisibleRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertNotContains(t, ts, `scheduler: "scheduler",`)
	assertNotContains(t, ts, `export interface SchedulerRow {`)
	assertNotContains(t, ts, `"scheduler": SchedulerRow;`)
	assertNotContains(t, ts, `decodeSchedulerRow`)
	assertNotContains(t, ts, `export function subscribeScheduler(`)
	assertNotContains(t, ts, `return subscribeTable("scheduler",`)
	assertNotContains(t, ts, `scheduler: { access:`)
}

func TestTypeScriptPublicProfileHidesPrivateAndInternalTableHelpers(t *testing.T) {
	out, err := Generate(publicProfileContractFixture(), Options{
		Language: LanguageTypeScript,
		Profile:  ProfilePublic,
	})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `messages: "messages",`)
	assertContains(t, ts, `notifications: "notifications",`)
	assertContains(t, ts, `export function subscribeNotificationsInserts(subscribeTable: TableSubscribeCaller<NotificationsRow>, onInsert: (event: SubscriptionRowEvent<NotificationsRow>) => void, options: TableSubscribeOptions<NotificationsRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `messages: { access: "private", permissions: [] },`)
	assertContains(t, ts, `sysVisible: { access: "private", permissions: [] },`)
	assertContains(t, ts, `notifications: { access: "private", permissions: [] },`)
	assertNotContains(t, ts, `internalNotes: "internal_notes",`)
	assertNotContains(t, ts, `privateNotes: "private_notes",`)
	assertNotContains(t, ts, `secretEvents: "secret_events",`)
	assertNotContains(t, ts, `export interface InternalNotesRow {`)
	assertNotContains(t, ts, `export interface PrivateNotesRow {`)
	assertNotContains(t, ts, `export interface SecretEventsRow {`)
	assertNotContains(t, ts, `decodeInternalNotesRow`)
	assertNotContains(t, ts, `decodePrivateNotesRow`)
	assertNotContains(t, ts, `decodeSecretEventsRow`)
	assertNotContains(t, ts, `export function subscribeInternalNotes(`)
	assertNotContains(t, ts, `export function subscribePrivateNotes(`)
	assertNotContains(t, ts, `export function subscribeSecretEvents(`)
	assertNotContains(t, ts, `subscribeSecretEventsInserts`)
	assertNotContains(t, ts, `internalNotes: { access:`)
	assertNotContains(t, ts, `privateNotes: { access:`)
	assertNotContains(t, ts, `secretEvents: { access:`)
}

func TestTypeScriptPublicProfileHonorsReflectedTableSDKVisibility(t *testing.T) {
	type ReflectedMessages struct {
		ID uint64 `shunter:"primarykey"`
	}

	b := schema.NewBuilder()
	b.SchemaVersion(1)
	if err := schema.RegisterTable[ReflectedMessages](b,
		schema.WithTableName("messages"),
		schema.WithTableSDKVisibility(schema.TableSDKVisibilityPrivate),
	); err != nil {
		t.Fatalf("RegisterTable failed: %v", err)
	}
	engine, err := b.Build(schema.EngineOptions{})
	if err != nil {
		t.Fatalf("Build failed: %v", err)
	}

	contract := contractFixture()
	found := false
	for _, table := range engine.ExportSchema().Tables {
		if table.Name == "messages" {
			contract.Schema.Tables[0] = table
			found = true
			break
		}
	}
	if !found || contract.Schema.Tables[0].SDK == nil || contract.Schema.Tables[0].SDK.Visibility != schema.TableSDKVisibilityPrivate {
		t.Fatalf("reflected messages SDK metadata was not exported: %#v", contract.Schema.Tables[0].SDK)
	}

	out, err := Generate(contract, Options{Language: LanguageTypeScript, Profile: ProfilePublic})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	assertNotContains(t, string(out), `messages: "messages",`)
	assertNotContains(t, string(out), `export interface MessagesRow {`)
}

func TestTypeScriptPublicProfileKeepsDeclaredReadDecodingForHiddenTables(t *testing.T) {
	out, err := Generate(publicProfileContractFixture(), Options{
		Language: LanguageTypeScript,
		Profile:  ProfilePublic,
	})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `privateNoteSummaries: "private_note_summaries",`)
	assertContains(t, ts, `privateNoteSummaries: "SELECT id, body FROM private_notes",`)
	assertContains(t, ts, `export interface PrivateNoteSummariesQueryRow {`)
	assertContains(t, ts, `export type PrivateNoteSummariesQueryRows = {`)
	assertContains(t, ts, `"private_notes": PrivateNoteSummariesQueryRow;`)
	assertContains(t, ts, `export const privateNoteSummariesQueryRowDecoders = {`)
	assertContains(t, ts, `"private_notes": decodePrivateNoteSummariesQueryRow,`)
	assertContains(t, ts, `const decodeOptions: DeclaredQueryDecodeOptions<PrivateNoteSummariesQueryRows> = options.tableDecoders === undefined && options.decodeRow === undefined ? { ...options, tableDecoders: privateNoteSummariesQueryRowDecoders } : options;`)
	assertContains(t, ts, `export async function queryPrivateNoteSummariesDecoded(runDeclaredQuery: DeclaredQueryRunner, options: DeclaredQueryDecodeOptions<PrivateNoteSummariesQueryRows> = {}): Promise<DecodedDeclaredQueryResult<typeof queries.privateNoteSummaries, PrivateNoteSummariesQueryRows>> {`)
	assertContains(t, ts, `liveInternalAudit: "live_internal_audit",`)
	assertContains(t, ts, `export interface LiveInternalAuditViewRow {`)
	assertContains(t, ts, `export function subscribeLiveInternalAudit(subscribeDeclaredView: DeclaredViewSubscriber, options: DeclaredViewSubscribeOptions<LiveInternalAuditViewRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertNotContains(t, ts, `tableRowDecoders["private_notes"]`)
}

func TestTypeScriptPublicProfileKeepsPermissionAndReadModelMetadataForHiddenTables(t *testing.T) {
	out, err := Generate(publicProfileContractFixture(), Options{
		Language: LanguageTypeScript,
		Profile:  ProfilePublic,
	})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `privateNoteSummaries: { required: ["notes:read"] },`)
	assertContains(t, ts, `liveInternalAudit: { required: ["audit:read"] },`)
	assertContains(t, ts, `privateNoteSummaries: { tables: ["private_notes"], tags: ["public-query"] },`)
	assertContains(t, ts, `liveInternalAudit: { tables: ["internal_notes"], tags: ["internal-view"] },`)
	assertNotContains(t, ts, `export function subscribePrivateNotes(`)
	assertNotContains(t, ts, `export function subscribeInternalNotes(`)
}

func TestGeneratorRejectsUnusableContractJSON(t *testing.T) {
	_, err := GenerateFromJSON([]byte(`{"version":1,"tables":[],"reducers":[]}`), Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !strings.Contains(err.Error(), "invalid module contract") {
		t.Fatalf("GenerateFromJSON error = %v, want invalid module contract", err)
	}
}

func TestGeneratorRejectsCodegenMetadataMismatchWithContext(t *testing.T) {
	contract := contractFixture()
	contract.Codegen.ContractFormat = "unexpected.format"
	contract.Codegen.ContractVersion = shunter.ModuleContractVersion + 1
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), `codegen.contract_format = "unexpected.format"`) {
		t.Fatalf("GenerateFromJSON error = %v, want codegen format context", err)
	}
	if !strings.Contains(err.Error(), "codegen.contract_version") {
		t.Fatalf("GenerateFromJSON error = %v, want codegen version context", err)
	}
}

func TestGeneratorRejectsContractWithInvalidDeclarationSQL(t *testing.T) {
	contract := contractFixture()
	contract.Queries[0].SQL = "SELECT * FROM missing"
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !strings.Contains(err.Error(), "queries.recent_messages.sql") {
		t.Fatalf("GenerateFromJSON error = %v, want declaration SQL context", err)
	}
}

func TestGeneratorRejectsUnknownPermissionTargetWithContext(t *testing.T) {
	contract := contractFixture()
	contract.Permissions.Reducers = []shunter.PermissionContractDeclaration{{
		Name:     "missing_reducer",
		Required: []string{"messages:send"},
	}}
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), "permissions.reducer.missing_reducer references unknown reducer") {
		t.Fatalf("GenerateFromJSON error = %v, want permission reducer target context", err)
	}
}

func TestGeneratorRejectsInvalidTableReadPolicyWithContext(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].ReadPolicy = schema.ReadPolicy{
		Access:      schema.TableAccessPublic,
		Permissions: []string{"messages:read"},
	}
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), "schema.tables.messages.read_policy invalid") {
		t.Fatalf("GenerateFromJSON error = %v, want table read policy context", err)
	}
	if !strings.Contains(err.Error(), "public read policy must not include permissions") {
		t.Fatalf("GenerateFromJSON error = %v, want public read policy detail", err)
	}
}

func TestGeneratorRejectsInvalidSchemaColumnTypeWithContext(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].Columns[1].Type = "notAType"
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), `schema.tables.messages.columns.body type "notAType" is invalid`) {
		t.Fatalf("GenerateFromJSON error = %v, want invalid schema column type context", err)
	}
}

func TestGeneratorRejectsUnknownReadModelTargetWithContext(t *testing.T) {
	contract := contractFixture()
	contract.ReadModel.Declarations = []shunter.ReadModelContractDeclaration{{
		Surface: shunter.ReadModelSurfaceQuery,
		Name:    "missing_query",
		Tables:  []string{"messages"},
		Tags:    []string{"history"},
	}}
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), "read_model.query.missing_query references unknown query") {
		t.Fatalf("GenerateFromJSON error = %v, want read model query target context", err)
	}
}

func TestGeneratorRejectsInvalidReadModelSurfaceWithContext(t *testing.T) {
	contract := contractFixture()
	contract.ReadModel.Declarations = []shunter.ReadModelContractDeclaration{{
		Surface: "subscription",
		Name:    "recent_messages",
		Tables:  []string{"messages"},
		Tags:    []string{"history"},
	}}
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), `read_model surface "subscription" is invalid`) {
		t.Fatalf("GenerateFromJSON error = %v, want invalid read model surface context", err)
	}
}

func TestGeneratorRejectsInvalidMigrationSurfaceWithContext(t *testing.T) {
	contract := contractFixture()
	contract.Migrations.Declarations = []shunter.MigrationContractDeclaration{{
		Surface: "subscription",
		Name:    "recent_messages",
		Metadata: shunter.MigrationMetadata{
			Compatibility: shunter.MigrationCompatibilityCompatible,
		},
	}}
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), `migrations surface "subscription" is invalid`) {
		t.Fatalf("GenerateFromJSON error = %v, want invalid migration surface context", err)
	}
}

func TestGeneratorRejectsUnknownMigrationTargetWithContext(t *testing.T) {
	contract := contractFixture()
	contract.Migrations.Declarations = []shunter.MigrationContractDeclaration{{
		Surface: shunter.MigrationSurfaceTable,
		Name:    "missing_table",
		Metadata: shunter.MigrationMetadata{
			Compatibility: shunter.MigrationCompatibilityCompatible,
		},
	}}
	data, err := contract.MarshalCanonicalJSON()
	if err != nil {
		t.Fatalf("MarshalCanonicalJSON returned error: %v", err)
	}

	_, err = GenerateFromJSON(data, Options{Language: LanguageTypeScript})
	if err == nil {
		t.Fatal("GenerateFromJSON returned nil error, want invalid contract error")
	}
	if !errors.Is(err, ErrInvalidContract) {
		t.Fatalf("GenerateFromJSON error = %v, want ErrInvalidContract", err)
	}
	if !strings.Contains(err.Error(), "migrations.table.missing_table references unknown table") {
		t.Fatalf("GenerateFromJSON error = %v, want unknown migration target context", err)
	}
}

func TestTypeScriptGeneratorEscapesModuleMetadataInHeaderComment(t *testing.T) {
	contract := contractFixture()
	contract.Module.Name = "chat\nexport const injected = true;"
	contract.Module.Version = "v1\r\nmore"

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `// Module: chat\nexport const injected = true; v1\r\nmore`)
	assertNotContains(t, ts, "\nexport const injected = true;")
}

func TestTypeScriptGeneratorIsDeterministic(t *testing.T) {
	first, err := Generate(contractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("first Generate returned error: %v", err)
	}
	second, err := Generate(contractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("second Generate returned error: %v", err)
	}
	if string(first) != string(second) {
		t.Fatalf("Generate was not deterministic:\nfirst:\n%s\nsecond:\n%s", first, second)
	}
}

func TestTypeScriptGeneratorConcurrentDeterminismShortSoak(t *testing.T) {
	const (
		seed       = uint64(0xc0de6e17)
		workers    = 6
		iterations = 64
	)
	fixtures := []struct {
		name     string
		contract shunter.ModuleContract
	}{
		{name: "canonical", contract: contractFixture()},
		{name: "collision", contract: codegenIdentifierCollisionFixture()},
	}
	for i := range fixtures {
		fixtures[i].contract.Module.Metadata["soak"] = fixtures[i].name
	}

	expected := make([][]byte, len(fixtures))
	canonicalJSON := make([][]byte, len(fixtures))
	for i, fixture := range fixtures {
		out, err := Generate(fixture.contract, Options{Language: LanguageTypeScript})
		if err != nil {
			t.Fatalf("seed=%#x fixture=%s operation=GenerateExpected observed_error=%v expected=nil", seed, fixture.name, err)
		}
		expected[i] = out
		data, err := fixture.contract.MarshalCanonicalJSON()
		if err != nil {
			t.Fatalf("seed=%#x fixture=%s operation=MarshalCanonicalJSON observed_error=%v expected=nil", seed, fixture.name, err)
		}
		canonicalJSON[i] = data
	}

	start := make(chan struct{})
	ready := make(chan struct{}, workers)
	failures := make(chan string, workers*iterations)
	var wg sync.WaitGroup
	for worker := range workers {
		wg.Add(1)
		go func(worker int) {
			defer wg.Done()
			ready <- struct{}{}
			<-start
			for op := range iterations {
				fixtureIndex := int((seed + uint64(worker)*11 + uint64(op)*7) % uint64(len(fixtures)))
				fixture := fixtures[fixtureIndex]
				var (
					out []byte
					err error
				)
				if (seed+uint64(worker)+uint64(op))%2 == 0 {
					out, err = Generate(fixture.contract, Options{Language: LanguageTypeScript})
				} else {
					out, err = GenerateFromJSON(canonicalJSON[fixtureIndex], Options{Language: LanguageTypeScript})
				}
				if err != nil {
					failures <- fmt.Sprintf("seed=%#x worker=%d op=%d runtime_config=workers=%d/iterations=%d fixture=%s operation=Generate observed_error=%v expected=nil",
						seed, worker, op, workers, iterations, fixture.name, err)
					continue
				}
				if !bytes.Equal(out, expected[fixtureIndex]) {
					failures <- fmt.Sprintf("seed=%#x worker=%d op=%d runtime_config=workers=%d/iterations=%d fixture=%s operation=GenerateDeterminism observed_len=%d expected_len=%d",
						seed, worker, op, workers, iterations, fixture.name, len(out), len(expected[fixtureIndex]))
				}
				if (seed+uint64(worker)+uint64(op))%5 == 0 {
					runtime.Gosched()
				}
			}
		}(worker)
	}

	waitForCodegenSoakWorkers(t, ready, workers, "seed=0xc0de6e17 codegen workers started")
	close(start)
	wg.Wait()
	close(failures)
	for failure := range failures {
		t.Fatal(failure)
	}
}

func TestTypeScriptGeneratorAvoidsTableViewSubscribeHelperNameCollisions(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables, schema.TableExport{
		Name: "live_messages",
		Columns: []schema.ColumnExport{
			{Name: "id", Type: "uint64"},
		},
		Indexes: []schema.IndexExport{},
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export function subscribeLiveMessages(subscribeTable: TableSubscribeCaller<LiveMessagesRow>, onRows?: (rows: LiveMessagesRow[]) => void, options: TableSubscribeOptions<LiveMessagesRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `export function subscribeLiveMessages2(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
}

func TestTypeScriptGeneratorDisambiguatesReducerHelperNameCollisions(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Reducers = append(contract.Schema.Reducers, schema.ReducerExport{Name: "send-message"})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `sendMessage: "send_message",`)
	assertContains(t, ts, `sendMessage2: "send-message",`)
	assertContains(t, ts, `export function callSendMessage(callReducer: ReducerCaller, args: Uint8Array): Promise<Uint8Array> {`)
	assertContains(t, ts, `return callReducer("send_message", args);`)
	assertContains(t, ts, `export function callSendMessage2(callReducer: ReducerCaller, args: Uint8Array): Promise<Uint8Array> {`)
	assertContains(t, ts, `return callReducer("send-message", args);`)
}

func TestTypeScriptGeneratorDisambiguatesTopLevelHelperNameCollisions(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Reducers = append(contract.Schema.Reducers, schema.ReducerExport{Name: "SendMessage"})
	contract.Queries = append(contract.Queries,
		shunter.QueryDescription{Name: "RecentMessages", SQL: "SELECT * FROM messages"},
		shunter.QueryDescription{Name: "sQL", SQL: "SELECT * FROM messages"},
	)

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export function callSendMessage(callReducer: ReducerCaller, args: Uint8Array): Promise<Uint8Array> {`)
	assertContains(t, ts, `return callReducer("send_message", args);`)
	assertContains(t, ts, `export function callSendMessage2(callReducer: ReducerCaller, args: Uint8Array): Promise<Uint8Array> {`)
	assertContains(t, ts, `return callReducer("SendMessage", args);`)
	assertContains(t, ts, `export function queryRecentMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("recent_messages");`)
	assertContains(t, ts, `export function queryRecentMessages2(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("RecentMessages");`)
	assertContains(t, ts, `sQL: "sQL",`)
	assertContains(t, ts, `export const querySQL = {`)
	assertContains(t, ts, `export function querySQL2(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("sQL");`)
	assertNotContains(t, ts, `export function querySQL(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
}

func TestTypeScriptGeneratorDisambiguatesLifecycleReducerIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Reducers = append(contract.Schema.Reducers,
		schema.ReducerExport{Name: "on-connect", Lifecycle: true},
		schema.ReducerExport{Name: "default", Lifecycle: true},
	)

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const lifecycleReducers = {`)
	assertContains(t, ts, `OnConnect: "OnConnect",`)
	assertContains(t, ts, `OnConnect2: "on-connect",`)
	assertContains(t, ts, `Default: "default",`)
}

func TestTypeScriptGeneratorDisambiguatesFallbackAndReservedTableIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables,
		schema.TableExport{
			Name:    "!!!",
			Columns: []schema.ColumnExport{{Name: "id", Type: "uint64"}},
		},
		schema.TableExport{
			Name:    "_",
			Columns: []schema.ColumnExport{{Name: "id", Type: "uint64"}},
		},
		schema.TableExport{
			Name:    "class",
			Columns: []schema.ColumnExport{{Name: "id", Type: "uint64"}},
		},
		schema.TableExport{
			Name:    "class!",
			Columns: []schema.ColumnExport{{Name: "id", Type: "uint64"}},
		},
	)

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export interface _Row {`)
	assertContains(t, ts, `export interface _2Row {`)
	assertContains(t, ts, `_: "!!!",`)
	assertContains(t, ts, `_2: "_",`)
	assertContains(t, ts, `class_: "class",`)
	assertContains(t, ts, `class_2: "class!",`)
	assertContains(t, ts, `"!!!": _Row;`)
	assertContains(t, ts, `"_": _2Row;`)
	assertContains(t, ts, `"class": ClassRow;`)
	assertContains(t, ts, `"class!": Class2Row;`)
	assertContains(t, ts, `export function subscribe_(subscribeTable: TableSubscribeCaller<_Row>, onRows?: (rows: _Row[]) => void, options: TableSubscribeOptions<_Row> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `export function subscribe_2(subscribeTable: TableSubscribeCaller<_2Row>, onRows?: (rows: _2Row[]) => void, options: TableSubscribeOptions<_2Row> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `export function subscribeClass(subscribeTable: TableSubscribeCaller<ClassRow>, onRows?: (rows: ClassRow[]) => void, options: TableSubscribeOptions<ClassRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `export function subscribeClass2(subscribeTable: TableSubscribeCaller<Class2Row>, onRows?: (rows: Class2Row[]) => void, options: TableSubscribeOptions<Class2Row> = {}): Promise<SubscriptionUnsubscribe> {`)
}

func TestTypeScriptGeneratorDisambiguatesRowFieldIdentifierCollisions(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].Columns = []schema.ColumnExport{
		{Name: "body_text", Type: "string"},
		{Name: "body-text", Type: "string"},
		{Name: "class", Type: "uint64"},
		{Name: "class!", Type: "uint64"},
	}
	contract.Schema.Tables[0].Indexes = nil

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export interface MessagesRow {`)
	assertContains(t, ts, `bodyText: string;`)
	assertContains(t, ts, `bodyText2: string;`)
	assertContains(t, ts, `class_: bigint;`)
	assertContains(t, ts, `class_2: bigint;`)
}

func TestTypeScriptGeneratorDeclaredHelpersUseNamedCallbacksNotSQL(t *testing.T) {
	out, err := Generate(contractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export type QueryRunner = ShunterQueryRunner<Uint8Array>;`)
	assertContains(t, ts, `export type ViewSubscriber = ShunterViewSubscriber;`)
	assertContains(t, ts, `export type DeclaredQueryRunner = ShunterDeclaredQueryRunner<ExecutableQueryName, Uint8Array>;`)
	assertContains(t, ts, `export type DeclaredViewSubscriber = ShunterDeclaredViewSubscriber<ExecutableViewName>;`)
	assertContains(t, ts, `export function queryRecentMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("recent_messages");`)
	assertContains(t, ts, `export function subscribeLiveMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_messages");`)
	assertNotContains(t, ts, `return runDeclaredQuery("SELECT * FROM messages");`)
	assertNotContains(t, ts, `return subscribeDeclaredView("SELECT * FROM messages");`)
	assertNotContains(t, ts, `return runQuery("SELECT * FROM messages");`)
	assertNotContains(t, ts, `return subscribeView("SELECT * FROM messages");`)
}

func TestTypeScriptGeneratorEmitsDeclaredQueryParameterCodec(t *testing.T) {
	out, err := Generate(declaredReadParametersContractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `DeclaredQueryOptions as ShunterDeclaredQueryOptions,`)
	assertContains(t, ts, `encodeBsatnProduct as shunterEncodeBsatnProduct,`)
	assertContains(t, ts, `export type DeclaredQueryOptions = ShunterDeclaredQueryOptions;`)
	assertContains(t, ts, `export type DeclaredQueryRunOptions = Omit<DeclaredQueryOptions, "params">;`)
	assertContains(t, ts, `export type DeclaredQueryDecodedRunOptions<RowsByName extends object = TableRows> = DeclaredQueryRunOptions & DeclaredQueryDecodeOptions<RowsByName>;`)
	assertContains(t, ts, `export interface MessagesByTopicParams {`)
	assertContains(t, ts, `topic: string;`)
	assertContains(t, ts, `afterId: bigint;`)
	assertContains(t, ts, `const messagesByTopicParamColumns = [`)
	assertContains(t, ts, `{ name: "topic", kind: "string" },`)
	assertContains(t, ts, `{ name: "after_id", kind: "uint64" },`)
	assertContains(t, ts, `export function encodeMessagesByTopicParams(value: MessagesByTopicParams): Uint8Array {`)
	assertContains(t, ts, `return shunterEncodeBsatnProduct([`)
	assertContains(t, ts, `value.topic,`)
	assertContains(t, ts, `value.afterId,`)
	assertContains(t, ts, `], messagesByTopicParamColumns);`)
}

func TestTypeScriptGeneratorEmitsDeclaredViewParameterCodec(t *testing.T) {
	out, err := Generate(declaredReadParametersContractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export interface LiveMessagesByTopicParams {`)
	assertContains(t, ts, `topic: string;`)
	assertContains(t, ts, `const liveMessagesByTopicParamColumns = [`)
	assertContains(t, ts, `{ name: "topic", kind: "string" },`)
	assertContains(t, ts, `export function encodeLiveMessagesByTopicParams(value: LiveMessagesByTopicParams): Uint8Array {`)
	assertContains(t, ts, `value.topic,`)
	assertContains(t, ts, `], liveMessagesByTopicParamColumns);`)
}

func TestTypeScriptGeneratorDeclaredQueryHelpersAcceptTypedParams(t *testing.T) {
	out, err := Generate(declaredReadParametersContractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export function queryMessagesByTopic(runDeclaredQuery: DeclaredQueryRunner, params: MessagesByTopicParams, options: DeclaredQueryRunOptions = {}): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("messages_by_topic", { ...options, params: encodeMessagesByTopicParams(params) });`)
	assertContains(t, ts, `export async function queryMessagesByTopicDecoded(runDeclaredQuery: DeclaredQueryRunner, params: MessagesByTopicParams, options: DeclaredQueryDecodedRunOptions<MessagesByTopicQueryRows> = {}): Promise<DecodedDeclaredQueryResult<typeof queries.messagesByTopic, MessagesByTopicQueryRows>> {`)
	assertContains(t, ts, `const queryOptions: DeclaredQueryOptions = {`)
	assertContains(t, ts, `params: encodeMessagesByTopicParams(params),`)
	assertContains(t, ts, `const decodeOptions: DeclaredQueryDecodeOptions<MessagesByTopicQueryRows> = {`)
	assertContains(t, ts, `return queryMessagesByTopicResult(await runDeclaredQuery("messages_by_topic", queryOptions), decodeOptions);`)
}

func TestTypeScriptGeneratorDeclaredViewHelpersAcceptTypedParams(t *testing.T) {
	out, err := Generate(declaredReadParametersContractFixture(), Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export function subscribeLiveMessagesByTopic(subscribeDeclaredView: DeclaredViewSubscriber, params: LiveMessagesByTopicParams, options: DeclaredViewSubscribeOptions<LiveMessagesByTopicViewRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_messages_by_topic", { ...subscribeOptions, params: encodeLiveMessagesByTopicParams(params) });`)
	assertContains(t, ts, `export function subscribeLiveMessagesByTopicHandle(subscribeDeclaredView: DeclaredViewHandleSubscriber, params: LiveMessagesByTopicParams, options: DeclaredViewSubscriptionOptions<LiveMessagesByTopicViewRow> & SubscriptionHandleReturnOptions): Promise<SubscriptionHandle<LiveMessagesByTopicViewRow>> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_messages_by_topic", { ...subscribeOptions, params: encodeLiveMessagesByTopicParams(params) });`)
}

func TestTypeScriptGeneratorDeclaredReadNoParamSignaturesRemainUnchanged(t *testing.T) {
	contract := declaredReadParametersContractFixture()
	contract.Queries[0].RowSchema = &shunter.ProductSchema{Columns: []shunter.ProductColumn{
		{Name: "id", Type: "uint64"},
		{Name: "body", Type: "string"},
		{Name: "sent_at", Type: "timestamp"},
		{Name: "payload", Type: "bytes"},
		{Name: "tags", Type: "arrayString"},
	}}
	contract.Queries[0].ResultShape = &shunter.ReadResultShape{Kind: shunter.ReadResultShapeTable, Table: "messages"}
	contract.Views[0].RowSchema = &shunter.ProductSchema{Columns: []shunter.ProductColumn{
		{Name: "id", Type: "uint64"},
		{Name: "body", Type: "string"},
		{Name: "sent_at", Type: "timestamp"},
		{Name: "payload", Type: "bytes"},
		{Name: "tags", Type: "arrayString"},
	}}
	contract.Views[0].ResultShape = &shunter.ReadResultShape{Kind: shunter.ReadResultShapeTable, Table: "messages"}

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export function queryRecentMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("recent_messages");`)
	assertContains(t, ts, `export async function queryRecentMessagesDecoded(runDeclaredQuery: DeclaredQueryRunner, options: DeclaredQueryDecodeOptions<RecentMessagesQueryRows> = {}): Promise<DecodedDeclaredQueryResult<typeof queries.recentMessages, RecentMessagesQueryRows>> {`)
	assertContains(t, ts, `export function subscribeLiveMessages(subscribeDeclaredView: DeclaredViewSubscriber, options: DeclaredViewSubscribeOptions<LiveMessagesViewRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_messages", subscribeOptions);`)
	assertContains(t, ts, `export function subscribeLiveMessagesHandle(subscribeDeclaredView: DeclaredViewHandleSubscriber, options: DeclaredViewSubscriptionOptions<LiveMessagesViewRow> & SubscriptionHandleReturnOptions): Promise<SubscriptionHandle<LiveMessagesViewRow>> {`)
	assertNotContains(t, ts, `queryRecentMessages(runDeclaredQuery: DeclaredQueryRunner, params:`)
	assertNotContains(t, ts, `queryRecentMessagesDecoded(runDeclaredQuery: DeclaredQueryRunner, params:`)
	assertNotContains(t, ts, `subscribeLiveMessages(subscribeDeclaredView: DeclaredViewSubscriber, params:`)
	assertNotContains(t, ts, `subscribeLiveMessagesHandle(subscribeDeclaredView: DeclaredViewHandleSubscriber, params:`)
}

func TestTypeScriptGeneratorDisambiguatesTableAndDeclaredReadRowTypes(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables, schema.TableExport{
		Name: "messages_query",
		Columns: []schema.ColumnExport{
			{Name: "shadow", Type: "string"},
		},
	}, schema.TableExport{
		Name: "table",
		Columns: []schema.ColumnExport{
			{Name: "value", Type: "string"},
		},
	})
	contract.Queries = append(contract.Queries, shunter.QueryDescription{
		Name: "messages",
		SQL:  "SELECT id, body FROM messages",
		RowSchema: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
			{Name: "id", Type: "uint64"},
			{Name: "body", Type: "string"},
		}},
		ResultShape: &shunter.ReadResultShape{Kind: shunter.ReadResultShapeProjection, Table: "messages"},
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, "export interface MessagesQueryRow {\n  shadow: string;\n}")
	assertContains(t, ts, "export interface MessagesQueryRow2 {\n  id: bigint;\n  body: string;\n}")
	assertContains(t, ts, "export interface TableRow2 {\n  value: string;\n}")
	assertContains(t, ts, "  \"table\": TableRow2;")
	assertContains(t, ts, "export type MessagesQueryRows = {\n  \"messages\": MessagesQueryRow2;\n}")
	assertContains(t, ts, `export function decodeMessagesQueryRow2(row: Uint8Array): MessagesQueryRow2 {`)
}

func TestTypeScriptGeneratorDisambiguatesDeclaredReadHelperNameCollisions(t *testing.T) {
	contract := contractFixture()
	contract.Queries = append(contract.Queries, shunter.QueryDescription{Name: "recent-messages", SQL: "SELECT * FROM messages"})
	contract.Views = append(contract.Views, shunter.ViewDescription{Name: "live messages", SQL: "SELECT * FROM messages"})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `recentMessages: "recent_messages",`)
	assertContains(t, ts, `recentMessages2: "recent-messages",`)
	assertContains(t, ts, `export function queryRecentMessages(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("recent_messages");`)
	assertContains(t, ts, `export function queryRecentMessages2(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("recent-messages");`)
	assertContains(t, ts, `liveMessages: "live_messages",`)
	assertContains(t, ts, `liveMessages2: "live messages",`)
	assertContains(t, ts, `export function subscribeLiveMessages(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live_messages");`)
	assertContains(t, ts, `export function subscribeLiveMessages2(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("live messages");`)
}

func TestTypeScriptGeneratorDisambiguatesDeclaredReadFallbackAndReservedIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.Queries = append(contract.Queries,
		shunter.QueryDescription{Name: "!!!", SQL: "SELECT * FROM messages"},
		shunter.QueryDescription{Name: "_", SQL: "SELECT * FROM messages"},
		shunter.QueryDescription{Name: "class", SQL: "SELECT * FROM messages"},
	)
	contract.Views = append(contract.Views,
		shunter.ViewDescription{Name: "???", SQL: "SELECT * FROM messages"},
		shunter.ViewDescription{Name: "default", SQL: "SELECT * FROM messages"},
	)

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `_: "!!!",`)
	assertContains(t, ts, `_2: "_",`)
	assertContains(t, ts, `class_: "class",`)
	assertContains(t, ts, `export function query_(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("!!!");`)
	assertContains(t, ts, `export function query_2(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("_");`)
	assertContains(t, ts, `export function queryClass_(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertContains(t, ts, `return runDeclaredQuery("class");`)
	assertContains(t, ts, `export function subscribe_(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("???");`)
	assertContains(t, ts, `export function subscribeDefault_(subscribeDeclaredView: DeclaredViewSubscriber): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `return subscribeDeclaredView("default");`)
}

func TestTypeScriptGeneratorDoesNotEmitExecutableHelpersForMetadataOnlyDeclarations(t *testing.T) {
	contract := contractFixture()
	contract.Queries[0].SQL = ""
	contract.Views[0].SQL = ""

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const queries = {`)
	assertContains(t, ts, `recentMessages: "recent_messages",`)
	assertContains(t, ts, `export const querySQL = {`)
	assertNotContains(t, ts, `export function queryRecentMessages(`)
	assertContains(t, ts, `export const views = {`)
	assertContains(t, ts, `liveMessages: "live_messages",`)
	assertContains(t, ts, `export const viewSQL = {`)
	assertNotContains(t, ts, `export function subscribeLiveMessages(`)
}

func TestTypeScriptGeneratorEmitsTableReadPolicyMetadata(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables[0].ReadPolicy = schema.ReadPolicy{
		Access:      schema.TableAccessPermissioned,
		Permissions: []string{"messages:read"},
	}

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const tableReadPolicies = {`)
	assertContains(t, ts, `messages: { access: "permissioned", permissions: ["messages:read"] },`)
}

func TestTypeScriptGeneratorEmitsTableKindMetadata(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables, schema.TableExport{
		Name:    "notifications",
		IsEvent: true,
		Columns: []schema.ColumnExport{
			{Name: "id", Type: "uint64"},
		},
		Indexes: []schema.IndexExport{{Name: "notifications_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const tableKinds = {`)
	assertContains(t, ts, `messages: "persistent",`)
	assertContains(t, ts, `notifications: "event",`)
	assertContains(t, ts, `export function subscribeNotificationsInserts(subscribeTable: TableSubscribeCaller<NotificationsRow>, onInsert: (event: SubscriptionRowEvent<NotificationsRow>) => void, options: TableSubscribeOptions<NotificationsRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertContains(t, ts, `const subscribeOptions: TableSubscribeOptions<NotificationsRow> = options.decodeRow === undefined ? { ...options, decodeRow: tableRowDecoders["notifications"], eventTable: true, onInsert } : { ...options, eventTable: true, onInsert };`)
	assertContains(t, ts, `events: {`)
	assertContains(t, ts, `notifications: {`)
	assertContains(t, ts, `onInsert: (handler: (event: SubscriptionRowEvent<NotificationsRow>) => void, options: TableSubscribeOptions<NotificationsRow> = {}) => subscribeNotificationsInserts(bindings.subscribeTable, handler, options),`)
}

func TestTypeScriptGeneratorDisambiguatesTableReadPolicyMetadataIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Tables = append(contract.Schema.Tables,
		schema.TableExport{
			Name: "audit_log",
			Columns: []schema.ColumnExport{
				{Name: "id", Type: "uint64"},
			},
			Indexes: []schema.IndexExport{{Name: "audit_log_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
			ReadPolicy: schema.ReadPolicy{
				Access:      schema.TableAccessPermissioned,
				Permissions: []string{`audit:read"quoted`},
			},
		},
		schema.TableExport{
			Name: "audit-log",
			Columns: []schema.ColumnExport{
				{Name: "id", Type: "uint64"},
			},
			Indexes: []schema.IndexExport{{Name: "audit_log_2_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
			ReadPolicy: schema.ReadPolicy{
				Access:      schema.TableAccessPermissioned,
				Permissions: []string{`audit\archive`},
			},
		},
	)

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const tableReadPolicies = {`)
	assertContains(t, ts, `auditLog: { access: "permissioned", permissions: ["audit:read\"quoted"] },`)
	assertContains(t, ts, `auditLog2: { access: "permissioned", permissions: ["audit\\archive"] },`)
}

func TestTypeScriptGeneratorEmitsVisibilityFilterMetadata(t *testing.T) {
	contract := contractFixture()
	contract.VisibilityFilters = []shunter.VisibilityFilterDescription{{
		Name:               "own_messages",
		SQL:                "SELECT * FROM messages WHERE body = :sender",
		ReturnTable:        "messages",
		ReturnTableID:      0,
		UsesCallerIdentity: true,
	}}

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const visibilityFilters = {`)
	assertContains(t, ts, `ownMessages: { sql: "SELECT * FROM messages WHERE body = :sender", returnTable: "messages", returnTableId: 0, usesCallerIdentity: true },`)
}

func TestTypeScriptGeneratorDisambiguatesVisibilityFilterMetadataIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.VisibilityFilters = []shunter.VisibilityFilterDescription{
		{
			Name:          "own_messages",
			SQL:           `SELECT * FROM messages WHERE body = 'said "hi"'`,
			ReturnTable:   "messages",
			ReturnTableID: 0,
		},
		{
			Name:          "own-messages",
			SQL:           `SELECT * FROM messages WHERE body = 'archived'`,
			ReturnTable:   "messages",
			ReturnTableID: 0,
		},
		{
			Name:          "class",
			SQL:           `SELECT * FROM messages WHERE body = 'reserved'`,
			ReturnTable:   "messages",
			ReturnTableID: 0,
		},
	}

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `export const visibilityFilters = {`)
	assertContains(t, ts, `ownMessages: { sql: "SELECT * FROM messages WHERE body = 'said \"hi\"'", returnTable: "messages", returnTableId: 0, usesCallerIdentity: false },`)
	assertContains(t, ts, `ownMessages2: { sql: "SELECT * FROM messages WHERE body = 'archived'", returnTable: "messages", returnTableId: 0, usesCallerIdentity: false },`)
	assertContains(t, ts, `class_: { sql: "SELECT * FROM messages WHERE body = 'reserved'", returnTable: "messages", returnTableId: 0, usesCallerIdentity: false },`)
}

func TestTypeScriptGeneratorDisambiguatesMetadataMapIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.Queries = append(contract.Queries, shunter.QueryDescription{Name: "recent-messages", SQL: "SELECT * FROM messages"})
	contract.Views = append(contract.Views, shunter.ViewDescription{Name: "live messages", SQL: "SELECT * FROM messages"})
	contract.Permissions.Queries = append(contract.Permissions.Queries, shunter.PermissionContractDeclaration{
		Name:     "recent-messages",
		Required: []string{`messages:read"quoted`},
	})
	contract.Permissions.Views = append(contract.Permissions.Views, shunter.PermissionContractDeclaration{
		Name:     "live messages",
		Required: []string{`messages:subscribe\slash`},
	})
	contract.ReadModel.Declarations = append(contract.ReadModel.Declarations,
		shunter.ReadModelContractDeclaration{
			Surface: shunter.ReadModelSurfaceQuery,
			Name:    "recent-messages",
			Tables:  []string{"messages"},
			Tags:    []string{`audit"trail`},
		},
		shunter.ReadModelContractDeclaration{
			Surface: shunter.ReadModelSurfaceView,
			Name:    "live messages",
			Tables:  []string{"messages"},
			Tags:    []string{`live\feed`},
		},
	)

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `recentMessages: "recent_messages",`)
	assertContains(t, ts, `recentMessages2: "recent-messages",`)
	assertContains(t, ts, `liveMessages: "live_messages",`)
	assertContains(t, ts, `liveMessages2: "live messages",`)
	assertContains(t, ts, `recentMessages2: { required: ["messages:read\"quoted"] },`)
	assertContains(t, ts, `liveMessages2: { required: ["messages:subscribe\\slash"] },`)
	assertContains(t, ts, `recentMessages2: { tables: ["messages"], tags: ["audit\"trail"] },`)
	assertContains(t, ts, `liveMessages2: { tables: ["messages"], tags: ["live\\feed"] },`)
}

func TestTypeScriptGeneratorDisambiguatesReducerPermissionMetadataIdentifiers(t *testing.T) {
	contract := contractFixture()
	contract.Schema.Reducers = append(contract.Schema.Reducers, schema.ReducerExport{Name: "send-message"})
	contract.Permissions.Reducers = append(contract.Permissions.Reducers, shunter.PermissionContractDeclaration{
		Name:     "send-message",
		Required: []string{`messages:send-alt`},
	})

	out, err := Generate(contract, Options{Language: LanguageTypeScript})
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	ts := string(out)

	assertContains(t, ts, `reducers: {`)
	assertContains(t, ts, `sendMessage: { required: ["messages:send"] },`)
	assertContains(t, ts, `sendMessage2: { required: ["messages:send-alt"] },`)
}

func contractFixture() shunter.ModuleContract {
	return shunter.ModuleContract{
		ContractVersion: shunter.ModuleContractVersion,
		Module: shunter.ModuleContractIdentity{
			Name:     "chat",
			Version:  "v1.2.3",
			Metadata: map[string]string{"team": "runtime"},
		},
		Schema: schema.SchemaExport{
			Version: 1,
			Tables: []schema.TableExport{
				{
					Name: "messages",
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
						{Name: "body", Type: "string"},
						{Name: "sent_at", Type: "timestamp"},
						{Name: "payload", Type: "bytes"},
						{Name: "tags", Type: "arrayString"},
					},
					Indexes: []schema.IndexExport{
						{Name: "messages_pk", Columns: []string{"id"}, Unique: true, Primary: true},
					},
				},
			},
			Reducers: []schema.ReducerExport{
				{Name: "send_message", Lifecycle: false},
				{Name: "OnConnect", Lifecycle: true},
			},
		},
		Queries: []shunter.QueryDescription{
			{Name: "recent_messages", SQL: "SELECT * FROM messages"},
		},
		Views: []shunter.ViewDescription{
			{Name: "live_messages", SQL: "SELECT * FROM messages"},
		},
		Permissions: shunter.PermissionContract{
			Reducers: []shunter.PermissionContractDeclaration{
				{Name: "send_message", Required: []string{"messages:send"}},
			},
			Queries: []shunter.PermissionContractDeclaration{
				{Name: "recent_messages", Required: []string{"messages:read"}},
			},
			Views: []shunter.PermissionContractDeclaration{
				{Name: "live_messages", Required: []string{"messages:subscribe"}},
			},
		},
		ReadModel: shunter.ReadModelContract{
			Declarations: []shunter.ReadModelContractDeclaration{
				{
					Surface: shunter.ReadModelSurfaceQuery,
					Name:    "recent_messages",
					Tables:  []string{"messages"},
					Tags:    []string{"history"},
				},
				{
					Surface: shunter.ReadModelSurfaceView,
					Name:    "live_messages",
					Tables:  []string{"messages"},
					Tags:    []string{"realtime"},
				},
			},
		},
		Migrations: shunter.MigrationContract{
			Declarations: []shunter.MigrationContractDeclaration{},
		},
		Codegen: shunter.CodegenContractMetadata{
			ContractFormat:          shunter.ModuleContractFormat,
			ContractVersion:         shunter.ModuleContractVersion,
			DefaultSnapshotFilename: shunter.DefaultContractSnapshotFilename,
		},
	}
}

func publicProfileContractFixture() shunter.ModuleContract {
	tableSDK := func(visibility schema.TableSDKVisibility) *schema.TableSDKMetadata {
		return &schema.TableSDKMetadata{Visibility: visibility}
	}
	return shunter.ModuleContract{
		ContractVersion: shunter.ModuleContractVersion,
		Module: shunter.ModuleContractIdentity{
			Name:     "public_profile",
			Version:  "v0.1.0",
			Metadata: map[string]string{"team": "runtime"},
		},
		Schema: schema.SchemaExport{
			Version: 1,
			Tables: []schema.TableExport{
				{
					Name: "messages",
					SDK:  tableSDK(schema.TableSDKVisibilityPublic),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
						{Name: "body", Type: "string"},
					},
					Indexes: []schema.IndexExport{{Name: "messages_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
				},
				{
					Name: "sys_visible",
					SDK:  tableSDK(schema.TableSDKVisibilityPublic),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
					},
					Indexes: []schema.IndexExport{{Name: "sys_visible_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
				},
				{
					Name: "internal_notes",
					SDK:  tableSDK(schema.TableSDKVisibilityInternal),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
						{Name: "action", Type: "string"},
					},
					Indexes: []schema.IndexExport{{Name: "internal_notes_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
					ReadPolicy: schema.ReadPolicy{
						Access:      schema.TableAccessPermissioned,
						Permissions: []string{"audit:raw-read"},
					},
				},
				{
					Name: "private_notes",
					SDK:  tableSDK(schema.TableSDKVisibilityPrivate),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
						{Name: "body", Type: "string"},
					},
					Indexes:    []schema.IndexExport{{Name: "private_notes_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
					ReadPolicy: schema.ReadPolicy{Access: schema.TableAccessPublic},
				},
				{
					Name: "scheduler",
					SDK:  tableSDK(schema.TableSDKVisibilitySystem),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
					},
					Indexes: []schema.IndexExport{{Name: "scheduler_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
				},
				{
					Name:    "notifications",
					IsEvent: true,
					SDK:     tableSDK(schema.TableSDKVisibilityPublic),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
						{Name: "message", Type: "string"},
					},
					Indexes: []schema.IndexExport{{Name: "notifications_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
				},
				{
					Name:    "secret_events",
					IsEvent: true,
					SDK:     tableSDK(schema.TableSDKVisibilityPrivate),
					Columns: []schema.ColumnExport{
						{Name: "id", Type: "uint64"},
					},
					Indexes: []schema.IndexExport{{Name: "secret_events_pk", Columns: []string{"id"}, Unique: true, Primary: true}},
				},
			},
			Reducers: []schema.ReducerExport{},
		},
		Queries: []shunter.QueryDescription{
			{
				Name: "private_note_summaries",
				SQL:  "SELECT id, body FROM private_notes",
				RowSchema: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
					{Name: "id", Type: "uint64"},
					{Name: "body", Type: "string"},
				}},
				ResultShape: &shunter.ReadResultShape{Kind: shunter.ReadResultShapeProjection, Table: "private_notes"},
			},
		},
		Views: []shunter.ViewDescription{
			{
				Name: "live_internal_audit",
				SQL:  "SELECT id, action FROM internal_notes",
				RowSchema: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
					{Name: "id", Type: "uint64"},
					{Name: "action", Type: "string"},
				}},
				ResultShape: &shunter.ReadResultShape{Kind: shunter.ReadResultShapeProjection, Table: "internal_notes"},
			},
		},
		Permissions: shunter.PermissionContract{
			Reducers: []shunter.PermissionContractDeclaration{},
			Queries: []shunter.PermissionContractDeclaration{
				{Name: "private_note_summaries", Required: []string{"notes:read"}},
			},
			Views: []shunter.PermissionContractDeclaration{
				{Name: "live_internal_audit", Required: []string{"audit:read"}},
			},
		},
		ReadModel: shunter.ReadModelContract{
			Declarations: []shunter.ReadModelContractDeclaration{
				{
					Surface: shunter.ReadModelSurfaceQuery,
					Name:    "private_note_summaries",
					Tables:  []string{"private_notes"},
					Tags:    []string{"public-query"},
				},
				{
					Surface: shunter.ReadModelSurfaceView,
					Name:    "live_internal_audit",
					Tables:  []string{"internal_notes"},
					Tags:    []string{"internal-view"},
				},
			},
		},
		Migrations: shunter.MigrationContract{
			Declarations: []shunter.MigrationContractDeclaration{},
		},
		Codegen: shunter.CodegenContractMetadata{
			ContractFormat:          shunter.ModuleContractFormat,
			ContractVersion:         shunter.ModuleContractVersion,
			DefaultSnapshotFilename: shunter.DefaultContractSnapshotFilename,
		},
	}
}

func declaredReadParametersContractFixture() shunter.ModuleContract {
	contract := contractFixture()
	contract.Queries = append(contract.Queries, shunter.QueryDescription{
		Name: "messages_by_topic",
		SQL:  "SELECT id, body FROM messages WHERE body = :topic AND id > :after_id",
		Parameters: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
			{Name: "topic", Type: "string"},
			{Name: "after_id", Type: "uint64"},
		}},
		RowSchema: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
			{Name: "id", Type: "uint64"},
			{Name: "body", Type: "string"},
		}},
		ResultShape: &shunter.ReadResultShape{Kind: shunter.ReadResultShapeProjection, Table: "messages"},
	})
	contract.Views = append(contract.Views, shunter.ViewDescription{
		Name: "live_messages_by_topic",
		SQL:  "SELECT id, body AS text FROM messages WHERE body = :topic",
		Parameters: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
			{Name: "topic", Type: "string"},
		}},
		RowSchema: &shunter.ProductSchema{Columns: []shunter.ProductColumn{
			{Name: "id", Type: "uint64"},
			{Name: "text", Type: "string"},
		}},
		ResultShape: &shunter.ReadResultShape{Kind: shunter.ReadResultShapeProjection, Table: "messages"},
	})
	return contract
}

func assertContains(t *testing.T, haystack, needle string) {
	t.Helper()
	if !strings.Contains(haystack, needle) {
		t.Fatalf("generated TypeScript missing %q:\n%s", needle, haystack)
	}
}

func assertNotContains(t *testing.T, haystack, needle string) {
	t.Helper()
	if strings.Contains(haystack, needle) {
		t.Fatalf("generated TypeScript unexpectedly contains %q:\n%s", needle, haystack)
	}
}

func assertTypeScriptOutputDiffersOnlyByProvenance(t *testing.T, got, want []byte) {
	t.Helper()
	gotWithoutProvenance := stripTypeScriptProvenanceLines(got)
	wantWithoutProvenance := stripTypeScriptProvenanceLines(want)
	if !bytes.Equal(gotWithoutProvenance, wantWithoutProvenance) {
		t.Fatalf("generated output changed outside provenance\n--- got ---\n%s\n--- want ---\n%s", got, want)
	}
}

func stripTypeScriptProvenanceLines(data []byte) []byte {
	lines := bytes.Split(data, []byte("\n"))
	out := lines[:0]
	for _, line := range lines {
		if bytes.HasPrefix(line, []byte("  generationProfile: ")) || bytes.HasPrefix(line, []byte("  runtimeImport: ")) {
			continue
		}
		out = append(out, line)
	}
	return bytes.Join(out, []byte("\n"))
}

func waitForCodegenSoakWorkers(t *testing.T, ch <-chan struct{}, want int, label string) {
	t.Helper()
	for i := 0; i < want; i++ {
		select {
		case <-ch:
		case <-time.After(2 * time.Second):
			t.Fatalf("%s: observed %d/%d workers", label, i, want)
		}
	}
}
