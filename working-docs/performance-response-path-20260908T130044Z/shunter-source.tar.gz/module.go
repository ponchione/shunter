package shunter

import (
	"maps"

	"github.com/ponchione/shunter/schema"
)

// Module owns an application module definition before it is built into a
// Runtime. It stores module identity metadata and delegates schema, reducer,
// and lifecycle registration to the underlying schema builder while owning
// query/view declaration metadata directly.
type Module struct {
	name              string
	version           string
	metadata          map[string]string
	builder           *schema.Builder
	reducers          []ReducerDeclaration
	procedures        []ProcedureDeclaration
	queries           []queryDeclaration
	views             []viewDeclaration
	visibilityFilters []VisibilityFilterDeclaration
	migration         MigrationMetadata
	tableMigrations   map[string]MigrationMetadata
	migrationHooks    []MigrationHook
}

// NewModule creates a module definition shell with the supplied name.
// Blank names are allowed at construction time and rejected by Build.
func NewModule(name string) *Module {
	return &Module{
		name:    name,
		builder: schema.NewBuilder(),
	}
}

// Name returns the exact module name supplied to NewModule.
func (m *Module) Name() string {
	return m.name
}

// Version stores the module's application version string and returns the
// receiver for fluent module declarations.
func (m *Module) Version(v string) *Module {
	m.version = v
	return m
}

// VersionString returns the module's application version string.
func (m *Module) VersionString() string {
	return m.version
}

// SchemaVersion sets the module schema version through the underlying schema
// builder and returns the receiver for fluent module declarations.
func (m *Module) SchemaVersion(v uint32) *Module {
	m.builder.SchemaVersion(v)
	return m
}

// TableDef registers a table definition through the underlying schema builder
// and returns the receiver for fluent module declarations.
func (m *Module) TableDef(def schema.TableDefinition, opts ...schema.TableOption) *Module {
	m.builder.TableDef(def, opts...)
	return m
}

// EventTable registers a transient table definition through the underlying
// schema builder and returns the receiver for fluent module declarations.
// Event table inserts are emitted to subscriptions for the committing
// transaction, but are not retained in committed state or snapshots.
func (m *Module) EventTable(def schema.TableDefinition, opts ...schema.TableOption) *Module {
	opts = append([]schema.TableOption{schema.WithEventTable()}, opts...)
	m.builder.TableDef(def, opts...)
	return m
}

// Reducer registers a named reducer through the underlying schema builder and
// returns the receiver for fluent module declarations.
func (m *Module) Reducer(name string, h schema.ReducerHandler, opts ...ReducerOption) *Module {
	var options reducerOptions
	for _, opt := range opts {
		if opt != nil {
			opt(&options)
		}
	}
	m.reducers = append(m.reducers, ReducerDeclaration{
		Name:        name,
		Permissions: copyPermissionMetadata(options.permissions),
		Args:        copyProductSchemaPtr(options.args),
		Result:      copyProductSchemaPtr(options.result),
	})
	m.builder.Reducer(name, h)
	return m
}

// Procedure registers a named procedure and returns the receiver for fluent
// module declarations. Procedures may perform external I/O; they are not run
// on the serialized reducer executor. State changes should go through
// ProcedureContext.CallReducer.
func (m *Module) Procedure(name string, h ProcedureHandler, opts ...ProcedureOption) *Module {
	var options procedureOptions
	for _, opt := range opts {
		if opt != nil {
			opt(&options)
		}
	}
	m.procedures = append(m.procedures, ProcedureDeclaration{
		Name:        name,
		Handler:     h,
		Permissions: copyPermissionMetadata(options.permissions),
		Args:        copyProductSchemaPtr(options.args),
		Result:      copyProductSchemaPtr(options.result),
	})
	return m
}

// OnConnect registers a connection lifecycle handler through the underlying
// schema builder and returns the receiver for fluent module declarations.
func (m *Module) OnConnect(h func(*schema.ReducerContext) error) *Module {
	m.builder.OnConnect(h)
	return m
}

// OnDisconnect registers a disconnection lifecycle handler through the
// underlying schema builder and returns the receiver for fluent module
// declarations.
func (m *Module) OnDisconnect(h func(*schema.ReducerContext) error) *Module {
	m.builder.OnDisconnect(h)
	return m
}

// Metadata replaces the module metadata with a defensive copy of values.
// Passing nil clears metadata.
func (m *Module) Metadata(values map[string]string) *Module {
	if values == nil {
		m.metadata = nil
		return m
	}

	m.metadata = copyStringMap(values)
	return m
}

// MetadataMap returns a defensive copy of the module metadata.
func (m *Module) MetadataMap() map[string]string {
	return copyStringMap(m.metadata)
}

// Migration stores descriptive module-level migration metadata and returns the
// receiver for fluent module declarations.
func (m *Module) Migration(metadata MigrationMetadata) *Module {
	m.migration = copyMigrationMetadata(metadata)
	return m
}

// TableMigration stores descriptive migration metadata for a named table.
func (m *Module) TableMigration(tableName string, metadata MigrationMetadata) *Module {
	if m.tableMigrations == nil {
		m.tableMigrations = make(map[string]MigrationMetadata)
	}
	m.tableMigrations[tableName] = copyMigrationMetadata(metadata)
	return m
}

// MigrationHook registers an app-owned startup migration hook. Hooks run during
// Runtime.Start after recovery and durability are available, but before normal
// reducer, subscription, and protocol readiness.
func (m *Module) MigrationHook(h MigrationHook) *Module {
	if h != nil {
		m.migrationHooks = append(m.migrationHooks, h)
	}
	return m
}

func copyStringMap(values map[string]string) map[string]string {
	if len(values) == 0 {
		return map[string]string{}
	}

	out := make(map[string]string, len(values))
	maps.Copy(out, values)
	return out
}
