package main

import (
	"flag"
	"log"
	"os"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter"
)

func main() {
	dataDir := flag.String("data-dir", "", "runtime data directory; defaults to a temporary directory")
	flag.Parse()

	dir := *dataDir
	if dir == "" {
		tmp, err := os.MkdirTemp("", "opsboard-canary-contract-*")
		if err != nil {
			log.Fatalf("create temp data dir: %v", err)
		}
		defer os.RemoveAll(tmp)
		dir = tmp
	}

	rt, err := shunter.Build(app.NewModule(), shunter.Config{DataDir: dir})
	if err != nil {
		log.Fatalf("build runtime: %v", err)
	}
	data, err := rt.ExportContractJSON()
	if err != nil {
		log.Fatalf("export contract: %v", err)
	}
	if _, err := os.Stdout.Write(data); err != nil {
		log.Fatalf("write contract: %v", err)
	}
}
