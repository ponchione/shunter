package main

import (
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/workflows"
)

func TestRunWritesFailureTrace(t *testing.T) {
	tracePath := filepath.Join(t.TempDir(), "trace", "workflow.json")
	err := run([]string{
		"--addr", "127.0.0.1:3999",
		"--trace-out", tracePath,
		"--seed", "99",
		"--data-dir", "/tmp/opsboard-canary-trace",
	}, io.Discard)
	if err == nil {
		t.Fatal("run returned nil error, want addr-mode failure")
	}
	if !strings.Contains(err.Error(), "dial") {
		t.Fatalf("run error = %v, want dial failure", err)
	}

	data, err := os.ReadFile(tracePath)
	if err != nil {
		t.Fatalf("read trace: %v", err)
	}
	var trace workflows.Trace
	if err := json.Unmarshal(data, &trace); err != nil {
		t.Fatalf("trace JSON is invalid: %v\n%s", err, data)
	}
	if trace.Version != workflows.TraceVersion || trace.Seed != 99 || trace.DataDir != "/tmp/opsboard-canary-trace" {
		t.Fatalf("trace header = version %d seed %d data_dir %q", trace.Version, trace.Seed, trace.DataDir)
	}
	if trace.Failure == nil || trace.Failure.OperationIndex != 0 || !strings.Contains(trace.Failure.Error, "dial") {
		t.Fatalf("trace failure = %#v", trace.Failure)
	}
	if len(trace.Operations) != 1 || trace.Operations[0].Action != "dial_caller" {
		t.Fatalf("trace operations = %#v", trace.Operations)
	}
}

func TestRunInProcessProtocolSmoke(t *testing.T) {
	var out strings.Builder
	err := run([]string{
		"--in-process",
		"--data-dir", t.TempDir(),
		"--seed", "123",
	}, &out)
	if err != nil {
		t.Fatalf("run returned error: %v", err)
	}
	if got := strings.TrimSpace(out.String()); got != "protocol workflow smoke passed" {
		t.Fatalf("stdout = %q", got)
	}
}
