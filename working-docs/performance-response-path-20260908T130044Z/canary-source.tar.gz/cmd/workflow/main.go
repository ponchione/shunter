package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"log"
	"os"

	"github.com/ponchione/opsboard-canary/internal/workflows"
)

func main() {
	if err := run(os.Args[1:], os.Stdout); err != nil {
		log.Fatal(err)
	}
}

func run(args []string, stdout io.Writer) error {
	fs := flag.NewFlagSet("workflow", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	inProcess := fs.Bool("in-process", true, "run against an in-process runtime")
	addr := fs.String("addr", "", "existing runtime address")
	dataDir := fs.String("data-dir", "./artifacts/workflow-data", "runtime data directory")
	seed := fs.Int64("seed", 0, "workflow seed")
	traceOut := fs.String("trace-out", "", "failure trace output path")
	if err := fs.Parse(args); err != nil {
		return err
	}

	trace, err := workflows.RunProtocolSmoke(context.Background(), workflows.ProtocolSmokeOptions{
		InProcess: *inProcess,
		Addr:      *addr,
		DataDir:   *dataDir,
		Seed:      *seed,
	})
	if err != nil {
		return failWithTrace(*traceOut, trace, err)
	}
	fmt.Fprintln(stdout, "protocol workflow smoke passed")
	return nil
}

func failWithTrace(path string, trace workflows.Trace, err error) error {
	if path == "" {
		return err
	}
	if traceErr := trace.WriteFile(path); traceErr != nil {
		return fmt.Errorf("%w; additionally failed to write trace: %v", err, traceErr)
	}
	return err
}
