package main

import (
	"io"
	"reflect"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter"
)

func TestServerConfigStrictDefaultsUseCanaryIssuerAndAudience(t *testing.T) {
	cfg, listen, err := serverConfig([]string{
		"--strict",
		"--data-dir", "/tmp/opsboard-canary-server",
		"--listen", "127.0.0.1:13000",
	}, io.Discard)
	if err != nil {
		t.Fatalf("serverConfig returned error: %v", err)
	}
	if listen != "127.0.0.1:13000" || cfg.ListenAddr != listen {
		t.Fatalf("listen = %q cfg.ListenAddr = %q", listen, cfg.ListenAddr)
	}
	if cfg.DataDir != "/tmp/opsboard-canary-server" {
		t.Fatalf("DataDir = %q", cfg.DataDir)
	}
	if !cfg.EnableProtocol || cfg.AuthMode != shunter.AuthModeStrict {
		t.Fatalf("protocol/auth = %v/%v", cfg.EnableProtocol, cfg.AuthMode)
	}
	if string(cfg.AuthSigningKey) != app.StrictAuthSigningKey {
		t.Fatalf("AuthSigningKey = %q", cfg.AuthSigningKey)
	}
	if !reflect.DeepEqual(cfg.AuthIssuers, []string{app.StrictAuthIssuer}) {
		t.Fatalf("AuthIssuers = %#v", cfg.AuthIssuers)
	}
	if !reflect.DeepEqual(cfg.AuthAudiences, []string{app.StrictAuthAudience}) {
		t.Fatalf("AuthAudiences = %#v", cfg.AuthAudiences)
	}
}

func TestServerConfigStrictAllowsExplicitIssuerAndAudience(t *testing.T) {
	cfg, _, err := serverConfig([]string{
		"--strict",
		"--signing-key", "secret",
		"--issuer", "issuer-a",
		"--audience", "audience-a",
	}, io.Discard)
	if err != nil {
		t.Fatalf("serverConfig returned error: %v", err)
	}
	if string(cfg.AuthSigningKey) != "secret" {
		t.Fatalf("AuthSigningKey = %q", cfg.AuthSigningKey)
	}
	if !reflect.DeepEqual(cfg.AuthIssuers, []string{"issuer-a"}) {
		t.Fatalf("AuthIssuers = %#v", cfg.AuthIssuers)
	}
	if !reflect.DeepEqual(cfg.AuthAudiences, []string{"audience-a"}) {
		t.Fatalf("AuthAudiences = %#v", cfg.AuthAudiences)
	}
}

func TestServerConfigStrictRequiresSigningKey(t *testing.T) {
	_, _, err := serverConfig([]string{"--strict", "--signing-key", ""}, io.Discard)
	if err == nil {
		t.Fatal("serverConfig returned nil error, want missing signing key failure")
	}
}
