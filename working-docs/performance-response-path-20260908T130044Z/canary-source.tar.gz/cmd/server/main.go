package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter"
)

func main() {
	cfg, listen, err := serverConfig(os.Args[1:], os.Stderr)
	if err != nil {
		log.Fatal(err)
	}

	rt, err := shunter.Build(app.NewModule(), cfg)
	if err != nil {
		log.Fatalf("build runtime: %v", err)
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	fmt.Fprintf(os.Stderr, "opsboard-canary serving %s\n", listen)
	if err := rt.ListenAndServe(ctx); err != nil && !errors.Is(err, context.Canceled) {
		log.Fatalf("serve runtime: %v", err)
	}
}

func serverConfig(args []string, output io.Writer) (shunter.Config, string, error) {
	fs := flag.NewFlagSet("server", flag.ContinueOnError)
	fs.SetOutput(output)
	dataDir := fs.String("data-dir", "./artifacts/server-data", "runtime data directory")
	listen := fs.String("listen", "127.0.0.1:3000", "protocol listen address")
	strict := fs.Bool("strict", false, "enable strict auth")
	signingKey := fs.String("signing-key", app.StrictAuthSigningKey, "strict auth signing key")
	issuer := fs.String("issuer", app.StrictAuthIssuer, "strict auth issuer")
	audience := fs.String("audience", app.StrictAuthAudience, "strict auth audience")
	if err := fs.Parse(args); err != nil {
		return shunter.Config{}, "", err
	}

	cfg := shunter.Config{
		DataDir:        *dataDir,
		EnableProtocol: true,
		ListenAddr:     *listen,
	}
	if *strict {
		if *signingKey == "" {
			return shunter.Config{}, "", fmt.Errorf("--signing-key is required when --strict is set")
		}
		cfg.AuthMode = shunter.AuthModeStrict
		cfg.AuthSigningKey = []byte(*signingKey)
		if *issuer != "" {
			cfg.AuthIssuers = []string{*issuer}
		}
		if *audience != "" {
			cfg.AuthAudiences = []string{*audience}
		}
	}
	return cfg, *listen, nil
}
