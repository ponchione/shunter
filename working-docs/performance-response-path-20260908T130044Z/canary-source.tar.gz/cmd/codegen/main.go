package main

import (
	"flag"
	"log"
	"os"
	"path/filepath"

	"github.com/ponchione/shunter/codegen"
)

func main() {
	contractPath := flag.String("contract", "contracts/shunter.contract.json", "contract JSON path")
	outDir := flag.String("out", "generated/typescript", "TypeScript output directory")
	flag.Parse()

	data, err := os.ReadFile(*contractPath)
	if err != nil {
		log.Fatalf("read contract: %v", err)
	}
	generated, err := codegen.GenerateFromJSON(data, codegen.Options{Language: codegen.LanguageTypeScript})
	if err != nil {
		log.Fatalf("generate TypeScript: %v", err)
	}
	if err := os.MkdirAll(*outDir, 0o755); err != nil {
		log.Fatalf("create output directory: %v", err)
	}
	if err := os.WriteFile(filepath.Join(*outDir, "index.ts"), generated, 0o644); err != nil {
		log.Fatalf("write TypeScript bindings: %v", err)
	}
}
