package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter"
)

func main() {
	dataDir := flag.String("data-dir", "", "offline runtime data directory to migrate")
	flag.Parse()
	if *dataDir == "" {
		log.Fatal("missing required --data-dir")
	}

	mod := app.NewModule().MigrationHook(app.OperationalProofMigration)
	result, err := shunter.RunModuleDataDirMigrations(context.Background(), mod, shunter.Config{DataDir: *dataDir})
	if err != nil {
		log.Fatalf("run migrations: %v", err)
	}
	fmt.Fprintf(os.Stdout, "migrated %s recovered_tx=%d durable_tx=%d hooks=%d\n", result.DataDir, result.RecoveredTxID, result.DurableTxID, len(result.Hooks))
}
