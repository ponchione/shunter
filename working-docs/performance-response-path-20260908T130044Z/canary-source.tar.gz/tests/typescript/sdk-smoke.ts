import assert from "node:assert/strict";
import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { createHash, createHmac } from "node:crypto";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import net from "node:net";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { createShunterClient } from "@shunter/client";

import {
  callAddCommentResult,
  callBootstrapDemoResult,
  callCreateTicketResult,
  decodeNotificationsRow,
  queryAuditFeedDecoded,
  queryMyProfileDecoded,
  queryMyTicketsDecoded,
  shunterProtocol,
  subscribeLiveAuditFeedHandle,
  subscribeLiveTicket100CommentsHandle,
  subscribeTickets,
  views,
  type DeclaredViewHandleSubscriber,
  type LiveAuditFeedViewRow,
  type LiveTicket100CommentsViewRow,
  type NotificationsRow,
  type TicketsRow,
} from "../../generated/typescript/index.ts";

const strictAuthIssuer = "opsboard-canary";
const strictAuthAudience = "opsboard";
const strictAuthSigningKey = "opsboard-canary-dev-signing-key-32";
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");

async function main(): Promise<void> {
  const port = await pickPort();
  const artifactRoot = path.join(repoRoot, "artifacts", "sdk-smoke");
  await mkdir(artifactRoot, { recursive: true });
  const dataDir = await mkdtemp(path.join(artifactRoot, "data-"));
  const server = startServer(port, dataDir);

  try {
    await waitForPort(port, server);
    await runSdkWorkflow(port);
  } finally {
    await stopServer(server);
    await rm(dataDir, { recursive: true, force: true });
  }
}

async function runSdkWorkflow(port: number): Promise<void> {
  const url = `ws://127.0.0.1:${port}/subscribe`;
  const admin = createShunterClient({
    url,
    protocol: shunterProtocol,
    token: mintStrictToken("admin", [
      "admin:write",
      "project:write",
      "ticket:write",
      "comment:write",
      "audit:read",
    ]),
  });
  const bob = createShunterClient({
    url,
    protocol: shunterProtocol,
    token: mintStrictToken("bob", ["ticket:write", "comment:write"]),
  });
  const viewer = createShunterClient({
    url,
    protocol: shunterProtocol,
    token: mintStrictToken("viewer", []),
  });

  try {
    await withTimeout(admin.connect(), 5000, "connect admin SDK client");
    const bootstrap = await withTimeout(
      callBootstrapDemoResult(
        admin.callReducer,
        jsonBytes({ now_ns: 1000 }),
      ),
      5000,
      "call bootstrap_demo through SDK",
    );
    assert.equal(bootstrap.status, "committed");

    const profile = await withTimeout(
      queryMyProfileDecoded(admin.runDeclaredQuery),
      5000,
      "run decoded my_profile declared query through SDK",
    );
    const profileRows = profile.tables.find((table) => table.tableName === "users")?.rows ?? [];
    assert.equal(profileRows.length, 1);
    assert.equal(profileRows[0]?.handle, "admin");

    const initialAuditFeed = await withTimeout(
      queryAuditFeedDecoded(admin.runDeclaredQuery),
      5000,
      "run decoded audit_feed declared query through SDK",
    );
    const initialAuditRows = initialAuditFeed.tables.find((table) => table.tableName === "audit_log")?.rows ?? [];
    assert(
      initialAuditRows.some((row) => row.action === "bootstrap_demo" && row.targetTable === "tickets"),
      "expected bootstrap audit row through generated permissioned SDK query",
    );

    await withTimeout(viewer.connect(), 5000, "connect viewer SDK client");
    const deniedCreate = await withTimeout(
      callCreateTicketResult(
        viewer.callReducer,
        jsonBytes({
          id: 102,
          project_id: 1,
          number: 4,
          title: "Permission denied public SDK ticket",
          priority: "normal",
          visibility: "public",
          assignee_identity: "",
          now_ns: 1500,
        }),
      ),
      5000,
      "call permission-denied create_ticket through SDK",
    );
    assert.equal(deniedCreate.status, "failed");
    assert.match(deniedCreate.error?.message ?? "", /permission/i);

    await withTimeout(bob.connect(), 5000, "connect bob SDK client");
    let ticketInitialRows: TicketsRow[] = [];
    const ticketUpdates: TicketsRow[] = [];
    const unsubscribeTickets = await withTimeout(
      subscribeTickets(admin.subscribeTable, (rows) => {
        ticketInitialRows = rows;
      }, {
        onUpdate: (update) => {
          ticketUpdates.push(...update.inserts);
        },
      }),
      5000,
      "subscribe tickets table through SDK",
    );
    assert(
      ticketInitialRows.some((row) => row.id === 200n && row.visibility === "public"),
      "expected bootstrap ticket through public SDK table subscription",
    );

    const notificationUpdates: NotificationsRow[] = [];
    const subscribeDeclaredViewHandle: DeclaredViewHandleSubscriber = bob.subscribeDeclaredView;
    const notifications = await withTimeout(
      subscribeDeclaredViewHandle<NotificationsRow>(views.myNotifications, {
        returnHandle: true,
        decodeRow: decodeNotificationsRow,
        onUpdate: (update) => {
          notificationUpdates.push(...update.inserts);
        },
      }),
      5000,
      "subscribe my_notifications declared view through SDK",
    );
    assert.equal(notifications.state.status, "active");
    assert(
      notifications.state.rows.some((row) => row.ticketId === 100n && row.recipientIdentity === deriveIdentityHex("bob")),
      "expected initial bob notification through public SDK declared view subscription",
    );

    const commentUpdates: LiveTicket100CommentsViewRow[] = [];
    const ticket100Comments = await withTimeout(
      subscribeLiveTicket100CommentsHandle(bob.subscribeDeclaredView, {
        returnHandle: true,
        onUpdate: (update) => {
          commentUpdates.push(...update.inserts);
        },
      }),
      5000,
      "subscribe live_ticket_100_comments generated declared view through SDK",
    );
    assert.equal(ticket100Comments.state.status, "active");
    assert(
      ticket100Comments.state.rows.some((row) => row.id === 500n && row.ticketId === 100n),
      "expected initial ticket 100 comment through generated SDK declared view subscription",
    );

    const auditUpdates: LiveAuditFeedViewRow[] = [];
    const auditFeed = await withTimeout(
      subscribeLiveAuditFeedHandle(admin.subscribeDeclaredView, {
        returnHandle: true,
        onUpdate: (update) => {
          auditUpdates.push(...update.inserts);
        },
      }),
      5000,
      "subscribe live_audit_feed generated declared view through SDK",
    );
    assert.equal(auditFeed.state.status, "active");
    assert(
      auditFeed.state.rows.some((row) => row.action === "bootstrap_demo" && row.targetTable === "tickets"),
      "expected initial audit rows through generated permissioned SDK declared view subscription",
    );

    const created = await withTimeout(
      callCreateTicketResult(
        admin.callReducer,
        jsonBytes({
          id: 101,
          project_id: 1,
          number: 3,
          title: "Exercise public TypeScript SDK",
          priority: "high",
          visibility: "internal",
          assignee_identity: deriveIdentityHex("bob"),
          now_ns: 2000,
        }),
      ),
      5000,
      "call create_ticket through SDK",
    );
    assert.equal(created.status, "committed");

    await waitFor(
      () => notificationUpdates.some((row) => row.ticketId === 101n && row.kind === "assigned"),
      "expected bob notification delta after SDK reducer call",
    );
    await waitFor(
      () => ticketUpdates.some((row) => row.id === 101n && row.reporterIdentity === deriveIdentityHex("admin")),
      "expected admin tickets table delta after SDK reducer call",
    );
    await waitFor(
      () => auditUpdates.some((row) => row.action === "create_ticket" && row.targetId === 101n),
      "expected generated live_audit_feed delta after SDK reducer call",
    );
    const myTickets = await withTimeout(
      queryMyTicketsDecoded(bob.runDeclaredQuery),
      5000,
      "run decoded my_tickets declared query through SDK",
    );
    const myTicketRows = myTickets.tables.find((table) => table.tableName === "tickets")?.rows ?? [];
    assert(
      myTicketRows.some((row) => row.id === 101n && row.assigneeIdentity === deriveIdentityHex("bob")),
      "expected generated my_tickets query to include SDK-created assignment",
    );

    const addedComment = await withTimeout(
      callAddCommentResult(
        bob.callReducer,
        jsonBytes({
          id: 700,
          ticket_id: 100,
          visibility: "public",
          body: "Exercise generated SDK comment path",
          now_ns: 2500,
        }),
      ),
      5000,
      "call add_comment generated reducer helper through SDK",
    );
    assert.equal(addedComment.status, "committed");
    await waitFor(
      () => commentUpdates.some((row) => row.id === 700n && row.authorIdentity === deriveIdentityHex("bob")),
      "expected generated live_ticket_100_comments delta after SDK reducer call",
    );
    await waitFor(
      () => auditUpdates.some((row) => row.action === "add_comment" && row.targetId === 700n),
      "expected generated live_audit_feed delta after SDK add_comment call",
    );
    await withTimeout(unsubscribeTickets(), 5000, "unsubscribe tickets table");
    await withTimeout(notifications.unsubscribe(), 5000, "unsubscribe my_notifications declared view");
    await withTimeout(ticket100Comments.unsubscribe(), 5000, "unsubscribe live_ticket_100_comments declared view");
    await withTimeout(auditFeed.unsubscribe(), 5000, "unsubscribe live_audit_feed declared view");
  } finally {
    await Promise.allSettled([
      withTimeout(admin.close(), 5000, "close admin SDK client"),
      withTimeout(bob.close(), 5000, "close bob SDK client"),
      withTimeout(viewer.close(), 5000, "close viewer SDK client"),
    ]);
  }
}

function startServer(port: number, dataDir: string): ChildProcessWithoutNullStreams {
  return spawn(
    "go",
    [
      "run",
      "./cmd/server",
      "--strict",
      "--listen",
      `127.0.0.1:${port}`,
      "--data-dir",
      dataDir,
    ],
    { cwd: repoRoot },
  );
}

async function stopServer(server: ChildProcessWithoutNullStreams): Promise<void> {
  if (server.exitCode !== null || server.signalCode !== null) {
    return;
  }
  server.kill("SIGTERM");
  await new Promise<void>((resolve) => {
    const timer = setTimeout(() => {
      if (server.exitCode === null && server.signalCode === null) {
        server.kill("SIGKILL");
      }
      resolve();
    }, 5000);
    server.once("exit", () => {
      clearTimeout(timer);
      resolve();
    });
  });
}

async function waitForPort(port: number, server: ChildProcessWithoutNullStreams): Promise<void> {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 20_000) {
    if (server.exitCode !== null) {
      throw new Error(`canary server exited early with code ${server.exitCode}`);
    }
    if (await canConnect(port)) {
      return;
    }
    await delay(100);
  }
  throw new Error("canary server did not become ready within 20s");
}

async function waitFor(predicate: () => boolean, message: string): Promise<void> {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 5000) {
    if (predicate()) {
      return;
    }
    await delay(25);
  }
  assert.fail(message);
}

async function withTimeout<T>(promise: Promise<T> | T, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      Promise.resolve(promise),
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
      }),
    ]);
  } finally {
    if (timer !== undefined) {
      clearTimeout(timer);
    }
  }
}

async function pickPort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      server.close(() => {
        if (typeof address === "object" && address !== null) {
          resolve(address.port);
          return;
        }
        reject(new Error("failed to allocate local port"));
      });
    });
  });
}

async function canConnect(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = net.connect({ host: "127.0.0.1", port });
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("error", () => {
      socket.destroy();
      resolve(false);
    });
  });
}

function mintStrictToken(subject: string, permissions: string[]): string {
  const now = Math.floor(Date.now() / 1000);
  const header = base64URL(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = base64URL(JSON.stringify({
    iss: strictAuthIssuer,
    sub: subject,
    aud: strictAuthAudience,
    iat: now,
    exp: now + 3600,
    permissions,
  }));
  const signingInput = `${header}.${payload}`;
  const signature = createHmac("sha256", strictAuthSigningKey)
    .update(signingInput)
    .digest("base64url");
  return `${signingInput}.${signature}`;
}

function deriveIdentityHex(subject: string): string {
  const issuer = Buffer.from(strictAuthIssuer);
  const length = Buffer.alloc(4);
  length.writeUInt32BE(issuer.length);
  return createHash("sha256")
    .update(length)
    .update(issuer)
    .update(subject)
    .digest("hex");
}

function jsonBytes(value: unknown): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(value));
}

function base64URL(value: string): string {
  return Buffer.from(value).toString("base64url");
}

async function delay(ms: number): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

await main();
process.exit(0);
