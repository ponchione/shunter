package workflows

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

const TraceVersion = 1

type Trace struct {
	Version    int              `json:"version"`
	Seed       int64            `json:"seed"`
	DataDir    string           `json:"data_dir"`
	StartedAt  time.Time        `json:"started_at"`
	Operations []TraceOperation `json:"operations"`
	Failure    *TraceFailure    `json:"failure,omitempty"`
}

type TraceOperation struct {
	Index        int    `json:"index"`
	Caller       string `json:"caller,omitempty"`
	Action       string `json:"action"`
	Reducer      string `json:"reducer,omitempty"`
	Query        string `json:"query,omitempty"`
	Subscription string `json:"subscription,omitempty"`
	Expected     string `json:"expected,omitempty"`
	Observed     string `json:"observed,omitempty"`
}

type TraceFailure struct {
	OperationIndex int    `json:"operation_index"`
	Error          string `json:"error"`
	Expected       string `json:"expected,omitempty"`
	Observed       string `json:"observed,omitempty"`
}

func NewTrace(seed int64, dataDir string) Trace {
	return Trace{
		Version:   TraceVersion,
		Seed:      seed,
		DataDir:   dataDir,
		StartedAt: time.Now().UTC(),
	}
}

func (t *Trace) AddOperation(op TraceOperation) {
	if op.Index == 0 && len(t.Operations) > 0 {
		op.Index = len(t.Operations)
	}
	t.Operations = append(t.Operations, op)
}

func (t *Trace) MarkFailure(op TraceOperation, err error) {
	t.AddOperation(op)
	t.Failure = &TraceFailure{
		OperationIndex: op.Index,
		Error:          err.Error(),
		Expected:       op.Expected,
		Observed:       op.Observed,
	}
}

func (t Trace) WriteFile(path string) error {
	if path == "" {
		return fmt.Errorf("trace path is required")
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return fmt.Errorf("create trace directory: %w", err)
	}
	data, err := json.MarshalIndent(t, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal trace: %w", err)
	}
	data = append(data, '\n')
	if err := os.WriteFile(path, data, 0o644); err != nil {
		return fmt.Errorf("write trace: %w", err)
	}
	return nil
}
