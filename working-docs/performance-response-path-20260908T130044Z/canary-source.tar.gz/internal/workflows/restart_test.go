package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestRestartWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	outsider := h.callers["outsider"].identity.Hex()

	createTicket := model.CreateTicketArgs{
		ID:               101,
		ProjectID:        1,
		Number:           3,
		Title:            "Restart recovery ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            1300,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create ticket: %v", err)
	}

	addComment := model.AddCommentArgs{ID: 502, TicketID: 101, Visibility: "internal", Body: "Restart note", NowNS: 1600}
	h.callReducer(t, "bob", app.ReducerAddComment, map[string]any{
		"id":         addComment.ID,
		"ticket_id":  addComment.TicketID,
		"visibility": addComment.Visibility,
		"body":       addComment.Body,
		"now_ns":     addComment.NowNS,
	})
	if err := h.model.AddComment(bob, addComment); err != nil {
		t.Fatalf("model add comment: %v", err)
	}

	h.restart(t)

	assertEqual(t, "users after restart",
		requireRawUsers(t, h, "alice", "SELECT * FROM users", "users-after-restart"),
		h.model.AllUsers())
	assertEqual(t, "projects after restart",
		requireRawProjects(t, h, "alice", "SELECT * FROM projects", "projects-after-restart"),
		h.model.AllProjects())
	assertEqual(t, "alice tickets after restart",
		requireRawTickets(t, h, "alice", "SELECT * FROM tickets", "alice-tickets-after-restart"),
		h.model.VisibleTickets(alice))
	assertEqual(t, "bob comments after restart",
		requireRawComments(t, h, "bob", "SELECT * FROM comments", "bob-comments-after-restart"),
		h.model.VisibleComments(bob))
	assertEqual(t, "audit after restart",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, "audit-after-restart")),
		model.AuditIDs(h.model.AuditFeed(true)))
	assertEqual(t, "bob my_tickets after restart",
		requireDeclaredTickets(t, h, "bob", app.QueryMyTickets, "bob-my-tickets-after-restart"),
		h.model.MyTickets(bob))
	requireOneOffError(t, h, "alice", "SELECT * FROM notifications", "notifications-private-after-restart", "")
	assertEqual(t, "outsider tickets after restart",
		requireRawTickets(t, h, "outsider", "SELECT * FROM tickets", "outsider-tickets-after-restart"),
		h.model.VisibleTickets(outsider))
	assertEqual(t, "bob live_alpha_board initial after restart",
		requireTicketSubscribeInitial(t, h, "bob", app.ViewLiveAlphaBoard, 800, 801),
		h.model.AlphaBoard(bob))
}

func TestRejectedReducerRollbackSurvivesRestart(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	createTicket := model.CreateTicketArgs{
		ID:               110,
		ProjectID:        1,
		Number:           10,
		Title:            "Committed before failed restart probes",
		Priority:         "normal",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            2100,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create ticket: %v", err)
	}

	addComment := model.AddCommentArgs{ID: 510, TicketID: 110, Visibility: "internal", Body: "Committed restart comment", NowNS: 2200}
	h.callReducer(t, "bob", app.ReducerAddComment, map[string]any{
		"id":         addComment.ID,
		"ticket_id":  addComment.TicketID,
		"visibility": addComment.Visibility,
		"body":       addComment.Body,
		"now_ns":     addComment.NowNS,
	})
	if err := h.model.AddComment(bob, addComment); err != nil {
		t.Fatalf("model add comment: %v", err)
	}

	assertRejectedState(t, h, "restart rollback baseline")

	h.callReducerFailed(t, "admin", app.ReducerFailAfterAuditProbe, map[string]any{}, "forced rollback")
	h.callReducerFailed(t, "admin", app.ReducerPanicAfterTicketProbe, map[string]any{}, app.ReducerPanicAfterTicketProbe)
	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                uint64(110),
		"project_id":        uint64(1),
		"number":            uint64(11),
		"title":             "duplicate primary key probe",
		"priority":          "normal",
		"visibility":        "public",
		"assignee_identity": bob,
		"now_ns":            int64(2300),
	}, "")
	h.callReducerFailed(t, "bob", app.ReducerAddComment, map[string]any{
		"id":         uint64(510),
		"ticket_id":  uint64(100),
		"visibility": "public",
		"body":       "duplicate comment id probe",
		"now_ns":     int64(2400),
	}, "")
	h.callReducerFailed(t, "bob", app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 uint64(710),
		"ticket_id":          uint64(404),
		"recipient_identity": bob,
		"delay_ms":           int64(50),
		"now_ns":             int64(2500),
	}, "ticket 404 not found")

	assertRejectedState(t, h, "before restart after failed probes")

	h.restart(t)

	assertEqual(t, "users after rejected restart",
		requireRawUsers(t, h, "alice", "SELECT * FROM users", "users-after-rejected-restart"),
		h.model.AllUsers())
	assertRejectedState(t, h, "after restart after failed probes")
	assertEqual(t, "bob my_tickets after rejected restart",
		requireDeclaredTickets(t, h, "bob", app.QueryMyTickets, "bob-my-tickets-after-rejected-restart"),
		h.model.MyTickets(bob))
	assertEqual(t, "alice my_notifications after rejected restart",
		requireNotificationSubscribeInitial(t, h, "alice", 1000, 1001),
		h.model.VisibleNotifications(alice))
	assertEqual(t, "bob my_notifications after rejected restart",
		requireNotificationSubscribeInitial(t, h, "bob", 1002, 1003),
		h.model.VisibleNotifications(bob))
	requireOneOffError(t, h, "alice", "SELECT * FROM ticket_reminders", "ticket-reminders-private-after-rejected-restart", "private")
}
