package workflows

import (
	"fmt"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestSubscriptionQueryIDReuseWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	h.addCallerAs(t, "bob-reuse-single", "bob", app.PermTicketWrite, app.PermCommentWrite)

	const singleQuery uint32 = 1901
	assertEqual(t, "bob initial public ticket subscription before reuse",
		requireRawTicketSubscribeInitial(t, h, "bob-reuse-single", "SELECT * FROM tickets WHERE visibility = 'public'", 1900, singleQuery),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-reuse-single"].client.UnsubscribeSingle(1902, singleQuery); err != nil {
		t.Fatalf("bob UnsubscribeSingle before query id reuse: %v", err)
	}
	assertEqual(t, "bob dropped public rows before query id reuse",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-reuse-single", 1902, singleQuery),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	assertEqual(t, "bob reused query id assignee snapshot",
		requireRawTicketSubscribeInitial(t, h, "bob-reuse-single", fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob), 1903, singleQuery),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.AssigneeIdentity == bob }))

	oldSingleOnly := model.CreateTicketArgs{
		ID:               198,
		ProjectID:        1,
		Number:           98,
		Title:            "Old single query public ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            13100,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                oldSingleOnly.ID,
		"project_id":        oldSingleOnly.ProjectID,
		"number":            oldSingleOnly.Number,
		"title":             oldSingleOnly.Title,
		"priority":          oldSingleOnly.Priority,
		"visibility":        oldSingleOnly.Visibility,
		"assignee_identity": oldSingleOnly.AssigneeIdentity,
		"now_ns":            oldSingleOnly.NowNS,
	})
	if err := h.model.CreateTicket(alice, oldSingleOnly); err != nil {
		t.Fatalf("model create old single-only ticket: %v", err)
	}

	newSingleMatch := model.CreateTicketArgs{
		ID:               199,
		ProjectID:        1,
		Number:           99,
		Title:            "Reused single query assignee ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            13200,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                newSingleMatch.ID,
		"project_id":        newSingleMatch.ProjectID,
		"number":            newSingleMatch.Number,
		"title":             newSingleMatch.Title,
		"priority":          newSingleMatch.Priority,
		"visibility":        newSingleMatch.Visibility,
		"assignee_identity": newSingleMatch.AssigneeIdentity,
		"now_ns":            newSingleMatch.NowNS,
	})
	if err := h.model.CreateTicket(alice, newSingleMatch); err != nil {
		t.Fatalf("model create new single-match ticket: %v", err)
	}
	singleInsert := requireTicketDeltaIDs(t, h, "bob-reuse-single", singleQuery, []uint64{199}, []uint64{})
	assertEqual(t, "bob reused single query insert row", singleInsert, []model.Ticket{h.model.Tickets[199]})

	h.addCallerAs(t, "alice-reuse-multi", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const multiQuery uint32 = 1905
	if err := h.callers["alice-reuse-multi"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets WHERE visibility = 'public'",
		"SELECT * FROM comments WHERE visibility = 'public'",
	}, 1904, multiQuery); err != nil {
		t.Fatalf("alice initial multi before reuse: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "alice-reuse-multi", 1904, multiQuery), multiQuery,
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.Visibility == "public" }))

	if err := h.callers["alice-reuse-multi"].client.UnsubscribeMulti(1906, multiQuery); err != nil {
		t.Fatalf("alice UnsubscribeMulti before query id reuse: %v", err)
	}
	assertMultiFilteredDeletes(t, h, requireUnsubscribeMultiApplied(t, h, "alice-reuse-multi", 1906, multiQuery), multiQuery,
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.Visibility == "public" }))

	preExistingMultiTicket := model.CreateTicketArgs{
		ID:               197,
		ProjectID:        1,
		Number:           97,
		Title:            "Pre-existing reused multi assignee ticket",
		Priority:         "normal",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            13250,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                preExistingMultiTicket.ID,
		"project_id":        preExistingMultiTicket.ProjectID,
		"number":            preExistingMultiTicket.Number,
		"title":             preExistingMultiTicket.Title,
		"priority":          preExistingMultiTicket.Priority,
		"visibility":        preExistingMultiTicket.Visibility,
		"assignee_identity": preExistingMultiTicket.AssigneeIdentity,
		"now_ns":            preExistingMultiTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, preExistingMultiTicket); err != nil {
		t.Fatalf("model create pre-existing multi ticket: %v", err)
	}

	if err := h.callers["alice-reuse-multi"].client.SubscribeMulti([]string{
		fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", alice),
		fmt.Sprintf("SELECT * FROM comments WHERE author_identity = '%s'", alice),
	}, 1907, multiQuery); err != nil {
		t.Fatalf("alice reused multi query id: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "alice-reuse-multi", 1907, multiQuery), multiQuery,
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.AssigneeIdentity == alice }),
		filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.AuthorIdentity == alice }))

	oldMultiOnlyTicket := model.CreateTicketArgs{
		ID:               201,
		ProjectID:        1,
		Number:           101,
		Title:            "Old multi public ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            13300,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                oldMultiOnlyTicket.ID,
		"project_id":        oldMultiOnlyTicket.ProjectID,
		"number":            oldMultiOnlyTicket.Number,
		"title":             oldMultiOnlyTicket.Title,
		"priority":          oldMultiOnlyTicket.Priority,
		"visibility":        oldMultiOnlyTicket.Visibility,
		"assignee_identity": oldMultiOnlyTicket.AssigneeIdentity,
		"now_ns":            oldMultiOnlyTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, oldMultiOnlyTicket); err != nil {
		t.Fatalf("model create old multi-only ticket: %v", err)
	}

	newMultiTicket := model.CreateTicketArgs{
		ID:               202,
		ProjectID:        1,
		Number:           102,
		Title:            "Reused multi assignee ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            13400,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                newMultiTicket.ID,
		"project_id":        newMultiTicket.ProjectID,
		"number":            newMultiTicket.Number,
		"title":             newMultiTicket.Title,
		"priority":          newMultiTicket.Priority,
		"visibility":        newMultiTicket.Visibility,
		"assignee_identity": newMultiTicket.AssigneeIdentity,
		"now_ns":            newMultiTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, newMultiTicket); err != nil {
		t.Fatalf("model create new multi-match ticket: %v", err)
	}
	updates := readSubscriptionUpdates(t, h.callers["alice-reuse-multi"].client)
	ticketInsert := requireTicketUpdateFromUpdates(t, h, updates, multiQuery, []uint64{202}, []uint64{})
	assertEqual(t, "alice reused multi ticket insert row", ticketInsert, []model.Ticket{h.model.Tickets[202]})
	assertNoTableUpdate(t, updates, multiQuery, "comments", "reused multi ticket transaction")

	oldMultiOnlyComment := model.AddCommentArgs{ID: 598, TicketID: 100, Visibility: "public", Body: "Old multi public comment", NowNS: 13500}
	h.callReducer(t, "bob", app.ReducerAddComment, map[string]any{
		"id":         oldMultiOnlyComment.ID,
		"ticket_id":  oldMultiOnlyComment.TicketID,
		"visibility": oldMultiOnlyComment.Visibility,
		"body":       oldMultiOnlyComment.Body,
		"now_ns":     oldMultiOnlyComment.NowNS,
	})
	if err := h.model.AddComment(bob, oldMultiOnlyComment); err != nil {
		t.Fatalf("model add old multi-only comment: %v", err)
	}

	newMultiComment := model.AddCommentArgs{ID: 599, TicketID: 100, Visibility: "internal", Body: "Reused multi author comment", NowNS: 13600}
	h.callReducer(t, "alice", app.ReducerAddComment, map[string]any{
		"id":         newMultiComment.ID,
		"ticket_id":  newMultiComment.TicketID,
		"visibility": newMultiComment.Visibility,
		"body":       newMultiComment.Body,
		"now_ns":     newMultiComment.NowNS,
	})
	if err := h.model.AddComment(alice, newMultiComment); err != nil {
		t.Fatalf("model add new multi-match comment: %v", err)
	}
	updates = readSubscriptionUpdates(t, h.callers["alice-reuse-multi"].client)
	assertNoTableUpdate(t, updates, multiQuery, "tickets", "reused multi comment transaction")
	commentInsert := requireCommentUpdateFromUpdates(t, h, updates, multiQuery, []uint64{599}, []uint64{})
	assertEqual(t, "alice reused multi comment insert row", commentInsert, []model.Comment{h.model.Comments[599]})
}

func assertMultiFilteredSnapshot(t *testing.T, h *workflowHarness, updates []protocol.SubscriptionUpdate, queryID uint32, wantTickets []model.Ticket, wantComments []model.Comment) {
	t.Helper()
	gotTables := map[string]bool{}
	for _, update := range updates {
		if update.QueryID != queryID {
			t.Fatalf("multi snapshot query id = %d, want %d", update.QueryID, queryID)
		}
		gotTables[update.TableName] = true
		switch update.TableName {
		case "tickets":
			assertEqual(t, "multi filtered ticket snapshot", decodeTicketPayload(t, h, update.Inserts), wantTickets)
		case "comments":
			assertEqual(t, "multi filtered comment snapshot", decodeCommentPayload(t, h, update.Inserts), wantComments)
		default:
			t.Fatalf("unexpected multi filtered table %q", update.TableName)
		}
	}
	assertEqual(t, "multi filtered snapshot tables", gotTables, map[string]bool{"tickets": true, "comments": true})
}

func assertMultiFilteredDeletes(t *testing.T, h *workflowHarness, updates []protocol.SubscriptionUpdate, queryID uint32, wantTickets []model.Ticket, wantComments []model.Comment) {
	t.Helper()
	gotTables := map[string]bool{}
	for _, update := range updates {
		if update.QueryID != queryID {
			t.Fatalf("multi unsubscribe query id = %d, want %d", update.QueryID, queryID)
		}
		gotTables[update.TableName] = true
		switch update.TableName {
		case "tickets":
			assertEqual(t, "multi filtered ticket deletes", decodeTicketPayload(t, h, update.Deletes), wantTickets)
		case "comments":
			assertEqual(t, "multi filtered comment deletes", decodeCommentPayload(t, h, update.Deletes), wantComments)
		default:
			t.Fatalf("unexpected multi filtered delete table %q", update.TableName)
		}
	}
	assertEqual(t, "multi filtered delete tables", gotTables, map[string]bool{"tickets": true, "comments": true})
}
