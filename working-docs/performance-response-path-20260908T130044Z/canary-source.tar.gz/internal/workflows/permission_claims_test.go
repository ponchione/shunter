package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestTokenPermissionClaimsDriveAccessWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	h.addCallerAs(t, "auditor-no-perm", "auditor")
	auditorIdentity := h.callers["auditor-no-perm"].identity.Hex()
	assertEqual(t, "auditor subject without audit permission profile",
		requireDeclaredUsers(t, h, "auditor-no-perm", app.QueryMyProfile, "auditor-no-perm-profile"),
		h.model.MyProfile(auditorIdentity))
	requireDeclaredError(t, h, "auditor-no-perm", app.QueryAuditFeed, "auditor-no-perm-audit-feed", "permission")
	requireOneOffError(t, h, "auditor-no-perm", "SELECT * FROM audit_log", "auditor-no-perm-raw-audit", "")

	h.addCallerAs(t, "outsider-audit", "outsider", app.PermAuditRead)
	assertEqual(t, "outsider subject with audit permission declared audit",
		model.AuditIDs(requireDeclaredAudit(t, h, "outsider-audit", app.QueryAuditFeed, "outsider-audit-feed")),
		model.AuditIDs(h.model.AuditFeed(true)))
	assertEqual(t, "outsider subject with audit permission raw audit",
		model.AuditIDs(requireRawAudit(t, h, "outsider-audit", "SELECT * FROM audit_log", "outsider-raw-audit")),
		model.AuditIDs(h.model.AuditFeed(true)))

	h.addCallerAs(t, "alice-no-perm", "alice")
	h.callReducerFailed(t, "alice-no-perm", app.ReducerCreateTicket, map[string]any{
		"id":                uint64(197),
		"project_id":        uint64(1),
		"number":            uint64(97),
		"title":             "permission claim denied ticket",
		"priority":          "normal",
		"visibility":        "public",
		"assignee_identity": "",
		"now_ns":            int64(12100),
	}, "permission")
	assertRejectedState(t, h, "after alice no-perm create_ticket")

	h.addCallerAs(t, "bob-ticket-only", "bob", app.PermTicketWrite)
	h.callReducerFailed(t, "bob-ticket-only", app.ReducerAddComment, map[string]any{
		"id":         uint64(597),
		"ticket_id":  uint64(100),
		"visibility": "public",
		"body":       "permission claim denied comment",
		"now_ns":     int64(12200),
	}, "permission")
	assertRejectedState(t, h, "after bob ticket-only add_comment")

	h.addCallerAs(t, "outsider-ticket-writer", "outsider", app.PermTicketWrite)
	outsiderIdentity := h.callers["outsider-ticket-writer"].identity.Hex()
	createTicket := model.CreateTicketArgs{
		ID:               197,
		ProjectID:        1,
		Number:           97,
		Title:            "Permission claim accepted ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: "",
		NowNS:            12300,
	}
	h.callReducer(t, "outsider-ticket-writer", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(outsiderIdentity, createTicket); err != nil {
		t.Fatalf("model create outsider permission-claim ticket: %v", err)
	}

	assertEqual(t, "outsider original connection sees same-identity internal ticket",
		requireRawTickets(t, h, "outsider", "SELECT * FROM tickets", "outsider-tickets-after-claim-ticket"),
		h.model.VisibleTickets(outsiderIdentity))
	assertEqual(t, "bob cannot see outsider internal ticket",
		requireRawTickets(t, h, "bob", "SELECT * FROM tickets", "bob-tickets-after-claim-ticket"),
		h.model.VisibleTickets(h.callers["bob"].identity.Hex()))
	assertEqual(t, "audit after permission-claim accepted ticket",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, "audit-after-permission-claims")),
		model.AuditIDs(h.model.AuditFeed(true)))
}
