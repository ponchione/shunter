package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestRawSubscriptionPredicateWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	carol := h.callers["carol"].identity.Hex()
	outsider := h.callers["outsider"].identity.Hex()

	h.addCallerAs(t, "bob-open-high", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "carol-open-high", "carol", app.PermCommentWrite)
	h.addCallerAs(t, "outsider-open-high", "outsider")

	const sql = "SELECT * FROM tickets WHERE status = 'open' AND priority = 'high'"

	const bobQuery uint32 = 1401
	assertEqual(t, "bob raw open high initial",
		requireRawTicketSubscribeInitial(t, h, "bob-open-high", sql, 1400, bobQuery),
		filterTickets(h.model.VisibleTickets(bob), isOpenHighTicket))

	const carolQuery uint32 = 1403
	assertEqual(t, "carol raw open high initial",
		requireRawTicketSubscribeInitial(t, h, "carol-open-high", sql, 1402, carolQuery),
		filterTickets(h.model.VisibleTickets(carol), isOpenHighTicket))

	const outsiderQuery uint32 = 1405
	assertEqual(t, "outsider raw open high initial",
		requireRawTicketSubscribeInitial(t, h, "outsider-open-high", sql, 1404, outsiderQuery),
		filterTickets(h.model.VisibleTickets(outsider), isOpenHighTicket))

	assign := model.AssignTicketArgs{TicketID: 100, AssigneeIdentity: carol, NowNS: 6100}
	h.callReducer(t, "alice", app.ReducerAssignTicket, map[string]any{
		"ticket_id":         assign.TicketID,
		"assignee_identity": assign.AssigneeIdentity,
		"now_ns":            assign.NowNS,
	})
	if err := h.model.AssignTicket(alice, assign); err != nil {
		t.Fatalf("model assign ticket 100: %v", err)
	}

	requireTicketDeltaIDs(t, h, "bob-open-high", bobQuery, []uint64{}, []uint64{100})
	carolVisibilityInsert := requireTicketDeltaIDs(t, h, "carol-open-high", carolQuery, []uint64{100}, []uint64{})
	assertEqual(t, "carol raw open high visibility insert", carolVisibilityInsert, []model.Ticket{h.model.Tickets[100]})

	createTicket := model.CreateTicketArgs{
		ID:               150,
		ProjectID:        1,
		Number:           50,
		Title:            "Raw subscription public high ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: bob,
		NowNS:            6200,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create raw subscription ticket: %v", err)
	}

	bobPublicInsert := requireTicketDeltaIDs(t, h, "bob-open-high", bobQuery, []uint64{150}, []uint64{})
	assertEqual(t, "bob raw open high public insert", bobPublicInsert, []model.Ticket{h.model.Tickets[150]})
	carolPublicInsert := requireTicketDeltaIDs(t, h, "carol-open-high", carolQuery, []uint64{150}, []uint64{})
	assertEqual(t, "carol raw open high public insert", carolPublicInsert, []model.Ticket{h.model.Tickets[150]})
	outsiderPublicInsert := requireTicketDeltaIDs(t, h, "outsider-open-high", outsiderQuery, []uint64{150}, []uint64{})
	assertEqual(t, "outsider raw open high public insert", outsiderPublicInsert, []model.Ticket{h.model.Tickets[150]})

	closeNow := int64(6300)
	h.callReducer(t, "alice", app.ReducerCloseTicket, map[string]any{
		"ticket_id": uint64(150),
		"now_ns":    closeNow,
	})
	if err := h.model.CloseTicket(alice, 150, closeNow); err != nil {
		t.Fatalf("model close raw subscription ticket: %v", err)
	}

	requireTicketDeltaIDs(t, h, "bob-open-high", bobQuery, []uint64{}, []uint64{150})
	requireTicketDeltaIDs(t, h, "carol-open-high", carolQuery, []uint64{}, []uint64{150})
	requireTicketDeltaIDs(t, h, "outsider-open-high", outsiderQuery, []uint64{}, []uint64{150})
}

func isOpenHighTicket(row model.Ticket) bool {
	return row.Status == "open" && row.Priority == "high"
}
