package workflows

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

type concurrentReducerTask struct {
	key       string
	subject   string
	reducer   string
	args      map[string]any
	requestID uint32
	apply     func() error
	audit     expectedAuditEntry
}

type expectedAuditEntry struct {
	action      string
	targetTable string
	targetID    uint64
}

func TestConcurrentReducerWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	carol := h.callers["carol"].identity.Hex()
	outsider := h.callers["outsider"].identity.Hex()

	waveOne := []concurrentReducerTask{}
	expectedAudit := []expectedAuditEntry{}

	for _, project := range []struct {
		id         uint64
		subject    string
		slug       string
		visibility string
		nowNS      int64
	}{
		{id: 30, subject: "admin", slug: "concurrent-admin", visibility: "public", nowNS: 7000},
		{id: 31, subject: "alice", slug: "concurrent-alice", visibility: "internal", nowNS: 7010},
	} {
		project := project
		args := model.CreateProjectArgs{ID: project.id, Slug: project.slug, Name: "Concurrent " + project.slug, Visibility: project.visibility, NowNS: project.nowNS}
		task := concurrentReducerTask{
			key:       fmt.Sprintf("concurrent-project-%d", project.id),
			subject:   project.subject,
			reducer:   app.ReducerCreateProject,
			requestID: uint32(7000 + project.id),
			args: map[string]any{
				"id":         args.ID,
				"slug":       args.Slug,
				"name":       args.Name,
				"visibility": args.Visibility,
				"now_ns":     args.NowNS,
			},
			apply: func() error {
				return h.model.CreateProject(h.callers[project.subject].identity.Hex(), args)
			},
			audit: expectedAuditEntry{action: app.ReducerCreateProject, targetTable: "projects", targetID: project.id},
		}
		waveOne = append(waveOne, task)
		expectedAudit = append(expectedAudit, task.audit)
	}

	for i := 0; i < 8; i++ {
		i := i
		subject := "alice"
		reporter := alice
		if i%2 == 1 {
			subject = "bob"
			reporter = bob
		}
		args := model.CreateTicketArgs{
			ID:         uint64(160 + i),
			ProjectID:  1,
			Number:     uint64(60 + i),
			Title:      fmt.Sprintf("Concurrent ticket %d", i),
			Priority:   []string{"low", "normal", "high"}[i%3],
			Visibility: []string{"public", "internal"}[i%2],
			NowNS:      int64(7100 + i),
		}
		task := concurrentReducerTask{
			key:       fmt.Sprintf("concurrent-ticket-%d", args.ID),
			subject:   subject,
			reducer:   app.ReducerCreateTicket,
			requestID: uint32(7100 + i),
			args: map[string]any{
				"id":                args.ID,
				"project_id":        args.ProjectID,
				"number":            args.Number,
				"title":             args.Title,
				"priority":          args.Priority,
				"visibility":        args.Visibility,
				"assignee_identity": "",
				"now_ns":            args.NowNS,
			},
			apply: func() error {
				return h.model.CreateTicket(reporter, args)
			},
			audit: expectedAuditEntry{action: app.ReducerCreateTicket, targetTable: "tickets", targetID: args.ID},
		}
		waveOne = append(waveOne, task)
		expectedAudit = append(expectedAudit, task.audit)
	}

	for i := 0; i < 6; i++ {
		i := i
		subject := []string{"alice", "bob", "carol"}[i%3]
		author := h.callers[subject].identity.Hex()
		ticketID := uint64(100)
		if i%2 == 1 {
			ticketID = 200
		}
		args := model.AddCommentArgs{
			ID:         uint64(560 + i),
			TicketID:   ticketID,
			Visibility: []string{"public", "internal"}[i%2],
			Body:       fmt.Sprintf("Concurrent comment %d", i),
			NowNS:      int64(7200 + i),
		}
		task := concurrentReducerTask{
			key:       fmt.Sprintf("concurrent-comment-%d", args.ID),
			subject:   subject,
			reducer:   app.ReducerAddComment,
			requestID: uint32(7200 + i),
			args: map[string]any{
				"id":         args.ID,
				"ticket_id":  args.TicketID,
				"visibility": args.Visibility,
				"body":       args.Body,
				"now_ns":     args.NowNS,
			},
			apply: func() error {
				return h.model.AddComment(author, args)
			},
			audit: expectedAuditEntry{action: app.ReducerAddComment, targetTable: "comments", targetID: args.ID},
		}
		waveOne = append(waveOne, task)
		expectedAudit = append(expectedAudit, task.audit)
	}

	addConcurrentTaskCallers(t, h, waveOne)
	runConcurrentReducerTasks(t, h, waveOne)
	applyConcurrentTasks(t, waveOne)

	waveTwo := []concurrentReducerTask{}
	for i := 0; i < 8; i++ {
		i := i
		subject := "alice"
		actor := alice
		if i%2 == 1 {
			subject = "bob"
			actor = bob
		}
		ticketID := uint64(160 + i)
		args := model.ChangeTicketStatusArgs{TicketID: ticketID, Status: []string{"blocked", "in_progress"}[i%2], NowNS: int64(7300 + i)}
		task := concurrentReducerTask{
			key:       fmt.Sprintf("concurrent-status-%d", ticketID),
			subject:   subject,
			reducer:   app.ReducerChangeTicketStatus,
			requestID: uint32(7300 + i),
			args: map[string]any{
				"ticket_id": args.TicketID,
				"status":    args.Status,
				"now_ns":    args.NowNS,
			},
			apply: func() error {
				return h.model.ChangeTicketStatus(actor, args)
			},
			audit: expectedAuditEntry{action: app.ReducerChangeTicketStatus, targetTable: "tickets", targetID: ticketID},
		}
		waveTwo = append(waveTwo, task)
		expectedAudit = append(expectedAudit, task.audit)
	}

	addConcurrentTaskCallers(t, h, waveTwo)
	runConcurrentReducerTasks(t, h, waveTwo)
	applyConcurrentTasks(t, waveTwo)

	assertEqual(t, "projects after concurrent reducers",
		requireRawProjects(t, h, "alice", "SELECT * FROM projects", "concurrent-projects"),
		h.model.AllProjects())
	for _, subject := range []struct {
		name     string
		identity string
	}{
		{name: "alice", identity: alice},
		{name: "bob", identity: bob},
		{name: "carol", identity: carol},
		{name: "outsider", identity: outsider},
	} {
		assertEqual(t, subject.name+" tickets after concurrent reducers",
			requireRawTickets(t, h, subject.name, "SELECT * FROM tickets", "concurrent-"+subject.name+"-tickets"),
			h.model.VisibleTickets(subject.identity))
		assertEqual(t, subject.name+" comments after concurrent reducers",
			requireRawComments(t, h, subject.name, "SELECT * FROM comments", "concurrent-"+subject.name+"-comments"),
			h.model.VisibleComments(subject.identity))
	}

	assertAuditContainsConcurrentEntries(t, h, expectedAudit)
}

func addConcurrentTaskCallers(t *testing.T, h *workflowHarness, tasks []concurrentReducerTask) {
	t.Helper()
	for _, task := range tasks {
		addConcurrentCaller(t, h, task.key, task.subject)
	}
}

func addConcurrentCaller(t *testing.T, h *workflowHarness, key, subject string) {
	t.Helper()
	switch subject {
	case "admin":
		h.addCallerAs(t, key, subject, app.PermAdminWrite, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite, app.PermAuditRead)
	case "alice":
		h.addCallerAs(t, key, subject, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	case "bob":
		h.addCallerAs(t, key, subject, app.PermTicketWrite, app.PermCommentWrite)
	case "carol":
		h.addCallerAs(t, key, subject, app.PermCommentWrite)
	default:
		h.addCallerAs(t, key, subject)
	}
}

func runConcurrentReducerTasks(t *testing.T, h *workflowHarness, tasks []concurrentReducerTask) {
	t.Helper()
	var wg sync.WaitGroup
	errCh := make(chan error, len(tasks))
	for _, task := range tasks {
		task := task
		caller := h.callers[task.key]
		wg.Add(1)
		go func() {
			defer wg.Done()
			errCh <- callReducerCommittedConcurrently(caller, task.reducer, task.args, task.requestID)
		}()
	}
	wg.Wait()
	close(errCh)
	for err := range errCh {
		if err != nil {
			t.Fatal(err)
		}
	}
}

func callReducerCommittedConcurrently(caller *workflowCaller, reducer string, args any, requestID uint32) error {
	if err := caller.client.CallReducer(reducer, args, requestID, protocol.CallReducerFlagsFullUpdate); err != nil {
		return fmt.Errorf("%s CallReducer %s: %w", caller.subject, reducer, err)
	}
	deadline := time.Now().Add(5 * time.Second)
	for {
		ctx, cancel := context.WithDeadline(context.Background(), deadline)
		tag, msg, err := caller.client.Read(ctx)
		cancel()
		if err != nil {
			return fmt.Errorf("%s read %s result: %w", caller.subject, reducer, err)
		}
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update, ok := msg.(protocol.TransactionUpdate)
		if !ok {
			return fmt.Errorf("%s %s response = %T, want TransactionUpdate", caller.subject, reducer, msg)
		}
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		if failed, ok := update.Status.(protocol.StatusFailed); ok {
			return fmt.Errorf("%s reducer %s failed: %s", caller.subject, reducer, failed.Error)
		}
		if _, ok := update.Status.(protocol.StatusCommitted); !ok {
			return fmt.Errorf("%s reducer %s status = %T, want StatusCommitted", caller.subject, reducer, update.Status)
		}
		return nil
	}
}

func applyConcurrentTasks(t *testing.T, tasks []concurrentReducerTask) {
	t.Helper()
	for _, task := range tasks {
		if err := task.apply(); err != nil {
			t.Fatalf("model apply %s %s: %v", task.key, task.reducer, err)
		}
	}
}

func assertAuditContainsConcurrentEntries(t *testing.T, h *workflowHarness, expected []expectedAuditEntry) {
	t.Helper()
	got := requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, "concurrent-audit")
	if len(got) != 4+len(expected) {
		t.Fatalf("concurrent audit row count = %d, want %d", len(got), 4+len(expected))
	}
	counts := map[expectedAuditEntry]int{}
	for _, row := range got {
		counts[expectedAuditEntry{action: row.Action, targetTable: row.TargetTable, targetID: row.TargetID}]++
	}
	for _, want := range expected {
		if counts[want] == 0 {
			t.Fatalf("missing concurrent audit entry %#v in %#v", want, got)
		}
		counts[want]--
	}
}
