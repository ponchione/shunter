package workflows

import (
	"fmt"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestActiveSingleQueryIDCollisionWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-active-single", "bob", app.PermTicketWrite, app.PermCommentWrite)

	const queryID uint32 = 2001
	assertEqual(t, "bob active single public initial",
		requireRawTicketSubscribeInitial(t, h, "bob-active-single", "SELECT * FROM tickets WHERE visibility = 'public'", 2000, queryID),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-active-single"].client.SubscribeSingle(fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob), 2002, queryID); err != nil {
		t.Fatalf("bob duplicate SubscribeSingle: %v", err)
	}
	requireSubscriptionError(t, h, "bob-active-single", 2002, queryID, "query id already live")

	if err := h.callers["bob-active-single"].client.SubscribeMulti([]string{
		fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob),
		fmt.Sprintf("SELECT * FROM comments WHERE author_identity = '%s'", bob),
	}, 2003, queryID); err != nil {
		t.Fatalf("bob duplicate SubscribeMulti: %v", err)
	}
	requireSubscriptionError(t, h, "bob-active-single", 2003, queryID, "query id already live")

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               210,
		ProjectID:        1,
		Number:           110,
		Title:            "Rejected duplicate active single match",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            14100,
	})

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               211,
		ProjectID:        1,
		Number:           111,
		Title:            "Original active single public match",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            14200,
	})
	publicInsert := requireTicketDeltaIDs(t, h, "bob-active-single", queryID, []uint64{211}, []uint64{})
	assertEqual(t, "bob original active single stayed live", publicInsert, []model.Ticket{h.model.Tickets[211]})

	if err := h.callers["bob-active-single"].client.UnsubscribeSingle(2004, queryID); err != nil {
		t.Fatalf("bob active single UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob active single unsubscribe deletes original public rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-active-single", 2004, queryID),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-active-single"].client.SubscribeMulti([]string{
		fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob),
		fmt.Sprintf("SELECT * FROM comments WHERE author_identity = '%s'", bob),
	}, 2005, queryID); err != nil {
		t.Fatalf("bob reused active single query id as multi: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "bob-active-single", 2005, queryID), queryID,
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.AssigneeIdentity == bob }),
		filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.AuthorIdentity == bob }))

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               212,
		ProjectID:        1,
		Number:           112,
		Title:            "Reused active single as multi ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            14300,
	})
	updates := readSubscriptionUpdates(t, h.callers["bob-active-single"].client)
	ticketInsert := requireTicketUpdateFromUpdates(t, h, updates, queryID, []uint64{212}, []uint64{})
	assertEqual(t, "bob reused single id as multi ticket row", ticketInsert, []model.Ticket{h.model.Tickets[212]})
	assertNoTableUpdate(t, updates, queryID, "comments", "reused active single ticket transaction")

	addCommentForWorkflow(t, h, "bob", model.AddCommentArgs{
		ID:         512,
		TicketID:   100,
		Visibility: "internal",
		Body:       "Reused active single as multi comment",
		NowNS:      14400,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-active-single"].client)
	assertNoTableUpdate(t, updates, queryID, "tickets", "reused active single comment transaction")
	commentInsert := requireCommentUpdateFromUpdates(t, h, updates, queryID, []uint64{512}, []uint64{})
	assertEqual(t, "bob reused single id as multi comment row", commentInsert, []model.Comment{h.model.Comments[512]})
}

func TestActiveMultiQueryIDCollisionWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	h.addCallerAs(t, "alice-active-multi", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const queryID uint32 = 2011
	if err := h.callers["alice-active-multi"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets WHERE visibility = 'public'",
		"SELECT * FROM comments WHERE visibility = 'public'",
	}, 2010, queryID); err != nil {
		t.Fatalf("alice active multi SubscribeMulti: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "alice-active-multi", 2010, queryID), queryID,
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.Visibility == "public" }))

	if err := h.callers["alice-active-multi"].client.SubscribeMulti([]string{
		fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", alice),
		fmt.Sprintf("SELECT * FROM comments WHERE author_identity = '%s'", alice),
	}, 2012, queryID); err != nil {
		t.Fatalf("alice duplicate SubscribeMulti: %v", err)
	}
	requireSubscriptionError(t, h, "alice-active-multi", 2012, queryID, "query id already live")

	if err := h.callers["alice-active-multi"].client.SubscribeSingle(fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", alice), 2013, queryID); err != nil {
		t.Fatalf("alice duplicate SubscribeSingle: %v", err)
	}
	requireSubscriptionError(t, h, "alice-active-multi", 2013, queryID, "query id already live")

	createTicketForWorkflow(t, h, "bob", model.CreateTicketArgs{
		ID:               220,
		ProjectID:        1,
		Number:           120,
		Title:            "Rejected duplicate active multi ticket match",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            14500,
	})

	addCommentForWorkflow(t, h, "alice", model.AddCommentArgs{
		ID:         520,
		TicketID:   100,
		Visibility: "internal",
		Body:       "Rejected duplicate active multi comment match",
		NowNS:      14600,
	})

	createTicketForWorkflow(t, h, "bob", model.CreateTicketArgs{
		ID:               221,
		ProjectID:        1,
		Number:           121,
		Title:            "Original active multi public ticket match",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            14700,
	})
	updates := readSubscriptionUpdates(t, h.callers["alice-active-multi"].client)
	ticketInsert := requireTicketUpdateFromUpdates(t, h, updates, queryID, []uint64{221}, []uint64{})
	assertEqual(t, "alice original active multi ticket stayed live", ticketInsert, []model.Ticket{h.model.Tickets[221]})
	assertNoTableUpdate(t, updates, queryID, "comments", "active multi public ticket transaction")

	addCommentForWorkflow(t, h, "bob", model.AddCommentArgs{
		ID:         521,
		TicketID:   100,
		Visibility: "public",
		Body:       "Original active multi public comment match",
		NowNS:      14800,
	})
	updates = readSubscriptionUpdates(t, h.callers["alice-active-multi"].client)
	assertNoTableUpdate(t, updates, queryID, "tickets", "active multi public comment transaction")
	commentInsert := requireCommentUpdateFromUpdates(t, h, updates, queryID, []uint64{521}, []uint64{})
	assertEqual(t, "alice original active multi comment stayed live", commentInsert, []model.Comment{h.model.Comments[521]})

	if err := h.callers["alice-active-multi"].client.UnsubscribeMulti(2014, queryID); err != nil {
		t.Fatalf("alice active multi UnsubscribeMulti: %v", err)
	}
	assertMultiFilteredDeletes(t, h, requireUnsubscribeMultiApplied(t, h, "alice-active-multi", 2014, queryID), queryID,
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.Visibility == "public" }))

	assertEqual(t, "alice reused active multi query id as single",
		requireRawTicketSubscribeInitial(t, h, "alice-active-multi", fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", alice), 2015, queryID),
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.AssigneeIdentity == alice }))
}

func createTicketForWorkflow(t *testing.T, h *workflowHarness, subject string, args model.CreateTicketArgs) {
	t.Helper()
	h.callReducer(t, subject, app.ReducerCreateTicket, map[string]any{
		"id":                args.ID,
		"project_id":        args.ProjectID,
		"number":            args.Number,
		"title":             args.Title,
		"priority":          args.Priority,
		"visibility":        args.Visibility,
		"assignee_identity": args.AssigneeIdentity,
		"now_ns":            args.NowNS,
	})
	if err := h.model.CreateTicket(h.callers[subject].identity.Hex(), args); err != nil {
		t.Fatalf("model create ticket %d: %v", args.ID, err)
	}
}

func addCommentForWorkflow(t *testing.T, h *workflowHarness, subject string, args model.AddCommentArgs) {
	t.Helper()
	h.callReducer(t, subject, app.ReducerAddComment, map[string]any{
		"id":         args.ID,
		"ticket_id":  args.TicketID,
		"visibility": args.Visibility,
		"body":       args.Body,
		"now_ns":     args.NowNS,
	})
	if err := h.model.AddComment(h.callers[subject].identity.Hex(), args); err != nil {
		t.Fatalf("model add comment %d: %v", args.ID, err)
	}
}
