package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestReadAndSubscriptionErrorRecoveryWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	requireOneOffError(t, h, "alice", "SELECT * FROM does_not_exist", "alice-missing-table", "")
	assertEqual(t, "alice my_profile after missing table one-off",
		requireDeclaredUsers(t, h, "alice", app.QueryMyProfile, "alice-profile-after-missing-table"),
		h.model.MyProfile(alice))

	requireOneOffError(t, h, "alice", "SELECT * FROM project_members", "alice-private-members", "private")
	assertEqual(t, "alice tickets after private one-off",
		requireRawTickets(t, h, "alice", "SELECT * FROM tickets", "alice-tickets-after-private-oneoff"),
		h.model.VisibleTickets(alice))

	requireDeclaredError(t, h, "alice", "missing_declared_query", "alice-missing-declared-query", "unknown")
	assertEqual(t, "alice my_tickets after missing declared query",
		requireDeclaredTickets(t, h, "alice", app.QueryMyTickets, "alice-my-tickets-after-missing-declared"),
		h.model.MyTickets(alice))

	h.addCallerAs(t, "alice-sub-recovery", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const failedRawQuery uint32 = 1501
	if err := h.callers["alice-sub-recovery"].client.SubscribeSingle("SELECT * FROM project_members", 1500, failedRawQuery); err != nil {
		t.Fatalf("alice private SubscribeSingle: %v", err)
	}
	requireSubscriptionError(t, h, "alice-sub-recovery", 1500, failedRawQuery, "project_members")

	const publicTicketsQuery uint32 = 1503
	assertEqual(t, "alice public ticket subscription after raw subscribe error",
		requireRawTicketSubscribeInitial(t, h, "alice-sub-recovery", "SELECT * FROM tickets WHERE visibility = 'public'", 1502, publicTicketsQuery),
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }))

	publicTicket := model.CreateTicketArgs{
		ID:               180,
		ProjectID:        1,
		Number:           80,
		Title:            "Read recovery public ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            8100,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                publicTicket.ID,
		"project_id":        publicTicket.ProjectID,
		"number":            publicTicket.Number,
		"title":             publicTicket.Title,
		"priority":          publicTicket.Priority,
		"visibility":        publicTicket.Visibility,
		"assignee_identity": publicTicket.AssigneeIdentity,
		"now_ns":            publicTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, publicTicket); err != nil {
		t.Fatalf("model create public recovery ticket: %v", err)
	}
	updates := readSubscriptionUpdates(t, h.callers["alice-sub-recovery"].client)
	assertNoSubscriptionQuery(t, updates, failedRawQuery, "failed raw private subscription")
	publicInsert := requireTicketUpdateFromUpdates(t, h, updates, publicTicketsQuery, []uint64{180}, []uint64{})
	assertEqual(t, "public ticket insert after raw subscribe recovery", publicInsert, []model.Ticket{h.model.Tickets[180]})

	const missingViewQuery uint32 = 1505
	if err := h.callers["alice-sub-recovery"].client.SubscribeDeclaredView("missing_declared_view", 1504, missingViewQuery); err != nil {
		t.Fatalf("alice missing declared view SubscribeDeclaredView: %v", err)
	}
	requireSubscriptionError(t, h, "alice-sub-recovery", 1504, missingViewQuery, "unknown")

	const alphaBoardQuery uint32 = 1507
	assertEqual(t, "alice alpha board subscription after missing declared view",
		requireTicketSubscribeInitial(t, h, "alice-sub-recovery", app.ViewLiveAlphaBoard, 1506, alphaBoardQuery),
		h.model.AlphaBoard(alice))

	internalTicket := model.CreateTicketArgs{
		ID:               181,
		ProjectID:        1,
		Number:           81,
		Title:            "Read recovery internal ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            8200,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                internalTicket.ID,
		"project_id":        internalTicket.ProjectID,
		"number":            internalTicket.Number,
		"title":             internalTicket.Title,
		"priority":          internalTicket.Priority,
		"visibility":        internalTicket.Visibility,
		"assignee_identity": internalTicket.AssigneeIdentity,
		"now_ns":            internalTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, internalTicket); err != nil {
		t.Fatalf("model create internal recovery ticket: %v", err)
	}
	updates = readSubscriptionUpdates(t, h.callers["alice-sub-recovery"].client)
	assertNoSubscriptionQuery(t, updates, failedRawQuery, "failed raw private subscription")
	assertNoSubscriptionQuery(t, updates, missingViewQuery, "failed declared view subscription")
	assertNoSubscriptionQuery(t, updates, publicTicketsQuery, "public tickets predicate for internal ticket")
	alphaInsert := requireTicketUpdateFromUpdates(t, h, updates, alphaBoardQuery, []uint64{181}, []uint64{})
	assertEqual(t, "alpha board insert after declared view recovery", alphaInsert, []model.Ticket{h.model.Tickets[181]})
}

func TestPermissionDeniedDeclaredQueryRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	requireDeclaredError(t, h, "alice", app.QueryAuditFeed, "alice-denied-audit-feed-recovery", "permission")

	assertEqual(t, "alice my_profile after permission-denied declared query",
		requireDeclaredUsers(t, h, "alice", app.QueryMyProfile, "alice-profile-after-denied-declared-query"),
		h.model.MyProfile(alice))
	assertEqual(t, "alice raw tickets after permission-denied declared query",
		requireRawTickets(t, h, "alice", "SELECT * FROM tickets", "alice-tickets-after-denied-declared-query"),
		h.model.VisibleTickets(alice))
}

func TestPermissionDeniedDeclaredViewSubscriptionRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	h.addCallerAs(t, "alice-audit-view-denied", "alice", app.PermTicketWrite)
	alice := h.callers["alice-audit-view-denied"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	const deniedAuditQuery uint32 = 1511
	if err := h.callers["alice-audit-view-denied"].client.SubscribeDeclaredView(app.ViewLiveAuditFeed, 1510, deniedAuditQuery); err != nil {
		t.Fatalf("alice denied audit view SubscribeDeclaredView: %v", err)
	}
	requireSubscriptionError(t, h, "alice-audit-view-denied", 1510, deniedAuditQuery, "permission")

	const alphaBoardQuery uint32 = 1513
	assertEqual(t, "alice alpha board subscription after permission-denied audit view",
		requireTicketSubscribeInitial(t, h, "alice-audit-view-denied", app.ViewLiveAlphaBoard, 1512, alphaBoardQuery),
		h.model.AlphaBoard(alice))

	internalTicket := model.CreateTicketArgs{
		ID:               182,
		ProjectID:        1,
		Number:           82,
		Title:            "Permission denied view recovery ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            8300,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                internalTicket.ID,
		"project_id":        internalTicket.ProjectID,
		"number":            internalTicket.Number,
		"title":             internalTicket.Title,
		"priority":          internalTicket.Priority,
		"visibility":        internalTicket.Visibility,
		"assignee_identity": internalTicket.AssigneeIdentity,
		"now_ns":            internalTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, internalTicket); err != nil {
		t.Fatalf("model create permission-denied view recovery ticket: %v", err)
	}
	updates := readSubscriptionUpdates(t, h.callers["alice-audit-view-denied"].client)
	assertNoSubscriptionQuery(t, updates, deniedAuditQuery, "permission-denied declared view subscription")
	alphaInsert := requireTicketUpdateFromUpdates(t, h, updates, alphaBoardQuery, []uint64{182}, []uint64{})
	assertEqual(t, "alpha board insert after permission-denied view recovery", alphaInsert, []model.Ticket{h.model.Tickets[182]})
}

func requireTicketUpdateFromUpdates(t *testing.T, h *workflowHarness, updates []protocol.SubscriptionUpdate, queryID uint32, wantInserts, wantDeletes []uint64) []model.Ticket {
	t.Helper()
	for _, update := range updates {
		if update.QueryID != queryID || update.TableName != "tickets" {
			continue
		}
		inserts := decodeTicketPayload(t, h, update.Inserts)
		deletes := decodeTicketPayload(t, h, update.Deletes)
		assertEqual(t, "ticket update inserts", model.TicketIDs(inserts), wantInserts)
		assertEqual(t, "ticket update deletes", model.TicketIDs(deletes), wantDeletes)
		return inserts
	}
	t.Fatalf("missing ticket subscription update for query %d in %#v", queryID, updates)
	return nil
}

func assertNoSubscriptionQuery(t *testing.T, updates []protocol.SubscriptionUpdate, queryID uint32, label string) {
	t.Helper()
	if containsSubscriptionQuery(updates, queryID) {
		t.Fatalf("%s query %d unexpectedly received update: %#v", label, queryID, updates)
	}
}
