package workflows

import (
	"context"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter"
)

func TestSmokeWorkflow(t *testing.T) {
	rt, err := shunter.Build(app.NewModule(), shunter.Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("Start returned error: %v", err)
	}
	if !rt.Ready() {
		t.Fatal("runtime is not ready after Start")
	}
	if err := rt.Close(); err != nil {
		t.Fatalf("Close returned error: %v", err)
	}
}
