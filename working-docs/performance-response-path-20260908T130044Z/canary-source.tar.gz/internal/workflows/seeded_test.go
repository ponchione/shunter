package workflows

import (
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

const seededWorkflowOperations = 24

type seededRunner struct {
	t                *testing.T
	h                *workflowHarness
	rng              *rand.Rand
	trace            Trace
	lastOp           TraceOperation
	nextProjectID    uint64
	nextTicketID     uint64
	nextTicketNumber uint64
	nextCommentID    uint64
	nextReminderID   uint64
	nextScheduleID   uint64
}

func TestSeededWorkflow(t *testing.T) {
	for _, seed := range loadSeedList(t) {
		seed := seed
		t.Run(fmt.Sprintf("seed_%d", seed), func(t *testing.T) {
			r := newSeededRunner(t, seed)
			t.Cleanup(func() {
				if !t.Failed() {
					return
				}
				if r.trace.Failure == nil {
					r.trace.MarkFailure(r.lastOp, fmt.Errorf("seeded workflow failed"))
				}
				path := filepath.Join("..", "..", "artifacts", "seeded", fmt.Sprintf("seed-%d-failure.json", seed))
				if err := r.trace.WriteFile(path); err != nil {
					t.Logf("write failure trace: %v", err)
					return
				}
				t.Logf("wrote failure trace: %s", path)
			})
			r.run()
		})
	}
}

func newSeededRunner(t *testing.T, seed int64) *seededRunner {
	t.Helper()
	h := newWorkflowHarness(t)
	return &seededRunner{
		t:                t,
		h:                h,
		rng:              rand.New(rand.NewSource(seed)),
		trace:            NewTrace(seed, h.dataDir),
		nextProjectID:    10,
		nextTicketID:     1000,
		nextTicketNumber: 1000,
		nextCommentID:    2000,
		nextReminderID:   3000,
		nextScheduleID:   1,
	}
}

func (r *seededRunner) run() {
	for i := 0; i < seededWorkflowOperations; i++ {
		switch r.rng.Intn(13) {
		case 0, 1:
			r.createTicket(i)
		case 2:
			r.assignTicket(i)
		case 3:
			r.changeTicketStatus(i)
		case 4:
			r.addComment(i)
		case 5:
			r.toggleTicketStatus(i)
		case 6:
			r.subscriptionSnapshotProbe(i)
		case 7:
			r.restart(i)
		case 8:
			r.failedReducerProbe(i)
		case 9:
			r.createProject(i)
		case 10:
			r.addProjectMember(i)
		case 11:
			r.scheduleReminder(i)
		default:
			r.declaredReadProbe(i)
		}
		r.assertCoreState(i)
	}
}

func (r *seededRunner) createProject(index int) {
	caller := r.pick([]string{"admin", "alice"})
	projectID := r.nextProjectID
	r.nextProjectID++
	args := model.CreateProjectArgs{
		ID:         projectID,
		Slug:       fmt.Sprintf("seeded-%d", projectID),
		Name:       fmt.Sprintf("Seeded Project %d", projectID),
		Visibility: r.pick([]string{"public", "internal"}),
		NowNS:      r.now(index),
	}

	op := TraceOperation{
		Index:    index,
		Caller:   caller,
		Action:   "call_reducer",
		Reducer:  app.ReducerCreateProject,
		Expected: fmt.Sprintf("project_id=%d committed", args.ID),
	}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerCreateProject, map[string]any{
		"id":         args.ID,
		"slug":       args.Slug,
		"name":       args.Name,
		"visibility": args.Visibility,
		"now_ns":     args.NowNS,
	})
	if err := r.h.model.CreateProject(r.identity(caller), args); err != nil {
		r.fail(op, err, "model create_project")
	}
}

func (r *seededRunner) addProjectMember(index int) {
	caller := r.pick([]string{"admin", "alice"})
	user := r.pick([]string{"alice", "bob", "carol", "auditor", "outsider"})
	args := model.AddProjectMemberArgs{
		ID:           nextMapID(r.h.model.Members),
		ProjectID:    r.pickProjectID(),
		UserIdentity: r.identity(user),
		Role:         r.pick([]string{"member", "viewer", "oncall"}),
		NowNS:        r.now(index),
	}

	op := TraceOperation{
		Index:    index,
		Caller:   caller,
		Action:   "call_reducer",
		Reducer:  app.ReducerAddProjectMember,
		Expected: fmt.Sprintf("member_id=%d project_id=%d user=%s", args.ID, args.ProjectID, user),
	}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerAddProjectMember, map[string]any{
		"id":            args.ID,
		"project_id":    args.ProjectID,
		"user_identity": args.UserIdentity,
		"role":          args.Role,
		"now_ns":        args.NowNS,
	})
	if err := r.h.model.AddProjectMember(r.identity(caller), args); err != nil {
		r.fail(op, err, "model add_project_member")
	}
}

func (r *seededRunner) createTicket(index int) {
	caller := r.pick([]string{"alice", "bob"})
	assignee := r.pick([]string{"", "alice", "bob", "carol"})
	visibility := r.pick([]string{"public", "internal"})
	priority := r.pick([]string{"low", "normal", "high"})
	args := model.CreateTicketArgs{
		ID:               r.nextTicketID,
		ProjectID:        r.pickProjectID(),
		Number:           r.nextTicketNumber,
		Title:            fmt.Sprintf("Seeded ticket %d", r.nextTicketID),
		Priority:         priority,
		Visibility:       visibility,
		AssigneeIdentity: r.identity(assignee),
		NowNS:            r.now(index),
	}
	r.nextTicketID++
	r.nextTicketNumber++

	op := TraceOperation{
		Index:    index,
		Caller:   caller,
		Action:   "call_reducer",
		Reducer:  app.ReducerCreateTicket,
		Expected: fmt.Sprintf("ticket_id=%d committed", args.ID),
	}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerCreateTicket, map[string]any{
		"id":                args.ID,
		"project_id":        args.ProjectID,
		"number":            args.Number,
		"title":             args.Title,
		"priority":          args.Priority,
		"visibility":        args.Visibility,
		"assignee_identity": args.AssigneeIdentity,
		"now_ns":            args.NowNS,
	})
	if err := r.h.model.CreateTicket(r.identity(caller), args); err != nil {
		r.fail(op, err, "model create_ticket")
	}
}

func (r *seededRunner) assignTicket(index int) {
	ticketID := r.pickTicketID()
	caller := r.pick([]string{"alice", "bob"})
	assignee := r.pick([]string{"alice", "bob", "carol"})
	args := model.AssignTicketArgs{TicketID: ticketID, AssigneeIdentity: r.identity(assignee), NowNS: r.now(index)}

	op := TraceOperation{Index: index, Caller: caller, Action: "call_reducer", Reducer: app.ReducerAssignTicket, Expected: fmt.Sprintf("ticket_id=%d assigned_to=%s", ticketID, assignee)}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerAssignTicket, map[string]any{
		"ticket_id":         args.TicketID,
		"assignee_identity": args.AssigneeIdentity,
		"now_ns":            args.NowNS,
	})
	if err := r.h.model.AssignTicket(r.identity(caller), args); err != nil {
		r.fail(op, err, "model assign_ticket")
	}
}

func (r *seededRunner) changeTicketStatus(index int) {
	ticketID := r.pickTicketID()
	caller := r.pick([]string{"alice", "bob"})
	status := r.pick([]string{"open", "in_progress", "blocked", "closed"})
	args := model.ChangeTicketStatusArgs{TicketID: ticketID, Status: status, NowNS: r.now(index)}

	op := TraceOperation{Index: index, Caller: caller, Action: "call_reducer", Reducer: app.ReducerChangeTicketStatus, Expected: fmt.Sprintf("ticket_id=%d status=%s", ticketID, status)}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": args.TicketID,
		"status":    args.Status,
		"now_ns":    args.NowNS,
	})
	if err := r.h.model.ChangeTicketStatus(r.identity(caller), args); err != nil {
		r.fail(op, err, "model change_ticket_status")
	}
}

func (r *seededRunner) addComment(index int) {
	ticketID := r.pickTicketID()
	caller := r.pick([]string{"alice", "bob", "carol"})
	args := model.AddCommentArgs{
		ID:         r.nextCommentID,
		TicketID:   ticketID,
		Visibility: r.pick([]string{"public", "internal"}),
		Body:       fmt.Sprintf("Seeded comment %d", r.nextCommentID),
		NowNS:      r.now(index),
	}
	r.nextCommentID++

	op := TraceOperation{Index: index, Caller: caller, Action: "call_reducer", Reducer: app.ReducerAddComment, Expected: fmt.Sprintf("comment_id=%d ticket_id=%d", args.ID, ticketID)}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerAddComment, map[string]any{
		"id":         args.ID,
		"ticket_id":  args.TicketID,
		"visibility": args.Visibility,
		"body":       args.Body,
		"now_ns":     args.NowNS,
	})
	if err := r.h.model.AddComment(r.identity(caller), args); err != nil {
		r.fail(op, err, "model add_comment")
	}
}

func (r *seededRunner) toggleTicketStatus(index int) {
	ticketID := r.pickTicketID()
	caller := r.pick([]string{"alice", "bob"})
	if r.rng.Intn(2) == 0 {
		op := TraceOperation{Index: index, Caller: caller, Action: "call_reducer", Reducer: app.ReducerCloseTicket, Expected: fmt.Sprintf("ticket_id=%d closed", ticketID)}
		r.record(op)
		nowNS := r.now(index)
		r.h.callReducer(r.t, caller, app.ReducerCloseTicket, map[string]any{"ticket_id": ticketID, "now_ns": nowNS})
		if err := r.h.model.CloseTicket(r.identity(caller), ticketID, nowNS); err != nil {
			r.fail(op, err, "model close_ticket")
		}
		return
	}

	op := TraceOperation{Index: index, Caller: caller, Action: "call_reducer", Reducer: app.ReducerReopenTicket, Expected: fmt.Sprintf("ticket_id=%d open", ticketID)}
	r.record(op)
	nowNS := r.now(index)
	r.h.callReducer(r.t, caller, app.ReducerReopenTicket, map[string]any{"ticket_id": ticketID, "now_ns": nowNS})
	if err := r.h.model.ReopenTicket(r.identity(caller), ticketID, nowNS); err != nil {
		r.fail(op, err, "model reopen_ticket")
	}
}

func (r *seededRunner) scheduleReminder(index int) {
	ticketID := r.pickTicketID()
	recipient := r.pick([]string{"alice", "bob", "carol"})
	key := fmt.Sprintf("%s-seeded-reminder-%d", recipient, index)
	r.addProbeCaller(key, recipient)
	defer r.h.closeCaller(key)

	requestID, queryID := r.nextRequestPair()
	initialOp := TraceOperation{Index: index, Caller: recipient, Action: "subscribe_declared_view", Subscription: app.ViewMyNotifications, Expected: "initial notifications match model before reminder"}
	r.record(initialOp)
	initial := requireNotificationSubscribeInitial(r.t, r.h, key, requestID, queryID)
	r.assertEqual(initialOp, "notification snapshot before reminder", initial, r.h.model.VisibleNotifications(r.identity(recipient)))

	caller := r.pick([]string{"alice", "bob"})
	args := model.ScheduleTicketReminderArgs{
		ID:                r.nextReminderID,
		TicketID:          ticketID,
		RecipientIdentity: r.identity(recipient),
		ScheduleID:        r.nextScheduleID,
		DelayMS:           20,
		NowNS:             r.now(index),
	}
	r.nextReminderID++
	r.nextScheduleID++

	op := TraceOperation{
		Index:    index,
		Caller:   caller,
		Action:   "call_reducer",
		Reducer:  app.ReducerScheduleTicketReminder,
		Expected: fmt.Sprintf("reminder_id=%d ticket_id=%d recipient=%s fires", args.ID, ticketID, recipient),
	}
	r.record(op)
	r.h.callReducer(r.t, caller, app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 args.ID,
		"ticket_id":          args.TicketID,
		"recipient_identity": args.RecipientIdentity,
		"delay_ms":           args.DelayMS,
		"now_ns":             args.NowNS,
	})
	if err := r.h.model.ScheduleTicketReminder(r.identity(caller), args); err != nil {
		r.fail(op, err, "model schedule_ticket_reminder")
	}
	wantNotificationID := nextMapID(r.h.model.Notifications)
	if err := r.h.model.FireTicketReminder(args.ID); err != nil {
		r.fail(op, err, "model fire_ticket_reminder")
	}
	got := requireNotificationDeltaIDs(r.t, r.h, key, queryID, []uint64{wantNotificationID}, []uint64{})
	r.assertEqual(op, "reminder notification delta", got, []model.Notification{r.h.model.Notifications[wantNotificationID]})
}

func (r *seededRunner) subscriptionSnapshotProbe(index int) {
	subject := r.pick([]string{"alice", "bob", "carol", "outsider"})
	key := fmt.Sprintf("%s-seeded-sub-%d", subject, index)
	r.addProbeCaller(key, subject)
	defer r.h.closeCaller(key)

	requestID, queryID := r.nextRequestPair()
	op := TraceOperation{Index: index, Caller: subject, Action: "subscribe_declared_view", Subscription: app.ViewLiveAlphaBoard, Expected: "initial rows match model"}
	r.record(op)
	got := requireTicketSubscribeInitial(r.t, r.h, key, app.ViewLiveAlphaBoard, requestID, queryID)
	r.assertEqual(op, "subscription alpha_board snapshot", got, r.h.model.AlphaBoard(r.identity(subject)))
}

func (r *seededRunner) declaredReadProbe(index int) {
	subject := r.pick([]string{"alice", "bob", "carol", "outsider"})
	identity := r.identity(subject)
	op := TraceOperation{Index: index, Caller: subject, Action: "declared_query", Query: app.QueryMyTickets, Expected: "my_tickets matches model"}
	r.record(op)
	got := requireDeclaredTickets(r.t, r.h, subject, app.QueryMyTickets, fmt.Sprintf("seed-%d-%s-my-tickets", index, subject))
	r.assertEqual(op, "declared my_tickets for "+subject, got, r.h.model.MyTickets(identity))
}

func (r *seededRunner) restart(index int) {
	op := TraceOperation{Index: index, Action: "restart_runtime", Expected: "restart succeeds"}
	r.record(op)
	r.h.restart(r.t)
}

func (r *seededRunner) failedReducerProbe(index int) {
	ticketID := r.pickTicketID()
	caller := r.pick([]string{"alice", "bob"})
	op := TraceOperation{Index: index, Caller: caller, Action: "call_reducer", Reducer: app.ReducerChangeTicketStatus, Expected: "invalid status rejected without mutation"}
	r.record(op)
	r.h.callReducerFailed(r.t, caller, app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": ticketID,
		"status":    "invalid_seeded_status",
		"now_ns":    r.now(index),
	}, "invalid")
}

func (r *seededRunner) assertCoreState(index int) {
	projectOp := TraceOperation{Index: index, Caller: "alice", Action: "one_off_query", Query: "SELECT * FROM projects", Expected: "projects match model"}
	gotProjects := requireRawProjects(r.t, r.h, "alice", "SELECT * FROM projects", fmt.Sprintf("seed-%d-projects", index))
	r.assertEqual(projectOp, "projects", gotProjects, r.h.model.AllProjects())

	for _, subject := range []string{"alice", "bob", "carol", "outsider"} {
		identity := r.identity(subject)
		ticketOp := TraceOperation{Index: index, Caller: subject, Action: "one_off_query", Query: "SELECT * FROM tickets", Expected: "visible tickets match model"}
		gotTickets := requireRawTickets(r.t, r.h, subject, "SELECT * FROM tickets", fmt.Sprintf("seed-%d-%s-tickets", index, subject))
		r.assertEqual(ticketOp, "visible tickets for "+subject, gotTickets, r.h.model.VisibleTickets(identity))

		commentOp := TraceOperation{Index: index, Caller: subject, Action: "one_off_query", Query: "SELECT * FROM comments", Expected: "visible comments match model"}
		gotComments := requireRawComments(r.t, r.h, subject, "SELECT * FROM comments", fmt.Sprintf("seed-%d-%s-comments", index, subject))
		r.assertEqual(commentOp, "visible comments for "+subject, gotComments, r.h.model.VisibleComments(identity))
	}

	auditOp := TraceOperation{Index: index, Caller: "auditor", Action: "declared_query", Query: app.QueryAuditFeed, Expected: "audit ids match model"}
	gotAudit := model.AuditIDs(requireDeclaredAudit(r.t, r.h, "auditor", app.QueryAuditFeed, fmt.Sprintf("seed-%d-audit", index)))
	r.assertEqual(auditOp, "audit ids", gotAudit, model.AuditIDs(r.h.model.AuditFeed(true)))
}

func (r *seededRunner) record(op TraceOperation) {
	r.lastOp = op
	r.trace.AddOperation(op)
}

func (r *seededRunner) fail(op TraceOperation, err error, observed string) {
	r.trace.MarkFailure(TraceOperation{
		Index:        op.Index,
		Caller:       op.Caller,
		Action:       op.Action,
		Reducer:      op.Reducer,
		Query:        op.Query,
		Subscription: op.Subscription,
		Expected:     op.Expected,
		Observed:     observed,
	}, err)
	r.t.Fatalf("seed=%d op=%d action=%s reducer=%s query=%s subscription=%s: %v", r.trace.Seed, op.Index, op.Action, op.Reducer, op.Query, op.Subscription, err)
}

func (r *seededRunner) assertEqual(op TraceOperation, label string, got, want any) {
	if reflect.DeepEqual(got, want) {
		return
	}
	r.trace.MarkFailure(TraceOperation{
		Index:        op.Index,
		Caller:       op.Caller,
		Action:       op.Action,
		Reducer:      op.Reducer,
		Query:        op.Query,
		Subscription: op.Subscription,
		Expected:     fmt.Sprintf("%#v", want),
		Observed:     fmt.Sprintf("%#v", got),
	}, fmt.Errorf("%s mismatch", label))
	r.t.Fatalf("seed=%d op=%d %s got %#v, want %#v", r.trace.Seed, op.Index, label, got, want)
}

func (r *seededRunner) pickTicketID() uint64 {
	ids := make([]uint64, 0, len(r.h.model.Tickets))
	for id := range r.h.model.Tickets {
		ids = append(ids, id)
	}
	if len(ids) == 0 {
		return 100
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	return ids[r.rng.Intn(len(ids))]
}

func (r *seededRunner) pickProjectID() uint64 {
	ids := make([]uint64, 0, len(r.h.model.Projects))
	for id := range r.h.model.Projects {
		ids = append(ids, id)
	}
	if len(ids) == 0 {
		return 1
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	return ids[r.rng.Intn(len(ids))]
}

func (r *seededRunner) pick(values []string) string {
	return values[r.rng.Intn(len(values))]
}

func nextMapID[T any](items map[uint64]T) uint64 {
	var max uint64
	for id := range items {
		if id > max {
			max = id
		}
	}
	return max + 1
}

func (r *seededRunner) now(index int) int64 {
	return int64(10_000 + index*100 + r.rng.Intn(50))
}

func (r *seededRunner) identity(subject string) string {
	if subject == "" {
		return ""
	}
	return r.h.callers[subject].identity.Hex()
}

func (r *seededRunner) nextRequestPair() (uint32, uint32) {
	requestID := r.h.nextReq
	queryID := requestID + 1
	r.h.nextReq += 2
	return requestID, queryID
}

func (r *seededRunner) addProbeCaller(key, subject string) {
	switch subject {
	case "admin":
		r.h.addCallerAs(r.t, key, subject, app.PermAdminWrite, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite, app.PermAuditRead)
	case "alice":
		r.h.addCallerAs(r.t, key, subject, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	case "bob":
		r.h.addCallerAs(r.t, key, subject, app.PermTicketWrite, app.PermCommentWrite)
	case "carol":
		r.h.addCallerAs(r.t, key, subject, app.PermCommentWrite)
	default:
		r.h.addCallerAs(r.t, key, subject)
	}
}

func loadSeedList(t *testing.T) []int64 {
	t.Helper()
	if raw := strings.TrimSpace(os.Getenv("OPSBOARD_CANARY_SEED")); raw != "" {
		seed, err := strconv.ParseInt(raw, 10, 64)
		if err != nil {
			t.Fatalf("OPSBOARD_CANARY_SEED=%q is invalid: %v", raw, err)
		}
		return []int64{seed}
	}

	data, err := os.ReadFile(filepath.Join("testdata", "seeds.txt"))
	if err != nil {
		t.Fatalf("read seed list: %v", err)
	}
	var seeds []int64
	for lineNo, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		seed, err := strconv.ParseInt(line, 10, 64)
		if err != nil {
			t.Fatalf("testdata/seeds.txt:%d invalid seed %q: %v", lineNo+1, line, err)
		}
		seeds = append(seeds, seed)
	}
	if len(seeds) == 0 {
		t.Fatal("testdata/seeds.txt contains no seeds")
	}
	return seeds
}
