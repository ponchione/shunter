package workflows

import (
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestSameConnectionDuplicateQueryHashWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-hash", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               240,
		ProjectID:        1,
		Number:           140,
		Title:            "Duplicate hash initial public ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16100,
	})

	const (
		firstQueryID  uint32 = 2201
		secondQueryID uint32 = 2203
	)
	const publicTicketsSQL = "SELECT * FROM tickets WHERE visibility = 'public'"
	publicTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" })
	}

	assertEqual(t, "bob duplicate hash first initial",
		requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash", publicTicketsSQL, 2200, firstQueryID),
		publicTickets())
	if got := requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash", publicTicketsSQL, 2202, secondQueryID); len(got) != 0 {
		t.Fatalf("bob duplicate hash second initial = %#v, want elided empty snapshot", got)
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               241,
		ProjectID:        1,
		Number:           141,
		Title:            "Duplicate hash live public ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16200,
	})
	updates := readSubscriptionUpdates(t, h.callers["bob-duplicate-hash"].client)
	firstInsert := requireTicketUpdateFromUpdates(t, h, updates, firstQueryID, []uint64{241}, []uint64{})
	assertEqual(t, "bob duplicate hash first live insert row", firstInsert, []model.Ticket{h.model.Tickets[241]})
	secondInsert := requireTicketUpdateFromUpdates(t, h, updates, secondQueryID, []uint64{241}, []uint64{})
	assertEqual(t, "bob duplicate hash second live insert row", secondInsert, []model.Ticket{h.model.Tickets[241]})

	if err := h.callers["bob-duplicate-hash"].client.UnsubscribeSingle(2204, firstQueryID); err != nil {
		t.Fatalf("bob duplicate hash first UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash first unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash", 2204, firstQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               242,
		ProjectID:        1,
		Number:           142,
		Title:            "Duplicate hash second remains live ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16300,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash"].client)
	assertNoSubscriptionQuery(t, updates, firstQueryID, "unsubscribed duplicate hash first query")
	secondOnlyInsert := requireTicketUpdateFromUpdates(t, h, updates, secondQueryID, []uint64{242}, []uint64{})
	assertEqual(t, "bob duplicate hash second stayed live insert row", secondOnlyInsert, []model.Ticket{h.model.Tickets[242]})

	if err := h.callers["bob-duplicate-hash"].client.UnsubscribeSingle(2205, secondQueryID); err != nil {
		t.Fatalf("bob duplicate hash second UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash second unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash", 2205, secondQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               243,
		ProjectID:        1,
		Number:           143,
		Title:            "Duplicate hash after all unsubscribed ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16400,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash"].client, 100*time.Millisecond, "duplicate hash after second unsubscribe")
}

func TestCrossConnectionDuplicateQueryHashWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-hash-a", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "bob-duplicate-hash-b", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               244,
		ProjectID:        1,
		Number:           144,
		Title:            "Cross connection duplicate hash initial ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16500,
	})

	const (
		connAQueryID uint32 = 2211
		connBQueryID uint32 = 2213
	)
	const publicTicketsSQL = "SELECT * FROM tickets WHERE visibility = 'public'"
	publicTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" })
	}

	assertEqual(t, "bob duplicate hash conn a initial",
		requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-a", publicTicketsSQL, 2210, connAQueryID),
		publicTickets())
	assertEqual(t, "bob duplicate hash conn b initial",
		requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-b", publicTicketsSQL, 2212, connBQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               245,
		ProjectID:        1,
		Number:           145,
		Title:            "Cross connection duplicate hash live ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16600,
	})
	connAInsert := requireTicketDeltaIDs(t, h, "bob-duplicate-hash-a", connAQueryID, []uint64{245}, []uint64{})
	assertEqual(t, "bob duplicate hash conn a live insert row", connAInsert, []model.Ticket{h.model.Tickets[245]})
	connBInsert := requireTicketDeltaIDs(t, h, "bob-duplicate-hash-b", connBQueryID, []uint64{245}, []uint64{})
	assertEqual(t, "bob duplicate hash conn b live insert row", connBInsert, []model.Ticket{h.model.Tickets[245]})

	if err := h.callers["bob-duplicate-hash-a"].client.UnsubscribeSingle(2214, connAQueryID); err != nil {
		t.Fatalf("bob duplicate hash conn a UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash conn a unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-a", 2214, connAQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               246,
		ProjectID:        1,
		Number:           146,
		Title:            "Cross connection duplicate hash conn b remains live",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16700,
	})
	connBOnlyInsert := requireTicketDeltaIDs(t, h, "bob-duplicate-hash-b", connBQueryID, []uint64{246}, []uint64{})
	assertEqual(t, "bob duplicate hash conn b stayed live insert row", connBOnlyInsert, []model.Ticket{h.model.Tickets[246]})
	requireNoMessage(t, h.callers["bob-duplicate-hash-a"].client, 100*time.Millisecond, "duplicate hash conn a after unsubscribe")

	if err := h.callers["bob-duplicate-hash-b"].client.UnsubscribeSingle(2215, connBQueryID); err != nil {
		t.Fatalf("bob duplicate hash conn b UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash conn b unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-b", 2215, connBQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               247,
		ProjectID:        1,
		Number:           147,
		Title:            "Cross connection duplicate hash after cleanup",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16800,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash-a"].client, 100*time.Millisecond, "duplicate hash conn a after all unsubscribe")
	requireNoMessage(t, h.callers["bob-duplicate-hash-b"].client, 100*time.Millisecond, "duplicate hash conn b after all unsubscribe")
}

func TestSameConnectionDuplicateQueryHashSingleAndMultiWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-hash-mixed", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               248,
		ProjectID:        1,
		Number:           148,
		Title:            "Mixed duplicate hash initial ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            16900,
	})
	addCommentForWorkflow(t, h, "bob", model.AddCommentArgs{
		ID:         540,
		TicketID:   100,
		Visibility: "public",
		Body:       "Mixed duplicate hash initial comment",
		NowNS:      17000,
	})

	const (
		singleQueryID uint32 = 2221
		multiQueryID  uint32 = 2223
	)
	const (
		publicTicketsSQL  = "SELECT * FROM tickets WHERE visibility = 'public'"
		publicCommentsSQL = "SELECT * FROM comments WHERE visibility = 'public'"
	)
	publicTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" })
	}
	publicComments := func() []model.Comment {
		return filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.Visibility == "public" })
	}

	assertEqual(t, "bob mixed duplicate hash single initial",
		requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-mixed", publicTicketsSQL, 2220, singleQueryID),
		publicTickets())
	if err := h.callers["bob-duplicate-hash-mixed"].client.SubscribeMulti([]string{publicTicketsSQL, publicCommentsSQL}, 2222, multiQueryID); err != nil {
		t.Fatalf("bob mixed duplicate hash SubscribeMulti: %v", err)
	}
	updates := requireSubscribeMultiInitial(t, h, "bob-duplicate-hash-mixed", 2222, multiQueryID)
	if len(updates) != 1 {
		t.Fatalf("bob mixed duplicate hash multi initial = %#v, want only comments snapshot", updates)
	}
	if update := updates[0]; update.QueryID != multiQueryID || update.TableName != "comments" {
		t.Fatalf("bob mixed duplicate hash multi initial update = %#v, want query %d comments", update, multiQueryID)
	} else {
		assertEqual(t, "bob mixed duplicate hash multi comment initial", decodeCommentPayload(t, h, update.Inserts), publicComments())
		if got := decodeCommentPayload(t, h, update.Deletes); len(got) != 0 {
			t.Fatalf("bob mixed duplicate hash multi comment initial deletes = %#v, want none", got)
		}
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               249,
		ProjectID:        1,
		Number:           149,
		Title:            "Mixed duplicate hash both variants ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            17100,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-mixed"].client)
	singleInsert := requireTicketUpdateFromUpdates(t, h, updates, singleQueryID, []uint64{249}, []uint64{})
	assertEqual(t, "bob mixed duplicate hash single ticket insert row", singleInsert, []model.Ticket{h.model.Tickets[249]})
	multiTicketInsert := requireTicketUpdateFromUpdates(t, h, updates, multiQueryID, []uint64{249}, []uint64{})
	assertEqual(t, "bob mixed duplicate hash multi ticket insert row", multiTicketInsert, []model.Ticket{h.model.Tickets[249]})
	assertNoTableUpdate(t, updates, multiQueryID, "comments", "mixed duplicate hash ticket transaction")

	addCommentForWorkflow(t, h, "alice", model.AddCommentArgs{
		ID:         541,
		TicketID:   100,
		Visibility: "public",
		Body:       "Mixed duplicate hash multi comment",
		NowNS:      17200,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-mixed"].client)
	assertNoSubscriptionQuery(t, updates, singleQueryID, "mixed duplicate hash single ticket query for comment transaction")
	multiCommentInsert := requireCommentUpdateFromUpdates(t, h, updates, multiQueryID, []uint64{541}, []uint64{})
	assertEqual(t, "bob mixed duplicate hash multi comment insert row", multiCommentInsert, []model.Comment{h.model.Comments[541]})

	if err := h.callers["bob-duplicate-hash-mixed"].client.UnsubscribeSingle(2224, singleQueryID); err != nil {
		t.Fatalf("bob mixed duplicate hash UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob mixed duplicate hash single unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-mixed", 2224, singleQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               250,
		ProjectID:        1,
		Number:           150,
		Title:            "Mixed duplicate hash multi stays live ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            17300,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-mixed"].client)
	assertNoSubscriptionQuery(t, updates, singleQueryID, "mixed duplicate hash single after unsubscribe")
	multiOnlyTicketInsert := requireTicketUpdateFromUpdates(t, h, updates, multiQueryID, []uint64{250}, []uint64{})
	assertEqual(t, "bob mixed duplicate hash multi stayed live ticket row", multiOnlyTicketInsert, []model.Ticket{h.model.Tickets[250]})

	addCommentForWorkflow(t, h, "alice", model.AddCommentArgs{
		ID:         542,
		TicketID:   100,
		Visibility: "public",
		Body:       "Mixed duplicate hash multi stayed live comment",
		NowNS:      17400,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-mixed"].client)
	assertNoSubscriptionQuery(t, updates, singleQueryID, "mixed duplicate hash single after unsubscribe for comment transaction")
	multiOnlyCommentInsert := requireCommentUpdateFromUpdates(t, h, updates, multiQueryID, []uint64{542}, []uint64{})
	assertEqual(t, "bob mixed duplicate hash multi stayed live comment row", multiOnlyCommentInsert, []model.Comment{h.model.Comments[542]})

	if err := h.callers["bob-duplicate-hash-mixed"].client.UnsubscribeMulti(2225, multiQueryID); err != nil {
		t.Fatalf("bob mixed duplicate hash UnsubscribeMulti: %v", err)
	}
	assertMultiFilteredDeletes(t, h, requireUnsubscribeMultiApplied(t, h, "bob-duplicate-hash-mixed", 2225, multiQueryID), multiQueryID,
		publicTickets(), publicComments())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               251,
		ProjectID:        1,
		Number:           151,
		Title:            "Mixed duplicate hash after all unsubscribed ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            17500,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash-mixed"].client, 100*time.Millisecond, "mixed duplicate hash after all unsubscribe ticket")

	addCommentForWorkflow(t, h, "alice", model.AddCommentArgs{
		ID:         543,
		TicketID:   100,
		Visibility: "public",
		Body:       "Mixed duplicate hash after all unsubscribed comment",
		NowNS:      17600,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash-mixed"].client, 100*time.Millisecond, "mixed duplicate hash after all unsubscribe comment")
}

func TestSubscribeMultiDuplicateQueryHashWithinRequestWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-hash-in-multi", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               252,
		ProjectID:        1,
		Number:           152,
		Title:            "Duplicate hash in multi initial ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            17700,
	})

	const queryID uint32 = 2231
	const publicTicketsSQL = "SELECT * FROM tickets WHERE visibility = 'public'"
	publicTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" })
	}

	if err := h.callers["bob-duplicate-hash-in-multi"].client.SubscribeMulti([]string{publicTicketsSQL, publicTicketsSQL}, 2230, queryID); err != nil {
		t.Fatalf("bob duplicate hash in multi SubscribeMulti: %v", err)
	}
	updates := requireSubscribeMultiInitial(t, h, "bob-duplicate-hash-in-multi", 2230, queryID)
	if len(updates) != 1 {
		t.Fatalf("bob duplicate hash in multi initial = %#v, want one deduped tickets snapshot", updates)
	}
	if update := updates[0]; update.QueryID != queryID || update.TableName != "tickets" {
		t.Fatalf("bob duplicate hash in multi initial update = %#v, want query %d tickets", update, queryID)
	} else {
		assertEqual(t, "bob duplicate hash in multi ticket initial", decodeTicketPayload(t, h, update.Inserts), publicTickets())
		if got := decodeTicketPayload(t, h, update.Deletes); len(got) != 0 {
			t.Fatalf("bob duplicate hash in multi initial deletes = %#v, want none", got)
		}
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               253,
		ProjectID:        1,
		Number:           153,
		Title:            "Duplicate hash in multi live ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            17800,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-in-multi"].client)
	if len(updates) != 1 {
		t.Fatalf("bob duplicate hash in multi live updates = %#v, want one deduped tickets update", updates)
	}
	ticketInsert := requireTicketUpdateFromUpdates(t, h, updates, queryID, []uint64{253}, []uint64{})
	assertEqual(t, "bob duplicate hash in multi live insert row", ticketInsert, []model.Ticket{h.model.Tickets[253]})

	if err := h.callers["bob-duplicate-hash-in-multi"].client.UnsubscribeMulti(2232, queryID); err != nil {
		t.Fatalf("bob duplicate hash in multi UnsubscribeMulti: %v", err)
	}
	updates = requireUnsubscribeMultiApplied(t, h, "bob-duplicate-hash-in-multi", 2232, queryID)
	if len(updates) != 1 {
		t.Fatalf("bob duplicate hash in multi unsubscribe updates = %#v, want one deduped tickets delete", updates)
	}
	if update := updates[0]; update.QueryID != queryID || update.TableName != "tickets" {
		t.Fatalf("bob duplicate hash in multi unsubscribe update = %#v, want query %d tickets", update, queryID)
	} else {
		assertEqual(t, "bob duplicate hash in multi ticket deletes", decodeTicketPayload(t, h, update.Deletes), publicTickets())
		if got := decodeTicketPayload(t, h, update.Inserts); len(got) != 0 {
			t.Fatalf("bob duplicate hash in multi unsubscribe inserts = %#v, want none", got)
		}
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               254,
		ProjectID:        1,
		Number:           154,
		Title:            "Duplicate hash in multi after unsubscribe ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            17900,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash-in-multi"].client, 100*time.Millisecond, "duplicate hash in multi after unsubscribe")
}

func TestSameConnectionDuplicateQueryHashMultiThenSingleWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-hash-multi-then-single", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               255,
		ProjectID:        1,
		Number:           155,
		Title:            "Multi then single duplicate hash initial ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18000,
	})
	addCommentForWorkflow(t, h, "bob", model.AddCommentArgs{
		ID:         544,
		TicketID:   100,
		Visibility: "public",
		Body:       "Multi then single duplicate hash initial comment",
		NowNS:      18100,
	})

	const (
		multiQueryID  uint32 = 2241
		singleQueryID uint32 = 2243
	)
	const (
		publicTicketsSQL  = "SELECT * FROM tickets WHERE visibility = 'public'"
		publicCommentsSQL = "SELECT * FROM comments WHERE visibility = 'public'"
	)
	publicTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" })
	}
	publicComments := func() []model.Comment {
		return filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.Visibility == "public" })
	}

	if err := h.callers["bob-duplicate-hash-multi-then-single"].client.SubscribeMulti([]string{publicTicketsSQL, publicCommentsSQL}, 2240, multiQueryID); err != nil {
		t.Fatalf("bob multi-then-single duplicate hash SubscribeMulti: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "bob-duplicate-hash-multi-then-single", 2240, multiQueryID), multiQueryID,
		publicTickets(), publicComments())
	if got := requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-multi-then-single", publicTicketsSQL, 2242, singleQueryID); len(got) != 0 {
		t.Fatalf("bob multi-then-single duplicate hash single initial = %#v, want elided empty snapshot", got)
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               256,
		ProjectID:        1,
		Number:           156,
		Title:            "Multi then single duplicate hash both ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18200,
	})
	updates := readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-multi-then-single"].client)
	multiTicketInsert := requireTicketUpdateFromUpdates(t, h, updates, multiQueryID, []uint64{256}, []uint64{})
	assertEqual(t, "bob multi-then-single duplicate hash multi ticket row", multiTicketInsert, []model.Ticket{h.model.Tickets[256]})
	singleTicketInsert := requireTicketUpdateFromUpdates(t, h, updates, singleQueryID, []uint64{256}, []uint64{})
	assertEqual(t, "bob multi-then-single duplicate hash single ticket row", singleTicketInsert, []model.Ticket{h.model.Tickets[256]})
	assertNoTableUpdate(t, updates, multiQueryID, "comments", "multi-then-single duplicate hash ticket transaction")

	addCommentForWorkflow(t, h, "alice", model.AddCommentArgs{
		ID:         545,
		TicketID:   100,
		Visibility: "public",
		Body:       "Multi then single duplicate hash multi comment",
		NowNS:      18300,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-multi-then-single"].client)
	assertNoSubscriptionQuery(t, updates, singleQueryID, "multi-then-single duplicate hash single ticket query for comment transaction")
	multiCommentInsert := requireCommentUpdateFromUpdates(t, h, updates, multiQueryID, []uint64{545}, []uint64{})
	assertEqual(t, "bob multi-then-single duplicate hash multi comment row", multiCommentInsert, []model.Comment{h.model.Comments[545]})

	if err := h.callers["bob-duplicate-hash-multi-then-single"].client.UnsubscribeMulti(2244, multiQueryID); err != nil {
		t.Fatalf("bob multi-then-single duplicate hash UnsubscribeMulti: %v", err)
	}
	assertMultiFilteredDeletes(t, h, requireUnsubscribeMultiApplied(t, h, "bob-duplicate-hash-multi-then-single", 2244, multiQueryID), multiQueryID,
		publicTickets(), publicComments())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               257,
		ProjectID:        1,
		Number:           157,
		Title:            "Multi then single duplicate hash single remains live",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18400,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-hash-multi-then-single"].client)
	assertNoSubscriptionQuery(t, updates, multiQueryID, "multi-then-single duplicate hash multi after unsubscribe")
	singleOnlyTicketInsert := requireTicketUpdateFromUpdates(t, h, updates, singleQueryID, []uint64{257}, []uint64{})
	assertEqual(t, "bob multi-then-single duplicate hash single stayed live row", singleOnlyTicketInsert, []model.Ticket{h.model.Tickets[257]})

	if err := h.callers["bob-duplicate-hash-multi-then-single"].client.UnsubscribeSingle(2245, singleQueryID); err != nil {
		t.Fatalf("bob multi-then-single duplicate hash UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob multi-then-single duplicate hash single unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-multi-then-single", 2245, singleQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               258,
		ProjectID:        1,
		Number:           158,
		Title:            "Multi then single duplicate hash after all unsubscribed",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18600,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash-multi-then-single"].client, 100*time.Millisecond, "multi-then-single duplicate hash after all unsubscribe")
}

func TestSameConnectionDuplicateQueryHashResubscribeAfterCleanupWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-hash-resubscribe", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               259,
		ProjectID:        1,
		Number:           159,
		Title:            "Duplicate hash resubscribe initial ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18700,
	})

	const (
		firstQueryID  uint32 = 2251
		secondQueryID uint32 = 2253
		freshQueryID  uint32 = 2257
	)
	const publicTicketsSQL = "SELECT * FROM tickets WHERE visibility = 'public'"
	publicTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" })
	}

	assertEqual(t, "bob duplicate hash resubscribe first initial",
		requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-resubscribe", publicTicketsSQL, 2250, firstQueryID),
		publicTickets())
	if got := requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-resubscribe", publicTicketsSQL, 2252, secondQueryID); len(got) != 0 {
		t.Fatalf("bob duplicate hash resubscribe second initial = %#v, want elided empty snapshot", got)
	}

	if err := h.callers["bob-duplicate-hash-resubscribe"].client.UnsubscribeSingle(2254, firstQueryID); err != nil {
		t.Fatalf("bob duplicate hash resubscribe first UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash resubscribe first unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-resubscribe", 2254, firstQueryID),
		publicTickets())

	if err := h.callers["bob-duplicate-hash-resubscribe"].client.UnsubscribeSingle(2255, secondQueryID); err != nil {
		t.Fatalf("bob duplicate hash resubscribe second UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash resubscribe second unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-resubscribe", 2255, secondQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               260,
		ProjectID:        1,
		Number:           160,
		Title:            "Duplicate hash resubscribe after cleanup snapshot ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18800,
	})

	assertEqual(t, "bob duplicate hash fresh initial after cleanup",
		requireRawTicketSubscribeInitial(t, h, "bob-duplicate-hash-resubscribe", publicTicketsSQL, 2256, freshQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               261,
		ProjectID:        1,
		Number:           161,
		Title:            "Duplicate hash resubscribe fresh live ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            18900,
	})
	freshInsert := requireTicketDeltaIDs(t, h, "bob-duplicate-hash-resubscribe", freshQueryID, []uint64{261}, []uint64{})
	assertEqual(t, "bob duplicate hash fresh live insert row", freshInsert, []model.Ticket{h.model.Tickets[261]})

	if err := h.callers["bob-duplicate-hash-resubscribe"].client.UnsubscribeSingle(2258, freshQueryID); err != nil {
		t.Fatalf("bob duplicate hash fresh UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate hash fresh unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-hash-resubscribe", 2258, freshQueryID),
		publicTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               262,
		ProjectID:        1,
		Number:           162,
		Title:            "Duplicate hash resubscribe after fresh unsubscribe ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19000,
	})
	requireNoMessage(t, h.callers["bob-duplicate-hash-resubscribe"].client, 100*time.Millisecond, "duplicate hash resubscribe after final unsubscribe")
}

func TestSameConnectionCanonicalDuplicateQueryHashWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-canonical-duplicate-hash", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               263,
		ProjectID:        1,
		Number:           163,
		Title:            "Canonical duplicate hash initial ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19100,
	})

	const (
		firstQueryID  uint32 = 2261
		secondQueryID uint32 = 2263
	)
	const (
		baseSQL      = "SELECT * FROM tickets WHERE status = 'open' AND priority = 'high'"
		reorderedSQL = "SELECT * FROM tickets WHERE priority = 'high' AND status = 'open'"
	)
	openHighTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), isOpenHighTicket)
	}

	assertEqual(t, "bob canonical duplicate hash first initial",
		requireRawTicketSubscribeInitial(t, h, "bob-canonical-duplicate-hash", baseSQL, 2260, firstQueryID),
		openHighTickets())
	if got := requireRawTicketSubscribeInitial(t, h, "bob-canonical-duplicate-hash", reorderedSQL, 2262, secondQueryID); len(got) != 0 {
		t.Fatalf("bob canonical duplicate hash second initial = %#v, want elided empty snapshot", got)
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               264,
		ProjectID:        1,
		Number:           164,
		Title:            "Canonical duplicate hash live ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19200,
	})
	updates := readSubscriptionUpdates(t, h.callers["bob-canonical-duplicate-hash"].client)
	firstInsert := requireTicketUpdateFromUpdates(t, h, updates, firstQueryID, []uint64{264}, []uint64{})
	assertEqual(t, "bob canonical duplicate hash first live row", firstInsert, []model.Ticket{h.model.Tickets[264]})
	secondInsert := requireTicketUpdateFromUpdates(t, h, updates, secondQueryID, []uint64{264}, []uint64{})
	assertEqual(t, "bob canonical duplicate hash second live row", secondInsert, []model.Ticket{h.model.Tickets[264]})

	if err := h.callers["bob-canonical-duplicate-hash"].client.UnsubscribeSingle(2264, firstQueryID); err != nil {
		t.Fatalf("bob canonical duplicate hash first UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob canonical duplicate hash first unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-canonical-duplicate-hash", 2264, firstQueryID),
		openHighTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               265,
		ProjectID:        1,
		Number:           165,
		Title:            "Canonical duplicate hash second remains live ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19300,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-canonical-duplicate-hash"].client)
	assertNoSubscriptionQuery(t, updates, firstQueryID, "canonical duplicate hash first after unsubscribe")
	secondOnlyInsert := requireTicketUpdateFromUpdates(t, h, updates, secondQueryID, []uint64{265}, []uint64{})
	assertEqual(t, "bob canonical duplicate hash second stayed live row", secondOnlyInsert, []model.Ticket{h.model.Tickets[265]})

	if err := h.callers["bob-canonical-duplicate-hash"].client.UnsubscribeSingle(2265, secondQueryID); err != nil {
		t.Fatalf("bob canonical duplicate hash second UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob canonical duplicate hash second unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-canonical-duplicate-hash", 2265, secondQueryID),
		openHighTickets())

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               266,
		ProjectID:        1,
		Number:           166,
		Title:            "Canonical duplicate hash after all unsubscribed ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19400,
	})
	requireNoMessage(t, h.callers["bob-canonical-duplicate-hash"].client, 100*time.Millisecond, "canonical duplicate hash after final unsubscribe")
}

func TestSubscribeMultiCanonicalDuplicateQueryHashWithinRequestWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-canonical-duplicate-hash-in-multi", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               267,
		ProjectID:        1,
		Number:           167,
		Title:            "Canonical duplicate hash in multi initial ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19500,
	})

	const queryID uint32 = 2271
	const (
		baseSQL      = "SELECT * FROM tickets WHERE status = 'open' AND priority = 'high'"
		reorderedSQL = "SELECT * FROM tickets WHERE priority = 'high' AND status = 'open'"
	)
	openHighTickets := func() []model.Ticket {
		return filterTickets(h.model.VisibleTickets(bob), isOpenHighTicket)
	}

	if err := h.callers["bob-canonical-duplicate-hash-in-multi"].client.SubscribeMulti([]string{baseSQL, reorderedSQL}, 2270, queryID); err != nil {
		t.Fatalf("bob canonical duplicate hash in multi SubscribeMulti: %v", err)
	}
	updates := requireSubscribeMultiInitial(t, h, "bob-canonical-duplicate-hash-in-multi", 2270, queryID)
	if len(updates) != 1 {
		t.Fatalf("bob canonical duplicate hash in multi initial = %#v, want one deduped tickets snapshot", updates)
	}
	if update := updates[0]; update.QueryID != queryID || update.TableName != "tickets" {
		t.Fatalf("bob canonical duplicate hash in multi initial update = %#v, want query %d tickets", update, queryID)
	} else {
		assertEqual(t, "bob canonical duplicate hash in multi ticket initial", decodeTicketPayload(t, h, update.Inserts), openHighTickets())
		if got := decodeTicketPayload(t, h, update.Deletes); len(got) != 0 {
			t.Fatalf("bob canonical duplicate hash in multi initial deletes = %#v, want none", got)
		}
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               268,
		ProjectID:        1,
		Number:           168,
		Title:            "Canonical duplicate hash in multi live ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19600,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-canonical-duplicate-hash-in-multi"].client)
	if len(updates) != 1 {
		t.Fatalf("bob canonical duplicate hash in multi live updates = %#v, want one deduped tickets update", updates)
	}
	ticketInsert := requireTicketUpdateFromUpdates(t, h, updates, queryID, []uint64{268}, []uint64{})
	assertEqual(t, "bob canonical duplicate hash in multi live row", ticketInsert, []model.Ticket{h.model.Tickets[268]})

	if err := h.callers["bob-canonical-duplicate-hash-in-multi"].client.UnsubscribeMulti(2272, queryID); err != nil {
		t.Fatalf("bob canonical duplicate hash in multi UnsubscribeMulti: %v", err)
	}
	updates = requireUnsubscribeMultiApplied(t, h, "bob-canonical-duplicate-hash-in-multi", 2272, queryID)
	if len(updates) != 1 {
		t.Fatalf("bob canonical duplicate hash in multi unsubscribe updates = %#v, want one deduped tickets delete", updates)
	}
	if update := updates[0]; update.QueryID != queryID || update.TableName != "tickets" {
		t.Fatalf("bob canonical duplicate hash in multi unsubscribe update = %#v, want query %d tickets", update, queryID)
	} else {
		assertEqual(t, "bob canonical duplicate hash in multi ticket deletes", decodeTicketPayload(t, h, update.Deletes), openHighTickets())
		if got := decodeTicketPayload(t, h, update.Inserts); len(got) != 0 {
			t.Fatalf("bob canonical duplicate hash in multi unsubscribe inserts = %#v, want none", got)
		}
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               269,
		ProjectID:        1,
		Number:           169,
		Title:            "Canonical duplicate hash in multi after unsubscribe ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19700,
	})
	requireNoMessage(t, h.callers["bob-canonical-duplicate-hash-in-multi"].client, 100*time.Millisecond, "canonical duplicate hash in multi after unsubscribe")
}

func TestSameConnectionDuplicateDeclaredViewQueryHashWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-duplicate-declared-view", "bob", app.PermTicketWrite, app.PermCommentWrite)

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               270,
		ProjectID:        1,
		Number:           170,
		Title:            "Duplicate declared view initial ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19800,
	})

	const (
		firstQueryID  uint32 = 2281
		secondQueryID uint32 = 2283
	)

	assertEqual(t, "bob duplicate declared view first initial",
		requireTicketSubscribeInitial(t, h, "bob-duplicate-declared-view", app.ViewLiveAlphaBoard, 2280, firstQueryID),
		h.model.AlphaBoard(bob))
	if got := requireTicketSubscribeInitial(t, h, "bob-duplicate-declared-view", app.ViewLiveAlphaBoard, 2282, secondQueryID); len(got) != 0 {
		t.Fatalf("bob duplicate declared view second initial = %#v, want elided empty snapshot", got)
	}

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               271,
		ProjectID:        1,
		Number:           171,
		Title:            "Duplicate declared view live ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            19900,
	})
	updates := readSubscriptionUpdates(t, h.callers["bob-duplicate-declared-view"].client)
	firstInsert := requireTicketUpdateFromUpdates(t, h, updates, firstQueryID, []uint64{271}, []uint64{})
	assertEqual(t, "bob duplicate declared view first live row", firstInsert, []model.Ticket{h.model.Tickets[271]})
	secondInsert := requireTicketUpdateFromUpdates(t, h, updates, secondQueryID, []uint64{271}, []uint64{})
	assertEqual(t, "bob duplicate declared view second live row", secondInsert, []model.Ticket{h.model.Tickets[271]})

	if err := h.callers["bob-duplicate-declared-view"].client.UnsubscribeSingle(2284, firstQueryID); err != nil {
		t.Fatalf("bob duplicate declared view first UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate declared view first unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-declared-view", 2284, firstQueryID),
		h.model.AlphaBoard(bob))

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               272,
		ProjectID:        1,
		Number:           172,
		Title:            "Duplicate declared view second remains live ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            20000,
	})
	updates = readSubscriptionUpdates(t, h.callers["bob-duplicate-declared-view"].client)
	assertNoSubscriptionQuery(t, updates, firstQueryID, "duplicate declared view first after unsubscribe")
	secondOnlyInsert := requireTicketUpdateFromUpdates(t, h, updates, secondQueryID, []uint64{272}, []uint64{})
	assertEqual(t, "bob duplicate declared view second stayed live row", secondOnlyInsert, []model.Ticket{h.model.Tickets[272]})

	if err := h.callers["bob-duplicate-declared-view"].client.UnsubscribeSingle(2285, secondQueryID); err != nil {
		t.Fatalf("bob duplicate declared view second UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob duplicate declared view second unsubscribe deletes rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-duplicate-declared-view", 2285, secondQueryID),
		h.model.AlphaBoard(bob))

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               273,
		ProjectID:        1,
		Number:           173,
		Title:            "Duplicate declared view after all unsubscribed ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            20100,
	})
	requireNoMessage(t, h.callers["bob-duplicate-declared-view"].client, 100*time.Millisecond, "duplicate declared view after final unsubscribe")
}
