package workflows

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func TestTraceWriteFileCreatesReplayableFailureArtifact(t *testing.T) {
	trace := NewTrace(42, "/tmp/opsboard-canary")
	trace.MarkFailure(TraceOperation{
		Index:    7,
		Caller:   "alice",
		Action:   "call_reducer",
		Reducer:  "create_ticket",
		Expected: "committed",
		Observed: "failed",
	}, errors.New("boom"))

	path := filepath.Join(t.TempDir(), "nested", "trace.json")
	if err := trace.WriteFile(path); err != nil {
		t.Fatalf("WriteFile returned error: %v", err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read trace: %v", err)
	}
	var decoded Trace
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("trace JSON is invalid: %v\n%s", err, data)
	}
	if decoded.Version != TraceVersion || decoded.Seed != 42 || decoded.DataDir != "/tmp/opsboard-canary" {
		t.Fatalf("trace header = version %d seed %d data_dir %q", decoded.Version, decoded.Seed, decoded.DataDir)
	}
	if len(decoded.Operations) != 1 || decoded.Operations[0].Index != 7 || decoded.Operations[0].Caller != "alice" || decoded.Operations[0].Reducer != "create_ticket" {
		t.Fatalf("trace operations = %#v", decoded.Operations)
	}
	if decoded.Failure == nil || decoded.Failure.OperationIndex != 7 || decoded.Failure.Error != "boom" || decoded.Failure.Expected != "committed" || decoded.Failure.Observed != "failed" {
		t.Fatalf("trace failure = %#v", decoded.Failure)
	}
}
