package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestReducerArgumentDecodingWorkflowPreservesState(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()

	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, []byte(``), "args must be a JSON object")
	assertRejectedState(t, h, "after empty create_ticket args")

	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, []byte(`{"id":9000,"project_id":1,"number":9000,"title":"unknown field","priority":"normal","visibility":"public","assignee_identity":"","now_ns":9000,"unexpected":true}`), "unknown field")
	assertRejectedState(t, h, "after unknown create_ticket field")

	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, map[string]any{
		"project_id":        uint64(1),
		"number":            uint64(9001),
		"title":             "missing id",
		"priority":          "normal",
		"visibility":        "public",
		"assignee_identity": "",
		"now_ns":            int64(9010),
	}, "id is required")
	assertRejectedState(t, h, "after missing create_ticket id")

	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, []byte(`{"id":"not-a-number","project_id":1,"number":9002,"title":"wrong id type","priority":"normal","visibility":"public","assignee_identity":"","now_ns":9020}`), "cannot unmarshal")
	assertRejectedState(t, h, "after wrong create_ticket id type")

	h.callReducerFailed(t, "carol", app.ReducerAddComment, []byte(`{"id":9003,"ticket_id":100,"visibility":"public","body":"extra value","now_ns":9030} {"id":9004}`), "must contain one JSON value")
	assertRejectedState(t, h, "after extra add_comment JSON value")

	h.callReducerFailed(t, "alice", app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 uint64(9005),
		"ticket_id":          uint64(100),
		"recipient_identity": bob,
		"delay_ms":           int64(50),
	}, "now_ns is required")
	assertRejectedState(t, h, "after missing reminder now_ns")

	h.callReducerFailed(t, "admin", app.ReducerFailAfterAuditProbe, map[string]any{
		"unexpected": true,
	}, "args must be empty")
	assertRejectedState(t, h, "after rollback probe unexpected args")
}

func TestMalformedReducerArgsCallRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, []byte(`{"id":"not-a-number"}`), "cannot unmarshal")

	created := model.CreateTicketArgs{
		ID:               9200,
		ProjectID:        1,
		Number:           9200,
		Title:            "Malformed args recovery ticket",
		Priority:         "normal",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            12500,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                created.ID,
		"project_id":        created.ProjectID,
		"number":            created.Number,
		"title":             created.Title,
		"priority":          created.Priority,
		"visibility":        created.Visibility,
		"assignee_identity": created.AssigneeIdentity,
		"now_ns":            created.NowNS,
	})
	if err := h.model.CreateTicket(alice, created); err != nil {
		t.Fatalf("model create malformed-args recovery ticket: %v", err)
	}

	assertEqual(t, "alice tickets after malformed reducer args recovery",
		requireRawTickets(t, h, "alice", "SELECT * FROM tickets", "alice-tickets-after-malformed-reducer-args"),
		h.model.VisibleTickets(alice))
}
