package workflows

import (
	"context"
	"fmt"
	"net/http/httptest"
	"os"
	"strings"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	canaryclient "github.com/ponchione/opsboard-canary/internal/client"
	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

// ProtocolSmokeOptions configures the standalone workflow command. The deeper
// canary coverage remains in the package tests; this runner keeps cmd/workflow
// useful for local and already-running runtime smoke checks.
type ProtocolSmokeOptions struct {
	InProcess bool
	Addr      string
	DataDir   string
	Seed      int64
}

// RunProtocolSmoke exercises the hosted protocol through public APIs.
func RunProtocolSmoke(ctx context.Context, opts ProtocolSmokeOptions) (Trace, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if opts.DataDir == "" {
		opts.DataDir = "./artifacts/workflow-data"
	}
	trace := NewTrace(opts.Seed, opts.DataDir)

	var (
		rt       *shunter.Runtime
		server   *httptest.Server
		endpoint string
		contract shunter.ModuleContract
	)
	if opts.Addr != "" {
		endpoint = opts.Addr
		exported, err := exportContractForRunner()
		if err != nil {
			op := TraceOperation{Index: 0, Action: "export_contract", Expected: "module contract exports for row decoding", Observed: err.Error()}
			trace.MarkFailure(op, err)
			return trace, err
		}
		contract = exported
	} else {
		if !opts.InProcess {
			err := fmt.Errorf("set --in-process or provide --addr")
			op := TraceOperation{
				Index:    0,
				Action:   "validate_args",
				Expected: "in-process workflow or existing runtime address",
				Observed: "--in-process=false without --addr",
			}
			trace.MarkFailure(op, err)
			return trace, err
		}

		built, err := shunter.Build(app.NewModule(), app.StrictAuthConfig(opts.DataDir, ""))
		if err != nil {
			op := TraceOperation{Index: 0, Action: "build_runtime", Expected: "runtime build succeeds", Observed: err.Error()}
			trace.MarkFailure(op, err)
			return trace, fmt.Errorf("build runtime: %w", err)
		}
		rt = built
		if err := rt.Start(ctx); err != nil {
			op := TraceOperation{Index: 0, Action: "start_runtime", Expected: "runtime start succeeds", Observed: err.Error()}
			trace.MarkFailure(op, err)
			_ = rt.Close()
			return trace, fmt.Errorf("start runtime: %w", err)
		}
		server = httptest.NewServer(rt.HTTPHandler())
		endpoint = server.URL
		contract = rt.ExportContract()
	}
	defer func() {
		if server != nil {
			server.Close()
		}
		if rt != nil {
			_ = rt.Close()
		}
	}()

	r, err := newProtocolSmokeRunner(endpoint, contract)
	if err != nil {
		op := TraceOperation{Index: len(trace.Operations), Action: "prepare_runner", Expected: "schemas load from exported contract", Observed: err.Error()}
		trace.MarkFailure(op, err)
		return trace, err
	}
	defer r.close()

	if err := r.run(ctx, &trace, opts.Seed); err != nil {
		return trace, err
	}
	return trace, nil
}

type protocolSmokeRunner struct {
	endpoint string
	schemas  map[string]*schema.TableSchema
	callers  map[string]*protocolSmokeCaller
	nextReq  uint32
}

type protocolSmokeCaller struct {
	identity types.Identity
	client   *canaryclient.Client
}

func newProtocolSmokeRunner(endpoint string, contract shunter.ModuleContract) (*protocolSmokeRunner, error) {
	r := &protocolSmokeRunner{
		endpoint: endpoint,
		schemas:  map[string]*schema.TableSchema{},
		callers:  map[string]*protocolSmokeCaller{},
		nextReq:  100,
	}
	for _, table := range []string{"tickets", "comments", "notifications", "audit_log"} {
		tableSchema, err := canaryclient.TableSchema(contract, table)
		if err != nil {
			return nil, fmt.Errorf("schema %s: %w", table, err)
		}
		r.schemas[table] = tableSchema
	}
	return r, nil
}

func (r *protocolSmokeRunner) run(ctx context.Context, trace *Trace, seed int64) error {
	nowNS := int64(1000)
	if seed != 0 {
		nowNS = seed
	}

	if err := r.step(trace, TraceOperation{Caller: "admin", Action: "dial_caller", Expected: "strict-auth admin connects"}, func() error {
		return r.addCaller(ctx, "admin", app.PermAdminWrite, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite, app.PermAuditRead)
	}); err != nil {
		return err
	}
	if err := r.step(trace, TraceOperation{Caller: "alice", Action: "dial_caller", Expected: "strict-auth alice connects"}, func() error {
		return r.addCaller(ctx, "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	}); err != nil {
		return err
	}
	if err := r.step(trace, TraceOperation{Caller: "bob", Action: "dial_caller", Expected: "strict-auth bob connects"}, func() error {
		return r.addCaller(ctx, "bob", app.PermTicketWrite, app.PermCommentWrite)
	}); err != nil {
		return err
	}
	if err := r.step(trace, TraceOperation{Caller: "auditor", Action: "dial_caller", Expected: "strict-auth auditor connects"}, func() error {
		return r.addCaller(ctx, "auditor", app.PermAuditRead)
	}); err != nil {
		return err
	}
	if err := r.step(trace, TraceOperation{Caller: "outsider", Action: "dial_caller", Expected: "strict-auth outsider connects"}, func() error {
		return r.addCaller(ctx, "outsider")
	}); err != nil {
		return err
	}

	if err := r.step(trace, TraceOperation{Caller: "admin", Action: "call_reducer", Reducer: app.ReducerBootstrapDemo, Expected: "demo data exists"}, func() error {
		if err := r.callReducer(ctx, "admin", app.ReducerBootstrapDemo, map[string]int64{"now_ns": nowNS}); err != nil {
			if strings.Contains(err.Error(), "already been applied") {
				return nil
			}
			return err
		}
		return nil
	}); err != nil {
		return err
	}

	if err := r.step(trace, TraceOperation{Caller: "outsider", Action: "one_off_query", Query: "SELECT * FROM tickets", Expected: "outsider sees public ticket only"}, func() error {
		tickets, err := r.queryTickets(ctx, "outsider", "SELECT * FROM tickets")
		if err != nil {
			return err
		}
		if containsTicketID(tickets, 100) {
			return fmt.Errorf("outsider saw internal ticket 100")
		}
		if !containsTicketID(tickets, 200) {
			return fmt.Errorf("outsider did not see public ticket 200; saw ids %v", ticketIDs(tickets))
		}
		return nil
	}); err != nil {
		return err
	}

	if err := r.step(trace, TraceOperation{Caller: "bob", Action: "declared_query", Query: app.QueryMyTickets, Expected: "bob sees assigned ticket 100"}, func() error {
		tickets, err := r.declaredTickets(ctx, "bob", app.QueryMyTickets)
		if err != nil {
			return err
		}
		if !containsTicketID(tickets, 100) {
			return fmt.Errorf("bob my_tickets missing ticket 100; saw ids %v", ticketIDs(tickets))
		}
		return nil
	}); err != nil {
		return err
	}

	if err := r.step(trace, TraceOperation{Caller: "auditor", Action: "declared_query", Query: app.QueryAuditFeed, Expected: "auditor can read audit feed"}, func() error {
		audit, err := r.declaredAudit(ctx, "auditor", app.QueryAuditFeed)
		if err != nil {
			return err
		}
		if len(audit) == 0 {
			return fmt.Errorf("audit feed returned no rows")
		}
		return nil
	}); err != nil {
		return err
	}

	if err := r.step(trace, TraceOperation{Caller: "outsider", Action: "declared_query", Query: app.QueryAuditFeed, Expected: "outsider cannot read audit feed"}, func() error {
		return r.declaredQueryError(ctx, "outsider", app.QueryAuditFeed, "permission")
	}); err != nil {
		return err
	}

	subscribeRequestID := r.nextRequestID()
	queryID := r.nextRequestID()
	if err := r.step(trace, TraceOperation{Caller: "bob", Action: "subscribe_declared_view", Subscription: app.ViewMyNotifications, Expected: "initial notifications include seeded assignment"}, func() error {
		notifications, err := r.subscribeNotifications(ctx, "bob", subscribeRequestID, queryID)
		if err != nil {
			return err
		}
		if len(notifications) == 0 {
			return fmt.Errorf("bob notification subscription returned no initial rows")
		}
		return nil
	}); err != nil {
		return err
	}

	commentID, err := r.nextCommentID(ctx)
	if err != nil {
		op := TraceOperation{Index: len(trace.Operations), Caller: "alice", Action: "one_off_query", Query: "SELECT * FROM comments", Expected: "next comment id can be derived", Observed: err.Error()}
		trace.MarkFailure(op, err)
		return err
	}
	if err := r.step(trace, TraceOperation{Caller: "alice", Action: "call_reducer", Reducer: app.ReducerAddComment, Expected: "comment creates a bob notification delta"}, func() error {
		return r.callReducer(ctx, "alice", app.ReducerAddComment, map[string]any{
			"id":         commentID,
			"ticket_id":  100,
			"visibility": "public",
			"body":       "Standalone workflow smoke comment",
			"now_ns":     nowNS + 1,
		})
	}); err != nil {
		return err
	}

	if err := r.step(trace, TraceOperation{Caller: "bob", Action: "read_subscription_delta", Subscription: app.ViewMyNotifications, Expected: "bob receives inserted notification delta"}, func() error {
		inserts, err := r.readNotificationDelta(ctx, "bob", queryID)
		if err != nil {
			return err
		}
		if len(inserts) == 0 {
			return fmt.Errorf("notification delta had no inserts")
		}
		return nil
	}); err != nil {
		return err
	}

	return nil
}

func (r *protocolSmokeRunner) step(trace *Trace, op TraceOperation, fn func() error) error {
	op.Index = len(trace.Operations)
	if err := fn(); err != nil {
		op.Observed = err.Error()
		trace.MarkFailure(op, err)
		return fmt.Errorf("%s: %w", op.Action, err)
	}
	op.Observed = "ok"
	trace.AddOperation(op)
	return nil
}

func (r *protocolSmokeRunner) addCaller(ctx context.Context, subject string, permissions ...string) error {
	token, identity, err := canaryclient.MintStrictToken(subject, permissions...)
	if err != nil {
		return fmt.Errorf("mint %s token: %w", subject, err)
	}
	dialCtx, cancel := context.WithTimeout(ctx, 3*time.Second)
	defer cancel()
	c, err := canaryclient.Dial(dialCtx, r.endpoint, token)
	if err != nil {
		return err
	}
	tag, msg, err := readProtocolMessage(ctx, c)
	if err != nil {
		_ = c.CloseNow()
		return err
	}
	if tag != protocol.TagIdentityToken {
		_ = c.CloseNow()
		return fmt.Errorf("identity tag = %d, want IdentityToken", tag)
	}
	identityToken, ok := msg.(protocol.IdentityToken)
	if !ok {
		_ = c.CloseNow()
		return fmt.Errorf("identity message = %T, want protocol.IdentityToken", msg)
	}
	if identityToken.Identity != identity {
		_ = c.CloseNow()
		return fmt.Errorf("identity = %x, want %x", identityToken.Identity, identity)
	}
	r.callers[subject] = &protocolSmokeCaller{identity: identity, client: c}
	return nil
}

func (r *protocolSmokeRunner) close() {
	for _, caller := range r.callers {
		_ = caller.client.CloseNow()
	}
}

func (r *protocolSmokeRunner) callReducer(ctx context.Context, subject, reducer string, args any) error {
	requestID := r.nextRequestID()
	c, err := r.client(subject)
	if err != nil {
		return err
	}
	if err := c.CallReducer(reducer, args, requestID, protocol.CallReducerFlagsFullUpdate); err != nil {
		return err
	}
	for {
		tag, msg, err := readProtocolMessage(ctx, c)
		if err != nil {
			return err
		}
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update, ok := msg.(protocol.TransactionUpdate)
		if !ok {
			return fmt.Errorf("transaction update = %T, want protocol.TransactionUpdate", msg)
		}
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		switch status := update.Status.(type) {
		case protocol.StatusCommitted:
			return nil
		case protocol.StatusFailed:
			return fmt.Errorf("reducer %s failed: %s", reducer, status.Error)
		default:
			return fmt.Errorf("reducer %s status = %T, want committed", reducer, update.Status)
		}
	}
}

func (r *protocolSmokeRunner) queryTickets(ctx context.Context, subject, sql string) ([]canaryclient.TicketRow, error) {
	resp, err := r.oneOff(ctx, subject, sql)
	if err != nil {
		return nil, err
	}
	rows, err := canaryclient.DecodeOneOffRows(resp, "tickets", r.schemas["tickets"])
	if err != nil {
		return nil, err
	}
	return canaryclient.TicketsFromRows(rows)
}

func (r *protocolSmokeRunner) declaredTickets(ctx context.Context, subject, name string) ([]canaryclient.TicketRow, error) {
	resp, err := r.declaredQuery(ctx, subject, name)
	if err != nil {
		return nil, err
	}
	rows, err := canaryclient.DecodeOneOffRows(resp, "tickets", r.schemas["tickets"])
	if err != nil {
		return nil, err
	}
	return canaryclient.TicketsFromRows(rows)
}

func (r *protocolSmokeRunner) declaredAudit(ctx context.Context, subject, name string) ([]canaryclient.AuditLogRow, error) {
	resp, err := r.declaredQuery(ctx, subject, name)
	if err != nil {
		return nil, err
	}
	rows, err := canaryclient.DecodeOneOffRows(resp, "audit_log", r.schemas["audit_log"])
	if err != nil {
		return nil, err
	}
	return canaryclient.AuditLogsFromRows(rows)
}

func (r *protocolSmokeRunner) declaredQueryError(ctx context.Context, subject, name, want string) error {
	resp, err := r.declaredQuery(ctx, subject, name)
	if err != nil {
		return err
	}
	if resp.Error == nil {
		return fmt.Errorf("declared query %q succeeded, want error containing %q", name, want)
	}
	if want != "" && !strings.Contains(strings.ToLower(*resp.Error), strings.ToLower(want)) {
		return fmt.Errorf("declared query error = %q, want substring %q", *resp.Error, want)
	}
	return nil
}

func (r *protocolSmokeRunner) oneOff(ctx context.Context, subject, sql string) (protocol.OneOffQueryResponse, error) {
	messageID := []byte(fmt.Sprintf("smoke-oneoff-%d", r.nextRequestID()))
	c, err := r.client(subject)
	if err != nil {
		return protocol.OneOffQueryResponse{}, err
	}
	if err := c.OneOff(sql, messageID); err != nil {
		return protocol.OneOffQueryResponse{}, err
	}
	return r.readOneOffResponse(ctx, c, messageID)
}

func (r *protocolSmokeRunner) declaredQuery(ctx context.Context, subject, name string) (protocol.OneOffQueryResponse, error) {
	messageID := []byte(fmt.Sprintf("smoke-declared-%d", r.nextRequestID()))
	c, err := r.client(subject)
	if err != nil {
		return protocol.OneOffQueryResponse{}, err
	}
	if err := c.DeclaredQuery(name, messageID); err != nil {
		return protocol.OneOffQueryResponse{}, err
	}
	return r.readOneOffResponse(ctx, c, messageID)
}

func (r *protocolSmokeRunner) readOneOffResponse(ctx context.Context, c *canaryclient.Client, messageID []byte) (protocol.OneOffQueryResponse, error) {
	for {
		tag, msg, err := readProtocolMessage(ctx, c)
		if err != nil {
			return protocol.OneOffQueryResponse{}, err
		}
		if tag != protocol.TagOneOffQueryResponse {
			continue
		}
		resp, ok := msg.(protocol.OneOffQueryResponse)
		if !ok {
			return protocol.OneOffQueryResponse{}, fmt.Errorf("one-off response = %T, want protocol.OneOffQueryResponse", msg)
		}
		if string(resp.MessageID) != string(messageID) {
			continue
		}
		return resp, nil
	}
}

func (r *protocolSmokeRunner) subscribeNotifications(ctx context.Context, subject string, requestID, queryID uint32) ([]canaryclient.NotificationRow, error) {
	c, err := r.client(subject)
	if err != nil {
		return nil, err
	}
	if err := c.SubscribeDeclaredView(app.ViewMyNotifications, requestID, queryID); err != nil {
		return nil, err
	}
	for {
		tag, msg, err := readProtocolMessage(ctx, c)
		if err != nil {
			return nil, err
		}
		if tag != protocol.TagSubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeSingleApplied)
		if !ok {
			return nil, fmt.Errorf("subscribe applied = %T, want protocol.SubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		rows, err := canaryclient.DecodeRows(applied.Rows, r.schemas["notifications"])
		if err != nil {
			return nil, err
		}
		return canaryclient.NotificationsFromRows(rows)
	}
}

func (r *protocolSmokeRunner) readNotificationDelta(ctx context.Context, subject string, queryID uint32) ([]canaryclient.NotificationRow, error) {
	c, err := r.client(subject)
	if err != nil {
		return nil, err
	}
	for {
		tag, msg, err := readProtocolMessage(ctx, c)
		if err != nil {
			return nil, err
		}
		var updates []protocol.SubscriptionUpdate
		switch tag {
		case protocol.TagTransactionUpdateLight:
			update, ok := msg.(protocol.TransactionUpdateLight)
			if !ok {
				return nil, fmt.Errorf("light update = %T, want protocol.TransactionUpdateLight", msg)
			}
			updates = update.Update
		case protocol.TagTransactionUpdate:
			update, ok := msg.(protocol.TransactionUpdate)
			if !ok {
				return nil, fmt.Errorf("transaction update = %T, want protocol.TransactionUpdate", msg)
			}
			committed, ok := update.Status.(protocol.StatusCommitted)
			if !ok {
				continue
			}
			updates = committed.Update
		default:
			continue
		}
		for _, update := range updates {
			if update.QueryID != queryID || update.TableName != "notifications" {
				continue
			}
			rows, err := canaryclient.DecodeRows(update.Inserts, r.schemas["notifications"])
			if err != nil {
				return nil, err
			}
			return canaryclient.NotificationsFromRows(rows)
		}
	}
}

func (r *protocolSmokeRunner) nextCommentID(ctx context.Context) (uint64, error) {
	resp, err := r.oneOff(ctx, "alice", "SELECT * FROM comments")
	if err != nil {
		return 0, err
	}
	rows, err := canaryclient.DecodeOneOffRows(resp, "comments", r.schemas["comments"])
	if err != nil {
		return 0, err
	}
	comments, err := canaryclient.CommentsFromRows(rows)
	if err != nil {
		return 0, err
	}
	var max uint64
	for _, comment := range comments {
		if comment.ID > max {
			max = comment.ID
		}
	}
	return max + 10_000, nil
}

func (r *protocolSmokeRunner) client(subject string) (*canaryclient.Client, error) {
	caller, ok := r.callers[subject]
	if !ok {
		return nil, fmt.Errorf("caller %q is not connected", subject)
	}
	return caller.client, nil
}

func (r *protocolSmokeRunner) nextRequestID() uint32 {
	requestID := r.nextReq
	r.nextReq++
	return requestID
}

func readProtocolMessage(ctx context.Context, c *canaryclient.Client) (uint8, any, error) {
	readCtx, cancel := context.WithTimeout(ctx, 3*time.Second)
	defer cancel()
	return c.Read(readCtx)
}

func exportContractForRunner() (shunter.ModuleContract, error) {
	tmp, err := os.MkdirTemp("", "opsboard-canary-contract-*")
	if err != nil {
		return shunter.ModuleContract{}, fmt.Errorf("create temp contract dir: %w", err)
	}
	defer os.RemoveAll(tmp)

	rt, err := shunter.Build(app.NewModule(), shunter.Config{DataDir: tmp})
	if err != nil {
		return shunter.ModuleContract{}, fmt.Errorf("build module for contract: %w", err)
	}
	defer rt.Close()
	return rt.ExportContract(), nil
}

func containsTicketID(tickets []canaryclient.TicketRow, id uint64) bool {
	for _, ticket := range tickets {
		if ticket.ID == id {
			return true
		}
	}
	return false
}

func ticketIDs(tickets []canaryclient.TicketRow) []uint64 {
	ids := make([]uint64, 0, len(tickets))
	for _, ticket := range tickets {
		ids = append(ids, ticket.ID)
	}
	return ids
}
