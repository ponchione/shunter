package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestClosedSubscribedConnectionsDoNotDisruptFanoutWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	h.addCallerAs(t, "bob-stay-board", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "bob-stay-notify", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "auditor-stay-audit", "auditor", app.PermAuditRead)

	const bobBoardQuery uint32 = 1601
	assertEqual(t, "bob stay board initial",
		requireTicketSubscribeInitial(t, h, "bob-stay-board", app.ViewLiveAlphaBoard, 1600, bobBoardQuery),
		h.model.AlphaBoard(bob))

	const bobNotificationsQuery uint32 = 1603
	assertEqual(t, "bob stay notifications initial",
		requireNotificationSubscribeInitial(t, h, "bob-stay-notify", 1602, bobNotificationsQuery),
		h.model.VisibleNotifications(bob))

	const auditQuery uint32 = 1605
	assertEqual(t, "auditor stay audit initial",
		model.AuditIDs(requireAuditSubscribeInitial(t, h, "auditor-stay-audit", app.ViewLiveAuditFeed, 1604, auditQuery)),
		model.AuditIDs(h.model.AuditFeed(true)))

	addSubscribedConnectionToClose(t, h, "bob-gone-board", "bob", app.ViewLiveAlphaBoard, 1610, 1611)
	addSubscribedNotificationConnectionToClose(t, h, "bob-gone-notify", "bob", 1612, 1613)
	addSubscribedAuditConnectionToClose(t, h, "auditor-gone-audit", 1614, 1615)
	addSubscribedConnectionToClose(t, h, "outsider-gone-board", "outsider", app.ViewLiveAlphaBoard, 1616, 1617)

	for _, key := range []string{"bob-gone-board", "bob-gone-notify", "auditor-gone-audit", "outsider-gone-board"} {
		h.closeCaller(key)
	}

	createTicket := model.CreateTicketArgs{
		ID:               190,
		ProjectID:        1,
		Number:           90,
		Title:            "Closed subscriber fanout ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            9100,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create closed-subscriber ticket: %v", err)
	}

	bobTicketInsert := requireTicketDeltaIDs(t, h, "bob-stay-board", bobBoardQuery, []uint64{190}, []uint64{})
	assertEqual(t, "bob stay board insert after closed subscribers", bobTicketInsert, []model.Ticket{h.model.Tickets[190]})

	bobNotificationInsert := requireNotificationDeltaIDs(t, h, "bob-stay-notify", bobNotificationsQuery, []uint64{601}, []uint64{})
	assertEqual(t, "bob stay notification insert after closed subscribers", bobNotificationInsert, []model.Notification{h.model.Notifications[601]})

	auditInsert := requireAuditDeltaIDs(t, h, "auditor-stay-audit", auditQuery, []uint64{904}, []uint64{})
	assertEqual(t, "auditor stay audit insert after closed subscribers", auditInsert, []model.AuditEntry{h.model.AuditLog[904]})

	h.addCallerAs(t, "bob-fresh-after-closed", "bob", app.PermTicketWrite, app.PermCommentWrite)
	assertEqual(t, "bob fresh board after closed subscribers",
		requireTicketSubscribeInitial(t, h, "bob-fresh-after-closed", app.ViewLiveAlphaBoard, 1620, 1621),
		h.model.AlphaBoard(bob))
	assertEqual(t, "bob fresh notifications after closed subscribers",
		requireNotificationSubscribeInitial(t, h, "bob-fresh-after-closed", 1622, 1623),
		h.model.VisibleNotifications(bob))

	h.addCallerAs(t, "auditor-fresh-after-closed", "auditor", app.PermAuditRead)
	assertEqual(t, "auditor fresh audit after closed subscribers",
		model.AuditIDs(requireAuditSubscribeInitial(t, h, "auditor-fresh-after-closed", app.ViewLiveAuditFeed, 1624, 1625)),
		model.AuditIDs(h.model.AuditFeed(true)))
}

func addSubscribedConnectionToClose(t *testing.T, h *workflowHarness, key, subject, view string, requestID, queryID uint32) {
	t.Helper()
	switch subject {
	case "bob":
		h.addCallerAs(t, key, subject, app.PermTicketWrite, app.PermCommentWrite)
	default:
		h.addCallerAs(t, key, subject)
	}
	identity := h.callers[key].identity.Hex()
	assertEqual(t, key+" initial before close",
		requireTicketSubscribeInitial(t, h, key, view, requestID, queryID),
		h.model.AlphaBoard(identity))
}

func addSubscribedNotificationConnectionToClose(t *testing.T, h *workflowHarness, key, subject string, requestID, queryID uint32) {
	t.Helper()
	h.addCallerAs(t, key, subject, app.PermTicketWrite, app.PermCommentWrite)
	identity := h.callers[key].identity.Hex()
	assertEqual(t, key+" notifications initial before close",
		requireNotificationSubscribeInitial(t, h, key, requestID, queryID),
		h.model.VisibleNotifications(identity))
}

func addSubscribedAuditConnectionToClose(t *testing.T, h *workflowHarness, key string, requestID, queryID uint32) {
	t.Helper()
	h.addCallerAs(t, key, "auditor", app.PermAuditRead)
	assertEqual(t, key+" audit initial before close",
		model.AuditIDs(requireAuditSubscribeInitial(t, h, key, app.ViewLiveAuditFeed, requestID, queryID)),
		model.AuditIDs(h.model.AuditFeed(true)))
}
