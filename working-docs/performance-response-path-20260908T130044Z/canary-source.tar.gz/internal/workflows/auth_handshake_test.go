package workflows

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/coder/websocket"
	"github.com/golang-jwt/jwt/v5"

	"github.com/ponchione/opsboard-canary/internal/app"
	canaryclient "github.com/ponchione/opsboard-canary/internal/client"
	"github.com/ponchione/shunter/protocol"
)

func TestStrictAuthHandshakeRejectsInvalidTokensAndRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	requireMalformedAuthorizationRejectedBeforeUpgrade(t, h.server.URL)
	requireAuthRejectedClose(t, h.server.URL, "", "missing token")
	requireAuthRejectedClose(t, h.server.URL, "not-a-jwt", "malformed token")
	requireAuthRejectedClose(t, h.server.URL, signedAuthProbeToken(t, "wrong-issuer", "not-"+app.StrictAuthIssuer, app.StrictAuthAudience, time.Now().Add(time.Hour)), "wrong issuer token")
	requireAuthRejectedClose(t, h.server.URL, signedAuthProbeToken(t, "wrong-audience", app.StrictAuthIssuer, "not-"+app.StrictAuthAudience, time.Now().Add(time.Hour)), "wrong audience token")
	requireAuthRejectedClose(t, h.server.URL, signedAuthProbeToken(t, "expired", app.StrictAuthIssuer, app.StrictAuthAudience, time.Now().Add(-time.Hour)), "expired token")

	h.addCallerAs(t, "alice-after-auth-failures", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	alice := h.callers["alice-after-auth-failures"].identity.Hex()
	assertEqual(t, "alice profile after rejected handshakes",
		requireDeclaredUsers(t, h, "alice-after-auth-failures", app.QueryMyProfile, "alice-profile-after-auth-failures"),
		h.model.MyProfile(alice))
}

func requireAuthRejectedClose(t *testing.T, runtimeURL, token, label string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	c, err := canaryclient.Dial(ctx, runtimeURL, token)
	if err != nil {
		t.Fatalf("%s dial should complete WebSocket upgrade: %v", label, err)
	}
	defer c.CloseNow()
	_, _, err = c.Read(ctx)
	if err == nil {
		t.Fatalf("%s read succeeded, want strict-auth close", label)
	}
	if got := websocket.CloseStatus(err); got != websocket.StatusPolicyViolation {
		t.Fatalf("%s close code = %d, want %d", label, got, websocket.StatusPolicyViolation)
	}
	var closeErr websocket.CloseError
	if !errors.As(err, &closeErr) {
		t.Fatalf("%s read error = %T %[2]v, want websocket.CloseError", label, err)
	}
	if closeErr.Reason != protocol.CloseReasonAuthRejected {
		t.Fatalf("%s close reason = %q, want %q", label, closeErr.Reason, protocol.CloseReasonAuthRejected)
	}
}

func requireMalformedAuthorizationRejectedBeforeUpgrade(t *testing.T, runtimeURL string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	header := http.Header{}
	header.Set("Authorization", "Basic credentials")
	conn, resp, err := websocket.Dial(ctx, strings.Replace(runtimeURL, "http://", "ws://", 1)+"/subscribe", &websocket.DialOptions{
		HTTPHeader:   header,
		Subprotocols: []string{protocol.SubprotocolV1},
	})
	if conn != nil {
		_ = conn.CloseNow()
	}
	if err == nil {
		t.Fatal("malformed Authorization header dial succeeded, want pre-upgrade rejection")
	}
	if resp == nil {
		t.Fatalf("malformed Authorization header dial failed without HTTP response: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("malformed Authorization header status = %d, want %d", resp.StatusCode, http.StatusUnauthorized)
	}
}

func signedAuthProbeToken(t *testing.T, subject, issuer, audience string, expiresAt time.Time) string {
	t.Helper()
	now := time.Now().UTC()
	claims := jwt.MapClaims{
		"iss": issuer,
		"sub": subject,
		"aud": audience,
		"iat": now.Unix(),
		"exp": expiresAt.UTC().Unix(),
	}
	token, err := jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString([]byte(app.StrictAuthSigningKey))
	if err != nil {
		t.Fatalf("sign auth probe token: %v", err)
	}
	return token
}
