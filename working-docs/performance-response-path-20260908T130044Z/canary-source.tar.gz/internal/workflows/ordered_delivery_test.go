package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter/protocol"
)

// Fast caller replies must still lead to complete, ordered peer delivery.
// Fixed timestamps check content and ordering without timing assertions.
func TestOrderedTicketDeliveryAcrossSnapshot(t *testing.T) {
	h := newWorkflowHarness(t)
	h.addCallerAs(t, "peer", "bob", app.PermTicketWrite)
	const queryID uint32 = 2901
	for _, peer := range []string{"bob", "peer"} {
		requireTicketSubscribeInitial(t, h, peer, app.ViewLiveAlphaBoard, 2900, queryID)
	}
	const writes = 24
	for i := range writes {
		h.callReducer(t, "alice", app.ReducerChangeTicketStatus, map[string]any{
			"ticket_id": uint64(100 + 100*(i%2)), "status": "blocked", "now_ns": int64(10000 + i),
		})
		if i == writes/2 {
			if _, err := h.runtime.CreateSnapshot(); err != nil {
				t.Fatal(err)
			}
		}
	}
	for _, peer := range []string{"bob", "peer"} {
		for i := range writes {
			updates := readSubscriptionUpdates(t, h.callers[peer].client)
			if len(updates) != 1 || updates[0].TableName != "tickets" || updates[0].QueryID != queryID {
				t.Fatalf("%s delivery %d: unexpected updates %+v", peer, i, updates)
			}
			rows := decodeTicketPayload(t, h, updates[0].Inserts)
			if len(rows) != 1 || rows[0].ID != uint64(100+100*(i%2)) || rows[0].UpdatedAtNS != int64(10000+i) || rows[0].Status != "blocked" {
				t.Fatalf("%s delivery %d: missing, duplicate or reordered row %+v", peer, i, rows)
			}
		}
		if err := h.callers[peer].client.UnsubscribeSingle(2902, queryID); err != nil {
			t.Fatal(err)
		}
		tag, msg := readWorkflowMessage(t, h.callers[peer].client)
		applied, ok := msg.(protocol.UnsubscribeSingleApplied)
		if tag != protocol.TagUnsubscribeSingleApplied || !ok || applied.QueryID != queryID || applied.RequestID != 2902 {
			t.Fatalf("%s delivery drain: unexpected extra message %T %+v", peer, msg, msg)
		}
	}
}
