package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestFailedReducersDoNotNotifySubscriptionsAndRecover(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	carol := h.callers["carol"].identity.Hex()

	h.addCallerAs(t, "bob-board", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "carol-board", "carol", app.PermCommentWrite)
	h.addCallerAs(t, "bob-notify", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "auditor-audit", "auditor", app.PermAuditRead)

	const bobBoardQuery uint32 = 1201
	assertEqual(t, "bob board initial before failed reducers",
		requireTicketSubscribeInitial(t, h, "bob-board", app.ViewLiveAlphaBoard, 1200, bobBoardQuery),
		h.model.AlphaBoard(bob))

	const carolBoardQuery uint32 = 1203
	assertEqual(t, "carol board initial before failed reducers",
		requireTicketSubscribeInitial(t, h, "carol-board", app.ViewLiveAlphaBoard, 1202, carolBoardQuery),
		h.model.AlphaBoard(carol))

	const bobNotificationsQuery uint32 = 1205
	assertEqual(t, "bob notifications initial before failed reducers",
		requireNotificationSubscribeInitial(t, h, "bob-notify", 1204, bobNotificationsQuery),
		h.model.VisibleNotifications(bob))

	const auditQuery uint32 = 1207
	assertEqual(t, "auditor audit initial before failed reducers",
		model.AuditIDs(requireAuditSubscribeInitial(t, h, "auditor-audit", app.ViewLiveAuditFeed, 1206, auditQuery)),
		model.AuditIDs(h.model.AuditFeed(true)))

	h.callReducerFailed(t, "admin", app.ReducerFailAfterAuditProbe, map[string]any{}, "forced rollback")

	h.callReducerFailed(t, "admin", app.ReducerPanicAfterTicketProbe, map[string]any{}, app.ReducerPanicAfterTicketProbe)

	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                uint64(120),
		"project_id":        uint64(1),
		"number":            uint64(1),
		"title":             "duplicate ticket number should not notify",
		"priority":          "normal",
		"visibility":        "public",
		"assignee_identity": bob,
		"now_ns":            int64(3100),
	}, "")

	h.callReducerFailed(t, "outsider", app.ReducerCreateTicket, map[string]any{
		"id":                uint64(121),
		"project_id":        uint64(1),
		"number":            uint64(12),
		"title":             "unauthorized public ticket should not notify",
		"priority":          "high",
		"visibility":        "public",
		"assignee_identity": bob,
		"now_ns":            int64(3200),
	}, "permission")

	assertRejectedState(t, h, "after failed subscription probes")

	createTicket := model.CreateTicketArgs{
		ID:               120,
		ProjectID:        1,
		Number:           12,
		Title:            "Subscription recovery ticket",
		Priority:         "high",
		Visibility:       "public",
		AssigneeIdentity: bob,
		NowNS:            3300,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create recovery ticket: %v", err)
	}

	bobTicketInsert := requireTicketDeltaIDs(t, h, "bob-board", bobBoardQuery, []uint64{120}, []uint64{})
	assertEqual(t, "bob board recovery insert row", bobTicketInsert, []model.Ticket{h.model.Tickets[120]})

	carolTicketInsert := requireTicketDeltaIDs(t, h, "carol-board", carolBoardQuery, []uint64{120}, []uint64{})
	assertEqual(t, "carol board recovery insert row", carolTicketInsert, []model.Ticket{h.model.Tickets[120]})

	bobNotificationInsert := requireNotificationDeltaIDs(t, h, "bob-notify", bobNotificationsQuery, []uint64{601}, []uint64{})
	assertEqual(t, "bob notification recovery insert row", bobNotificationInsert, []model.Notification{h.model.Notifications[601]})

	auditInsert := requireAuditDeltaIDs(t, h, "auditor-audit", auditQuery, []uint64{904}, []uint64{})
	assertEqual(t, "audit recovery insert row", auditInsert, []model.AuditEntry{h.model.AuditLog[904]})
}
