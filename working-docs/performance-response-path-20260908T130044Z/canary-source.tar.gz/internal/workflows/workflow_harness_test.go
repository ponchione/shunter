package workflows

import (
	"context"
	"net/http/httptest"
	"reflect"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	canaryclient "github.com/ponchione/opsboard-canary/internal/client"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

type workflowHarness struct {
	runtime  *shunter.Runtime
	server   *httptest.Server
	dataDir  string
	contract shunter.ModuleContract
	schemas  map[string]*schema.TableSchema
	callers  map[string]*workflowCaller
	model    *model.State
	nextReq  uint32
}

type workflowCaller struct {
	subject  string
	token    string
	identity types.Identity
	client   *canaryclient.Client
}

func newWorkflowHarness(t *testing.T) *workflowHarness {
	t.Helper()
	return newWorkflowHarnessWithDataDir(t, t.TempDir())
}

func newWorkflowHarnessWithDataDir(t *testing.T, dataDir string) *workflowHarness {
	t.Helper()
	return newWorkflowHarnessWithBootstrap(t, dataDir, true)
}

func newWorkflowHarnessWithBootstrap(t *testing.T, dataDir string, bootstrap bool) *workflowHarness {
	t.Helper()

	rt, err := shunter.Build(app.NewModule(), app.StrictAuthConfig(dataDir, ""))
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("Start returned error: %v", err)
	}
	srv := httptest.NewServer(rt.HTTPHandler())
	h := &workflowHarness{
		runtime:  rt,
		server:   srv,
		dataDir:  dataDir,
		contract: rt.ExportContract(),
		schemas:  map[string]*schema.TableSchema{},
		callers:  map[string]*workflowCaller{},
		model:    model.New(),
		nextReq:  100,
	}
	t.Cleanup(func() {
		for _, caller := range h.callers {
			_ = caller.client.CloseNow()
		}
		if h.server != nil {
			h.server.Close()
		}
		if h.runtime != nil {
			_ = h.runtime.Close()
		}
	})

	for _, table := range []string{"users", "projects", "tickets", "comments", "notifications", "audit_log"} {
		tableSchema, err := canaryclient.TableSchema(h.contract, table)
		if err != nil {
			t.Fatalf("schema %s: %v", table, err)
		}
		h.schemas[table] = tableSchema
	}

	h.addCaller(t, "admin", app.PermAdminWrite, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite, app.PermAuditRead)
	h.addCaller(t, "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	h.addCaller(t, "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCaller(t, "carol", app.PermCommentWrite)
	h.addCaller(t, "auditor", app.PermAuditRead)
	h.addCaller(t, "outsider")

	if bootstrap {
		h.callReducer(t, "admin", app.ReducerBootstrapDemo, map[string]int64{"now_ns": 1000})
		if err := h.model.BootstrapDemo(h.identities(), 1000); err != nil {
			t.Fatalf("model bootstrap: %v", err)
		}
	}
	return h
}

func (h *workflowHarness) close(t *testing.T) {
	t.Helper()
	for _, caller := range h.callers {
		_ = caller.client.CloseNow()
	}
	h.callers = map[string]*workflowCaller{}
	if h.server != nil {
		h.server.Close()
		h.server = nil
	}
	if h.runtime != nil {
		if err := h.runtime.Close(); err != nil {
			t.Fatalf("close runtime: %v", err)
		}
		h.runtime = nil
	}
}

func (h *workflowHarness) restart(t *testing.T) {
	t.Helper()
	h.close(t)

	rt, err := shunter.Build(app.NewModule(), app.StrictAuthConfig(h.dataDir, ""))
	if err != nil {
		t.Fatalf("rebuild runtime: %v", err)
	}
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("restart runtime: %v", err)
	}
	h.runtime = rt
	h.server = httptest.NewServer(rt.HTTPHandler())
	h.contract = rt.ExportContract()
	h.schemas = map[string]*schema.TableSchema{}
	for _, table := range []string{"users", "projects", "tickets", "comments", "notifications", "audit_log"} {
		tableSchema, err := canaryclient.TableSchema(h.contract, table)
		if err != nil {
			t.Fatalf("schema %s after restart: %v", table, err)
		}
		h.schemas[table] = tableSchema
	}

	h.addCaller(t, "admin", app.PermAdminWrite, app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite, app.PermAuditRead)
	h.addCaller(t, "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	h.addCaller(t, "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCaller(t, "carol", app.PermCommentWrite)
	h.addCaller(t, "auditor", app.PermAuditRead)
	h.addCaller(t, "outsider")
}

func (h *workflowHarness) addCaller(t *testing.T, subject string, permissions ...string) {
	t.Helper()
	h.addCallerAs(t, subject, subject, permissions...)
}

func (h *workflowHarness) addCallerAs(t *testing.T, key, subject string, permissions ...string) {
	t.Helper()
	token, identity, err := canaryclient.MintStrictToken(subject, permissions...)
	if err != nil {
		t.Fatalf("mint %s token: %v", subject, err)
	}
	client := dialWorkflowClient(t, h.server.URL, token)
	h.callers[key] = &workflowCaller{subject: subject, token: token, identity: identity, client: client}
	requireWorkflowIdentity(t, client, identity)
}

func (h *workflowHarness) closeCaller(key string) {
	caller, ok := h.callers[key]
	if !ok {
		return
	}
	_ = caller.client.CloseNow()
	delete(h.callers, key)
}

func (h *workflowHarness) identities() map[string]string {
	out := make(map[string]string, len(h.callers))
	for subject, caller := range h.callers {
		out[subject] = caller.identity.Hex()
	}
	return out
}

func (h *workflowHarness) callReducer(t *testing.T, subject, reducer string, args any) protocol.TransactionUpdate {
	t.Helper()
	requestID := h.nextReq
	h.nextReq++
	c := h.callers[subject].client
	if err := c.CallReducer(reducer, args, requestID, protocol.CallReducerFlagsFullUpdate); err != nil {
		t.Fatalf("%s CallReducer %s: %v", subject, reducer, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, c)
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update := msg.(protocol.TransactionUpdate)
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		if failed, ok := update.Status.(protocol.StatusFailed); ok {
			t.Fatalf("%s reducer %s failed: %s", subject, reducer, failed.Error)
		}
		if _, ok := update.Status.(protocol.StatusCommitted); !ok {
			t.Fatalf("%s reducer %s status = %T, want StatusCommitted", subject, reducer, update.Status)
		}
		return update
	}
}

func (h *workflowHarness) callReducerFailed(t *testing.T, subject, reducer string, args any, want string) protocol.TransactionUpdate {
	t.Helper()
	requestID := h.nextReq
	h.nextReq++
	c := h.callers[subject].client
	if err := c.CallReducer(reducer, args, requestID, protocol.CallReducerFlagsFullUpdate); err != nil {
		t.Fatalf("%s CallReducer %s: %v", subject, reducer, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, c)
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update := msg.(protocol.TransactionUpdate)
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		failed, ok := update.Status.(protocol.StatusFailed)
		if !ok {
			t.Fatalf("%s reducer %s status = %T, want StatusFailed", subject, reducer, update.Status)
		}
		if want != "" && !strings.Contains(failed.Error, want) {
			t.Fatalf("%s reducer %s error = %q, want substring %q", subject, reducer, failed.Error, want)
		}
		return update
	}
}

func dialWorkflowClient(t *testing.T, runtimeURL, token string) *canaryclient.Client {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	c, err := canaryclient.Dial(ctx, runtimeURL, token)
	if err != nil {
		t.Fatalf("Dial returned error: %v", err)
	}
	return c
}

func readWorkflowMessage(t *testing.T, c *canaryclient.Client) (uint8, any) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	tag, msg, err := c.Read(ctx)
	if err != nil {
		t.Fatalf("Read returned error: %v", err)
	}
	return tag, msg
}

func requireWorkflowIdentity(t *testing.T, c *canaryclient.Client, want types.Identity) {
	t.Helper()
	tag, msg := readWorkflowMessage(t, c)
	if tag != protocol.TagIdentityToken {
		t.Fatalf("identity tag = %d, msg = %T, want IdentityToken", tag, msg)
	}
	identityToken, ok := msg.(protocol.IdentityToken)
	if !ok {
		t.Fatalf("identity msg = %T, want protocol.IdentityToken", msg)
	}
	if identityToken.Identity != want {
		t.Fatalf("identity = %x, want %x", identityToken.Identity, want)
	}
}

func requireRawUsers(t *testing.T, h *workflowHarness, subject, sql, messageID string) []model.User {
	t.Helper()
	if err := h.callers[subject].client.OneOff(sql, []byte(messageID)); err != nil {
		t.Fatalf("%s OneOff users: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "users", h.schemas["users"])
	if err != nil {
		t.Fatalf("decode users response: %v", err)
	}
	users, err := canaryclient.UsersFromRows(rows)
	if err != nil {
		t.Fatalf("UsersFromRows: %v", err)
	}
	return usersToModel(users)
}

func requireRawProjects(t *testing.T, h *workflowHarness, subject, sql, messageID string) []model.Project {
	t.Helper()
	if err := h.callers[subject].client.OneOff(sql, []byte(messageID)); err != nil {
		t.Fatalf("%s OneOff projects: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "projects", h.schemas["projects"])
	if err != nil {
		t.Fatalf("decode projects response: %v", err)
	}
	projects, err := canaryclient.ProjectsFromRows(rows)
	if err != nil {
		t.Fatalf("ProjectsFromRows: %v", err)
	}
	return projectsToModel(projects)
}

func requireRawTickets(t *testing.T, h *workflowHarness, subject, sql, messageID string) []model.Ticket {
	t.Helper()
	if err := h.callers[subject].client.OneOff(sql, []byte(messageID)); err != nil {
		t.Fatalf("%s OneOff tickets: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "tickets", h.schemas["tickets"])
	if err != nil {
		t.Fatalf("decode tickets response: %v", err)
	}
	tickets, err := canaryclient.TicketsFromRows(rows)
	if err != nil {
		t.Fatalf("TicketsFromRows: %v", err)
	}
	return ticketsToModel(tickets)
}

func requireRawComments(t *testing.T, h *workflowHarness, subject, sql, messageID string) []model.Comment {
	t.Helper()
	if err := h.callers[subject].client.OneOff(sql, []byte(messageID)); err != nil {
		t.Fatalf("%s OneOff comments: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "comments", h.schemas["comments"])
	if err != nil {
		t.Fatalf("decode comments response: %v", err)
	}
	comments, err := canaryclient.CommentsFromRows(rows)
	if err != nil {
		t.Fatalf("CommentsFromRows: %v", err)
	}
	return commentsToModel(comments)
}

func requireRawAudit(t *testing.T, h *workflowHarness, subject, sql, messageID string) []model.AuditEntry {
	t.Helper()
	if err := h.callers[subject].client.OneOff(sql, []byte(messageID)); err != nil {
		t.Fatalf("%s OneOff audit: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "audit_log", h.schemas["audit_log"])
	if err != nil {
		t.Fatalf("decode audit response: %v", err)
	}
	audit, err := canaryclient.AuditLogsFromRows(rows)
	if err != nil {
		t.Fatalf("AuditLogsFromRows: %v", err)
	}
	return auditToModel(audit)
}

func requireDeclaredUsers(t *testing.T, h *workflowHarness, subject, name, messageID string) []model.User {
	t.Helper()
	if err := h.callers[subject].client.DeclaredQuery(name, []byte(messageID)); err != nil {
		t.Fatalf("%s DeclaredQuery %s: %v", subject, name, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "users", h.schemas["users"])
	if err != nil {
		t.Fatalf("decode users response: %v", err)
	}
	users, err := canaryclient.UsersFromRows(rows)
	if err != nil {
		t.Fatalf("UsersFromRows: %v", err)
	}
	return usersToModel(users)
}

func requireDeclaredTickets(t *testing.T, h *workflowHarness, subject, name, messageID string) []model.Ticket {
	t.Helper()
	if err := h.callers[subject].client.DeclaredQuery(name, []byte(messageID)); err != nil {
		t.Fatalf("%s DeclaredQuery %s: %v", subject, name, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "tickets", h.schemas["tickets"])
	if err != nil {
		t.Fatalf("decode tickets response: %v", err)
	}
	tickets, err := canaryclient.TicketsFromRows(rows)
	if err != nil {
		t.Fatalf("TicketsFromRows: %v", err)
	}
	return ticketsToModel(tickets)
}

func requireDeclaredAudit(t *testing.T, h *workflowHarness, subject, name, messageID string) []model.AuditEntry {
	t.Helper()
	if err := h.callers[subject].client.DeclaredQuery(name, []byte(messageID)); err != nil {
		t.Fatalf("%s DeclaredQuery %s: %v", subject, name, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	rows, err := canaryclient.DecodeOneOffRows(resp, "audit_log", h.schemas["audit_log"])
	if err != nil {
		t.Fatalf("decode audit response: %v", err)
	}
	audit, err := canaryclient.AuditLogsFromRows(rows)
	if err != nil {
		t.Fatalf("AuditLogsFromRows: %v", err)
	}
	return auditToModel(audit)
}

func requireOneOffError(t *testing.T, h *workflowHarness, subject, sql, messageID, want string) {
	t.Helper()
	if err := h.callers[subject].client.OneOff(sql, []byte(messageID)); err != nil {
		t.Fatalf("%s OneOff error probe: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	if resp.Error == nil {
		t.Fatalf("%s OneOff %q succeeded, want error containing %q", subject, sql, want)
	}
	if want != "" && !strings.Contains(*resp.Error, want) {
		t.Fatalf("%s OneOff error = %q, want substring %q", subject, *resp.Error, want)
	}
}

func requireDeclaredError(t *testing.T, h *workflowHarness, subject, name, messageID, want string) {
	t.Helper()
	if err := h.callers[subject].client.DeclaredQuery(name, []byte(messageID)); err != nil {
		t.Fatalf("%s DeclaredQuery error probe: %v", subject, err)
	}
	resp := requireOneOffResponse(t, h.callers[subject].client, []byte(messageID))
	if resp.Error == nil {
		t.Fatalf("%s DeclaredQuery %q succeeded, want error containing %q", subject, name, want)
	}
	if want != "" && !strings.Contains(*resp.Error, want) {
		t.Fatalf("%s DeclaredQuery error = %q, want substring %q", subject, *resp.Error, want)
	}
}

func requireOneOffResponse(t *testing.T, c *canaryclient.Client, messageID []byte) protocol.OneOffQueryResponse {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, c)
		if tag != protocol.TagOneOffQueryResponse {
			continue
		}
		resp, ok := msg.(protocol.OneOffQueryResponse)
		if !ok {
			t.Fatalf("msg = %T, want protocol.OneOffQueryResponse", msg)
		}
		if !reflect.DeepEqual(resp.MessageID, messageID) {
			continue
		}
		return resp
	}
}

func requireNotificationSubscribeInitial(t *testing.T, h *workflowHarness, subject string, requestID, queryID uint32) []model.Notification {
	t.Helper()
	if err := h.callers[subject].client.SubscribeDeclaredView(app.ViewMyNotifications, requestID, queryID); err != nil {
		t.Fatalf("%s SubscribeDeclaredView my_notifications: %v", subject, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeSingleApplied)
		if !ok {
			t.Fatalf("msg = %T, want SubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		if applied.TableName != "notifications" {
			t.Fatalf("SubscribeSingleApplied table = %q, want notifications", applied.TableName)
		}
		rows, err := canaryclient.DecodeRows(applied.Rows, h.schemas["notifications"])
		if err != nil {
			t.Fatalf("decode notification subscribe rows: %v", err)
		}
		notifications, err := canaryclient.NotificationsFromRows(rows)
		if err != nil {
			t.Fatalf("NotificationsFromRows: %v", err)
		}
		return notificationsToModel(notifications)
	}
}

func requireTicketSubscribeInitial(t *testing.T, h *workflowHarness, subject, viewName string, requestID, queryID uint32) []model.Ticket {
	t.Helper()
	if err := h.callers[subject].client.SubscribeDeclaredView(viewName, requestID, queryID); err != nil {
		t.Fatalf("%s SubscribeDeclaredView %s: %v", subject, viewName, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeSingleApplied)
		if !ok {
			t.Fatalf("msg = %T, want SubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		if applied.TableName != "tickets" {
			t.Fatalf("SubscribeSingleApplied table = %q, want tickets", applied.TableName)
		}
		rows, err := canaryclient.DecodeRows(applied.Rows, h.schemas["tickets"])
		if err != nil {
			t.Fatalf("decode ticket subscribe rows: %v", err)
		}
		tickets, err := canaryclient.TicketsFromRows(rows)
		if err != nil {
			t.Fatalf("TicketsFromRows: %v", err)
		}
		return ticketsToModel(tickets)
	}
}

func requireRawTicketSubscribeInitial(t *testing.T, h *workflowHarness, subject, sql string, requestID, queryID uint32) []model.Ticket {
	t.Helper()
	if err := h.callers[subject].client.SubscribeSingle(sql, requestID, queryID); err != nil {
		t.Fatalf("%s SubscribeSingle %s: %v", subject, sql, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeSingleApplied)
		if !ok {
			t.Fatalf("msg = %T, want SubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		if applied.TableName != "tickets" {
			t.Fatalf("SubscribeSingleApplied table = %q, want tickets", applied.TableName)
		}
		rows, err := canaryclient.DecodeRows(applied.Rows, h.schemas["tickets"])
		if err != nil {
			t.Fatalf("decode raw ticket subscribe rows: %v", err)
		}
		tickets, err := canaryclient.TicketsFromRows(rows)
		if err != nil {
			t.Fatalf("TicketsFromRows: %v", err)
		}
		return ticketsToModel(tickets)
	}
}

func requireAuditSubscribeInitial(t *testing.T, h *workflowHarness, subject, viewName string, requestID, queryID uint32) []model.AuditEntry {
	t.Helper()
	if err := h.callers[subject].client.SubscribeDeclaredView(viewName, requestID, queryID); err != nil {
		t.Fatalf("%s SubscribeDeclaredView %s: %v", subject, viewName, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeSingleApplied)
		if !ok {
			t.Fatalf("msg = %T, want SubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		if applied.TableName != "audit_log" {
			t.Fatalf("SubscribeSingleApplied table = %q, want audit_log", applied.TableName)
		}
		rows, err := canaryclient.DecodeRows(applied.Rows, h.schemas["audit_log"])
		if err != nil {
			t.Fatalf("decode audit subscribe rows: %v", err)
		}
		audit, err := canaryclient.AuditLogsFromRows(rows)
		if err != nil {
			t.Fatalf("AuditLogsFromRows: %v", err)
		}
		return auditToModel(audit)
	}
}

func requireCommentSubscribeInitial(t *testing.T, h *workflowHarness, subject, viewName string, requestID, queryID uint32) []model.Comment {
	t.Helper()
	if err := h.callers[subject].client.SubscribeDeclaredView(viewName, requestID, queryID); err != nil {
		t.Fatalf("%s SubscribeDeclaredView %s: %v", subject, viewName, err)
	}
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeSingleApplied)
		if !ok {
			t.Fatalf("msg = %T, want SubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		if applied.TableName != "comments" {
			t.Fatalf("SubscribeSingleApplied table = %q, want comments", applied.TableName)
		}
		rows, err := canaryclient.DecodeRows(applied.Rows, h.schemas["comments"])
		if err != nil {
			t.Fatalf("decode comment subscribe rows: %v", err)
		}
		comments, err := canaryclient.CommentsFromRows(rows)
		if err != nil {
			t.Fatalf("CommentsFromRows: %v", err)
		}
		return commentsToModel(comments)
	}
}

func requireSubscriptionError(t *testing.T, h *workflowHarness, subject string, requestID, queryID uint32, want string) protocol.SubscriptionError {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscriptionError {
			continue
		}
		subErr, ok := msg.(protocol.SubscriptionError)
		if !ok {
			t.Fatalf("msg = %T, want SubscriptionError", msg)
		}
		if subErr.RequestID == nil || *subErr.RequestID != requestID || subErr.QueryID == nil || *subErr.QueryID != queryID {
			continue
		}
		if want != "" && !strings.Contains(subErr.Error, want) {
			t.Fatalf("subscription error = %q, want substring %q", subErr.Error, want)
		}
		return subErr
	}
}

func requireSubscribeMultiInitial(t *testing.T, h *workflowHarness, subject string, requestID, queryID uint32) []protocol.SubscriptionUpdate {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagSubscribeMultiApplied {
			continue
		}
		applied, ok := msg.(protocol.SubscribeMultiApplied)
		if !ok {
			t.Fatalf("msg = %T, want SubscribeMultiApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		return applied.Update
	}
}

func requireTicketUnsubscribeSingleApplied(t *testing.T, h *workflowHarness, subject string, requestID, queryID uint32) []model.Ticket {
	t.Helper()
	applied := requireUnsubscribeSingleApplied(t, h, subject, requestID, queryID)
	if !applied.HasRows {
		return nil
	}
	return decodeTicketPayload(t, h, applied.Rows)
}

func requireUnsubscribeSingleApplied(t *testing.T, h *workflowHarness, subject string, requestID, queryID uint32) protocol.UnsubscribeSingleApplied {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagUnsubscribeSingleApplied {
			continue
		}
		applied, ok := msg.(protocol.UnsubscribeSingleApplied)
		if !ok {
			t.Fatalf("msg = %T, want UnsubscribeSingleApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		return applied
	}
}

func requireUnsubscribeMultiApplied(t *testing.T, h *workflowHarness, subject string, requestID, queryID uint32) []protocol.SubscriptionUpdate {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagUnsubscribeMultiApplied {
			continue
		}
		applied, ok := msg.(protocol.UnsubscribeMultiApplied)
		if !ok {
			t.Fatalf("msg = %T, want UnsubscribeMultiApplied", msg)
		}
		if applied.RequestID != requestID || applied.QueryID != queryID {
			continue
		}
		return applied.Update
	}
}

func requireTicketDeltaIDs(t *testing.T, h *workflowHarness, subject string, queryID uint32, wantInserts, wantDeletes []uint64) []model.Ticket {
	t.Helper()
	for {
		inserts, deletes, ok := readTicketDelta(t, h, subject, queryID)
		if !ok {
			continue
		}
		assertEqual(t, subject+" ticket delta inserts", model.TicketIDs(inserts), wantInserts)
		assertEqual(t, subject+" ticket delta deletes", model.TicketIDs(deletes), wantDeletes)
		return inserts
	}
}

func requireNotificationDeltaIDs(t *testing.T, h *workflowHarness, subject string, queryID uint32, wantInserts, wantDeletes []uint64) []model.Notification {
	t.Helper()
	for {
		inserts, deletes, ok := readNotificationDelta(t, h, subject, queryID)
		if !ok {
			continue
		}
		assertEqual(t, subject+" notification delta inserts", model.NotificationIDs(inserts), wantInserts)
		assertEqual(t, subject+" notification delta deletes", model.NotificationIDs(deletes), wantDeletes)
		return inserts
	}
}

func requireAuditDeltaIDs(t *testing.T, h *workflowHarness, subject string, queryID uint32, wantInserts, wantDeletes []uint64) []model.AuditEntry {
	t.Helper()
	for {
		inserts, deletes, ok := readAuditDelta(t, h, subject, queryID)
		if !ok {
			continue
		}
		assertEqual(t, subject+" audit delta inserts", model.AuditIDs(inserts), wantInserts)
		assertEqual(t, subject+" audit delta deletes", model.AuditIDs(deletes), wantDeletes)
		return inserts
	}
}

func readTicketDelta(t *testing.T, h *workflowHarness, subject string, queryID uint32) ([]model.Ticket, []model.Ticket, bool) {
	t.Helper()
	updates := readSubscriptionUpdates(t, h.callers[subject].client)
	for _, update := range updates {
		if update.QueryID != queryID || update.TableName != "tickets" {
			continue
		}
		inserts := decodeTicketPayload(t, h, update.Inserts)
		deletes := decodeTicketPayload(t, h, update.Deletes)
		return inserts, deletes, true
	}
	return nil, nil, false
}

func readNotificationDelta(t *testing.T, h *workflowHarness, subject string, queryID uint32) ([]model.Notification, []model.Notification, bool) {
	t.Helper()
	updates := readSubscriptionUpdates(t, h.callers[subject].client)
	for _, update := range updates {
		if update.QueryID != queryID || update.TableName != "notifications" {
			continue
		}
		inserts := decodeNotificationPayload(t, h, update.Inserts)
		deletes := decodeNotificationPayload(t, h, update.Deletes)
		return inserts, deletes, true
	}
	return nil, nil, false
}

func readAuditDelta(t *testing.T, h *workflowHarness, subject string, queryID uint32) ([]model.AuditEntry, []model.AuditEntry, bool) {
	t.Helper()
	updates := readSubscriptionUpdates(t, h.callers[subject].client)
	for _, update := range updates {
		if update.QueryID != queryID || update.TableName != "audit_log" {
			continue
		}
		inserts := decodeAuditPayload(t, h, update.Inserts)
		deletes := decodeAuditPayload(t, h, update.Deletes)
		return inserts, deletes, true
	}
	return nil, nil, false
}

func readSubscriptionUpdates(t *testing.T, c *canaryclient.Client) []protocol.SubscriptionUpdate {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, c)
		switch tag {
		case protocol.TagTransactionUpdateLight:
			update, ok := msg.(protocol.TransactionUpdateLight)
			if !ok {
				t.Fatalf("msg = %T, want TransactionUpdateLight", msg)
			}
			return update.Update
		case protocol.TagTransactionUpdate:
			update, ok := msg.(protocol.TransactionUpdate)
			if !ok {
				t.Fatalf("msg = %T, want TransactionUpdate", msg)
			}
			committed, ok := update.Status.(protocol.StatusCommitted)
			if !ok {
				continue
			}
			return committed.Update
		}
	}
}

func decodeTicketPayload(t *testing.T, h *workflowHarness, payload []byte) []model.Ticket {
	t.Helper()
	if len(payload) == 0 {
		return nil
	}
	rows, err := canaryclient.DecodeRows(payload, h.schemas["tickets"])
	if err != nil {
		t.Fatalf("decode ticket delta rows: %v", err)
	}
	tickets, err := canaryclient.TicketsFromRows(rows)
	if err != nil {
		t.Fatalf("TicketsFromRows: %v", err)
	}
	return ticketsToModel(tickets)
}

func decodeNotificationPayload(t *testing.T, h *workflowHarness, payload []byte) []model.Notification {
	t.Helper()
	if len(payload) == 0 {
		return nil
	}
	rows, err := canaryclient.DecodeRows(payload, h.schemas["notifications"])
	if err != nil {
		t.Fatalf("decode notification delta rows: %v", err)
	}
	notifications, err := canaryclient.NotificationsFromRows(rows)
	if err != nil {
		t.Fatalf("NotificationsFromRows: %v", err)
	}
	return notificationsToModel(notifications)
}

func decodeCommentPayload(t *testing.T, h *workflowHarness, payload []byte) []model.Comment {
	t.Helper()
	if len(payload) == 0 {
		return nil
	}
	rows, err := canaryclient.DecodeRows(payload, h.schemas["comments"])
	if err != nil {
		t.Fatalf("decode comment delta rows: %v", err)
	}
	comments, err := canaryclient.CommentsFromRows(rows)
	if err != nil {
		t.Fatalf("CommentsFromRows: %v", err)
	}
	return commentsToModel(comments)
}

func decodeAuditPayload(t *testing.T, h *workflowHarness, payload []byte) []model.AuditEntry {
	t.Helper()
	if len(payload) == 0 {
		return nil
	}
	rows, err := canaryclient.DecodeRows(payload, h.schemas["audit_log"])
	if err != nil {
		t.Fatalf("decode audit delta rows: %v", err)
	}
	audit, err := canaryclient.AuditLogsFromRows(rows)
	if err != nil {
		t.Fatalf("AuditLogsFromRows: %v", err)
	}
	return auditToModel(audit)
}

func containsSubscriptionQuery(updates []protocol.SubscriptionUpdate, queryID uint32) bool {
	for _, update := range updates {
		if update.QueryID == queryID {
			return true
		}
	}
	return false
}

func requireNoMessage(t *testing.T, c *canaryclient.Client, wait time.Duration, label string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), wait)
	defer cancel()
	tag, msg, err := c.Read(ctx)
	if err != nil {
		return
	}
	t.Fatalf("%s received unexpected message tag=%d msg=%T", label, tag, msg)
}

func usersToModel(rows []canaryclient.UserRow) []model.User {
	out := make([]model.User, 0, len(rows))
	for _, row := range rows {
		out = append(out, model.User{ID: row.ID, Identity: row.Identity, Handle: row.Handle, DisplayName: row.DisplayName, Role: row.Role, Active: row.Active})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func projectsToModel(rows []canaryclient.ProjectRow) []model.Project {
	out := make([]model.Project, 0, len(rows))
	for _, row := range rows {
		out = append(out, model.Project{ID: row.ID, Slug: row.Slug, Name: row.Name, Visibility: row.Visibility, OwnerIdentity: row.OwnerIdentity, CreatedAtNS: row.CreatedAtNS})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func ticketsToModel(rows []canaryclient.TicketRow) []model.Ticket {
	out := make([]model.Ticket, 0, len(rows))
	for _, row := range rows {
		out = append(out, model.Ticket{
			ID:               row.ID,
			ProjectID:        row.ProjectID,
			Number:           row.Number,
			Title:            row.Title,
			Status:           row.Status,
			Priority:         row.Priority,
			Visibility:       row.Visibility,
			ReporterIdentity: row.ReporterIdentity,
			AssigneeIdentity: row.AssigneeIdentity,
			UpdatedAtNS:      row.UpdatedAtNS,
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func commentsToModel(rows []canaryclient.CommentRow) []model.Comment {
	out := make([]model.Comment, 0, len(rows))
	for _, row := range rows {
		out = append(out, model.Comment{ID: row.ID, TicketID: row.TicketID, ProjectID: row.ProjectID, AuthorIdentity: row.AuthorIdentity, Visibility: row.Visibility, Body: row.Body, CreatedAtNS: row.CreatedAtNS})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func notificationsToModel(rows []canaryclient.NotificationRow) []model.Notification {
	out := make([]model.Notification, 0, len(rows))
	for _, row := range rows {
		out = append(out, model.Notification{ID: row.ID, RecipientIdentity: row.RecipientIdentity, TicketID: row.TicketID, Kind: row.Kind, Body: row.Body, Delivered: row.Delivered, CreatedAtNS: row.CreatedAtNS})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func auditToModel(rows []canaryclient.AuditLogRow) []model.AuditEntry {
	out := make([]model.AuditEntry, 0, len(rows))
	for _, row := range rows {
		out = append(out, model.AuditEntry{ID: row.ID, ActorIdentity: row.ActorIdentity, Action: row.Action, TargetTable: row.TargetTable, TargetID: row.TargetID, Body: row.Body, CreatedAtNS: row.CreatedAtNS})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func assertEqual[T any](t *testing.T, label string, got, want T) {
	t.Helper()
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("%s = %#v, want %#v", label, got, want)
	}
}
