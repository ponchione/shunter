package workflows

import (
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestSchedulerWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	const bobNotificationsQuery uint32 = 901
	assertEqual(t, "bob my_notifications initial before live reminder",
		requireNotificationSubscribeInitial(t, h, "bob", 900, bobNotificationsQuery),
		h.model.VisibleNotifications(bob))

	firstReminder := model.ScheduleTicketReminderArgs{
		ID:                700,
		TicketID:          100,
		RecipientIdentity: bob,
		ScheduleID:        1,
		DelayMS:           50,
		NowNS:             1900,
	}
	h.callReducer(t, "alice", app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 firstReminder.ID,
		"ticket_id":          firstReminder.TicketID,
		"recipient_identity": firstReminder.RecipientIdentity,
		"delay_ms":           firstReminder.DelayMS,
		"now_ns":             firstReminder.NowNS,
	})
	if err := h.model.ScheduleTicketReminder(alice, firstReminder); err != nil {
		t.Fatalf("model schedule first reminder: %v", err)
	}
	if err := h.model.FireTicketReminder(firstReminder.ID); err != nil {
		t.Fatalf("model fire first reminder: %v", err)
	}
	firstFire := requireNotificationDeltaIDs(t, h, "bob", bobNotificationsQuery, []uint64{601}, []uint64{})
	assertEqual(t, "first reminder notification row", firstFire, []model.Notification{h.model.Notifications[601]})

	secondReminder := model.ScheduleTicketReminderArgs{
		ID:                701,
		TicketID:          100,
		RecipientIdentity: bob,
		ScheduleID:        2,
		DelayMS:           300,
		NowNS:             2000,
	}
	h.callReducer(t, "alice", app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 secondReminder.ID,
		"ticket_id":          secondReminder.TicketID,
		"recipient_identity": secondReminder.RecipientIdentity,
		"delay_ms":           secondReminder.DelayMS,
		"now_ns":             secondReminder.NowNS,
	})
	if err := h.model.ScheduleTicketReminder(alice, secondReminder); err != nil {
		t.Fatalf("model schedule second reminder: %v", err)
	}

	h.restart(t)

	const restartedBobNotificationsQuery uint32 = 903
	assertEqual(t, "bob my_notifications initial after scheduler restart",
		requireNotificationSubscribeInitial(t, h, "bob", 902, restartedBobNotificationsQuery),
		h.model.VisibleNotifications(bob))
	if err := h.model.FireTicketReminder(secondReminder.ID); err != nil {
		t.Fatalf("model fire second reminder: %v", err)
	}
	secondFire := requireNotificationDeltaIDs(t, h, "bob", restartedBobNotificationsQuery, []uint64{602}, []uint64{})
	assertEqual(t, "second reminder notification row", secondFire, []model.Notification{h.model.Notifications[602]})

	requireNoMessage(t, h.callers["bob"].client, 200*time.Millisecond, "bob after fired reminder duplicate window")
}

func TestSchedulerManualFireBeforeScheduledCallbackIsIdempotent(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	const bobNotificationsQuery uint32 = 911
	assertEqual(t, "bob notifications before manual reminder fire",
		requireNotificationSubscribeInitial(t, h, "bob", 910, bobNotificationsQuery),
		h.model.VisibleNotifications(bob))

	reminder := model.ScheduleTicketReminderArgs{
		ID:                720,
		TicketID:          100,
		RecipientIdentity: bob,
		ScheduleID:        1,
		DelayMS:           200,
		NowNS:             2900,
	}
	h.callReducer(t, "alice", app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 reminder.ID,
		"ticket_id":          reminder.TicketID,
		"recipient_identity": reminder.RecipientIdentity,
		"delay_ms":           reminder.DelayMS,
		"now_ns":             reminder.NowNS,
	})
	if err := h.model.ScheduleTicketReminder(alice, reminder); err != nil {
		t.Fatalf("model schedule manual-fire reminder: %v", err)
	}

	h.callReducer(t, "alice", app.ReducerFireTicketReminder, map[string]any{
		"reminder_id": reminder.ID,
	})
	if err := h.model.FireTicketReminder(reminder.ID); err != nil {
		t.Fatalf("model manual fire reminder: %v", err)
	}
	manualFire := requireNotificationDeltaIDs(t, h, "bob", bobNotificationsQuery, []uint64{601}, []uint64{})
	assertEqual(t, "manual reminder fire notification row", manualFire, []model.Notification{h.model.Notifications[601]})

	requireNoMessage(t, h.callers["bob"].client, 350*time.Millisecond, "bob after scheduled duplicate reminder callback")

	h.addCallerAs(t, "bob-after-manual-fire", "bob", app.PermTicketWrite, app.PermCommentWrite)
	assertEqual(t, "bob notifications after scheduled duplicate callback",
		requireNotificationSubscribeInitial(t, h, "bob-after-manual-fire", 912, 913),
		h.model.VisibleNotifications(bob))
	assertEqual(t, "audit after scheduled duplicate callback",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, "audit-after-manual-reminder-fire")),
		model.AuditIDs(h.model.AuditFeed(true)))
}
