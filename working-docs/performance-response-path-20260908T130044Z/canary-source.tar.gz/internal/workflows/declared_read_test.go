package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
)

func TestDeclaredReadWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	outsider := h.callers["outsider"].identity.Hex()

	assertEqual(t, "alice my_profile",
		requireDeclaredUsers(t, h, "alice", app.QueryMyProfile, "alice-profile"),
		h.model.MyProfile(alice))
	assertEqual(t, "bob my_tickets",
		requireDeclaredTickets(t, h, "bob", app.QueryMyTickets, "bob-my-tickets"),
		h.model.MyTickets(bob))
	assertEqual(t, "alice alpha_board",
		requireDeclaredTickets(t, h, "alice", app.QueryAlphaBoard, "alice-alpha-board"),
		h.model.AlphaBoard(alice))
	assertEqual(t, "outsider alpha_board",
		requireDeclaredTickets(t, h, "outsider", app.QueryAlphaBoard, "outsider-alpha-board"),
		h.model.AlphaBoard(outsider))
	assertEqual(t, "outsider ticket_100_detail",
		requireDeclaredTickets(t, h, "outsider", app.QueryTicket100Detail, "outsider-ticket-100"),
		h.model.Ticket100Detail(outsider))
	assertEqual(t, "alice ticket_100_detail",
		requireDeclaredTickets(t, h, "alice", app.QueryTicket100Detail, "alice-ticket-100"),
		h.model.Ticket100Detail(alice))

	assertEqual(t, "alice live_ticket_100_comments initial",
		requireCommentSubscribeInitial(t, h, "alice", app.ViewLiveTicket100Comments, 300, 301),
		h.model.Ticket100Comments(alice))
	assertEqual(t, "bob live_ticket_100_comments initial",
		requireCommentSubscribeInitial(t, h, "bob", app.ViewLiveTicket100Comments, 302, 303),
		h.model.Ticket100Comments(bob))

	requireOneOffError(t, h, "bob", "SELECT * FROM notifications WHERE recipient_identity = :sender", "bob-raw-my-notifications-denied", "")
}
