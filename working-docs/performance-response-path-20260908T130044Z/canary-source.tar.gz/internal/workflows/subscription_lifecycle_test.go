package workflows

import (
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestSubscriptionUnsubscribeLifecycleWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	admin := h.callers["admin"].identity.Hex()
	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	h.addCallerAs(t, "bob-old-board", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "alice-old-multi", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const oldBoardQuery uint32 = 1301
	assertEqual(t, "old bob board initial",
		requireTicketSubscribeInitial(t, h, "bob-old-board", app.ViewLiveAlphaBoard, 1300, oldBoardQuery),
		h.model.AlphaBoard(bob))

	if err := h.callers["bob-old-board"].client.UnsubscribeSingle(1302, oldBoardQuery); err != nil {
		t.Fatalf("bob old board UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "old bob board unsubscribe dropped rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-old-board", 1302, oldBoardQuery),
		h.model.AlphaBoard(bob))

	const oldMultiQuery uint32 = 1305
	if err := h.callers["alice-old-multi"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM comments",
	}, 1304, oldMultiQuery); err != nil {
		t.Fatalf("alice old multi SubscribeMulti: %v", err)
	}
	oldMultiInitial := requireSubscribeMultiInitial(t, h, "alice-old-multi", 1304, oldMultiQuery)
	assertMultiSnapshot(t, h, oldMultiInitial, oldMultiQuery, alice, false)

	if err := h.callers["alice-old-multi"].client.UnsubscribeMulti(1306, oldMultiQuery); err != nil {
		t.Fatalf("alice old multi UnsubscribeMulti: %v", err)
	}
	oldMultiDropped := requireUnsubscribeMultiApplied(t, h, "alice-old-multi", 1306, oldMultiQuery)
	assertMultiSnapshot(t, h, oldMultiDropped, oldMultiQuery, alice, true)

	firstTicket := model.CreateTicketArgs{
		ID:               130,
		ProjectID:        1,
		Number:           30,
		Title:            "Unsubscribe lifecycle snapshot ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: bob,
		NowNS:            4100,
	}
	h.callReducer(t, "admin", app.ReducerCreateTicket, map[string]any{
		"id":                firstTicket.ID,
		"project_id":        firstTicket.ProjectID,
		"number":            firstTicket.Number,
		"title":             firstTicket.Title,
		"priority":          firstTicket.Priority,
		"visibility":        firstTicket.Visibility,
		"assignee_identity": firstTicket.AssigneeIdentity,
		"now_ns":            firstTicket.NowNS,
	})
	if err := h.model.CreateTicket(admin, firstTicket); err != nil {
		t.Fatalf("model create first lifecycle ticket: %v", err)
	}

	h.addCallerAs(t, "bob-fresh-board", "bob", app.PermTicketWrite, app.PermCommentWrite)
	const freshBoardQuery uint32 = 1309
	assertEqual(t, "fresh bob board snapshot after old unsubscribe",
		requireTicketSubscribeInitial(t, h, "bob-fresh-board", app.ViewLiveAlphaBoard, 1308, freshBoardQuery),
		h.model.AlphaBoard(bob))

	secondTicket := model.CreateTicketArgs{
		ID:               131,
		ProjectID:        1,
		Number:           31,
		Title:            "Unsubscribe lifecycle delta ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            4200,
	}
	h.callReducer(t, "admin", app.ReducerCreateTicket, map[string]any{
		"id":                secondTicket.ID,
		"project_id":        secondTicket.ProjectID,
		"number":            secondTicket.Number,
		"title":             secondTicket.Title,
		"priority":          secondTicket.Priority,
		"visibility":        secondTicket.Visibility,
		"assignee_identity": secondTicket.AssigneeIdentity,
		"now_ns":            secondTicket.NowNS,
	})
	if err := h.model.CreateTicket(admin, secondTicket); err != nil {
		t.Fatalf("model create second lifecycle ticket: %v", err)
	}
	freshInsert := requireTicketDeltaIDs(t, h, "bob-fresh-board", freshBoardQuery, []uint64{131}, []uint64{})
	assertEqual(t, "fresh bob board delta after old unsubscribe", freshInsert, []model.Ticket{h.model.Tickets[131]})

	requireNoMessage(t, h.callers["bob-old-board"].client, 100*time.Millisecond, "old bob board after unsubscribe")
	requireNoMessage(t, h.callers["alice-old-multi"].client, 100*time.Millisecond, "old alice multi after unsubscribe")
}

func assertMultiSnapshot(t *testing.T, h *workflowHarness, updates []protocol.SubscriptionUpdate, queryID uint32, identity string, useDeletes bool) {
	t.Helper()
	gotTables := map[string]bool{}
	for _, update := range updates {
		if update.QueryID != queryID {
			t.Fatalf("multi update query id = %d, want %d", update.QueryID, queryID)
		}
		gotTables[update.TableName] = true
		ticketPayload := update.Inserts
		commentPayload := update.Inserts
		if useDeletes {
			ticketPayload = update.Deletes
			commentPayload = update.Deletes
		}
		switch update.TableName {
		case "tickets":
			assertEqual(t, "multi tickets snapshot", decodeTicketPayload(t, h, ticketPayload), h.model.VisibleTickets(identity))
		case "comments":
			assertEqual(t, "multi comments snapshot", decodeCommentPayload(t, h, commentPayload), h.model.VisibleComments(identity))
		default:
			t.Fatalf("unexpected multi table %q", update.TableName)
		}
	}
	assertEqual(t, "multi snapshot tables", gotTables, map[string]bool{"tickets": true, "comments": true})
}
