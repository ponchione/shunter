package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestSubscriptionWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	carol := h.callers["carol"].identity.Hex()

	const bobBoardQuery uint32 = 401
	assertEqual(t, "bob live_alpha_board initial",
		requireTicketSubscribeInitial(t, h, "bob", app.ViewLiveAlphaBoard, 400, bobBoardQuery),
		h.model.AlphaBoard(bob))

	createTicket := model.CreateTicketArgs{
		ID:               101,
		ProjectID:        1,
		Number:           3,
		Title:            "Investigate failed webhook",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            1300,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create ticket: %v", err)
	}
	bobInsert := requireTicketDeltaIDs(t, h, "bob", bobBoardQuery, []uint64{101}, []uint64{})
	assertEqual(t, "bob ticket insert row", bobInsert, []model.Ticket{h.model.Tickets[101]})

	const carolBoardQuery uint32 = 403
	assertEqual(t, "carol live_alpha_board initial before assignment",
		requireTicketSubscribeInitial(t, h, "carol", app.ViewLiveAlphaBoard, 402, carolBoardQuery),
		h.model.AlphaBoard(carol))

	assignTicket := model.AssignTicketArgs{TicketID: 101, AssigneeIdentity: carol, NowNS: 1400}
	h.callReducer(t, "alice", app.ReducerAssignTicket, map[string]any{
		"ticket_id":         assignTicket.TicketID,
		"assignee_identity": assignTicket.AssigneeIdentity,
		"now_ns":            assignTicket.NowNS,
	})
	if err := h.model.AssignTicket(alice, assignTicket); err != nil {
		t.Fatalf("model assign ticket: %v", err)
	}
	requireTicketDeltaIDs(t, h, "bob", bobBoardQuery, []uint64{}, []uint64{101})
	carolInsert := requireTicketDeltaIDs(t, h, "carol", carolBoardQuery, []uint64{101}, []uint64{})
	assertEqual(t, "carol ticket insert row", carolInsert, []model.Ticket{h.model.Tickets[101]})

	const bobNotificationsQuery uint32 = 501
	assertEqual(t, "bob my_notifications after assignment",
		requireNotificationSubscribeInitial(t, h, "bob", 500, bobNotificationsQuery),
		h.model.VisibleNotifications(bob))

	const carolNotificationsQuery uint32 = 503
	assertEqual(t, "carol my_notifications after assignment",
		requireNotificationSubscribeInitial(t, h, "carol", 502, carolNotificationsQuery),
		h.model.VisibleNotifications(carol))

	addComment := model.AddCommentArgs{ID: 502, TicketID: 101, Visibility: "internal", Body: "Looking now", NowNS: 1600}
	h.callReducer(t, "alice", app.ReducerAddComment, map[string]any{
		"id":         addComment.ID,
		"ticket_id":  addComment.TicketID,
		"visibility": addComment.Visibility,
		"body":       addComment.Body,
		"now_ns":     addComment.NowNS,
	})
	if err := h.model.AddComment(alice, addComment); err != nil {
		t.Fatalf("model add comment: %v", err)
	}
	carolNotificationInsert := requireNotificationDeltaIDs(t, h, "carol", carolNotificationsQuery, []uint64{603}, []uint64{})
	assertEqual(t, "carol notification insert row", carolNotificationInsert, []model.Notification{h.model.Notifications[603]})

	h.addCallerAs(t, "bob-check", "bob", app.PermTicketWrite, app.PermCommentWrite)
	assertEqual(t, "bob my_notifications after comment",
		requireNotificationSubscribeInitial(t, h, "bob-check", 504, 505),
		h.model.VisibleNotifications(bob))
}
