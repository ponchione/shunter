package workflows

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter"
)

func TestBackupRestoreAndMigrationWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	createTicket := model.CreateTicketArgs{
		ID:               130,
		ProjectID:        1,
		Number:           30,
		Title:            "Backup restore migration ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            3100,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create ticket: %v", err)
	}

	addComment := model.AddCommentArgs{ID: 530, TicketID: 130, Visibility: "internal", Body: "Operational proof note", NowNS: 3200}
	h.callReducer(t, "bob", app.ReducerAddComment, map[string]any{
		"id":         addComment.ID,
		"ticket_id":  addComment.TicketID,
		"visibility": addComment.Visibility,
		"body":       addComment.Body,
		"now_ns":     addComment.NowNS,
	})
	if err := h.model.AddComment(bob, addComment); err != nil {
		t.Fatalf("model add comment: %v", err)
	}

	sourceDataDir := h.dataDir
	h.close(t)

	backupDir := filepath.Join(t.TempDir(), "backup")
	if err := shunter.BackupDataDir(sourceDataDir, backupDir); err != nil {
		t.Fatalf("BackupDataDir returned error: %v", err)
	}
	restoreDir := filepath.Join(t.TempDir(), "restored")
	if err := shunter.RestoreDataDir(backupDir, restoreDir); err != nil {
		t.Fatalf("RestoreDataDir returned error: %v", err)
	}

	migratingModule := app.NewModule().MigrationHook(app.OperationalProofMigration)
	result, err := shunter.RunModuleDataDirMigrations(context.Background(), migratingModule, shunter.Config{DataDir: restoreDir})
	if err != nil {
		t.Fatalf("RunModuleDataDirMigrations returned error: %v", err)
	}
	if len(result.Hooks) != 2 || result.Hooks[0].Changed || !result.Hooks[1].Changed {
		t.Fatalf("migration result hooks = %#v, want unchanged allocator initialization and changed proof hook", result.Hooks)
	}
	secondResult, err := shunter.RunModuleDataDirMigrations(context.Background(), migratingModule, shunter.Config{DataDir: restoreDir})
	if err != nil {
		t.Fatalf("second RunModuleDataDirMigrations returned error: %v", err)
	}
	if len(secondResult.Hooks) != 2 || secondResult.Hooks[0].Changed || secondResult.Hooks[1].Changed {
		t.Fatalf("second migration result hooks = %#v, want two unchanged idempotent hooks", secondResult.Hooks)
	}

	restored := newWorkflowHarnessWithBootstrap(t, restoreDir, false)
	assertEqual(t, "users after restore",
		requireRawUsers(t, restored, "alice", "SELECT * FROM users", "users-after-restore"),
		h.model.AllUsers())
	assertEqual(t, "projects after restore",
		requireRawProjects(t, restored, "alice", "SELECT * FROM projects", "projects-after-restore"),
		h.model.AllProjects())
	assertEqual(t, "alice tickets after restore",
		requireRawTickets(t, restored, "alice", "SELECT * FROM tickets", "alice-tickets-after-restore"),
		h.model.VisibleTickets(alice))
	assertEqual(t, "bob comments after restore",
		requireRawComments(t, restored, "bob", "SELECT * FROM comments", "bob-comments-after-restore"),
		h.model.VisibleComments(bob))
	assertEqual(t, "bob my_tickets after restore",
		requireDeclaredTickets(t, restored, "bob", app.QueryMyTickets, "bob-my-tickets-after-restore"),
		h.model.MyTickets(bob))
	assertEqual(t, "bob live_alpha_board initial after restore",
		requireTicketSubscribeInitial(t, restored, "bob", app.ViewLiveAlphaBoard, 1200, 1201),
		h.model.AlphaBoard(bob))

	audit := requireDeclaredAudit(t, restored, "auditor", app.QueryAuditFeed, "audit-after-migration")
	if !containsAuditAction(audit, app.MigrationOperationalProofAction) {
		t.Fatalf("audit feed missing migration action %q; got %#v", app.MigrationOperationalProofAction, model.AuditIDs(audit))
	}
	if countAuditAction(audit, app.MigrationOperationalProofAction) != 1 {
		t.Fatalf("audit feed contains duplicate migration action %q", app.MigrationOperationalProofAction)
	}
	requireOneOffError(t, restored, "outsider", "SELECT * FROM audit_log", "outsider-audit-after-migration", "")
}

func containsAuditAction(rows []model.AuditEntry, action string) bool {
	return countAuditAction(rows, action) > 0
}

func countAuditAction(rows []model.AuditEntry, action string) int {
	var count int
	for _, row := range rows {
		if strings.EqualFold(row.Action, action) {
			count++
		}
	}
	return count
}
