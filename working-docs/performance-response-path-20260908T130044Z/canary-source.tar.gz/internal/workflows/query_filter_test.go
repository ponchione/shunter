package workflows

import (
	"fmt"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestRawQueryPredicateWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()
	carol := h.callers["carol"].identity.Hex()
	outsider := h.callers["outsider"].identity.Hex()

	publicTicket := model.CreateTicketArgs{
		ID:               140,
		ProjectID:        1,
		Number:           40,
		Title:            "Raw query public predicate ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: bob,
		NowNS:            5100,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                publicTicket.ID,
		"project_id":        publicTicket.ProjectID,
		"number":            publicTicket.Number,
		"title":             publicTicket.Title,
		"priority":          publicTicket.Priority,
		"visibility":        publicTicket.Visibility,
		"assignee_identity": publicTicket.AssigneeIdentity,
		"now_ns":            publicTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, publicTicket); err != nil {
		t.Fatalf("model create public ticket: %v", err)
	}

	internalTicket := model.CreateTicketArgs{
		ID:               141,
		ProjectID:        1,
		Number:           41,
		Title:            "Raw query internal predicate ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: carol,
		NowNS:            5200,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                internalTicket.ID,
		"project_id":        internalTicket.ProjectID,
		"number":            internalTicket.Number,
		"title":             internalTicket.Title,
		"priority":          internalTicket.Priority,
		"visibility":        internalTicket.Visibility,
		"assignee_identity": internalTicket.AssigneeIdentity,
		"now_ns":            internalTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, internalTicket); err != nil {
		t.Fatalf("model create internal ticket: %v", err)
	}

	internalComment := model.AddCommentArgs{ID: 520, TicketID: 141, Visibility: "internal", Body: "Internal raw query predicate comment", NowNS: 5300}
	h.callReducer(t, "carol", app.ReducerAddComment, map[string]any{
		"id":         internalComment.ID,
		"ticket_id":  internalComment.TicketID,
		"visibility": internalComment.Visibility,
		"body":       internalComment.Body,
		"now_ns":     internalComment.NowNS,
	})
	if err := h.model.AddComment(carol, internalComment); err != nil {
		t.Fatalf("model add internal comment: %v", err)
	}

	publicComment := model.AddCommentArgs{ID: 521, TicketID: 141, Visibility: "public", Body: "Public raw query predicate comment", NowNS: 5400}
	h.callReducer(t, "bob", app.ReducerAddComment, map[string]any{
		"id":         publicComment.ID,
		"ticket_id":  publicComment.TicketID,
		"visibility": publicComment.Visibility,
		"body":       publicComment.Body,
		"now_ns":     publicComment.NowNS,
	})
	if err := h.model.AddComment(bob, publicComment); err != nil {
		t.Fatalf("model add public comment: %v", err)
	}

	assertEqual(t, "project slug predicate",
		requireRawProjects(t, h, "alice", "SELECT * FROM projects WHERE slug = 'alpha'", "query-project-slug-alpha"),
		filterProjects(h.model.AllProjects(), func(row model.Project) bool { return row.Slug == "alpha" }))

	assertEqual(t, "outsider project ticket predicate keeps visibility",
		requireRawTickets(t, h, "outsider", "SELECT * FROM tickets WHERE project_id = 1", "query-outsider-project-tickets"),
		filterTickets(h.model.VisibleTickets(outsider), func(row model.Ticket) bool { return row.ProjectID == 1 }))

	assertEqual(t, "bob assignee predicate",
		requireRawTickets(t, h, "bob", fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob), "query-bob-assignee"),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.AssigneeIdentity == bob }))

	assertEqual(t, "bob reporter predicate",
		requireRawTickets(t, h, "bob", fmt.Sprintf("SELECT * FROM tickets WHERE reporter_identity = '%s'", bob), "query-bob-reporter"),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.ReporterIdentity == bob }))

	assertEqual(t, "alice cannot see bob internal reporter predicate row",
		requireRawTickets(t, h, "alice", fmt.Sprintf("SELECT * FROM tickets WHERE reporter_identity = '%s'", bob), "query-alice-bob-reporter"),
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.ReporterIdentity == bob }))

	assertEqual(t, "compound project number predicate",
		requireRawTickets(t, h, "outsider", "SELECT * FROM tickets WHERE project_id = 1 AND number = 40", "query-project-number"),
		filterTickets(h.model.VisibleTickets(outsider), func(row model.Ticket) bool { return row.ProjectID == 1 && row.Number == 40 }))

	assertEqual(t, "carol comment ticket predicate",
		requireRawComments(t, h, "carol", "SELECT * FROM comments WHERE ticket_id = 141", "query-carol-ticket-comments"),
		filterComments(h.model.VisibleComments(carol), func(row model.Comment) bool { return row.TicketID == 141 }))

	assertEqual(t, "bob comment ticket predicate keeps visibility",
		requireRawComments(t, h, "bob", "SELECT * FROM comments WHERE ticket_id = 141", "query-bob-ticket-comments"),
		filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.TicketID == 141 }))

	assertEqual(t, "carol author predicate",
		requireRawComments(t, h, "carol", fmt.Sprintf("SELECT * FROM comments WHERE author_identity = '%s'", carol), "query-carol-author-comments"),
		filterComments(h.model.VisibleComments(carol), func(row model.Comment) bool { return row.AuthorIdentity == carol }))

	assertEqual(t, "bob cannot see carol internal author predicate row",
		requireRawComments(t, h, "bob", fmt.Sprintf("SELECT * FROM comments WHERE author_identity = '%s'", carol), "query-bob-carol-author-comments"),
		filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.AuthorIdentity == carol }))

	assertEqual(t, "audit target table predicate",
		model.AuditIDs(requireRawAudit(t, h, "auditor", "SELECT * FROM audit_log WHERE target_table = 'tickets'", "query-audit-ticket-targets")),
		model.AuditIDs(filterAudit(h.model.AuditFeed(true), func(row model.AuditEntry) bool { return row.TargetTable == "tickets" })))

	assertEqual(t, "audit actor predicate",
		model.AuditIDs(requireRawAudit(t, h, "auditor", fmt.Sprintf("SELECT * FROM audit_log WHERE actor_identity = '%s'", bob), "query-audit-bob-actor")),
		model.AuditIDs(filterAudit(h.model.AuditFeed(true), func(row model.AuditEntry) bool { return row.ActorIdentity == bob })))
}

func filterProjects(rows []model.Project, keep func(model.Project) bool) []model.Project {
	out := []model.Project{}
	for _, row := range rows {
		if keep(row) {
			out = append(out, row)
		}
	}
	return out
}

func filterTickets(rows []model.Ticket, keep func(model.Ticket) bool) []model.Ticket {
	out := []model.Ticket{}
	for _, row := range rows {
		if keep(row) {
			out = append(out, row)
		}
	}
	return out
}

func filterComments(rows []model.Comment, keep func(model.Comment) bool) []model.Comment {
	out := []model.Comment{}
	for _, row := range rows {
		if keep(row) {
			out = append(out, row)
		}
	}
	return out
}

func filterAudit(rows []model.AuditEntry, keep func(model.AuditEntry) bool) []model.AuditEntry {
	out := []model.AuditEntry{}
	for _, row := range rows {
		if keep(row) {
			out = append(out, row)
		}
	}
	return out
}
