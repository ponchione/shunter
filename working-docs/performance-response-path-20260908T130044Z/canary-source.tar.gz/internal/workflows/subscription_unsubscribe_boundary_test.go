package workflows

import (
	"fmt"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestUnknownAndStaleUnsubscribeWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.addCallerAs(t, "bob-unsub-boundary", "bob", app.PermTicketWrite, app.PermCommentWrite)

	const queryID uint32 = 2101
	if err := h.callers["bob-unsub-boundary"].client.UnsubscribeSingle(2100, queryID); err != nil {
		t.Fatalf("bob unknown UnsubscribeSingle: %v", err)
	}
	requireSubscriptionError(t, h, "bob-unsub-boundary", 2100, queryID, "subscription not found")

	if err := h.callers["bob-unsub-boundary"].client.UnsubscribeMulti(2102, queryID+1); err != nil {
		t.Fatalf("bob unknown UnsubscribeMulti: %v", err)
	}
	requireSubscriptionError(t, h, "bob-unsub-boundary", 2102, queryID+1, "subscription not found")

	assertEqual(t, "bob subscribe after unknown unsubscribe",
		requireRawTicketSubscribeInitial(t, h, "bob-unsub-boundary", "SELECT * FROM tickets WHERE visibility = 'public'", 2103, queryID),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-unsub-boundary"].client.UnsubscribeSingle(2104, queryID); err != nil {
		t.Fatalf("bob first UnsubscribeSingle: %v", err)
	}
	assertEqual(t, "bob first unsubscribe deletes public rows",
		requireTicketUnsubscribeSingleApplied(t, h, "bob-unsub-boundary", 2104, queryID),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-unsub-boundary"].client.UnsubscribeSingle(2105, queryID); err != nil {
		t.Fatalf("bob stale UnsubscribeSingle: %v", err)
	}
	requireSubscriptionError(t, h, "bob-unsub-boundary", 2105, queryID, "subscription not found")

	if err := h.callers["bob-unsub-boundary"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets WHERE visibility = 'public'",
		"SELECT * FROM comments WHERE visibility = 'public'",
	}, 2106, queryID); err != nil {
		t.Fatalf("bob subscribe multi after stale single unsubscribe: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "bob-unsub-boundary", 2106, queryID), queryID,
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-unsub-boundary"].client.UnsubscribeMulti(2107, queryID); err != nil {
		t.Fatalf("bob first UnsubscribeMulti: %v", err)
	}
	assertMultiFilteredDeletes(t, h, requireUnsubscribeMultiApplied(t, h, "bob-unsub-boundary", 2107, queryID), queryID,
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(bob), func(row model.Comment) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-unsub-boundary"].client.UnsubscribeMulti(2108, queryID); err != nil {
		t.Fatalf("bob stale UnsubscribeMulti: %v", err)
	}
	requireSubscriptionError(t, h, "bob-unsub-boundary", 2108, queryID, "subscription not found")

	assertEqual(t, "bob subscribe after stale multi unsubscribe",
		requireRawTicketSubscribeInitial(t, h, "bob-unsub-boundary", fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob), 2109, queryID),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.AssigneeIdentity == bob }))
}

func TestWrongVariantUnsubscribeWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	h.addCallerAs(t, "bob-wrong-unsub-single", "bob", app.PermTicketWrite, app.PermCommentWrite)

	const singleQuery uint32 = 2111
	assertEqual(t, "bob single before wrong-variant unsubscribe",
		requireRawTicketSubscribeInitial(t, h, "bob-wrong-unsub-single", "SELECT * FROM tickets WHERE visibility = 'public'", 2110, singleQuery),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	if err := h.callers["bob-wrong-unsub-single"].client.UnsubscribeMulti(2112, singleQuery); err != nil {
		t.Fatalf("bob UnsubscribeMulti against single query: %v", err)
	}
	assertSingleTableMultiDeletes(t, h, requireUnsubscribeMultiApplied(t, h, "bob-wrong-unsub-single", 2112, singleQuery), singleQuery,
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.Visibility == "public" }))

	assertEqual(t, "bob reuse after multi unsubscribe against single query",
		requireRawTicketSubscribeInitial(t, h, "bob-wrong-unsub-single", fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", bob), 2113, singleQuery),
		filterTickets(h.model.VisibleTickets(bob), func(row model.Ticket) bool { return row.AssigneeIdentity == bob }))

	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               230,
		ProjectID:        1,
		Number:           130,
		Title:            "Wrong variant old single public ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            15100,
	})
	createTicketForWorkflow(t, h, "alice", model.CreateTicketArgs{
		ID:               231,
		ProjectID:        1,
		Number:           131,
		Title:            "Wrong variant reused single assignee ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            15200,
	})
	reusedSingleInsert := requireTicketDeltaIDs(t, h, "bob-wrong-unsub-single", singleQuery, []uint64{231}, []uint64{})
	assertEqual(t, "bob wrong-variant single reuse insert", reusedSingleInsert, []model.Ticket{h.model.Tickets[231]})

	h.addCallerAs(t, "alice-wrong-unsub-multi", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const multiQuery uint32 = 2121
	if err := h.callers["alice-wrong-unsub-multi"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets WHERE visibility = 'public'",
		"SELECT * FROM comments WHERE visibility = 'public'",
	}, 2120, multiQuery); err != nil {
		t.Fatalf("alice multi before wrong-variant unsubscribe: %v", err)
	}
	assertMultiFilteredSnapshot(t, h, requireSubscribeMultiInitial(t, h, "alice-wrong-unsub-multi", 2120, multiQuery), multiQuery,
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }),
		filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.Visibility == "public" }))

	if err := h.callers["alice-wrong-unsub-multi"].client.UnsubscribeSingle(2122, multiQuery); err != nil {
		t.Fatalf("alice UnsubscribeSingle against multi query: %v", err)
	}
	assertWrongVariantSingleUnsubscribeApplied(t, requireUnsubscribeSingleApplied(t, h, "alice-wrong-unsub-multi", 2122, multiQuery),
		len(filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.Visibility == "public" }))+
			len(filterComments(h.model.VisibleComments(alice), func(row model.Comment) bool { return row.Visibility == "public" })))

	assertEqual(t, "alice reuse after single unsubscribe against multi query",
		requireRawTicketSubscribeInitial(t, h, "alice-wrong-unsub-multi", fmt.Sprintf("SELECT * FROM tickets WHERE assignee_identity = '%s'", alice), 2123, multiQuery),
		filterTickets(h.model.VisibleTickets(alice), func(row model.Ticket) bool { return row.AssigneeIdentity == alice }))

	addCommentForWorkflow(t, h, "bob", model.AddCommentArgs{
		ID:         530,
		TicketID:   100,
		Visibility: "public",
		Body:       "Wrong variant old multi public comment",
		NowNS:      15300,
	})
	createTicketForWorkflow(t, h, "bob", model.CreateTicketArgs{
		ID:               232,
		ProjectID:        1,
		Number:           132,
		Title:            "Wrong variant reused multi as single ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            15400,
	})
	updates := readSubscriptionUpdates(t, h.callers["alice-wrong-unsub-multi"].client)
	reusedMultiAsSingleInsert := requireTicketUpdateFromUpdates(t, h, updates, multiQuery, []uint64{232}, []uint64{})
	assertEqual(t, "alice wrong-variant multi reuse insert", reusedMultiAsSingleInsert, []model.Ticket{h.model.Tickets[232]})
	assertNoTableUpdate(t, updates, multiQuery, "comments", "wrong-variant multi reused as single")
}

func assertSingleTableMultiDeletes(t *testing.T, h *workflowHarness, updates []protocol.SubscriptionUpdate, queryID uint32, wantTickets []model.Ticket) {
	t.Helper()
	if len(updates) != 1 {
		t.Fatalf("single-query multi unsubscribe updates = %#v, want one tickets update", updates)
	}
	update := updates[0]
	if update.QueryID != queryID || update.TableName != "tickets" {
		t.Fatalf("single-query multi unsubscribe update = %#v, want query %d tickets", update, queryID)
	}
	assertEqual(t, "single-query multi unsubscribe ticket deletes", decodeTicketPayload(t, h, update.Deletes), wantTickets)
	if got := decodeTicketPayload(t, h, update.Inserts); len(got) != 0 {
		t.Fatalf("single-query multi unsubscribe inserts = %#v, want none", got)
	}
}

func assertWrongVariantSingleUnsubscribeApplied(t *testing.T, applied protocol.UnsubscribeSingleApplied, wantRows int) {
	t.Helper()
	if applied.QueryID == 0 || !applied.HasRows {
		t.Fatalf("wrong-variant single unsubscribe applied = %+v, want rows", applied)
	}
	rows, err := protocol.DecodeRowList(applied.Rows)
	if err != nil {
		t.Fatalf("decode wrong-variant single unsubscribe rows: %v", err)
	}
	if len(rows) != wantRows {
		t.Fatalf("wrong-variant single unsubscribe row count = %d, want %d", len(rows), wantRows)
	}
}
