package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestAuthVisibilityWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	outsider := h.callers["outsider"].identity.Hex()
	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	assertEqual(t, "outsider raw visible tickets",
		requireRawTickets(t, h, "outsider", "SELECT * FROM tickets", "outsider-tickets"),
		h.model.VisibleTickets(outsider))
	assertEqual(t, "alice raw visible tickets",
		requireRawTickets(t, h, "alice", "SELECT * FROM tickets", "alice-tickets"),
		h.model.VisibleTickets(alice))
	assertEqual(t, "bob raw visible tickets",
		requireRawTickets(t, h, "bob", "SELECT * FROM tickets", "bob-tickets"),
		h.model.VisibleTickets(bob))

	assertEqual(t, "auditor raw audit feed",
		model.AuditIDs(requireRawAudit(t, h, "auditor", "SELECT * FROM audit_log", "auditor-audit")),
		model.AuditIDs(h.model.AuditFeed(true)))
	requireOneOffError(t, h, "alice", "SELECT * FROM audit_log", "alice-audit-denied", "")
	requireOneOffError(t, h, "alice", "SELECT * FROM notifications", "alice-notifications-denied", "private")

	assertEqual(t, "bob my_notifications initial",
		requireNotificationSubscribeInitial(t, h, "bob", 200, 201),
		h.model.VisibleNotifications(bob))

	requireDeclaredError(t, h, "alice", app.QueryAuditFeed, "alice-audit-feed-denied", "permission")
	assertEqual(t, "auditor declared audit feed",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, "auditor-audit-feed")),
		model.AuditIDs(h.model.AuditFeed(true)))
	requireDeclaredError(t, h, "auditor", "SELECT * FROM audit_log", "unknown-declared-read", "unknown")
}
