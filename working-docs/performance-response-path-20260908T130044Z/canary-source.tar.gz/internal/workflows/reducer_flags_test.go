package workflows

import (
	"strings"
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestReducerNoSuccessNotifyWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	h.addCallerAs(t, "bob-flag-board", "bob", app.PermTicketWrite, app.PermCommentWrite)
	h.addCallerAs(t, "alice-fire-and-forget", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const bobBoardQuery uint32 = 1701
	assertEqual(t, "bob board before no-success reducer",
		requireTicketSubscribeInitial(t, h, "bob-flag-board", app.ViewLiveAlphaBoard, 1700, bobBoardQuery),
		h.model.AlphaBoard(bob))

	createTicket := model.CreateTicketArgs{
		ID:               195,
		ProjectID:        1,
		Number:           95,
		Title:            "No success notify ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            10100,
	}
	if err := h.callers["alice-fire-and-forget"].client.CallReducer(app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	}, 1702, protocol.CallReducerFlagsNoSuccessNotify); err != nil {
		t.Fatalf("alice no-success create_ticket: %v", err)
	}
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create no-success ticket: %v", err)
	}

	bobInsert := requireTicketDeltaIDs(t, h, "bob-flag-board", bobBoardQuery, []uint64{195}, []uint64{})
	assertEqual(t, "bob received no-success reducer fanout", bobInsert, []model.Ticket{h.model.Tickets[195]})
	requireNoMessage(t, h.callers["alice-fire-and-forget"].client, 100*time.Millisecond, "alice fire-and-forget caller")

	h.addCallerAs(t, "alice-no-success-failure", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)
	if err := h.callers["alice-no-success-failure"].client.CallReducer(app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": uint64(195),
		"status":    "invalid_flag_status",
		"now_ns":    int64(10200),
	}, 1703, protocol.CallReducerFlagsNoSuccessNotify); err != nil {
		t.Fatalf("alice no-success failed status call: %v", err)
	}
	requireReducerFailureForRequest(t, h, "alice-no-success-failure", 1703, "invalid")

	assertEqual(t, "bob tickets after no-success failed reducer",
		requireRawTickets(t, h, "bob", "SELECT * FROM tickets", "bob-tickets-after-no-success-failure"),
		h.model.VisibleTickets(bob))
	assertEqual(t, "audit after no-success failed reducer",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, "audit-after-no-success-failure")),
		model.AuditIDs(h.model.AuditFeed(true)))
}

func requireReducerFailureForRequest(t *testing.T, h *workflowHarness, subject string, requestID uint32, want string) {
	t.Helper()
	for {
		tag, msg := readWorkflowMessage(t, h.callers[subject].client)
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update, ok := msg.(protocol.TransactionUpdate)
		if !ok {
			t.Fatalf("msg = %T, want TransactionUpdate", msg)
		}
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		failed, ok := update.Status.(protocol.StatusFailed)
		if !ok {
			t.Fatalf("reducer request %d status = %T, want StatusFailed", requestID, update.Status)
		}
		if want != "" && !strings.Contains(failed.Error, want) {
			t.Fatalf("reducer request %d error = %q, want substring %q", requestID, failed.Error, want)
		}
		return
	}
}
