package workflows

import (
	"strings"
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestRejectedReducerWorkflowPreservesState(t *testing.T) {
	h := newWorkflowHarness(t)

	assertRejectedState(t, h, "initial")

	h.callReducerFailed(t, "outsider", app.ReducerCreateTicket, map[string]any{
		"id":                9000,
		"project_id":        1,
		"number":            9000,
		"title":             "unauthorized ticket",
		"priority":          "normal",
		"visibility":        "public",
		"assignee_identity": "",
		"now_ns":            int64(9000),
	}, "permission")
	assertRejectedState(t, h, "after unauthorized create_ticket")

	h.callReducerFailed(t, "alice", app.ReducerCreateProject, map[string]any{
		"id":         20,
		"slug":       "missing visibility",
		"name":       "Missing Visibility",
		"visibility": "restricted",
		"now_ns":     int64(9010),
	}, "visibility")
	assertRejectedState(t, h, "after invalid project visibility")

	h.callReducerFailed(t, "alice", app.ReducerCreateProject, map[string]any{
		"id":         1,
		"slug":       "alpha-duplicate-id",
		"name":       "Duplicate ID",
		"visibility": "public",
		"now_ns":     int64(9020),
	}, "")
	assertRejectedState(t, h, "after duplicate project id")

	h.callReducerFailed(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                9001,
		"project_id":        404,
		"number":            9001,
		"title":             "missing project",
		"priority":          "normal",
		"visibility":        "public",
		"assignee_identity": "",
		"now_ns":            int64(9030),
	}, "project 404 not found")
	assertRejectedState(t, h, "after missing project create_ticket")

	h.callReducerFailed(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                9002,
		"project_id":        1,
		"number":            1,
		"title":             "duplicate project number",
		"priority":          "high",
		"visibility":        "internal",
		"assignee_identity": h.callers["alice"].identity.Hex(),
		"now_ns":            int64(9040),
	}, "")
	assertRejectedState(t, h, "after duplicate ticket project number")

	h.callReducerFailed(t, "bob", app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": uint64(100),
		"status":    "triaged",
		"now_ns":    int64(9050),
	}, "status")
	assertRejectedState(t, h, "after invalid ticket status")

	h.callReducerFailed(t, "bob", app.ReducerAssignTicket, map[string]any{
		"ticket_id":         uint64(404),
		"assignee_identity": h.callers["alice"].identity.Hex(),
		"now_ns":            int64(9060),
	}, "ticket 404 not found")
	assertRejectedState(t, h, "after missing ticket assignment")

	h.callReducerFailed(t, "carol", app.ReducerAddComment, map[string]any{
		"id":         uint64(9003),
		"ticket_id":  uint64(404),
		"visibility": "public",
		"body":       "missing ticket comment",
		"now_ns":     int64(9070),
	}, "ticket 404 not found")
	assertRejectedState(t, h, "after missing ticket comment")

	h.callReducerFailed(t, "bob", app.ReducerScheduleTicketReminder, map[string]any{
		"id":                 uint64(9004),
		"ticket_id":          uint64(100),
		"recipient_identity": h.callers["bob"].identity.Hex(),
		"delay_ms":           int64(0),
		"now_ns":             int64(9080),
	}, "delay_ms")
	assertRejectedState(t, h, "after invalid reminder delay")

	requireOneOffError(t, h, "alice", "SELECT * FROM project_members", "alice-project-members-denied", "private")
	requireOneOffError(t, h, "bob", "SELECT * FROM ticket_reminders", "bob-ticket-reminders-denied", "private")
	assertRejectedState(t, h, "after private table read probes")
}

func TestPermissionDeniedReducerCallRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.callReducerFailed(t, "bob", app.ReducerCreateProject, map[string]any{
		"id":         uint64(21),
		"slug":       "bob-denied-project",
		"name":       "Bob Denied Project",
		"visibility": "public",
		"now_ns":     int64(12400),
	}, "permission")

	created := model.CreateTicketArgs{
		ID:               198,
		ProjectID:        1,
		Number:           98,
		Title:            "Reducer permission recovery ticket",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            12410,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                created.ID,
		"project_id":        created.ProjectID,
		"number":            created.Number,
		"title":             created.Title,
		"priority":          created.Priority,
		"visibility":        created.Visibility,
		"assignee_identity": created.AssigneeIdentity,
		"now_ns":            created.NowNS,
	})
	if err := h.model.CreateTicket(bob, created); err != nil {
		t.Fatalf("model create reducer recovery ticket: %v", err)
	}

	assertEqual(t, "bob tickets after reducer permission recovery",
		requireRawTickets(t, h, "bob", "SELECT * FROM tickets", "bob-tickets-after-reducer-permission-recovery"),
		h.model.VisibleTickets(bob))
}

func TestMissingReducerCallRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	h.callReducerFailed(t, "alice", "missing_reducer", map[string]any{}, "reducer not found")

	created := model.CreateTicketArgs{
		ID:               199,
		ProjectID:        1,
		Number:           99,
		Title:            "Missing reducer recovery ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            12420,
	}
	h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                created.ID,
		"project_id":        created.ProjectID,
		"number":            created.Number,
		"title":             created.Title,
		"priority":          created.Priority,
		"visibility":        created.Visibility,
		"assignee_identity": created.AssigneeIdentity,
		"now_ns":            created.NowNS,
	})
	if err := h.model.CreateTicket(alice, created); err != nil {
		t.Fatalf("model create missing reducer recovery ticket: %v", err)
	}

	assertEqual(t, "alice tickets after missing reducer recovery",
		requireRawTickets(t, h, "alice", "SELECT * FROM tickets", "alice-tickets-after-missing-reducer-recovery"),
		h.model.VisibleTickets(alice))
}

func TestAppReducerValidationFailureRecovers(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	h.callReducerFailed(t, "bob", app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": uint64(100),
		"status":    "triaged",
		"now_ns":    int64(12600),
	}, "status")

	change := model.ChangeTicketStatusArgs{
		TicketID: 100,
		Status:   "blocked",
		NowNS:    12610,
	}
	h.callReducer(t, "bob", app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": change.TicketID,
		"status":    change.Status,
		"now_ns":    change.NowNS,
	})
	if err := h.model.ChangeTicketStatus(bob, change); err != nil {
		t.Fatalf("model change ticket status after validation recovery: %v", err)
	}

	assertEqual(t, "bob tickets after reducer validation recovery",
		requireRawTickets(t, h, "bob", "SELECT * FROM tickets", "bob-tickets-after-reducer-validation-recovery"),
		h.model.VisibleTickets(bob))
}

func assertRejectedState(t *testing.T, h *workflowHarness, label string) {
	t.Helper()
	assertEqual(t, label+" projects",
		requireRawProjects(t, h, "alice", "SELECT * FROM projects", messageID(label, "projects")),
		h.model.AllProjects())

	for _, subject := range []string{"alice", "bob", "carol", "outsider"} {
		identity := h.callers[subject].identity.Hex()
		assertEqual(t, label+" visible tickets for "+subject,
			requireRawTickets(t, h, subject, "SELECT * FROM tickets", messageID(label, subject+"-tickets")),
			h.model.VisibleTickets(identity))
		assertEqual(t, label+" visible comments for "+subject,
			requireRawComments(t, h, subject, "SELECT * FROM comments", messageID(label, subject+"-comments")),
			h.model.VisibleComments(identity))
	}

	assertEqual(t, label+" audit ids",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor", app.QueryAuditFeed, messageID(label, "audit"))),
		model.AuditIDs(h.model.AuditFeed(true)))
}

func messageID(parts ...string) string {
	return strings.Join(parts, ":")
}
