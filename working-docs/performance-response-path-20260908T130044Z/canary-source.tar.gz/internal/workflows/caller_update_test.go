package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestCallerFullTransactionUpdateIncludesOwnSubscriptionDeltas(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	const liveBoardQuery uint32 = 1801
	assertEqual(t, "alice caller live board initial",
		requireTicketSubscribeInitial(t, h, "alice", app.ViewLiveAlphaBoard, 1800, liveBoardQuery),
		h.model.AlphaBoard(alice))

	const multiQuery uint32 = 1803
	if err := h.callers["alice"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM comments",
	}, 1802, multiQuery); err != nil {
		t.Fatalf("alice caller SubscribeMulti: %v", err)
	}
	assertMultiSnapshot(t, h, requireSubscribeMultiInitial(t, h, "alice", 1802, multiQuery), multiQuery, alice, false)

	createTicket := model.CreateTicketArgs{
		ID:               196,
		ProjectID:        1,
		Number:           96,
		Title:            "Caller full update ticket",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: bob,
		NowNS:            11100,
	}
	update := h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create caller full update ticket: %v", err)
	}

	updates := committedUpdates(t, update)
	liveBoardInsert := requireTicketUpdateFromUpdates(t, h, updates, liveBoardQuery, []uint64{196}, []uint64{})
	assertEqual(t, "caller live board committed update row", liveBoardInsert, []model.Ticket{h.model.Tickets[196]})
	multiTicketInsert := requireTicketUpdateFromUpdates(t, h, updates, multiQuery, []uint64{196}, []uint64{})
	assertEqual(t, "caller multi ticket committed update row", multiTicketInsert, []model.Ticket{h.model.Tickets[196]})
	assertNoTableUpdate(t, updates, multiQuery, "comments", "caller create_ticket committed update")

	addComment := model.AddCommentArgs{ID: 596, TicketID: 196, Visibility: "internal", Body: "Caller full update comment", NowNS: 11200}
	update = h.callReducer(t, "alice", app.ReducerAddComment, map[string]any{
		"id":         addComment.ID,
		"ticket_id":  addComment.TicketID,
		"visibility": addComment.Visibility,
		"body":       addComment.Body,
		"now_ns":     addComment.NowNS,
	})
	if err := h.model.AddComment(alice, addComment); err != nil {
		t.Fatalf("model add caller full update comment: %v", err)
	}

	updates = committedUpdates(t, update)
	assertNoSubscriptionQuery(t, updates, liveBoardQuery, "caller live board after comment")
	assertNoTableUpdate(t, updates, multiQuery, "tickets", "caller add_comment committed update")
	commentInsert := requireCommentUpdateFromUpdates(t, h, updates, multiQuery, []uint64{596}, []uint64{})
	assertEqual(t, "caller multi comment committed update row", commentInsert, []model.Comment{h.model.Comments[596]})
}

func committedUpdates(t *testing.T, update protocol.TransactionUpdate) []protocol.SubscriptionUpdate {
	t.Helper()
	committed, ok := update.Status.(protocol.StatusCommitted)
	if !ok {
		t.Fatalf("transaction status = %T, want StatusCommitted", update.Status)
	}
	return committed.Update
}
