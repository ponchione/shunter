package workflows

import (
	"testing"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
	"github.com/ponchione/shunter/protocol"
)

func TestSubscribeMultiAtomicWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)
	alice := h.callers["alice"].identity.Hex()

	const failedReq uint32 = 600
	const failedQuery uint32 = 601
	if err := h.callers["alice"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM project_members",
	}, failedReq, failedQuery); err != nil {
		t.Fatalf("alice SubscribeMulti failure probe: %v", err)
	}
	requireSubscriptionError(t, h, "alice", failedReq, failedQuery, "project_members")

	createTicket := model.CreateTicketArgs{
		ID:         102,
		ProjectID:  1,
		Number:     4,
		Title:      "Atomic subscribe probe",
		Priority:   "normal",
		Visibility: "internal",
		NowNS:      1310,
	}
	update := h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": "",
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(alice, createTicket); err != nil {
		t.Fatalf("model create ticket: %v", err)
	}
	committed, ok := update.Status.(protocol.StatusCommitted)
	if !ok {
		t.Fatalf("create_ticket status = %T, want StatusCommitted", update.Status)
	}
	if containsSubscriptionQuery(committed.Update, failedQuery) {
		t.Fatalf("failed SubscribeMulti query %d still received reducer delta: %#v", failedQuery, committed.Update)
	}

	const goodReq uint32 = 602
	const goodQuery uint32 = 603
	if err := h.callers["alice"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM comments",
	}, goodReq, goodQuery); err != nil {
		t.Fatalf("alice SubscribeMulti recovery probe: %v", err)
	}
	updates := requireSubscribeMultiInitial(t, h, "alice", goodReq, goodQuery)
	gotTables := map[string]bool{}
	for _, update := range updates {
		if update.QueryID != goodQuery {
			t.Fatalf("SubscribeMulti update query id = %d, want %d", update.QueryID, goodQuery)
		}
		gotTables[update.TableName] = true
		switch update.TableName {
		case "tickets":
			assertEqual(t, "recovered SubscribeMulti tickets",
				decodeTicketPayload(t, h, update.Inserts),
				h.model.VisibleTickets(alice))
		case "comments":
			assertEqual(t, "recovered SubscribeMulti comments",
				decodeCommentPayload(t, h, update.Inserts),
				h.model.VisibleComments(alice))
		default:
			t.Fatalf("unexpected SubscribeMulti table %q", update.TableName)
		}
	}
	assertEqual(t, "recovered SubscribeMulti tables", gotTables, map[string]bool{"tickets": true, "comments": true})
}

func TestSubscribeMultiAuditAdmissionFailureWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)
	outsider := h.callers["outsider"].identity.Hex()

	const failedReq uint32 = 604
	const failedQuery uint32 = 605
	if err := h.callers["outsider"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM audit_log",
	}, failedReq, failedQuery); err != nil {
		t.Fatalf("outsider SubscribeMulti audit admission probe: %v", err)
	}
	requireSubscriptionError(t, h, "outsider", failedReq, failedQuery, "audit_log")

	createTicket := model.CreateTicketArgs{
		ID:               103,
		ProjectID:        1,
		Number:           5,
		Title:            "Audit admission multi probe",
		Priority:         "normal",
		Visibility:       "public",
		AssigneeIdentity: "",
		NowNS:            1320,
	}
	update := h.callReducer(t, "alice", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(h.callers["alice"].identity.Hex(), createTicket); err != nil {
		t.Fatalf("model create audit admission multi ticket: %v", err)
	}
	committed, ok := update.Status.(protocol.StatusCommitted)
	if !ok {
		t.Fatalf("create_ticket status = %T, want StatusCommitted", update.Status)
	}
	if containsSubscriptionQuery(committed.Update, failedQuery) {
		t.Fatalf("audit-admission-failed SubscribeMulti query %d received reducer delta: %#v", failedQuery, committed.Update)
	}

	const goodReq uint32 = 606
	const goodQuery uint32 = 607
	if err := h.callers["outsider"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM comments",
	}, goodReq, goodQuery); err != nil {
		t.Fatalf("outsider SubscribeMulti recovery probe: %v", err)
	}
	updates := requireSubscribeMultiInitial(t, h, "outsider", goodReq, goodQuery)
	gotTables := map[string]bool{}
	for _, update := range updates {
		if update.QueryID != goodQuery {
			t.Fatalf("SubscribeMulti update query id = %d, want %d", update.QueryID, goodQuery)
		}
		gotTables[update.TableName] = true
		switch update.TableName {
		case "tickets":
			assertEqual(t, "audit admission recovery SubscribeMulti tickets",
				decodeTicketPayload(t, h, update.Inserts),
				h.model.VisibleTickets(outsider))
		case "comments":
			assertEqual(t, "audit admission recovery SubscribeMulti comments",
				decodeCommentPayload(t, h, update.Inserts),
				h.model.VisibleComments(outsider))
		default:
			t.Fatalf("unexpected SubscribeMulti table %q", update.TableName)
		}
	}
	assertEqual(t, "audit admission recovery SubscribeMulti tables", gotTables, map[string]bool{"tickets": true, "comments": true})
}

func TestSubscribeMultiLiveDeltaWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	alice := h.callers["alice"].identity.Hex()
	bob := h.callers["bob"].identity.Hex()

	h.addCallerAs(t, "alice-live-multi", "alice", app.PermProjectWrite, app.PermTicketWrite, app.PermCommentWrite)

	const requestID uint32 = 610
	const queryID uint32 = 611
	if err := h.callers["alice-live-multi"].client.SubscribeMulti([]string{
		"SELECT * FROM tickets",
		"SELECT * FROM comments",
	}, requestID, queryID); err != nil {
		t.Fatalf("alice live SubscribeMulti: %v", err)
	}
	assertMultiSnapshot(t, h, requireSubscribeMultiInitial(t, h, "alice-live-multi", requestID, queryID), queryID, alice, false)

	createTicket := model.CreateTicketArgs{
		ID:               106,
		ProjectID:        1,
		Number:           6,
		Title:            "Live multi ticket insert",
		Priority:         "high",
		Visibility:       "internal",
		AssigneeIdentity: alice,
		NowNS:            1810,
	}
	h.callReducer(t, "bob", app.ReducerCreateTicket, map[string]any{
		"id":                createTicket.ID,
		"project_id":        createTicket.ProjectID,
		"number":            createTicket.Number,
		"title":             createTicket.Title,
		"priority":          createTicket.Priority,
		"visibility":        createTicket.Visibility,
		"assignee_identity": createTicket.AssigneeIdentity,
		"now_ns":            createTicket.NowNS,
	})
	if err := h.model.CreateTicket(bob, createTicket); err != nil {
		t.Fatalf("model create live multi ticket: %v", err)
	}
	updates := readSubscriptionUpdates(t, h.callers["alice-live-multi"].client)
	ticketInsert := requireTicketUpdateFromUpdates(t, h, updates, queryID, []uint64{106}, []uint64{})
	assertEqual(t, "live multi ticket insert row", ticketInsert, []model.Ticket{h.model.Tickets[106]})
	assertNoTableUpdate(t, updates, queryID, "comments", "ticket insert transaction")

	addComment := model.AddCommentArgs{ID: 506, TicketID: 100, Visibility: "internal", Body: "Live multi comment insert", NowNS: 1820}
	h.callReducer(t, "alice", app.ReducerAddComment, map[string]any{
		"id":         addComment.ID,
		"ticket_id":  addComment.TicketID,
		"visibility": addComment.Visibility,
		"body":       addComment.Body,
		"now_ns":     addComment.NowNS,
	})
	if err := h.model.AddComment(alice, addComment); err != nil {
		t.Fatalf("model add live multi comment: %v", err)
	}
	updates = readSubscriptionUpdates(t, h.callers["alice-live-multi"].client)
	assertNoTableUpdate(t, updates, queryID, "tickets", "comment insert transaction")
	commentInsert := requireCommentUpdateFromUpdates(t, h, updates, queryID, []uint64{506}, []uint64{})
	assertEqual(t, "live multi comment insert row", commentInsert, []model.Comment{h.model.Comments[506]})

	status := model.ChangeTicketStatusArgs{TicketID: 106, Status: "blocked", NowNS: 1830}
	h.callReducer(t, "bob", app.ReducerChangeTicketStatus, map[string]any{
		"ticket_id": status.TicketID,
		"status":    status.Status,
		"now_ns":    status.NowNS,
	})
	if err := h.model.ChangeTicketStatus(bob, status); err != nil {
		t.Fatalf("model change live multi ticket status: %v", err)
	}
	updates = readSubscriptionUpdates(t, h.callers["alice-live-multi"].client)
	ticketUpdate := requireTicketUpdateFromUpdates(t, h, updates, queryID, []uint64{106}, []uint64{106})
	assertEqual(t, "live multi ticket update row", ticketUpdate, []model.Ticket{h.model.Tickets[106]})
	assertNoTableUpdate(t, updates, queryID, "comments", "ticket update transaction")
}

func requireCommentUpdateFromUpdates(t *testing.T, h *workflowHarness, updates []protocol.SubscriptionUpdate, queryID uint32, wantInserts, wantDeletes []uint64) []model.Comment {
	t.Helper()
	for _, update := range updates {
		if update.QueryID != queryID || update.TableName != "comments" {
			continue
		}
		inserts := decodeCommentPayload(t, h, update.Inserts)
		deletes := decodeCommentPayload(t, h, update.Deletes)
		assertEqual(t, "comment update inserts", model.CommentIDs(inserts), wantInserts)
		assertEqual(t, "comment update deletes", model.CommentIDs(deletes), wantDeletes)
		return inserts
	}
	t.Fatalf("missing comment subscription update for query %d in %#v", queryID, updates)
	return nil
}

func assertNoTableUpdate(t *testing.T, updates []protocol.SubscriptionUpdate, queryID uint32, tableName, label string) {
	t.Helper()
	for _, update := range updates {
		if update.QueryID == queryID && update.TableName == tableName {
			t.Fatalf("%s unexpectedly received %s update: %#v", label, tableName, updates)
		}
	}
}
