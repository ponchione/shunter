package workflows

import (
	"testing"
	"time"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/opsboard-canary/internal/model"
)

func TestRollbackWorkflow(t *testing.T) {
	h := newWorkflowHarness(t)

	bob := h.callers["bob"].identity.Hex()
	outsider := h.callers["outsider"].identity.Hex()

	const auditQuery uint32 = 701
	assertEqual(t, "auditor live_audit_feed initial",
		model.AuditIDs(requireAuditSubscribeInitial(t, h, "auditor", app.ViewLiveAuditFeed, 700, auditQuery)),
		model.AuditIDs(h.model.AuditFeed(true)))

	h.callReducerFailed(t, "admin", app.ReducerFailAfterAuditProbe, map[string]any{}, "forced rollback")
	requireNoMessage(t, h.callers["auditor"].client, 100*time.Millisecond, "auditor after failed audit probe")
	h.addCallerAs(t, "auditor-check", "auditor", app.PermAuditRead)
	assertEqual(t, "audit feed after failed probe",
		model.AuditIDs(requireDeclaredAudit(t, h, "auditor-check", app.QueryAuditFeed, "audit-after-fail-probe")),
		model.AuditIDs(h.model.AuditFeed(true)))

	const bobBoardQuery uint32 = 703
	assertEqual(t, "bob live_alpha_board initial before panic",
		requireTicketSubscribeInitial(t, h, "bob", app.ViewLiveAlphaBoard, 702, bobBoardQuery),
		h.model.AlphaBoard(bob))

	h.callReducerFailed(t, "admin", app.ReducerPanicAfterTicketProbe, map[string]any{}, app.ReducerPanicAfterTicketProbe)
	requireNoMessage(t, h.callers["bob"].client, 100*time.Millisecond, "bob after panic ticket probe")
	assertEqual(t, "outsider tickets after panic probe",
		requireRawTickets(t, h, "outsider", "SELECT * FROM tickets", "outsider-tickets-after-panic"),
		h.model.VisibleTickets(outsider))
}
