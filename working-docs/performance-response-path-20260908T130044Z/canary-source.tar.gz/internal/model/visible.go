package model

import "sort"

func (s *State) AllUsers() []User {
	out := make([]User, 0, len(s.Users))
	for _, row := range s.Users {
		out = append(out, row)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) AllProjects() []Project {
	out := make([]Project, 0, len(s.Projects))
	for _, row := range s.Projects {
		out = append(out, row)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) VisibleTickets(caller string) []Ticket {
	out := []Ticket{}
	for _, row := range s.Tickets {
		if row.Visibility == "public" || row.ReporterIdentity == caller || row.AssigneeIdentity == caller {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) VisibleComments(caller string) []Comment {
	out := []Comment{}
	for _, row := range s.Comments {
		if row.Visibility == "public" || row.AuthorIdentity == caller {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) VisibleNotifications(caller string) []Notification {
	out := []Notification{}
	for _, row := range s.Notifications {
		if row.RecipientIdentity == caller {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) MyProfile(caller string) []User {
	out := []User{}
	for _, row := range s.Users {
		if row.Identity == caller {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) MyTickets(caller string) []Ticket {
	out := []Ticket{}
	for _, row := range s.VisibleTickets(caller) {
		if row.AssigneeIdentity == caller {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) AlphaBoard(caller string) []Ticket {
	out := []Ticket{}
	for _, row := range s.VisibleTickets(caller) {
		if row.ProjectID == 1 {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) Ticket100Detail(caller string) []Ticket {
	out := []Ticket{}
	for _, row := range s.VisibleTickets(caller) {
		if row.ID == 100 {
			out = append(out, row)
		}
	}
	return out
}

func (s *State) Ticket100Comments(caller string) []Comment {
	out := []Comment{}
	for _, row := range s.VisibleComments(caller) {
		if row.TicketID == 100 {
			out = append(out, row)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (s *State) AuditFeed(canRead bool) []AuditEntry {
	if !canRead {
		return nil
	}
	out := make([]AuditEntry, 0, len(s.AuditLog))
	for _, row := range s.AuditLog {
		out = append(out, row)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func TicketIDs(rows []Ticket) []uint64 {
	out := make([]uint64, len(rows))
	for i, row := range rows {
		out[i] = row.ID
	}
	return out
}

func CommentIDs(rows []Comment) []uint64 {
	out := make([]uint64, len(rows))
	for i, row := range rows {
		out[i] = row.ID
	}
	return out
}

func NotificationIDs(rows []Notification) []uint64 {
	out := make([]uint64, len(rows))
	for i, row := range rows {
		out[i] = row.ID
	}
	return out
}

func AuditIDs(rows []AuditEntry) []uint64 {
	out := make([]uint64, len(rows))
	for i, row := range rows {
		out[i] = row.ID
	}
	return out
}
