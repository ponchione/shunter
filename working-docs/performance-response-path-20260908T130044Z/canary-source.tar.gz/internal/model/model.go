package model

type State struct {
	Users         map[uint64]User
	Projects      map[uint64]Project
	Members       map[uint64]ProjectMember
	Tickets       map[uint64]Ticket
	Comments      map[uint64]Comment
	Notifications map[uint64]Notification
	AuditLog      map[uint64]AuditEntry
	Reminders     map[uint64]Reminder
}

type User struct {
	ID          uint64
	Identity    string
	Handle      string
	DisplayName string
	Role        string
	Active      bool
}

type Project struct {
	ID            uint64
	Slug          string
	Name          string
	Visibility    string
	OwnerIdentity string
	CreatedAtNS   int64
}

type ProjectMember struct {
	ID           uint64
	ProjectID    uint64
	UserIdentity string
	Role         string
	CreatedAtNS  int64
}

type Ticket struct {
	ID               uint64
	ProjectID        uint64
	Number           uint64
	Title            string
	Status           string
	Priority         string
	Visibility       string
	ReporterIdentity string
	AssigneeIdentity string
	UpdatedAtNS      int64
}

type Comment struct {
	ID             uint64
	TicketID       uint64
	ProjectID      uint64
	AuthorIdentity string
	Visibility     string
	Body           string
	CreatedAtNS    int64
}

type Notification struct {
	ID                uint64
	RecipientIdentity string
	TicketID          uint64
	Kind              string
	Body              string
	Delivered         bool
	CreatedAtNS       int64
}

type AuditEntry struct {
	ID            uint64
	ActorIdentity string
	Action        string
	TargetTable   string
	TargetID      uint64
	Body          string
	CreatedAtNS   int64
}

type Reminder struct {
	ID                uint64
	TicketID          uint64
	RecipientIdentity string
	ScheduleID        uint64
	DueAtNS           int64
	Fired             bool
}

func New() *State {
	return &State{
		Users:         map[uint64]User{},
		Projects:      map[uint64]Project{},
		Members:       map[uint64]ProjectMember{},
		Tickets:       map[uint64]Ticket{},
		Comments:      map[uint64]Comment{},
		Notifications: map[uint64]Notification{},
		AuditLog:      map[uint64]AuditEntry{},
		Reminders:     map[uint64]Reminder{},
	}
}
