package model

import "fmt"

const (
	ReducerBootstrapDemo          = "bootstrap_demo"
	ReducerCreateProject          = "create_project"
	ReducerAddProjectMember       = "add_project_member"
	ReducerCreateTicket           = "create_ticket"
	ReducerAssignTicket           = "assign_ticket"
	ReducerChangeTicketStatus     = "change_ticket_status"
	ReducerAddComment             = "add_comment"
	ReducerCloseTicket            = "close_ticket"
	ReducerReopenTicket           = "reopen_ticket"
	ReducerFireTicketReminder     = "fire_ticket_reminder"
	ReducerScheduleTicketReminder = "schedule_ticket_reminder"
)

type CreateProjectArgs struct {
	ID         uint64
	Slug       string
	Name       string
	Visibility string
	NowNS      int64
}

type AddProjectMemberArgs struct {
	ID           uint64
	ProjectID    uint64
	UserIdentity string
	Role         string
	NowNS        int64
}

type CreateTicketArgs struct {
	ID               uint64
	ProjectID        uint64
	Number           uint64
	Title            string
	Priority         string
	Visibility       string
	AssigneeIdentity string
	NowNS            int64
}

type AssignTicketArgs struct {
	TicketID         uint64
	AssigneeIdentity string
	NowNS            int64
}

type ChangeTicketStatusArgs struct {
	TicketID uint64
	Status   string
	NowNS    int64
}

type AddCommentArgs struct {
	ID         uint64
	TicketID   uint64
	Visibility string
	Body       string
	NowNS      int64
}

type ScheduleTicketReminderArgs struct {
	ID                uint64
	TicketID          uint64
	RecipientIdentity string
	ScheduleID        uint64
	DelayMS           int64
	NowNS             int64
}

func (s *State) BootstrapDemo(identities map[string]string, nowNS int64) error {
	if len(s.Users) != 0 || len(s.Projects) != 0 || len(s.Tickets) != 0 {
		return fmt.Errorf("%s has already been applied", ReducerBootstrapDemo)
	}
	s.Users[1] = User{ID: 1, Identity: identities["admin"], Handle: "admin", DisplayName: "Admin", Role: "admin", Active: true}
	s.Users[2] = User{ID: 2, Identity: identities["alice"], Handle: "alice", DisplayName: "Alice", Role: "operator", Active: true}
	s.Users[3] = User{ID: 3, Identity: identities["bob"], Handle: "bob", DisplayName: "Bob", Role: "operator", Active: true}
	s.Users[4] = User{ID: 4, Identity: identities["carol"], Handle: "carol", DisplayName: "Carol", Role: "operator", Active: true}
	s.Users[5] = User{ID: 5, Identity: identities["auditor"], Handle: "auditor", DisplayName: "Auditor", Role: "auditor", Active: true}
	s.Users[6] = User{ID: 6, Identity: identities["outsider"], Handle: "outsider", DisplayName: "Outsider", Role: "viewer", Active: true}

	s.Projects[1] = Project{ID: 1, Slug: "alpha", Name: "Alpha", Visibility: "internal", OwnerIdentity: identities["admin"], CreatedAtNS: nowNS}
	s.Members[1] = ProjectMember{ID: 1, ProjectID: 1, UserIdentity: identities["admin"], Role: "owner", CreatedAtNS: nowNS}
	s.Members[2] = ProjectMember{ID: 2, ProjectID: 1, UserIdentity: identities["alice"], Role: "member", CreatedAtNS: nowNS}
	s.Members[3] = ProjectMember{ID: 3, ProjectID: 1, UserIdentity: identities["bob"], Role: "member", CreatedAtNS: nowNS}

	s.Tickets[100] = Ticket{ID: 100, ProjectID: 1, Number: 1, Title: "Investigate canary deploy", Status: "open", Priority: "high", Visibility: "internal", ReporterIdentity: identities["alice"], AssigneeIdentity: identities["bob"], UpdatedAtNS: nowNS}
	s.Tickets[200] = Ticket{ID: 200, ProjectID: 1, Number: 2, Title: "Publish status note", Status: "open", Priority: "normal", Visibility: "public", ReporterIdentity: identities["carol"], UpdatedAtNS: nowNS}

	s.Comments[500] = Comment{ID: 500, TicketID: 100, ProjectID: 1, AuthorIdentity: identities["alice"], Visibility: "public", Body: "Initial public triage note", CreatedAtNS: nowNS}
	s.Comments[501] = Comment{ID: 501, TicketID: 100, ProjectID: 1, AuthorIdentity: identities["bob"], Visibility: "internal", Body: "Internal handoff details", CreatedAtNS: nowNS}
	s.Notifications[600] = Notification{ID: 600, RecipientIdentity: identities["bob"], TicketID: 100, Kind: "assigned", Body: "Ticket 100 assigned to bob", Delivered: false, CreatedAtNS: nowNS}

	s.AuditLog[900] = AuditEntry{ID: 900, ActorIdentity: identities["admin"], Action: ReducerBootstrapDemo, TargetTable: "users", TargetID: 1, Body: "seeded users", CreatedAtNS: nowNS}
	s.AuditLog[901] = AuditEntry{ID: 901, ActorIdentity: identities["admin"], Action: ReducerBootstrapDemo, TargetTable: "projects", TargetID: 1, Body: "seeded alpha project", CreatedAtNS: nowNS}
	s.AuditLog[902] = AuditEntry{ID: 902, ActorIdentity: identities["admin"], Action: ReducerBootstrapDemo, TargetTable: "tickets", TargetID: 100, Body: "seeded tickets", CreatedAtNS: nowNS}
	s.AuditLog[903] = AuditEntry{ID: 903, ActorIdentity: identities["admin"], Action: ReducerBootstrapDemo, TargetTable: "comments", TargetID: 500, Body: "seeded comments", CreatedAtNS: nowNS}
	return nil
}

func (s *State) CreateProject(actor string, args CreateProjectArgs) error {
	s.Projects[args.ID] = Project{ID: args.ID, Slug: args.Slug, Name: args.Name, Visibility: args.Visibility, OwnerIdentity: actor, CreatedAtNS: args.NowNS}
	memberID := nextID(s.Members)
	s.Members[memberID] = ProjectMember{ID: memberID, ProjectID: args.ID, UserIdentity: actor, Role: "owner", CreatedAtNS: args.NowNS}
	s.insertAudit(actor, ReducerCreateProject, "projects", args.ID, "created project "+args.Slug, args.NowNS)
	return nil
}

func (s *State) AddProjectMember(actor string, args AddProjectMemberArgs) error {
	if _, ok := s.Projects[args.ProjectID]; !ok {
		return fmt.Errorf("project %d not found", args.ProjectID)
	}
	s.Members[args.ID] = ProjectMember{ID: args.ID, ProjectID: args.ProjectID, UserIdentity: args.UserIdentity, Role: args.Role, CreatedAtNS: args.NowNS}
	s.insertAudit(actor, ReducerAddProjectMember, "project_members", args.ID, "added project member", args.NowNS)
	return nil
}

func (s *State) CreateTicket(actor string, args CreateTicketArgs) error {
	if _, ok := s.Projects[args.ProjectID]; !ok {
		return fmt.Errorf("project %d not found", args.ProjectID)
	}
	s.Tickets[args.ID] = Ticket{
		ID:               args.ID,
		ProjectID:        args.ProjectID,
		Number:           args.Number,
		Title:            args.Title,
		Status:           "open",
		Priority:         args.Priority,
		Visibility:       args.Visibility,
		ReporterIdentity: actor,
		AssigneeIdentity: args.AssigneeIdentity,
		UpdatedAtNS:      args.NowNS,
	}
	if args.AssigneeIdentity != "" {
		s.insertNotification(args.AssigneeIdentity, args.ID, "assigned", fmt.Sprintf("Ticket %d assigned", args.ID), args.NowNS)
	}
	s.insertAudit(actor, ReducerCreateTicket, "tickets", args.ID, "created ticket "+args.Title, args.NowNS)
	return nil
}

func (s *State) AssignTicket(actor string, args AssignTicketArgs) error {
	ticket, ok := s.Tickets[args.TicketID]
	if !ok {
		return fmt.Errorf("ticket %d not found", args.TicketID)
	}
	ticket.AssigneeIdentity = args.AssigneeIdentity
	ticket.UpdatedAtNS = args.NowNS
	s.Tickets[args.TicketID] = ticket
	s.insertNotification(args.AssigneeIdentity, args.TicketID, "assigned", fmt.Sprintf("Ticket %d assigned", args.TicketID), args.NowNS)
	s.insertAudit(actor, ReducerAssignTicket, "tickets", args.TicketID, "assigned ticket", args.NowNS)
	return nil
}

func (s *State) ChangeTicketStatus(actor string, args ChangeTicketStatusArgs) error {
	ticket, ok := s.Tickets[args.TicketID]
	if !ok {
		return fmt.Errorf("ticket %d not found", args.TicketID)
	}
	ticket.Status = args.Status
	ticket.UpdatedAtNS = args.NowNS
	s.Tickets[args.TicketID] = ticket
	s.insertTicketNotifications(ticket, actor, "status_changed", fmt.Sprintf("Ticket %d status changed to %s", args.TicketID, args.Status), args.NowNS)
	s.insertAudit(actor, ReducerChangeTicketStatus, "tickets", args.TicketID, "changed ticket status to "+args.Status, args.NowNS)
	return nil
}

func (s *State) AddComment(actor string, args AddCommentArgs) error {
	ticket, ok := s.Tickets[args.TicketID]
	if !ok {
		return fmt.Errorf("ticket %d not found", args.TicketID)
	}
	s.Comments[args.ID] = Comment{ID: args.ID, TicketID: args.TicketID, ProjectID: ticket.ProjectID, AuthorIdentity: actor, Visibility: args.Visibility, Body: args.Body, CreatedAtNS: args.NowNS}
	s.insertTicketNotifications(ticket, actor, "comment", fmt.Sprintf("Ticket %d has a new comment", args.TicketID), args.NowNS)
	s.insertAudit(actor, ReducerAddComment, "comments", args.ID, "added comment", args.NowNS)
	return nil
}

func (s *State) CloseTicket(actor string, ticketID uint64, nowNS int64) error {
	return s.setTicketStatus(actor, ticketID, "closed", nowNS, ReducerCloseTicket)
}

func (s *State) ReopenTicket(actor string, ticketID uint64, nowNS int64) error {
	return s.setTicketStatus(actor, ticketID, "open", nowNS, ReducerReopenTicket)
}

func (s *State) ScheduleTicketReminder(actor string, args ScheduleTicketReminderArgs) error {
	if _, ok := s.Tickets[args.TicketID]; !ok {
		return fmt.Errorf("ticket %d not found", args.TicketID)
	}
	s.Reminders[args.ID] = Reminder{
		ID:                args.ID,
		TicketID:          args.TicketID,
		RecipientIdentity: args.RecipientIdentity,
		ScheduleID:        args.ScheduleID,
		DueAtNS:           args.NowNS + args.DelayMS*1_000_000,
		Fired:             false,
	}
	s.insertAudit(actor, ReducerScheduleTicketReminder, "ticket_reminders", args.ID, "scheduled ticket reminder", args.NowNS)
	return nil
}

func (s *State) FireTicketReminder(reminderID uint64) error {
	reminder, ok := s.Reminders[reminderID]
	if !ok || reminder.Fired {
		return nil
	}
	reminder.Fired = true
	s.Reminders[reminderID] = reminder
	s.insertNotification(reminder.RecipientIdentity, reminder.TicketID, "reminder", fmt.Sprintf("Ticket %d reminder", reminder.TicketID), reminder.DueAtNS)
	s.insertAudit("system", ReducerFireTicketReminder, "ticket_reminders", reminderID, "fired ticket reminder", reminder.DueAtNS)
	return nil
}

func (s *State) setTicketStatus(actor string, ticketID uint64, status string, nowNS int64, reducer string) error {
	ticket, ok := s.Tickets[ticketID]
	if !ok {
		return fmt.Errorf("ticket %d not found", ticketID)
	}
	ticket.Status = status
	ticket.UpdatedAtNS = nowNS
	s.Tickets[ticketID] = ticket
	s.insertAudit(actor, reducer, "tickets", ticketID, "set ticket status to "+status, nowNS)
	return nil
}

func (s *State) insertTicketNotifications(ticket Ticket, actor, kind, body string, nowNS int64) {
	seen := map[string]struct{}{}
	for _, identity := range []string{ticket.ReporterIdentity, ticket.AssigneeIdentity} {
		if identity == "" || identity == actor {
			continue
		}
		if _, ok := seen[identity]; ok {
			continue
		}
		seen[identity] = struct{}{}
		s.insertNotification(identity, ticket.ID, kind, body, nowNS)
	}
}

func (s *State) insertNotification(recipient string, ticketID uint64, kind, body string, nowNS int64) {
	id := nextID(s.Notifications)
	s.Notifications[id] = Notification{ID: id, RecipientIdentity: recipient, TicketID: ticketID, Kind: kind, Body: body, Delivered: false, CreatedAtNS: nowNS}
}

func (s *State) insertAudit(actor, action, targetTable string, targetID uint64, body string, nowNS int64) {
	id := nextID(s.AuditLog)
	s.AuditLog[id] = AuditEntry{ID: id, ActorIdentity: actor, Action: action, TargetTable: targetTable, TargetID: targetID, Body: body, CreatedAtNS: nowNS}
}

func nextID[T any](items map[uint64]T) uint64 {
	var max uint64
	for id := range items {
		if id > max {
			max = id
		}
	}
	return max + 1
}
