package client

import (
	"fmt"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/bsatn"
	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

type UserRow struct {
	ID          uint64
	Identity    string
	Handle      string
	DisplayName string
	Role        string
	Active      bool
}

type TicketRow struct {
	ID               uint64
	ProjectID        uint64
	Number           uint64
	Title            string
	Status           string
	Priority         string
	Visibility       string
	ReporterIdentity string
	AssigneeIdentity string
	UpdatedAtNS      int64
}

type ProjectRow struct {
	ID            uint64
	Slug          string
	Name          string
	Visibility    string
	OwnerIdentity string
	CreatedAtNS   int64
}

type CommentRow struct {
	ID             uint64
	TicketID       uint64
	ProjectID      uint64
	AuthorIdentity string
	Visibility     string
	Body           string
	CreatedAtNS    int64
}

type NotificationRow struct {
	ID                uint64
	RecipientIdentity string
	TicketID          uint64
	Kind              string
	Body              string
	Delivered         bool
	CreatedAtNS       int64
}

type AuditLogRow struct {
	ID            uint64
	ActorIdentity string
	Action        string
	TargetTable   string
	TargetID      uint64
	Body          string
	CreatedAtNS   int64
}

// TableSchema returns a detached table schema from an exported contract.
func TableSchema(contract shunter.ModuleContract, tableName string) (*schema.TableSchema, error) {
	for i := range contract.Schema.Tables {
		if contract.Schema.Tables[i].Name == tableName {
			export := contract.Schema.Tables[i]
			table := &schema.TableSchema{
				ID:         schema.TableID(i),
				Name:       export.Name,
				ReadPolicy: export.ReadPolicy,
				Columns:    make([]schema.ColumnSchema, len(export.Columns)),
			}
			for colIdx, col := range export.Columns {
				kind, err := valueKindFromExport(col.Type)
				if err != nil {
					return nil, fmt.Errorf("%s.%s: %w", export.Name, col.Name, err)
				}
				table.Columns[colIdx] = schema.ColumnSchema{
					Index: colIdx,
					Name:  col.Name,
					Type:  kind,
				}
			}
			return table, nil
		}
	}
	return nil, fmt.Errorf("table %q not found in contract", tableName)
}

func valueKindFromExport(name string) (schema.ValueKind, error) {
	for _, kind := range []schema.ValueKind{
		schema.KindBool,
		schema.KindInt8,
		schema.KindUint8,
		schema.KindInt16,
		schema.KindUint16,
		schema.KindInt32,
		schema.KindUint32,
		schema.KindInt64,
		schema.KindUint64,
		schema.KindFloat32,
		schema.KindFloat64,
		schema.KindString,
		schema.KindBytes,
		schema.KindInt128,
		schema.KindUint128,
		schema.KindInt256,
		schema.KindUint256,
		schema.KindTimestamp,
		schema.KindArrayString,
	} {
		if schema.ValueKindExportString(kind) == name {
			return kind, nil
		}
	}
	return 0, fmt.Errorf("unknown exported value kind %q", name)
}

// DecodeRows decodes a protocol RowList payload into schema-aligned product rows.
func DecodeRows(encoded []byte, table *schema.TableSchema) ([]types.ProductValue, error) {
	if table == nil {
		return nil, fmt.Errorf("table schema is nil")
	}
	rawRows, err := protocol.DecodeRowList(encoded)
	if err != nil {
		return nil, err
	}
	rows := make([]types.ProductValue, 0, len(rawRows))
	for i, raw := range rawRows {
		row, err := bsatn.DecodeProductValueFromBytes(raw, table)
		if err != nil {
			return nil, fmt.Errorf("decode %s row %d: %w", table.Name, i, err)
		}
		rows = append(rows, row)
	}
	return rows, nil
}

// DecodeOneOffRows decodes rows for tableName from a one-off query response.
func DecodeOneOffRows(resp protocol.OneOffQueryResponse, tableName string, table *schema.TableSchema) ([]types.ProductValue, error) {
	if resp.Error != nil {
		return nil, fmt.Errorf("one-off query failed: %s", *resp.Error)
	}
	for _, resultTable := range resp.Tables {
		if resultTable.TableName == tableName {
			return DecodeRows(resultTable.Rows, table)
		}
	}
	return nil, fmt.Errorf("one-off response did not include table %q", tableName)
}

func UsersFromRows(rows []types.ProductValue) ([]UserRow, error) {
	out := make([]UserRow, 0, len(rows))
	for i, row := range rows {
		user, err := userFromRow(row)
		if err != nil {
			return nil, fmt.Errorf("decode user row %d: %w", i, err)
		}
		out = append(out, user)
	}
	return out, nil
}

func TicketsFromRows(rows []types.ProductValue) ([]TicketRow, error) {
	out := make([]TicketRow, 0, len(rows))
	for i, row := range rows {
		ticket, err := ticketFromRow(row)
		if err != nil {
			return nil, fmt.Errorf("decode ticket row %d: %w", i, err)
		}
		out = append(out, ticket)
	}
	return out, nil
}

func ProjectsFromRows(rows []types.ProductValue) ([]ProjectRow, error) {
	out := make([]ProjectRow, 0, len(rows))
	for i, row := range rows {
		project, err := projectFromRow(row)
		if err != nil {
			return nil, fmt.Errorf("decode project row %d: %w", i, err)
		}
		out = append(out, project)
	}
	return out, nil
}

func CommentsFromRows(rows []types.ProductValue) ([]CommentRow, error) {
	out := make([]CommentRow, 0, len(rows))
	for i, row := range rows {
		comment, err := commentFromRow(row)
		if err != nil {
			return nil, fmt.Errorf("decode comment row %d: %w", i, err)
		}
		out = append(out, comment)
	}
	return out, nil
}

func NotificationsFromRows(rows []types.ProductValue) ([]NotificationRow, error) {
	out := make([]NotificationRow, 0, len(rows))
	for i, row := range rows {
		notification, err := notificationFromRow(row)
		if err != nil {
			return nil, fmt.Errorf("decode notification row %d: %w", i, err)
		}
		out = append(out, notification)
	}
	return out, nil
}

func AuditLogsFromRows(rows []types.ProductValue) ([]AuditLogRow, error) {
	out := make([]AuditLogRow, 0, len(rows))
	for i, row := range rows {
		entry, err := auditLogFromRow(row)
		if err != nil {
			return nil, fmt.Errorf("decode audit_log row %d: %w", i, err)
		}
		out = append(out, entry)
	}
	return out, nil
}

func userFromRow(row types.ProductValue) (UserRow, error) {
	if err := requireColumns(row, 6); err != nil {
		return UserRow{}, err
	}
	return UserRow{
		ID:          row[0].AsUint64(),
		Identity:    row[1].AsString(),
		Handle:      row[2].AsString(),
		DisplayName: row[3].AsString(),
		Role:        row[4].AsString(),
		Active:      row[5].AsBool(),
	}, nil
}

func ticketFromRow(row types.ProductValue) (TicketRow, error) {
	if err := requireColumns(row, 10); err != nil {
		return TicketRow{}, err
	}
	return TicketRow{
		ID:               row[0].AsUint64(),
		ProjectID:        row[1].AsUint64(),
		Number:           row[2].AsUint64(),
		Title:            row[3].AsString(),
		Status:           row[4].AsString(),
		Priority:         row[5].AsString(),
		Visibility:       row[6].AsString(),
		ReporterIdentity: row[7].AsString(),
		AssigneeIdentity: row[8].AsString(),
		UpdatedAtNS:      row[9].AsInt64(),
	}, nil
}

func projectFromRow(row types.ProductValue) (ProjectRow, error) {
	if err := requireColumns(row, 6); err != nil {
		return ProjectRow{}, err
	}
	return ProjectRow{
		ID:            row[0].AsUint64(),
		Slug:          row[1].AsString(),
		Name:          row[2].AsString(),
		Visibility:    row[3].AsString(),
		OwnerIdentity: row[4].AsString(),
		CreatedAtNS:   row[5].AsInt64(),
	}, nil
}

func commentFromRow(row types.ProductValue) (CommentRow, error) {
	if err := requireColumns(row, 7); err != nil {
		return CommentRow{}, err
	}
	return CommentRow{
		ID:             row[0].AsUint64(),
		TicketID:       row[1].AsUint64(),
		ProjectID:      row[2].AsUint64(),
		AuthorIdentity: row[3].AsString(),
		Visibility:     row[4].AsString(),
		Body:           row[5].AsString(),
		CreatedAtNS:    row[6].AsInt64(),
	}, nil
}

func notificationFromRow(row types.ProductValue) (NotificationRow, error) {
	if err := requireColumns(row, 7); err != nil {
		return NotificationRow{}, err
	}
	return NotificationRow{
		ID:                row[0].AsUint64(),
		RecipientIdentity: row[1].AsString(),
		TicketID:          row[2].AsUint64(),
		Kind:              row[3].AsString(),
		Body:              row[4].AsString(),
		Delivered:         row[5].AsBool(),
		CreatedAtNS:       row[6].AsInt64(),
	}, nil
}

func auditLogFromRow(row types.ProductValue) (AuditLogRow, error) {
	if err := requireColumns(row, 7); err != nil {
		return AuditLogRow{}, err
	}
	return AuditLogRow{
		ID:            row[0].AsUint64(),
		ActorIdentity: row[1].AsString(),
		Action:        row[2].AsString(),
		TargetTable:   row[3].AsString(),
		TargetID:      row[4].AsUint64(),
		Body:          row[5].AsString(),
		CreatedAtNS:   row[6].AsInt64(),
	}, nil
}

func requireColumns(row types.ProductValue, want int) error {
	if len(row) != want {
		return fmt.Errorf("got %d columns, want %d", len(row), want)
	}
	return nil
}
