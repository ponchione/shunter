package client

import (
	"reflect"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter/auth"
)

func TestMintStrictToken(t *testing.T) {
	before := time.Now().UTC().Unix()
	tokenString, identity, err := MintStrictToken("alice", app.PermProjectWrite, app.PermTicketWrite)
	after := time.Now().UTC().Unix()
	if err != nil {
		t.Fatalf("MintStrictToken returned error: %v", err)
	}
	if tokenString == "" {
		t.Fatal("MintStrictToken returned empty token")
	}
	wantIdentity := auth.DeriveIdentity(app.StrictAuthIssuer, "alice")
	if identity != wantIdentity {
		t.Fatalf("identity = %x, want %x", identity, wantIdentity)
	}

	parsed, err := jwt.Parse(tokenString, func(tok *jwt.Token) (any, error) {
		return []byte(app.StrictAuthSigningKey), nil
	})
	if err != nil {
		t.Fatalf("Parse signed token: %v", err)
	}
	if !parsed.Valid {
		t.Fatal("parsed token is invalid")
	}
	claims, ok := parsed.Claims.(jwt.MapClaims)
	if !ok {
		t.Fatalf("claims type = %T, want jwt.MapClaims", parsed.Claims)
	}
	if got := claims["iss"]; got != app.StrictAuthIssuer {
		t.Fatalf("iss = %#v, want %q", got, app.StrictAuthIssuer)
	}
	if got := claims["sub"]; got != "alice" {
		t.Fatalf("sub = %#v, want alice", got)
	}
	if got := claims["aud"]; got != app.StrictAuthAudience {
		t.Fatalf("aud = %#v, want %q", got, app.StrictAuthAudience)
	}
	if got := claims["identity"]; got != identity.Hex() {
		t.Fatalf("identity claim = %#v, want %q", got, identity.Hex())
	}
	if got := claims["hex_identity"]; got != identity.Hex() {
		t.Fatalf("hex_identity claim = %#v, want %q", got, identity.Hex())
	}
	iat, ok := numericClaim(claims["iat"])
	if !ok {
		t.Fatalf("iat claim = %#v, want numeric Unix seconds", claims["iat"])
	}
	if iat < before || iat > after {
		t.Fatalf("iat = %d, want between %d and %d", iat, before, after)
	}
	exp, ok := numericClaim(claims["exp"])
	if !ok {
		t.Fatalf("exp claim = %#v, want numeric Unix seconds", claims["exp"])
	}
	if got, want := exp-iat, int64(strictTokenTTL/time.Second); got != want {
		t.Fatalf("token TTL seconds = %d, want %d", got, want)
	}
	if got, want := stringClaims(claims["permissions"]), []string{app.PermProjectWrite, app.PermTicketWrite}; !reflect.DeepEqual(got, want) {
		t.Fatalf("permissions = %#v, want %#v", got, want)
	}
}

func numericClaim(raw any) (int64, bool) {
	switch v := raw.(type) {
	case float64:
		return int64(v), true
	case int64:
		return v, true
	default:
		return 0, false
	}
}

func stringClaims(raw any) []string {
	items, ok := raw.([]any)
	if !ok {
		return nil
	}
	out := make([]string, 0, len(items))
	for _, item := range items {
		if s, ok := item.(string); ok {
			out = append(out, s)
		}
	}
	return out
}
