package client

import (
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter/auth"
	"github.com/ponchione/shunter/types"
)

const strictTokenTTL = time.Hour

// MintStrictToken mints a strict-auth JWT accepted by the canary runtime and
// returns the derived Shunter identity for the same issuer/subject pair.
func MintStrictToken(subject string, permissions ...string) (token string, identity types.Identity, err error) {
	if subject == "" {
		return "", types.Identity{}, fmt.Errorf("subject is required")
	}

	identity = auth.DeriveIdentity(app.StrictAuthIssuer, subject)
	permissionClaims := make([]string, len(permissions))
	copy(permissionClaims, permissions)
	now := time.Now().UTC()
	claims := jwt.MapClaims{
		"iss":          app.StrictAuthIssuer,
		"sub":          subject,
		"aud":          app.StrictAuthAudience,
		"iat":          now.Unix(),
		"exp":          now.Add(strictTokenTTL).Unix(),
		"identity":     identity.Hex(),
		"hex_identity": identity.Hex(),
		"permissions":  permissionClaims,
	}

	signed, err := jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString([]byte(app.StrictAuthSigningKey))
	if err != nil {
		return "", types.Identity{}, fmt.Errorf("sign strict auth token: %w", err)
	}
	return signed, identity, nil
}
