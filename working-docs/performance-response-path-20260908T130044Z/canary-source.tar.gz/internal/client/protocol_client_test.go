package client

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"reflect"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/coder/websocket"

	"github.com/ponchione/opsboard-canary/internal/app"
	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/protocol"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

func TestClientCallReducerEncodesJSONArgs(t *testing.T) {
	msgCh := make(chan any, 1)
	errCh := make(chan error, 1)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
			Subprotocols: []string{protocol.SubprotocolV1},
		})
		if err != nil {
			errCh <- err
			return
		}
		defer conn.CloseNow()

		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		messageType, frame, err := conn.Read(ctx)
		if err != nil {
			errCh <- err
			return
		}
		if messageType != websocket.MessageBinary {
			errCh <- fmt.Errorf("message type = %v, want binary", messageType)
			return
		}
		_, msg, err := protocol.DecodeClientMessage(frame)
		if err != nil {
			errCh <- err
			return
		}
		msgCh <- msg
	}))
	defer srv.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	c, err := Dial(ctx, srv.URL, "test-token")
	if err != nil {
		t.Fatalf("Dial returned error: %v", err)
	}
	defer c.CloseNow()

	if err := c.CallReducer(app.ReducerBootstrapDemo, map[string]int64{"now_ns": 1000}, 17, protocol.CallReducerFlagsNoSuccessNotify); err != nil {
		t.Fatalf("CallReducer returned error: %v", err)
	}

	select {
	case err := <-errCh:
		t.Fatalf("server read returned error: %v", err)
	case msg := <-msgCh:
		call, ok := msg.(protocol.CallReducerMsg)
		if !ok {
			t.Fatalf("decoded msg = %T, want protocol.CallReducerMsg", msg)
		}
		if call.ReducerName != app.ReducerBootstrapDemo || call.RequestID != 17 || call.Flags != protocol.CallReducerFlagsNoSuccessNotify {
			t.Fatalf("call reducer msg = %+v", call)
		}
		var args map[string]int64
		if err := json.Unmarshal(call.Args, &args); err != nil {
			t.Fatalf("Unmarshal call args: %v", err)
		}
		if !reflect.DeepEqual(args, map[string]int64{"now_ns": 1000}) {
			t.Fatalf("call args = %#v, want now_ns 1000", args)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("timed out waiting for encoded protocol message")
	}
}

func TestClientEncodesQuerySubscriptionAndUnsubscribeMessages(t *testing.T) {
	const messageCount = 7
	msgCh := make(chan any, messageCount)
	errCh := make(chan error, 1)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got, want := r.Header.Get("Authorization"), "Bearer test-token"; got != want {
			errCh <- fmt.Errorf("authorization header = %q, want %q", got, want)
			return
		}
		conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
			Subprotocols: []string{protocol.SubprotocolV1},
		})
		if err != nil {
			errCh <- err
			return
		}
		defer conn.CloseNow()

		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		for i := 0; i < messageCount; i++ {
			messageType, frame, err := conn.Read(ctx)
			if err != nil {
				errCh <- err
				return
			}
			if messageType != websocket.MessageBinary {
				errCh <- fmt.Errorf("message type = %v, want binary", messageType)
				return
			}
			_, msg, err := protocol.DecodeClientMessage(frame)
			if err != nil {
				errCh <- err
				return
			}
			msgCh <- msg
		}
	}))
	defer srv.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	c, err := Dial(ctx, srv.URL, "test-token")
	if err != nil {
		t.Fatalf("Dial returned error: %v", err)
	}
	defer c.CloseNow()

	if err := c.OneOff("SELECT * FROM users", []byte("one-off")); err != nil {
		t.Fatalf("OneOff returned error: %v", err)
	}
	if err := c.DeclaredQuery(app.QueryMyProfile, []byte("declared")); err != nil {
		t.Fatalf("DeclaredQuery returned error: %v", err)
	}
	if err := c.SubscribeSingle("SELECT * FROM tickets", 11, 12); err != nil {
		t.Fatalf("SubscribeSingle returned error: %v", err)
	}
	if err := c.SubscribeMulti([]string{"SELECT * FROM tickets", "SELECT * FROM comments"}, 21, 22); err != nil {
		t.Fatalf("SubscribeMulti returned error: %v", err)
	}
	if err := c.SubscribeDeclaredView(app.ViewMyNotifications, 31, 32); err != nil {
		t.Fatalf("SubscribeDeclaredView returned error: %v", err)
	}
	if err := c.UnsubscribeSingle(41, 42); err != nil {
		t.Fatalf("UnsubscribeSingle returned error: %v", err)
	}
	if err := c.UnsubscribeMulti(51, 52); err != nil {
		t.Fatalf("UnsubscribeMulti returned error: %v", err)
	}

	messages := readCapturedClientMessages(t, msgCh, errCh, messageCount)
	if got, want := messages[0], (protocol.OneOffQueryMsg{MessageID: []byte("one-off"), QueryString: "SELECT * FROM users"}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 0 = %#v, want %#v", got, want)
	}
	if got, want := messages[1], (protocol.DeclaredQueryMsg{MessageID: []byte("declared"), Name: app.QueryMyProfile}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 1 = %#v, want %#v", got, want)
	}
	if got, want := messages[2], (protocol.SubscribeSingleMsg{RequestID: 11, QueryID: 12, QueryString: "SELECT * FROM tickets"}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 2 = %#v, want %#v", got, want)
	}
	if got, want := messages[3], (protocol.SubscribeMultiMsg{RequestID: 21, QueryID: 22, QueryStrings: []string{"SELECT * FROM tickets", "SELECT * FROM comments"}}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 3 = %#v, want %#v", got, want)
	}
	if got, want := messages[4], (protocol.SubscribeDeclaredViewMsg{RequestID: 31, QueryID: 32, Name: app.ViewMyNotifications}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 4 = %#v, want %#v", got, want)
	}
	if got, want := messages[5], (protocol.UnsubscribeSingleMsg{RequestID: 41, QueryID: 42}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 5 = %#v, want %#v", got, want)
	}
	if got, want := messages[6], (protocol.UnsubscribeMultiMsg{RequestID: 51, QueryID: 52}); !reflect.DeepEqual(got, want) {
		t.Fatalf("message 6 = %#v, want %#v", got, want)
	}
}

func TestProtocolBootstrapOneOffAndDeclaredReads(t *testing.T) {
	rt := buildStartedStrictRuntime(t)
	defer rt.Close()

	contract := rt.ExportContract()
	usersSchema, err := TableSchema(contract, "users")
	if err != nil {
		t.Fatal(err)
	}
	projectsSchema, err := TableSchema(contract, "projects")
	if err != nil {
		t.Fatal(err)
	}
	ticketsSchema, err := TableSchema(contract, "tickets")
	if err != nil {
		t.Fatal(err)
	}
	commentsSchema, err := TableSchema(contract, "comments")
	if err != nil {
		t.Fatal(err)
	}
	notificationsSchema, err := TableSchema(contract, "notifications")
	if err != nil {
		t.Fatal(err)
	}
	auditSchema, err := TableSchema(contract, "audit_log")
	if err != nil {
		t.Fatal(err)
	}

	srv := httptest.NewServer(rt.HTTPHandler())
	defer srv.Close()

	adminToken, adminIdentity, err := MintStrictToken("admin", app.PermAdminWrite)
	if err != nil {
		t.Fatalf("mint admin token: %v", err)
	}
	admin := dialRuntimeClient(t, srv.URL, adminToken)
	defer admin.CloseNow()
	requireIdentityToken(t, admin, adminIdentity)

	if err := admin.CallReducer(app.ReducerBootstrapDemo, map[string]int64{"now_ns": 1000}, 101, protocol.CallReducerFlagsFullUpdate); err != nil {
		t.Fatalf("bootstrap CallReducer: %v", err)
	}
	requireReducerCommitted(t, admin, 101)

	aliceToken, aliceIdentity, err := MintStrictToken("alice")
	if err != nil {
		t.Fatalf("mint alice token: %v", err)
	}
	alice := dialRuntimeClient(t, srv.URL, aliceToken)
	defer alice.CloseNow()
	requireIdentityToken(t, alice, aliceIdentity)

	if err := alice.OneOff("SELECT * FROM users", []byte("users")); err != nil {
		t.Fatalf("users OneOff: %v", err)
	}
	users := requireOneOffUsers(t, alice, []byte("users"), usersSchema)
	if len(users) != 6 {
		t.Fatalf("users row count = %d, want 6", len(users))
	}
	if usersByHandle(users)["alice"].Identity != aliceIdentity.Hex() {
		t.Fatalf("alice identity row = %q, want %q", usersByHandle(users)["alice"].Identity, aliceIdentity.Hex())
	}

	if err := alice.DeclaredQuery(app.QueryMyProfile, []byte("my-profile")); err != nil {
		t.Fatalf("my_profile DeclaredQuery: %v", err)
	}
	profile := requireOneOffUsers(t, alice, []byte("my-profile"), usersSchema)
	if len(profile) != 1 || profile[0].Handle != "alice" || profile[0].Identity != aliceIdentity.Hex() {
		t.Fatalf("my_profile rows = %#v, want alice", profile)
	}

	if err := alice.OneOff("SELECT * FROM projects", []byte("projects")); err != nil {
		t.Fatalf("projects OneOff: %v", err)
	}
	projects := requireOneOffProjects(t, alice, []byte("projects"), projectsSchema)
	if len(projects) != 1 {
		t.Fatalf("projects row count = %d, want 1", len(projects))
	}
	if got := projects[0]; got.ID != 1 || got.Slug != "alpha" || got.Visibility != "internal" || got.OwnerIdentity != adminIdentity.Hex() || got.CreatedAtNS != 1000 {
		t.Fatalf("project seed row = %+v, want alpha project owned by admin", got)
	}

	if err := alice.DeclaredQuery(app.QueryAlphaBoard, []byte("alpha-board")); err != nil {
		t.Fatalf("alpha_board DeclaredQuery: %v", err)
	}
	aliceTickets := requireOneOffTickets(t, alice, []byte("alpha-board"), ticketsSchema)
	if got, want := sortedTicketIDs(aliceTickets), []uint64{100, 200}; !reflect.DeepEqual(got, want) {
		t.Fatalf("alice alpha_board ticket ids = %#v, want %#v", got, want)
	}

	outsiderToken, outsiderIdentity, err := MintStrictToken("outsider")
	if err != nil {
		t.Fatalf("mint outsider token: %v", err)
	}
	outsider := dialRuntimeClient(t, srv.URL, outsiderToken)
	defer outsider.CloseNow()
	requireIdentityToken(t, outsider, outsiderIdentity)

	if err := outsider.DeclaredQuery(app.QueryAlphaBoard, []byte("outsider-alpha-board")); err != nil {
		t.Fatalf("outsider alpha_board DeclaredQuery: %v", err)
	}
	outsiderTickets := requireOneOffTickets(t, outsider, []byte("outsider-alpha-board"), ticketsSchema)
	if got, want := sortedTicketIDs(outsiderTickets), []uint64{200}; !reflect.DeepEqual(got, want) {
		t.Fatalf("outsider alpha_board ticket ids = %#v, want %#v", got, want)
	}

	bobToken, bobIdentity, err := MintStrictToken("bob")
	if err != nil {
		t.Fatalf("mint bob token: %v", err)
	}
	bob := dialRuntimeClient(t, srv.URL, bobToken)
	defer bob.CloseNow()
	requireIdentityToken(t, bob, bobIdentity)

	if err := alice.OneOff("SELECT * FROM comments", []byte("alice-comments")); err != nil {
		t.Fatalf("alice comments OneOff: %v", err)
	}
	aliceComments := requireOneOffComments(t, alice, []byte("alice-comments"), commentsSchema)
	if got, want := sortedCommentIDs(aliceComments), []uint64{500}; !reflect.DeepEqual(got, want) {
		t.Fatalf("alice comment ids = %#v, want %#v", got, want)
	}

	if err := bob.OneOff("SELECT * FROM comments", []byte("bob-comments")); err != nil {
		t.Fatalf("bob comments OneOff: %v", err)
	}
	bobComments := requireOneOffComments(t, bob, []byte("bob-comments"), commentsSchema)
	if got, want := sortedCommentIDs(bobComments), []uint64{500, 501}; !reflect.DeepEqual(got, want) {
		t.Fatalf("bob comment ids = %#v, want %#v", got, want)
	}
	if got := commentsByID(bobComments)[501]; got.Visibility != "internal" || got.AuthorIdentity != bobIdentity.Hex() || got.TicketID != 100 {
		t.Fatalf("internal comment seed row = %+v, want bob internal comment on ticket 100", got)
	}

	if err := bob.SubscribeDeclaredView(app.ViewMyNotifications, 301, 302); err != nil {
		t.Fatalf("bob my_notifications SubscribeDeclaredView: %v", err)
	}
	bobNotifications := requireSubscribeNotifications(t, bob, 301, 302, notificationsSchema)
	if got, want := sortedNotificationIDs(bobNotifications), []uint64{600}; !reflect.DeepEqual(got, want) {
		t.Fatalf("bob notification ids = %#v, want %#v", got, want)
	}
	if got := notificationsByID(bobNotifications)[600]; got.RecipientIdentity != bobIdentity.Hex() || got.TicketID != 100 || got.Kind != "assigned" || got.Delivered {
		t.Fatalf("notification seed row = %+v, want undelivered assignment notification for bob", got)
	}
	if err := bob.UnsubscribeSingle(303, 302); err != nil {
		t.Fatalf("bob my_notifications UnsubscribeSingle: %v", err)
	}
	requireUnsubscribeSingleApplied(t, bob, 303, 302)

	auditorToken, auditorIdentity, err := MintStrictToken("auditor", app.PermAuditRead)
	if err != nil {
		t.Fatalf("mint auditor token: %v", err)
	}
	auditor := dialRuntimeClient(t, srv.URL, auditorToken)
	defer auditor.CloseNow()
	requireIdentityToken(t, auditor, auditorIdentity)

	if err := auditor.DeclaredQuery(app.QueryAuditFeed, []byte("audit-feed")); err != nil {
		t.Fatalf("audit_feed DeclaredQuery: %v", err)
	}
	auditRows := requireOneOffAuditLogs(t, auditor, []byte("audit-feed"), auditSchema)
	if got, want := sortedAuditIDs(auditRows), []uint64{900, 901, 902, 903}; !reflect.DeepEqual(got, want) {
		t.Fatalf("audit ids = %#v, want %#v", got, want)
	}
	if got := auditLogsByID(auditRows)[902]; got.Action != app.ReducerBootstrapDemo || got.TargetTable != "tickets" || got.TargetID != 100 || got.ActorIdentity != adminIdentity.Hex() {
		t.Fatalf("ticket audit seed row = %+v, want bootstrap ticket audit by admin", got)
	}

	if err := admin.CallReducer(app.ReducerBootstrapDemo, map[string]int64{"now_ns": 1000}, 102, protocol.CallReducerFlagsFullUpdate); err != nil {
		t.Fatalf("second bootstrap CallReducer: %v", err)
	}
	requireReducerFailed(t, admin, 102, "already been applied")

	if err := auditor.DeclaredQuery(app.QueryAuditFeed, []byte("audit-feed-after-second-bootstrap")); err != nil {
		t.Fatalf("audit_feed after second bootstrap DeclaredQuery: %v", err)
	}
	auditAfterSecondBootstrap := requireOneOffAuditLogs(t, auditor, []byte("audit-feed-after-second-bootstrap"), auditSchema)
	if got, want := sortedAuditIDs(auditAfterSecondBootstrap), []uint64{900, 901, 902, 903}; !reflect.DeepEqual(got, want) {
		t.Fatalf("audit ids after second bootstrap = %#v, want unchanged %#v", got, want)
	}
}

func readCapturedClientMessages(t *testing.T, msgCh <-chan any, errCh <-chan error, count int) []any {
	t.Helper()
	messages := make([]any, 0, count)
	for len(messages) < count {
		select {
		case err := <-errCh:
			t.Fatalf("server read returned error: %v", err)
		case msg := <-msgCh:
			messages = append(messages, msg)
		case <-time.After(2 * time.Second):
			t.Fatalf("timed out waiting for encoded protocol message %d of %d", len(messages)+1, count)
		}
	}
	return messages
}

func buildStartedStrictRuntime(t *testing.T) *shunter.Runtime {
	t.Helper()
	rt, err := shunter.Build(app.NewModule(), app.StrictAuthConfig(t.TempDir(), ""))
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	if err := rt.Start(context.Background()); err != nil {
		t.Fatalf("Start returned error: %v", err)
	}
	return rt
}

func dialRuntimeClient(t *testing.T, runtimeURL, token string) *Client {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	c, err := Dial(ctx, runtimeURL, token)
	if err != nil {
		t.Fatalf("Dial returned error: %v", err)
	}
	return c
}

func readRuntimeMessage(t *testing.T, c *Client) (uint8, any) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	tag, msg, err := c.Read(ctx)
	if err != nil {
		t.Fatalf("Read returned error: %v", err)
	}
	return tag, msg
}

func requireIdentityToken(t *testing.T, c *Client, want [32]byte) {
	t.Helper()
	tag, msg := readRuntimeMessage(t, c)
	if tag != protocol.TagIdentityToken {
		t.Fatalf("first tag = %d, msg = %T, want IdentityToken", tag, msg)
	}
	identityToken, ok := msg.(protocol.IdentityToken)
	if !ok {
		t.Fatalf("first msg = %T, want protocol.IdentityToken", msg)
	}
	if identityToken.Identity != want {
		t.Fatalf("identity token identity = %x, want %x", identityToken.Identity, want)
	}
}

func requireReducerCommitted(t *testing.T, c *Client, requestID uint32) {
	t.Helper()
	for {
		tag, msg := readRuntimeMessage(t, c)
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update := msg.(protocol.TransactionUpdate)
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		if failed, ok := update.Status.(protocol.StatusFailed); ok {
			t.Fatalf("reducer request %d failed: %s", requestID, failed.Error)
		}
		if _, ok := update.Status.(protocol.StatusCommitted); !ok {
			t.Fatalf("reducer status = %T, want StatusCommitted", update.Status)
		}
		return
	}
}

func requireReducerFailed(t *testing.T, c *Client, requestID uint32, wantError string) {
	t.Helper()
	for {
		tag, msg := readRuntimeMessage(t, c)
		if tag != protocol.TagTransactionUpdate {
			continue
		}
		update := msg.(protocol.TransactionUpdate)
		if update.ReducerCall.RequestID != requestID {
			continue
		}
		failed, ok := update.Status.(protocol.StatusFailed)
		if !ok {
			t.Fatalf("reducer status = %T, want StatusFailed", update.Status)
		}
		if !strings.Contains(failed.Error, wantError) {
			t.Fatalf("reducer failure error = %q, want substring %q", failed.Error, wantError)
		}
		return
	}
}

func requireOneOffUsers(t *testing.T, c *Client, messageID []byte, table *schema.TableSchema) []UserRow {
	t.Helper()
	rows := requireOneOffRows(t, c, messageID, "users", table)
	users, err := UsersFromRows(rows)
	if err != nil {
		t.Fatalf("UsersFromRows: %v", err)
	}
	return users
}

func requireOneOffProjects(t *testing.T, c *Client, messageID []byte, table *schema.TableSchema) []ProjectRow {
	t.Helper()
	rows := requireOneOffRows(t, c, messageID, "projects", table)
	projects, err := ProjectsFromRows(rows)
	if err != nil {
		t.Fatalf("ProjectsFromRows: %v", err)
	}
	return projects
}

func requireOneOffTickets(t *testing.T, c *Client, messageID []byte, table *schema.TableSchema) []TicketRow {
	t.Helper()
	rows := requireOneOffRows(t, c, messageID, "tickets", table)
	tickets, err := TicketsFromRows(rows)
	if err != nil {
		t.Fatalf("TicketsFromRows: %v", err)
	}
	return tickets
}

func requireOneOffComments(t *testing.T, c *Client, messageID []byte, table *schema.TableSchema) []CommentRow {
	t.Helper()
	rows := requireOneOffRows(t, c, messageID, "comments", table)
	comments, err := CommentsFromRows(rows)
	if err != nil {
		t.Fatalf("CommentsFromRows: %v", err)
	}
	return comments
}

func requireOneOffAuditLogs(t *testing.T, c *Client, messageID []byte, table *schema.TableSchema) []AuditLogRow {
	t.Helper()
	rows := requireOneOffRows(t, c, messageID, "audit_log", table)
	logs, err := AuditLogsFromRows(rows)
	if err != nil {
		t.Fatalf("AuditLogsFromRows: %v", err)
	}
	return logs
}

func requireOneOffRows(t *testing.T, c *Client, messageID []byte, tableName string, table *schema.TableSchema) []types.ProductValue {
	t.Helper()
	tag, msg := readRuntimeMessage(t, c)
	if tag != protocol.TagOneOffQueryResponse {
		t.Fatalf("tag = %d, msg = %T, want OneOffQueryResponse", tag, msg)
	}
	resp, ok := msg.(protocol.OneOffQueryResponse)
	if !ok {
		t.Fatalf("msg = %T, want protocol.OneOffQueryResponse", msg)
	}
	if !reflect.DeepEqual(resp.MessageID, messageID) {
		t.Fatalf("message id = %q, want %q", resp.MessageID, messageID)
	}
	rows, err := DecodeOneOffRows(resp, tableName, table)
	if err != nil {
		t.Fatalf("DecodeOneOffRows: %v", err)
	}
	return rows
}

func requireSubscribeNotifications(t *testing.T, c *Client, requestID uint32, queryID uint32, table *schema.TableSchema) []NotificationRow {
	t.Helper()
	tag, msg := readRuntimeMessage(t, c)
	if tag != protocol.TagSubscribeSingleApplied {
		t.Fatalf("tag = %d, msg = %T, want SubscribeSingleApplied", tag, msg)
	}
	applied, ok := msg.(protocol.SubscribeSingleApplied)
	if !ok {
		t.Fatalf("msg = %T, want protocol.SubscribeSingleApplied", msg)
	}
	if applied.RequestID != requestID || applied.QueryID != queryID || applied.TableName != "notifications" {
		t.Fatalf("SubscribeSingleApplied = %+v, want request=%d query=%d notifications", applied, requestID, queryID)
	}
	rows, err := DecodeRows(applied.Rows, table)
	if err != nil {
		t.Fatalf("DecodeRows notifications: %v", err)
	}
	notifications, err := NotificationsFromRows(rows)
	if err != nil {
		t.Fatalf("NotificationsFromRows: %v", err)
	}
	return notifications
}

func requireUnsubscribeSingleApplied(t *testing.T, c *Client, requestID uint32, queryID uint32) {
	t.Helper()
	tag, msg := readRuntimeMessage(t, c)
	if tag != protocol.TagUnsubscribeSingleApplied {
		t.Fatalf("tag = %d, msg = %T, want UnsubscribeSingleApplied", tag, msg)
	}
	applied, ok := msg.(protocol.UnsubscribeSingleApplied)
	if !ok {
		t.Fatalf("msg = %T, want protocol.UnsubscribeSingleApplied", msg)
	}
	if applied.RequestID != requestID || applied.QueryID != queryID {
		t.Fatalf("UnsubscribeSingleApplied = %+v, want request=%d query=%d", applied, requestID, queryID)
	}
}

func usersByHandle(users []UserRow) map[string]UserRow {
	out := make(map[string]UserRow, len(users))
	for _, user := range users {
		out[user.Handle] = user
	}
	return out
}

func commentsByID(comments []CommentRow) map[uint64]CommentRow {
	out := make(map[uint64]CommentRow, len(comments))
	for _, comment := range comments {
		out[comment.ID] = comment
	}
	return out
}

func notificationsByID(notifications []NotificationRow) map[uint64]NotificationRow {
	out := make(map[uint64]NotificationRow, len(notifications))
	for _, notification := range notifications {
		out[notification.ID] = notification
	}
	return out
}

func auditLogsByID(logs []AuditLogRow) map[uint64]AuditLogRow {
	out := make(map[uint64]AuditLogRow, len(logs))
	for _, entry := range logs {
		out[entry.ID] = entry
	}
	return out
}

func ticketIDs(tickets []TicketRow) []uint64 {
	out := make([]uint64, 0, len(tickets))
	for _, ticket := range tickets {
		out = append(out, ticket.ID)
	}
	return out
}

func sortedTicketIDs(tickets []TicketRow) []uint64 {
	out := ticketIDs(tickets)
	sort.Slice(out, func(i, j int) bool {
		return out[i] < out[j]
	})
	return out
}

func sortedCommentIDs(comments []CommentRow) []uint64 {
	out := make([]uint64, 0, len(comments))
	for _, comment := range comments {
		out = append(out, comment.ID)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i] < out[j]
	})
	return out
}

func sortedNotificationIDs(notifications []NotificationRow) []uint64 {
	out := make([]uint64, 0, len(notifications))
	for _, notification := range notifications {
		out = append(out, notification.ID)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i] < out[j]
	})
	return out
}

func sortedAuditIDs(logs []AuditLogRow) []uint64 {
	out := make([]uint64, 0, len(logs))
	for _, entry := range logs {
		out = append(out, entry.ID)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i] < out[j]
	})
	return out
}
