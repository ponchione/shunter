package client

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"

	"github.com/coder/websocket"

	"github.com/ponchione/shunter/protocol"
)

// Client is a small WebSocket protocol wrapper for canary workflow tests. It
// deliberately exposes decoded Shunter protocol messages rather than hiding
// them behind a larger SDK abstraction.
type Client struct {
	conn *websocket.Conn
}

// Dial connects to a Shunter runtime protocol endpoint using bearer-token auth.
// runtimeURL may be an http(s) runtime base URL, a ws(s) endpoint URL, or a
// bare host:port value; base URLs are normalized to /subscribe.
func Dial(ctx context.Context, runtimeURL, bearerToken string) (*Client, error) {
	wsURL, err := protocolURL(runtimeURL)
	if err != nil {
		return nil, err
	}
	header := http.Header{}
	if bearerToken != "" {
		header.Set("Authorization", "Bearer "+bearerToken)
	}
	conn, _, err := websocket.Dial(ctx, wsURL, &websocket.DialOptions{
		HTTPHeader:   header,
		Subprotocols: []string{protocol.SubprotocolV1},
	})
	if err != nil {
		return nil, fmt.Errorf("dial protocol %s: %w", wsURL, err)
	}
	return &Client{conn: conn}, nil
}

// Close sends a normal WebSocket close frame.
func (c *Client) Close() error {
	if c == nil || c.conn == nil {
		return nil
	}
	return c.conn.Close(websocket.StatusNormalClosure, "")
}

// CloseNow closes the WebSocket connection without waiting for a close reply.
func (c *Client) CloseNow() error {
	if c == nil || c.conn == nil {
		return nil
	}
	return c.conn.CloseNow()
}

// CallReducer sends a CallReducer protocol message with JSON-encoded args.
func (c *Client) CallReducer(name string, args any, requestID uint32, flags byte) error {
	argBytes, err := reducerArgs(args)
	if err != nil {
		return err
	}
	return c.write(context.Background(), protocol.CallReducerMsg{
		ReducerName: name,
		Args:        argBytes,
		RequestID:   requestID,
		Flags:       flags,
	})
}

// OneOff sends a raw SQL one-off query.
func (c *Client) OneOff(sql string, messageID []byte) error {
	return c.write(context.Background(), protocol.OneOffQueryMsg{
		MessageID:   cloneBytes(messageID),
		QueryString: sql,
	})
}

// DeclaredQuery sends a named declared query request.
func (c *Client) DeclaredQuery(name string, messageID []byte) error {
	return c.write(context.Background(), protocol.DeclaredQueryMsg{
		MessageID: cloneBytes(messageID),
		Name:      name,
	})
}

// SubscribeSingle subscribes to one raw SQL query.
func (c *Client) SubscribeSingle(sql string, requestID uint32, queryID uint32) error {
	return c.write(context.Background(), protocol.SubscribeSingleMsg{
		RequestID:   requestID,
		QueryID:     queryID,
		QueryString: sql,
	})
}

// SubscribeMulti subscribes to multiple raw SQL queries under one query ID.
func (c *Client) SubscribeMulti(sqls []string, requestID uint32, queryID uint32) error {
	return c.write(context.Background(), protocol.SubscribeMultiMsg{
		RequestID:    requestID,
		QueryID:      queryID,
		QueryStrings: append([]string(nil), sqls...),
	})
}

// SubscribeDeclaredView subscribes to a named declared view.
func (c *Client) SubscribeDeclaredView(name string, requestID uint32, queryID uint32) error {
	return c.write(context.Background(), protocol.SubscribeDeclaredViewMsg{
		RequestID: requestID,
		QueryID:   queryID,
		Name:      name,
	})
}

// UnsubscribeSingle removes one raw SQL subscription.
func (c *Client) UnsubscribeSingle(requestID uint32, queryID uint32) error {
	return c.write(context.Background(), protocol.UnsubscribeSingleMsg{
		RequestID: requestID,
		QueryID:   queryID,
	})
}

// UnsubscribeMulti removes every subscription under the query ID.
func (c *Client) UnsubscribeMulti(requestID uint32, queryID uint32) error {
	return c.write(context.Background(), protocol.UnsubscribeMultiMsg{
		RequestID: requestID,
		QueryID:   queryID,
	})
}

// Read reads one binary WebSocket frame and decodes it as a Shunter server
// protocol message.
func (c *Client) Read(ctx context.Context) (uint8, any, error) {
	if c == nil || c.conn == nil {
		return 0, nil, fmt.Errorf("protocol client is not connected")
	}
	messageType, frame, err := c.conn.Read(ctx)
	if err != nil {
		return 0, nil, fmt.Errorf("read protocol frame: %w", err)
	}
	if messageType != websocket.MessageBinary {
		return 0, nil, fmt.Errorf("read protocol frame: got websocket message type %v, want binary", messageType)
	}
	tag, msg, err := protocol.DecodeServerMessage(frame)
	if err != nil {
		return 0, nil, fmt.Errorf("decode protocol frame: %w", err)
	}
	return tag, msg, nil
}

func (c *Client) write(ctx context.Context, msg any) error {
	if c == nil || c.conn == nil {
		return fmt.Errorf("protocol client is not connected")
	}
	frame, err := protocol.EncodeClientMessage(msg)
	if err != nil {
		return fmt.Errorf("encode protocol message %T: %w", msg, err)
	}
	if err := c.conn.Write(ctx, websocket.MessageBinary, frame); err != nil {
		return fmt.Errorf("write protocol message %T: %w", msg, err)
	}
	return nil
}

func reducerArgs(args any) ([]byte, error) {
	switch v := args.(type) {
	case nil:
		return nil, nil
	case []byte:
		return cloneBytes(v), nil
	case json.RawMessage:
		return cloneBytes(v), nil
	case string:
		return []byte(v), nil
	default:
		data, err := json.Marshal(v)
		if err != nil {
			return nil, fmt.Errorf("marshal reducer args: %w", err)
		}
		return data, nil
	}
}

func protocolURL(raw string) (string, error) {
	if strings.TrimSpace(raw) == "" {
		return "", fmt.Errorf("runtime URL is required")
	}
	if !strings.Contains(raw, "://") {
		raw = "ws://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil {
		return "", fmt.Errorf("parse runtime URL: %w", err)
	}
	switch u.Scheme {
	case "http":
		u.Scheme = "ws"
	case "https":
		u.Scheme = "wss"
	case "ws", "wss":
	default:
		return "", fmt.Errorf("unsupported runtime URL scheme %q", u.Scheme)
	}
	if u.Host == "" {
		return "", fmt.Errorf("runtime URL host is required")
	}
	if u.Path == "" || u.Path == "/" {
		u.Path = "/subscribe"
	}
	return u.String(), nil
}

func cloneBytes(in []byte) []byte {
	if in == nil {
		return nil
	}
	return append([]byte(nil), in...)
}
