package app

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/auth"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

const (
	ReducerBootstrapDemo          = "bootstrap_demo"
	ReducerCreateProject          = "create_project"
	ReducerAddProjectMember       = "add_project_member"
	ReducerCreateTicket           = "create_ticket"
	ReducerAssignTicket           = "assign_ticket"
	ReducerChangeTicketStatus     = "change_ticket_status"
	ReducerAddComment             = "add_comment"
	ReducerCloseTicket            = "close_ticket"
	ReducerReopenTicket           = "reopen_ticket"
	ReducerScheduleTicketReminder = "schedule_ticket_reminder"
	ReducerFireTicketReminder     = "fire_ticket_reminder"
	ReducerFailAfterAuditProbe    = "fail_after_audit_probe"
	ReducerPanicAfterTicketProbe  = "panic_after_ticket_probe"
)

func registerReducers(m *shunter.Module) {
	m.Reducer(ReducerBootstrapDemo, bootstrapDemoReducer, withReducerPermissions(PermAdminWrite)).
		Reducer(ReducerCreateProject, createProjectReducer, withReducerPermissions(PermProjectWrite)).
		Reducer(ReducerAddProjectMember, addProjectMemberReducer, withReducerPermissions(PermProjectWrite)).
		Reducer(ReducerCreateTicket, createTicketReducer, withReducerPermissions(PermTicketWrite)).
		Reducer(ReducerAssignTicket, assignTicketReducer, withReducerPermissions(PermTicketWrite)).
		Reducer(ReducerChangeTicketStatus, changeTicketStatusReducer, withReducerPermissions(PermTicketWrite)).
		Reducer(ReducerAddComment, addCommentReducer, withReducerPermissions(PermCommentWrite)).
		Reducer(ReducerCloseTicket, closeTicketReducer, withReducerPermissions(PermTicketWrite)).
		Reducer(ReducerReopenTicket, reopenTicketReducer, withReducerPermissions(PermTicketWrite)).
		Reducer(ReducerScheduleTicketReminder, scheduleTicketReminderReducer, withReducerPermissions(PermTicketWrite)).
		Reducer(ReducerFireTicketReminder, fireTicketReminderReducer).
		Reducer(ReducerFailAfterAuditProbe, failAfterAuditProbeReducer, withReducerPermissions(PermAdminWrite)).
		Reducer(ReducerPanicAfterTicketProbe, panicAfterTicketProbeReducer, withReducerPermissions(PermAdminWrite))
}

func withReducerPermissions(required ...string) shunter.ReducerOption {
	return shunter.WithReducerPermissions(shunter.PermissionMetadata{Required: required})
}

type bootstrapDemoArgs struct {
	NowNS *int64 `json:"now_ns"`
}

func bootstrapDemoReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[bootstrapDemoArgs](ReducerBootstrapDemo, args)
	if err != nil {
		return nil, err
	}
	nowNS, err := requiredInt64("now_ns", in.NowNS)
	if err != nil {
		return nil, err
	}
	if tableHasRows(ctx, TableUsers) || tableHasRows(ctx, TableProjects) || tableHasRows(ctx, TableTickets) {
		return nil, fmt.Errorf("%s has already been applied", ReducerBootstrapDemo)
	}
	return nil, insertBootstrapDemoRows(ctx, nowNS)
}

type createProjectArgs struct {
	ID         *uint64 `json:"id"`
	Slug       string  `json:"slug"`
	Name       string  `json:"name"`
	Visibility string  `json:"visibility"`
	NowNS      *int64  `json:"now_ns"`
}

func createProjectReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[createProjectArgs](ReducerCreateProject, args)
	if err != nil {
		return nil, err
	}
	if err := validateCreateProjectArgs(in); err != nil {
		return nil, err
	}
	id := *in.ID
	nowNS := *in.NowNS
	actor := ctx.Caller.Identity.Hex()

	if _, err := ctx.DB.Insert(uint32(TableProjects), projectRow(seedProject{
		id:            id,
		slug:          in.Slug,
		name:          in.Name,
		visibility:    in.Visibility,
		ownerIdentity: actor,
		createdAtNS:   nowNS,
	})); err != nil {
		return nil, fmt.Errorf("insert project %d: %w", id, err)
	}
	memberID := nextPrimaryID(ctx, TableProjectMembers)
	if _, err := ctx.DB.Insert(uint32(TableProjectMembers), projectMemberRow(seedProjectMember{
		id:           memberID,
		projectID:    id,
		userIdentity: actor,
		role:         "owner",
		createdAtNS:  nowNS,
	})); err != nil {
		return nil, fmt.Errorf("insert project owner member %d: %w", memberID, err)
	}
	if err := insertAudit(ctx, actor, ReducerCreateProject, "projects", id, "created project "+in.Slug, nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type addProjectMemberArgs struct {
	ID           *uint64 `json:"id"`
	ProjectID    *uint64 `json:"project_id"`
	UserIdentity string  `json:"user_identity"`
	Role         string  `json:"role"`
	NowNS        *int64  `json:"now_ns"`
}

func addProjectMemberReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[addProjectMemberArgs](ReducerAddProjectMember, args)
	if err != nil {
		return nil, err
	}
	if err := validateAddProjectMemberArgs(in); err != nil {
		return nil, err
	}
	id := *in.ID
	projectID := *in.ProjectID
	nowNS := *in.NowNS
	if _, _, ok := findProject(ctx, projectID); !ok {
		return nil, fmt.Errorf("project %d not found", projectID)
	}
	if _, err := ctx.DB.Insert(uint32(TableProjectMembers), projectMemberRow(seedProjectMember{
		id:           id,
		projectID:    projectID,
		userIdentity: in.UserIdentity,
		role:         in.Role,
		createdAtNS:  nowNS,
	})); err != nil {
		return nil, fmt.Errorf("insert project member %d: %w", id, err)
	}
	if err := insertAudit(ctx, ctx.Caller.Identity.Hex(), ReducerAddProjectMember, "project_members", id, "added project member", nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type createTicketArgs struct {
	ID               *uint64 `json:"id"`
	ProjectID        *uint64 `json:"project_id"`
	Number           *uint64 `json:"number"`
	Title            string  `json:"title"`
	Priority         string  `json:"priority"`
	Visibility       string  `json:"visibility"`
	AssigneeIdentity string  `json:"assignee_identity"`
	NowNS            *int64  `json:"now_ns"`
}

func createTicketReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[createTicketArgs](ReducerCreateTicket, args)
	if err != nil {
		return nil, err
	}
	if err := validateCreateTicketArgs(in); err != nil {
		return nil, err
	}
	id := *in.ID
	projectID := *in.ProjectID
	nowNS := *in.NowNS
	if _, _, ok := findProject(ctx, projectID); !ok {
		return nil, fmt.Errorf("project %d not found", projectID)
	}
	reporter := ctx.Caller.Identity.Hex()
	if _, err := ctx.DB.Insert(uint32(TableTickets), ticketRow(seedTicket{
		id:               id,
		projectID:        projectID,
		number:           *in.Number,
		title:            in.Title,
		status:           "open",
		priority:         in.Priority,
		visibility:       in.Visibility,
		reporterIdentity: reporter,
		assigneeIdentity: in.AssigneeIdentity,
		updatedAtNS:      nowNS,
	})); err != nil {
		return nil, fmt.Errorf("insert ticket %d: %w", id, err)
	}
	if in.AssigneeIdentity != "" {
		if err := insertNotification(ctx, in.AssigneeIdentity, id, "assigned", fmt.Sprintf("Ticket %d assigned", id), nowNS); err != nil {
			return nil, err
		}
	}
	if err := insertAudit(ctx, reporter, ReducerCreateTicket, "tickets", id, "created ticket "+in.Title, nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type assignTicketArgs struct {
	TicketID         *uint64 `json:"ticket_id"`
	AssigneeIdentity string  `json:"assignee_identity"`
	NowNS            *int64  `json:"now_ns"`
}

func assignTicketReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[assignTicketArgs](ReducerAssignTicket, args)
	if err != nil {
		return nil, err
	}
	if err := validateAssignTicketArgs(in); err != nil {
		return nil, err
	}
	ticketID := *in.TicketID
	nowNS := *in.NowNS
	rowID, ticket, ok := findTicket(ctx, ticketID)
	if !ok {
		return nil, fmt.Errorf("ticket %d not found", ticketID)
	}
	ticket.assigneeIdentity = in.AssigneeIdentity
	ticket.updatedAtNS = nowNS
	if _, err := ctx.DB.Update(uint32(TableTickets), rowID, ticketRow(ticket)); err != nil {
		return nil, fmt.Errorf("assign ticket %d: %w", ticketID, err)
	}
	if err := insertNotification(ctx, in.AssigneeIdentity, ticketID, "assigned", fmt.Sprintf("Ticket %d assigned", ticketID), nowNS); err != nil {
		return nil, err
	}
	if err := insertAudit(ctx, ctx.Caller.Identity.Hex(), ReducerAssignTicket, "tickets", ticketID, "assigned ticket", nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type changeTicketStatusArgs struct {
	TicketID *uint64 `json:"ticket_id"`
	Status   string  `json:"status"`
	NowNS    *int64  `json:"now_ns"`
}

func changeTicketStatusReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[changeTicketStatusArgs](ReducerChangeTicketStatus, args)
	if err != nil {
		return nil, err
	}
	if err := validateChangeTicketStatusArgs(in); err != nil {
		return nil, err
	}
	ticketID := *in.TicketID
	nowNS := *in.NowNS
	rowID, ticket, ok := findTicket(ctx, ticketID)
	if !ok {
		return nil, fmt.Errorf("ticket %d not found", ticketID)
	}
	actor := ctx.Caller.Identity.Hex()
	ticket.status = in.Status
	ticket.updatedAtNS = nowNS
	if _, err := ctx.DB.Update(uint32(TableTickets), rowID, ticketRow(ticket)); err != nil {
		return nil, fmt.Errorf("change ticket %d status: %w", ticketID, err)
	}
	if err := insertTicketNotifications(ctx, ticket, actor, "status_changed", fmt.Sprintf("Ticket %d status changed to %s", ticketID, in.Status), nowNS); err != nil {
		return nil, err
	}
	if err := insertAudit(ctx, actor, ReducerChangeTicketStatus, "tickets", ticketID, "changed ticket status to "+in.Status, nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type addCommentArgs struct {
	ID         *uint64 `json:"id"`
	TicketID   *uint64 `json:"ticket_id"`
	Visibility string  `json:"visibility"`
	Body       string  `json:"body"`
	NowNS      *int64  `json:"now_ns"`
}

func addCommentReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[addCommentArgs](ReducerAddComment, args)
	if err != nil {
		return nil, err
	}
	if err := validateAddCommentArgs(in); err != nil {
		return nil, err
	}
	id := *in.ID
	ticketID := *in.TicketID
	nowNS := *in.NowNS
	_, ticket, ok := findTicket(ctx, ticketID)
	if !ok {
		return nil, fmt.Errorf("ticket %d not found", ticketID)
	}
	actor := ctx.Caller.Identity.Hex()
	if _, err := ctx.DB.Insert(uint32(TableComments), commentRow(seedComment{
		id:             id,
		ticketID:       ticketID,
		projectID:      ticket.projectID,
		authorIdentity: actor,
		visibility:     in.Visibility,
		body:           in.Body,
		createdAtNS:    nowNS,
	})); err != nil {
		return nil, fmt.Errorf("insert comment %d: %w", id, err)
	}
	if err := insertTicketNotifications(ctx, ticket, actor, "comment", fmt.Sprintf("Ticket %d has a new comment", ticketID), nowNS); err != nil {
		return nil, err
	}
	if err := insertAudit(ctx, actor, ReducerAddComment, "comments", id, "added comment", nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type ticketStatusOnlyArgs struct {
	TicketID *uint64 `json:"ticket_id"`
	NowNS    *int64  `json:"now_ns"`
}

func closeTicketReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[ticketStatusOnlyArgs](ReducerCloseTicket, args)
	if err != nil {
		return nil, err
	}
	if err := validateTicketStatusOnlyArgs(in); err != nil {
		return nil, err
	}
	return nil, setTicketStatus(ctx, *in.TicketID, "closed", *in.NowNS, ReducerCloseTicket)
}

func reopenTicketReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[ticketStatusOnlyArgs](ReducerReopenTicket, args)
	if err != nil {
		return nil, err
	}
	if err := validateTicketStatusOnlyArgs(in); err != nil {
		return nil, err
	}
	return nil, setTicketStatus(ctx, *in.TicketID, "open", *in.NowNS, ReducerReopenTicket)
}

type scheduleTicketReminderArgs struct {
	ID                *uint64 `json:"id"`
	TicketID          *uint64 `json:"ticket_id"`
	RecipientIdentity string  `json:"recipient_identity"`
	DelayMS           *int64  `json:"delay_ms"`
	NowNS             *int64  `json:"now_ns"`
}

func scheduleTicketReminderReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[scheduleTicketReminderArgs](ReducerScheduleTicketReminder, args)
	if err != nil {
		return nil, err
	}
	if err := validateScheduleTicketReminderArgs(in); err != nil {
		return nil, err
	}
	id := *in.ID
	ticketID := *in.TicketID
	delayMS := *in.DelayMS
	nowNS := *in.NowNS
	if _, _, ok := findTicket(ctx, ticketID); !ok {
		return nil, fmt.Errorf("ticket %d not found", ticketID)
	}
	fireArgs, err := json.Marshal(fireTicketReminderArgs{ReminderID: &id})
	if err != nil {
		return nil, fmt.Errorf("marshal reminder fire args: %w", err)
	}
	scheduleID, err := ctx.Scheduler.Schedule(ReducerFireTicketReminder, fireArgs, ctx.Caller.Timestamp.Add(time.Duration(delayMS)*time.Millisecond))
	if err != nil {
		return nil, fmt.Errorf("schedule ticket reminder %d: %w", id, err)
	}
	if _, err := ctx.DB.Insert(uint32(TableTicketReminders), ticketReminderRow(seedTicketReminder{
		id:                id,
		ticketID:          ticketID,
		recipientIdentity: in.RecipientIdentity,
		scheduleID:        uint64(scheduleID),
		dueAtNS:           nowNS + delayMS*int64(time.Millisecond),
		fired:             false,
	})); err != nil {
		return nil, fmt.Errorf("insert ticket reminder %d: %w", id, err)
	}
	if err := insertAudit(ctx, ctx.Caller.Identity.Hex(), ReducerScheduleTicketReminder, "ticket_reminders", id, "scheduled ticket reminder", nowNS); err != nil {
		return nil, err
	}
	return nil, nil
}

type fireTicketReminderArgs struct {
	ReminderID *uint64 `json:"reminder_id"`
}

func fireTicketReminderReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	in, err := decodeReducerArgs[fireTicketReminderArgs](ReducerFireTicketReminder, args)
	if err != nil {
		return nil, err
	}
	reminderID, err := requiredUint64("reminder_id", in.ReminderID)
	if err != nil {
		return nil, err
	}
	rowID, reminder, ok := findTicketReminder(ctx, reminderID)
	if !ok || reminder.fired {
		return nil, nil
	}
	reminder.fired = true
	if _, err := ctx.DB.Update(uint32(TableTicketReminders), rowID, ticketReminderRow(reminder)); err != nil {
		return nil, fmt.Errorf("mark ticket reminder %d fired: %w", reminderID, err)
	}
	if err := insertNotification(ctx, reminder.recipientIdentity, reminder.ticketID, "reminder", fmt.Sprintf("Ticket %d reminder", reminder.ticketID), reminder.dueAtNS); err != nil {
		return nil, err
	}
	if err := insertAudit(ctx, "system", ReducerFireTicketReminder, "ticket_reminders", reminderID, "fired ticket reminder", reminder.dueAtNS); err != nil {
		return nil, err
	}
	return nil, nil
}

func failAfterAuditProbeReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	if err := decodeOptionalNoArgs(ReducerFailAfterAuditProbe, args); err != nil {
		return nil, err
	}
	if err := insertAudit(ctx, ctx.Caller.Identity.Hex(), ReducerFailAfterAuditProbe, "audit_log", 0, "rollback probe audit row", 0); err != nil {
		return nil, err
	}
	return nil, fmt.Errorf("%s forced rollback after audit insert", ReducerFailAfterAuditProbe)
}

func panicAfterTicketProbeReducer(ctx *schema.ReducerContext, args []byte) ([]byte, error) {
	if err := decodeOptionalNoArgs(ReducerPanicAfterTicketProbe, args); err != nil {
		return nil, err
	}
	_, _ = ctx.DB.Insert(uint32(TableTickets), ticketRow(seedTicket{
		id:               9999,
		projectID:        1,
		number:           9999,
		title:            "panic rollback probe",
		status:           "open",
		priority:         "normal",
		visibility:       "public",
		reporterIdentity: ctx.Caller.Identity.Hex(),
		updatedAtNS:      0,
	}))
	panic(ReducerPanicAfterTicketProbe + " forced rollback after ticket insert")
}

func insertBootstrapDemoRows(ctx *schema.ReducerContext, nowNS int64) error {
	identities := map[string]string{}
	for _, subject := range []string{"admin", "alice", "bob", "carol", "auditor", "outsider"} {
		identities[subject] = auth.DeriveIdentity(StrictAuthIssuer, subject).Hex()
	}

	users := []seedUser{
		{id: 1, identity: identities["admin"], handle: "admin", displayName: "Admin", role: "admin", active: true},
		{id: 2, identity: identities["alice"], handle: "alice", displayName: "Alice", role: "operator", active: true},
		{id: 3, identity: identities["bob"], handle: "bob", displayName: "Bob", role: "operator", active: true},
		{id: 4, identity: identities["carol"], handle: "carol", displayName: "Carol", role: "operator", active: true},
		{id: 5, identity: identities["auditor"], handle: "auditor", displayName: "Auditor", role: "auditor", active: true},
		{id: 6, identity: identities["outsider"], handle: "outsider", displayName: "Outsider", role: "viewer", active: true},
	}
	for _, row := range users {
		if _, err := ctx.DB.Insert(uint32(TableUsers), userRow(row)); err != nil {
			return fmt.Errorf("insert seed user %s: %w", row.handle, err)
		}
	}

	project := seedProject{
		id:            1,
		slug:          "alpha",
		name:          "Alpha",
		visibility:    "internal",
		ownerIdentity: identities["admin"],
		createdAtNS:   nowNS,
	}
	if _, err := ctx.DB.Insert(uint32(TableProjects), projectRow(project)); err != nil {
		return fmt.Errorf("insert seed project alpha: %w", err)
	}

	members := []seedProjectMember{
		{id: 1, projectID: 1, userIdentity: identities["admin"], role: "owner", createdAtNS: nowNS},
		{id: 2, projectID: 1, userIdentity: identities["alice"], role: "member", createdAtNS: nowNS},
		{id: 3, projectID: 1, userIdentity: identities["bob"], role: "member", createdAtNS: nowNS},
	}
	for _, row := range members {
		if _, err := ctx.DB.Insert(uint32(TableProjectMembers), projectMemberRow(row)); err != nil {
			return fmt.Errorf("insert seed project member %d: %w", row.id, err)
		}
	}

	tickets := []seedTicket{
		{
			id:               100,
			projectID:        1,
			number:           1,
			title:            "Investigate canary deploy",
			status:           "open",
			priority:         "high",
			visibility:       "internal",
			reporterIdentity: identities["alice"],
			assigneeIdentity: identities["bob"],
			updatedAtNS:      nowNS,
		},
		{
			id:               200,
			projectID:        1,
			number:           2,
			title:            "Publish status note",
			status:           "open",
			priority:         "normal",
			visibility:       "public",
			reporterIdentity: identities["carol"],
			assigneeIdentity: "",
			updatedAtNS:      nowNS,
		},
	}
	for _, row := range tickets {
		if _, err := ctx.DB.Insert(uint32(TableTickets), ticketRow(row)); err != nil {
			return fmt.Errorf("insert seed ticket %d: %w", row.id, err)
		}
	}

	comments := []seedComment{
		{
			id:             500,
			ticketID:       100,
			projectID:      1,
			authorIdentity: identities["alice"],
			visibility:     "public",
			body:           "Initial public triage note",
			createdAtNS:    nowNS,
		},
		{
			id:             501,
			ticketID:       100,
			projectID:      1,
			authorIdentity: identities["bob"],
			visibility:     "internal",
			body:           "Internal handoff details",
			createdAtNS:    nowNS,
		},
	}
	for _, row := range comments {
		if _, err := ctx.DB.Insert(uint32(TableComments), commentRow(row)); err != nil {
			return fmt.Errorf("insert seed comment %d: %w", row.id, err)
		}
	}

	notifications := []seedNotification{
		{
			id:                600,
			recipientIdentity: identities["bob"],
			ticketID:          100,
			kind:              "assigned",
			body:              "Ticket 100 assigned to bob",
			delivered:         false,
			createdAtNS:       nowNS,
		},
	}
	for _, row := range notifications {
		if _, err := ctx.DB.Insert(uint32(TableNotifications), notificationRow(row)); err != nil {
			return fmt.Errorf("insert seed notification %d: %w", row.id, err)
		}
	}

	audits := []seedAuditLog{
		{id: 900, actorIdentity: identities["admin"], action: "bootstrap_demo", targetTable: "users", targetID: 1, body: "seeded users", createdAtNS: nowNS},
		{id: 901, actorIdentity: identities["admin"], action: "bootstrap_demo", targetTable: "projects", targetID: 1, body: "seeded alpha project", createdAtNS: nowNS},
		{id: 902, actorIdentity: identities["admin"], action: "bootstrap_demo", targetTable: "tickets", targetID: 100, body: "seeded tickets", createdAtNS: nowNS},
		{id: 903, actorIdentity: identities["admin"], action: "bootstrap_demo", targetTable: "comments", targetID: 500, body: "seeded comments", createdAtNS: nowNS},
	}
	for _, row := range audits {
		if err := insertAuditRow(ctx, row, false); err != nil {
			return fmt.Errorf("insert seed audit %d: %w", row.id, err)
		}
	}

	return nil
}

func tableHasRows(ctx *schema.ReducerContext, tableID schema.TableID) bool {
	for range ctx.DB.ScanTable(uint32(tableID)) {
		return true
	}
	return false
}

func findProject(ctx *schema.ReducerContext, id uint64) (types.RowID, seedProject, bool) {
	for rowID, row := range ctx.DB.ScanTable(uint32(TableProjects)) {
		project := projectFromProduct(row)
		if project.id == id {
			return rowID, project, true
		}
	}
	return 0, seedProject{}, false
}

func findTicket(ctx *schema.ReducerContext, id uint64) (types.RowID, seedTicket, bool) {
	// The schema builder assigns index 0 to this table's primary key.
	for rowID, row := range ctx.DB.SeekIndex(uint32(TableTickets), 0, types.NewUint64(id)) {
		return rowID, ticketFromProduct(row), true
	}
	return 0, seedTicket{}, false
}

func findTicketReminder(ctx *schema.ReducerContext, id uint64) (types.RowID, seedTicketReminder, bool) {
	for rowID, row := range ctx.DB.ScanTable(uint32(TableTicketReminders)) {
		reminder := ticketReminderFromProduct(row)
		if reminder.id == id {
			return rowID, reminder, true
		}
	}
	return 0, seedTicketReminder{}, false
}

func setTicketStatus(ctx *schema.ReducerContext, ticketID uint64, status string, nowNS int64, reducerName string) error {
	rowID, ticket, ok := findTicket(ctx, ticketID)
	if !ok {
		return fmt.Errorf("ticket %d not found", ticketID)
	}
	ticket.status = status
	ticket.updatedAtNS = nowNS
	if _, err := ctx.DB.Update(uint32(TableTickets), rowID, ticketRow(ticket)); err != nil {
		return fmt.Errorf("%s ticket %d: %w", reducerName, ticketID, err)
	}
	if err := insertAudit(ctx, ctx.Caller.Identity.Hex(), reducerName, "tickets", ticketID, "set ticket status to "+status, nowNS); err != nil {
		return err
	}
	return nil
}

func insertTicketNotifications(ctx *schema.ReducerContext, ticket seedTicket, actor, kind, body string, nowNS int64) error {
	seen := map[string]struct{}{}
	recipients := []string{}
	for _, identity := range []string{ticket.reporterIdentity, ticket.assigneeIdentity} {
		if identity == "" || identity == actor {
			continue
		}
		if _, ok := seen[identity]; ok {
			continue
		}
		seen[identity] = struct{}{}
		recipients = append(recipients, identity)
	}
	for _, identity := range recipients {
		if err := insertNotification(ctx, identity, ticket.id, kind, body, nowNS); err != nil {
			return err
		}
	}
	return nil
}

func insertNotification(ctx *schema.ReducerContext, recipientIdentity string, ticketID uint64, kind, body string, nowNS int64) error {
	if strings.TrimSpace(recipientIdentity) == "" {
		return nil
	}
	id := nextPrimaryID(ctx, TableNotifications)
	if _, err := ctx.DB.Insert(uint32(TableNotifications), notificationRow(seedNotification{
		id:                id,
		recipientIdentity: recipientIdentity,
		ticketID:          ticketID,
		kind:              kind,
		body:              body,
		delivered:         false,
		createdAtNS:       nowNS,
	})); err != nil {
		return fmt.Errorf("insert notification %d: %w", id, err)
	}
	return nil
}

func insertAudit(ctx *schema.ReducerContext, actor, action, targetTable string, targetID uint64, body string, nowNS int64) error {
	return insertAuditRow(ctx, seedAuditLog{
		actorIdentity: actor, action: action, targetTable: targetTable,
		targetID: targetID, body: body, createdAtNS: nowNS,
	}, true)
}

func nextPrimaryID(ctx *schema.ReducerContext, tableID schema.TableID) uint64 {
	var max uint64
	for _, row := range ctx.DB.ScanTable(uint32(tableID)) {
		if len(row) == 0 {
			continue
		}
		id := row[0].AsUint64()
		if id > max {
			max = id
		}
	}
	return max + 1
}

func projectFromProduct(row types.ProductValue) seedProject {
	return seedProject{
		id:            row[0].AsUint64(),
		slug:          row[1].AsString(),
		name:          row[2].AsString(),
		visibility:    row[3].AsString(),
		ownerIdentity: row[4].AsString(),
		createdAtNS:   row[5].AsInt64(),
	}
}

func ticketFromProduct(row types.ProductValue) seedTicket {
	return seedTicket{
		id:               row[0].AsUint64(),
		projectID:        row[1].AsUint64(),
		number:           row[2].AsUint64(),
		title:            row[3].AsString(),
		status:           row[4].AsString(),
		priority:         row[5].AsString(),
		visibility:       row[6].AsString(),
		reporterIdentity: row[7].AsString(),
		assigneeIdentity: row[8].AsString(),
		updatedAtNS:      row[9].AsInt64(),
	}
}

func ticketReminderFromProduct(row types.ProductValue) seedTicketReminder {
	return seedTicketReminder{
		id:                row[0].AsUint64(),
		ticketID:          row[1].AsUint64(),
		recipientIdentity: row[2].AsString(),
		scheduleID:        row[3].AsUint64(),
		dueAtNS:           row[4].AsInt64(),
		fired:             row[5].AsBool(),
	}
}

func validateCreateProjectArgs(in createProjectArgs) error {
	if _, err := requiredUint64("id", in.ID); err != nil {
		return err
	}
	if err := requiredString("slug", in.Slug); err != nil {
		return err
	}
	if err := requiredString("name", in.Name); err != nil {
		return err
	}
	if err := validateEnum("visibility", in.Visibility, allowedVisibility); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateAddProjectMemberArgs(in addProjectMemberArgs) error {
	if _, err := requiredUint64("id", in.ID); err != nil {
		return err
	}
	if _, err := requiredUint64("project_id", in.ProjectID); err != nil {
		return err
	}
	if err := requiredString("user_identity", in.UserIdentity); err != nil {
		return err
	}
	if err := requiredString("role", in.Role); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateCreateTicketArgs(in createTicketArgs) error {
	if _, err := requiredUint64("id", in.ID); err != nil {
		return err
	}
	if _, err := requiredUint64("project_id", in.ProjectID); err != nil {
		return err
	}
	if _, err := requiredUint64("number", in.Number); err != nil {
		return err
	}
	if err := requiredString("title", in.Title); err != nil {
		return err
	}
	if err := validateEnum("priority", in.Priority, allowedPriority); err != nil {
		return err
	}
	if err := validateEnum("visibility", in.Visibility, allowedVisibility); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateAssignTicketArgs(in assignTicketArgs) error {
	if _, err := requiredUint64("ticket_id", in.TicketID); err != nil {
		return err
	}
	if err := requiredString("assignee_identity", in.AssigneeIdentity); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateChangeTicketStatusArgs(in changeTicketStatusArgs) error {
	if _, err := requiredUint64("ticket_id", in.TicketID); err != nil {
		return err
	}
	if err := validateEnum("status", in.Status, allowedStatus); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateAddCommentArgs(in addCommentArgs) error {
	if _, err := requiredUint64("id", in.ID); err != nil {
		return err
	}
	if _, err := requiredUint64("ticket_id", in.TicketID); err != nil {
		return err
	}
	if err := validateEnum("visibility", in.Visibility, allowedVisibility); err != nil {
		return err
	}
	if err := requiredString("body", in.Body); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateTicketStatusOnlyArgs(in ticketStatusOnlyArgs) error {
	if _, err := requiredUint64("ticket_id", in.TicketID); err != nil {
		return err
	}
	_, err := requiredInt64("now_ns", in.NowNS)
	return err
}

func validateScheduleTicketReminderArgs(in scheduleTicketReminderArgs) error {
	if _, err := requiredUint64("id", in.ID); err != nil {
		return err
	}
	if _, err := requiredUint64("ticket_id", in.TicketID); err != nil {
		return err
	}
	if err := requiredString("recipient_identity", in.RecipientIdentity); err != nil {
		return err
	}
	delayMS, err := requiredInt64("delay_ms", in.DelayMS)
	if err != nil {
		return err
	}
	if delayMS <= 0 {
		return fmt.Errorf("delay_ms must be positive")
	}
	_, err = requiredInt64("now_ns", in.NowNS)
	return err
}

func decodeReducerArgs[T any](reducer string, args []byte) (T, error) {
	var out T
	if len(bytes.TrimSpace(args)) == 0 {
		return out, fmt.Errorf("%s args must be a JSON object", reducer)
	}
	decoder := json.NewDecoder(bytes.NewReader(args))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&out); err != nil {
		return out, fmt.Errorf("%s args: %w", reducer, err)
	}
	var extra json.RawMessage
	if err := decoder.Decode(&extra); err != io.EOF {
		return out, fmt.Errorf("%s args must contain one JSON value", reducer)
	}
	return out, nil
}

func decodeOptionalNoArgs(reducer string, args []byte) error {
	if len(bytes.TrimSpace(args)) == 0 {
		return nil
	}
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(args, &obj); err != nil {
		return fmt.Errorf("%s args: %w", reducer, err)
	}
	if len(obj) != 0 {
		return fmt.Errorf("%s args must be empty", reducer)
	}
	return nil
}

func requiredUint64(name string, value *uint64) (uint64, error) {
	if value == nil {
		return 0, fmt.Errorf("%s is required", name)
	}
	return *value, nil
}

func requiredInt64(name string, value *int64) (int64, error) {
	if value == nil {
		return 0, fmt.Errorf("%s is required", name)
	}
	return *value, nil
}

func requiredString(name, value string) error {
	if strings.TrimSpace(value) == "" {
		return fmt.Errorf("%s is required", name)
	}
	return nil
}

func validateEnum(name, value string, allowed map[string]struct{}) error {
	if _, ok := allowed[value]; ok {
		return nil
	}
	return fmt.Errorf("%s has invalid value %q", name, value)
}

var (
	allowedVisibility = map[string]struct{}{
		"public":   {},
		"internal": {},
	}
	allowedStatus = map[string]struct{}{
		"open":        {},
		"in_progress": {},
		"blocked":     {},
		"closed":      {},
	}
	allowedPriority = map[string]struct{}{
		"low":    {},
		"normal": {},
		"high":   {},
	}
)
