package app

import (
	"bytes"
	"encoding/json"
	"os/exec"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/schema"
)

func TestNewModuleBuildsRuntime(t *testing.T) {
	rt, err := shunter.Build(NewModule(), shunter.Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	if rt.ModuleName() != ModuleName {
		t.Fatalf("ModuleName() = %q, want %q", rt.ModuleName(), ModuleName)
	}
}

func TestNewModuleExportsContract(t *testing.T) {
	rt, err := shunter.Build(NewModule(), shunter.Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}

	contract := rt.ExportContract()
	if contract.Module.Name != ModuleName {
		t.Fatalf("contract module name = %q, want %q", contract.Module.Name, ModuleName)
	}
	if len(contract.Schema.Tables) == 0 {
		t.Fatal("contract has no tables")
	}
	if _, err := rt.ExportContractJSON(); err != nil {
		t.Fatalf("ExportContractJSON returned error: %v", err)
	}
}

func TestSchemaTablesMatchMilestone1Contract(t *testing.T) {
	contract := buildContract(t)

	expected := []tableExpectation{
		{
			id:      TableUsers,
			name:    "users",
			access:  schema.TableAccessPublic,
			columns: []string{"id", "identity", "handle", "display_name", "role", "active"},
			indexes: map[string]indexExpectation{
				"pk":             {columns: []string{"id"}, unique: true, primary: true},
				"users_identity": {columns: []string{"identity"}, unique: true},
				"users_handle":   {columns: []string{"handle"}, unique: true},
			},
		},
		{
			id:      TableProjects,
			name:    "projects",
			access:  schema.TableAccessPublic,
			columns: []string{"id", "slug", "name", "visibility", "owner_identity", "created_at_ns"},
			indexes: map[string]indexExpectation{
				"pk":            {columns: []string{"id"}, unique: true, primary: true},
				"projects_slug": {columns: []string{"slug"}, unique: true},
			},
		},
		{
			id:      TableProjectMembers,
			name:    "project_members",
			access:  schema.TableAccessPrivate,
			columns: []string{"id", "project_id", "user_identity", "role", "created_at_ns"},
			indexes: map[string]indexExpectation{
				"pk":                      {columns: []string{"id"}, unique: true, primary: true},
				"project_members_project": {columns: []string{"project_id"}},
				"project_members_user":    {columns: []string{"user_identity"}},
			},
		},
		{
			id:      TableTickets,
			name:    "tickets",
			access:  schema.TableAccessPublic,
			columns: []string{"id", "project_id", "number", "title", "status", "priority", "visibility", "reporter_identity", "assignee_identity", "updated_at_ns"},
			indexes: map[string]indexExpectation{
				"pk":                     {columns: []string{"id"}, unique: true, primary: true},
				"tickets_project":        {columns: []string{"project_id"}},
				"tickets_assignee":       {columns: []string{"assignee_identity"}},
				"tickets_reporter":       {columns: []string{"reporter_identity"}},
				"tickets_project_number": {columns: []string{"project_id", "number"}, unique: true},
			},
		},
		{
			id:      TableComments,
			name:    "comments",
			access:  schema.TableAccessPublic,
			columns: []string{"id", "ticket_id", "project_id", "author_identity", "visibility", "body", "created_at_ns"},
			indexes: map[string]indexExpectation{
				"pk":              {columns: []string{"id"}, unique: true, primary: true},
				"comments_ticket": {columns: []string{"ticket_id"}},
				"comments_author": {columns: []string{"author_identity"}},
			},
		},
		{
			id:      TableNotifications,
			name:    "notifications",
			access:  schema.TableAccessPrivate,
			columns: []string{"id", "recipient_identity", "ticket_id", "kind", "body", "delivered", "created_at_ns"},
			indexes: map[string]indexExpectation{
				"pk":                      {columns: []string{"id"}, unique: true, primary: true},
				"notifications_recipient": {columns: []string{"recipient_identity"}},
			},
		},
		{
			id:          TableAuditLog,
			name:        "audit_log",
			access:      schema.TableAccessPermissioned,
			permissions: []string{PermAuditRead},
			columns:     []string{"id", "actor_identity", "action", "target_table", "target_id", "body", "created_at_ns"},
			indexes: map[string]indexExpectation{
				"pk":           {columns: []string{"id"}, unique: true, primary: true},
				"audit_actor":  {columns: []string{"actor_identity"}},
				"audit_target": {columns: []string{"target_table", "target_id"}},
			},
		},
		{
			id:      TableTicketReminders,
			name:    "ticket_reminders",
			access:  schema.TableAccessPrivate,
			columns: []string{"id", "ticket_id", "recipient_identity", "schedule_id", "due_at_ns", "fired"},
			indexes: map[string]indexExpectation{
				"pk":                  {columns: []string{"id"}, unique: true, primary: true},
				"reminders_ticket":    {columns: []string{"ticket_id"}},
				"reminders_recipient": {columns: []string{"recipient_identity"}},
			},
		},
	}

	if len(contract.Schema.Tables) < len(expected) {
		t.Fatalf("contract tables = %d, want at least %d", len(contract.Schema.Tables), len(expected))
	}
	for _, want := range expected {
		got := contract.Schema.Tables[int(want.id)]
		if got.Name != want.name {
			t.Fatalf("table id %d name = %q, want %q", want.id, got.Name, want.name)
		}
		if got.ReadPolicy.Access != want.access {
			t.Fatalf("%s read access = %s, want %s", got.Name, got.ReadPolicy.Access, want.access)
		}
		if !stringSlicesEqual(got.ReadPolicy.Permissions, want.permissions) {
			t.Fatalf("%s read permissions = %#v, want %#v", got.Name, got.ReadPolicy.Permissions, want.permissions)
		}
		if gotColumns := columnNames(got.Columns); !reflect.DeepEqual(gotColumns, want.columns) {
			t.Fatalf("%s columns = %#v, want %#v", got.Name, gotColumns, want.columns)
		}
		gotIndexes := indexMap(got.Indexes)
		if !reflect.DeepEqual(gotIndexes, want.indexes) {
			t.Fatalf("%s indexes = %#v, want %#v", got.Name, gotIndexes, want.indexes)
		}
	}
}

func TestReducersAreRegisteredWithPermissionMetadata(t *testing.T) {
	contract := buildContract(t)

	wantReducers := []string{
		ReducerBootstrapDemo,
		ReducerCreateProject,
		ReducerAddProjectMember,
		ReducerCreateTicket,
		ReducerAssignTicket,
		ReducerChangeTicketStatus,
		ReducerAddComment,
		ReducerCloseTicket,
		ReducerReopenTicket,
		ReducerScheduleTicketReminder,
		ReducerFireTicketReminder,
		ReducerFailAfterAuditProbe,
		ReducerPanicAfterTicketProbe,
	}
	if got := reducerNames(contract.Schema.Reducers); !reflect.DeepEqual(got, wantReducers) {
		t.Fatalf("reducers = %#v, want %#v", got, wantReducers)
	}

	wantPermissions := map[string][]string{
		ReducerBootstrapDemo:          {PermAdminWrite},
		ReducerCreateProject:          {PermProjectWrite},
		ReducerAddProjectMember:       {PermProjectWrite},
		ReducerCreateTicket:           {PermTicketWrite},
		ReducerAssignTicket:           {PermTicketWrite},
		ReducerChangeTicketStatus:     {PermTicketWrite},
		ReducerAddComment:             {PermCommentWrite},
		ReducerCloseTicket:            {PermTicketWrite},
		ReducerReopenTicket:           {PermTicketWrite},
		ReducerScheduleTicketReminder: {PermTicketWrite},
		ReducerFailAfterAuditProbe:    {PermAdminWrite},
		ReducerPanicAfterTicketProbe:  {PermAdminWrite},
	}
	if got := permissionMap(contract.Permissions.Reducers); !reflect.DeepEqual(got, wantPermissions) {
		t.Fatalf("reducer permissions = %#v, want %#v", got, wantPermissions)
	}
}

func TestDeclaredReadsAndViewsMatchMilestone1Contract(t *testing.T) {
	contract := buildContract(t)

	wantQueries := map[string]string{
		QueryMyProfile:       "SELECT * FROM users WHERE identity = :sender",
		QueryMyTickets:       "SELECT * FROM tickets WHERE assignee_identity = :sender",
		QueryAlphaBoard:      "SELECT * FROM tickets WHERE project_id = 1",
		QueryTicket100Detail: "SELECT * FROM tickets WHERE id = 100",
		QueryAuditFeed:       "SELECT * FROM audit_log",
	}
	if got := queryMap(contract.Queries); !reflect.DeepEqual(got, wantQueries) {
		t.Fatalf("queries = %#v, want %#v", got, wantQueries)
	}

	wantViews := map[string]string{
		ViewLiveAlphaBoard:        "SELECT * FROM tickets WHERE project_id = 1",
		ViewLiveTicket100Comments: "SELECT * FROM comments WHERE ticket_id = 100",
		ViewMyNotifications:       "SELECT * FROM notifications WHERE recipient_identity = :sender",
		ViewLiveAuditFeed:         "SELECT * FROM audit_log",
	}
	if got := viewMap(contract.Views); !reflect.DeepEqual(got, wantViews) {
		t.Fatalf("views = %#v, want %#v", got, wantViews)
	}

	if got, want := permissionMap(contract.Permissions.Queries), map[string][]string{QueryAuditFeed: {PermAuditRead}}; !reflect.DeepEqual(got, want) {
		t.Fatalf("query permissions = %#v, want %#v", got, want)
	}
	if got, want := permissionMap(contract.Permissions.Views), map[string][]string{ViewLiveAuditFeed: {PermAuditRead}}; !reflect.DeepEqual(got, want) {
		t.Fatalf("view permissions = %#v, want %#v", got, want)
	}
}

func TestVisibilityFiltersMatchMilestone1Contract(t *testing.T) {
	contract := buildContract(t)

	want := map[string]visibilityFilterExpectation{
		"ticket_reporter": {
			sql:        "SELECT * FROM tickets WHERE reporter_identity = :sender",
			table:      "tickets",
			tableID:    TableTickets,
			usesCaller: true,
		},
		"ticket_assignee": {
			sql:        "SELECT * FROM tickets WHERE assignee_identity = :sender",
			table:      "tickets",
			tableID:    TableTickets,
			usesCaller: true,
		},
		"ticket_public": {
			sql:     "SELECT * FROM tickets WHERE visibility = 'public'",
			table:   "tickets",
			tableID: TableTickets,
		},
		"comment_author": {
			sql:        "SELECT * FROM comments WHERE author_identity = :sender",
			table:      "comments",
			tableID:    TableComments,
			usesCaller: true,
		},
		"comment_public": {
			sql:     "SELECT * FROM comments WHERE visibility = 'public'",
			table:   "comments",
			tableID: TableComments,
		},
		"notification_recipient": {
			sql:        "SELECT * FROM notifications WHERE recipient_identity = :sender",
			table:      "notifications",
			tableID:    TableNotifications,
			usesCaller: true,
		},
	}
	if got := visibilityFilterMap(contract.VisibilityFilters); !reflect.DeepEqual(got, want) {
		t.Fatalf("visibility filters = %#v, want %#v", got, want)
	}
}

func TestStrictAuthConfigMatchesSpec(t *testing.T) {
	cfg := StrictAuthConfig("/tmp/opsboard", "127.0.0.1:0")
	if cfg.DataDir != "/tmp/opsboard" || cfg.ListenAddr != "127.0.0.1:0" {
		t.Fatalf("strict config data/listen = %q/%q", cfg.DataDir, cfg.ListenAddr)
	}
	if !cfg.EnableProtocol || cfg.AuthMode != shunter.AuthModeStrict {
		t.Fatalf("strict config protocol/auth = %v/%v", cfg.EnableProtocol, cfg.AuthMode)
	}
	if string(cfg.AuthSigningKey) != StrictAuthSigningKey {
		t.Fatalf("strict config signing key = %q, want %q", cfg.AuthSigningKey, StrictAuthSigningKey)
	}
	if !reflect.DeepEqual(cfg.AuthIssuers, []string{StrictAuthIssuer}) {
		t.Fatalf("strict config issuers = %#v", cfg.AuthIssuers)
	}
	if !reflect.DeepEqual(cfg.AuthAudiences, []string{StrictAuthAudience}) {
		t.Fatalf("strict config audiences = %#v", cfg.AuthAudiences)
	}
}

func TestExportContractCommandIsDeterministic(t *testing.T) {
	first := runExportContract(t, filepath.Join(t.TempDir(), "first"))
	second := runExportContract(t, filepath.Join(t.TempDir(), "second"))
	if !bytes.Equal(first, second) {
		t.Fatalf("export contract output differs across temp dirs\nfirst:\n%s\nsecond:\n%s", first, second)
	}

	var decoded shunter.ModuleContract
	if err := json.Unmarshal(first, &decoded); err != nil {
		t.Fatalf("export contract output is not valid JSON: %v\n%s", err, first)
	}
	if decoded.Module.Name != ModuleName {
		t.Fatalf("export contract module name = %q, want %q", decoded.Module.Name, ModuleName)
	}
}

func buildContract(t *testing.T) shunter.ModuleContract {
	t.Helper()
	rt, err := shunter.Build(NewModule(), shunter.Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	return rt.ExportContract()
}

func runExportContract(t *testing.T, dataDir string) []byte {
	t.Helper()
	cmd := exec.Command("go", "run", "./cmd/export-contract", "--data-dir", dataDir)
	cmd.Dir = filepath.Clean(filepath.Join("..", ".."))
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("go run ./cmd/export-contract failed: %v\n%s", err, out)
	}
	return out
}

type tableExpectation struct {
	id          schema.TableID
	name        string
	access      schema.TableAccess
	permissions []string
	columns     []string
	indexes     map[string]indexExpectation
}

type indexExpectation struct {
	columns []string
	unique  bool
	primary bool
}

type visibilityFilterExpectation struct {
	sql        string
	table      string
	tableID    schema.TableID
	usesCaller bool
}

func columnNames(cols []schema.ColumnExport) []string {
	out := make([]string, len(cols))
	for i, col := range cols {
		out[i] = col.Name
	}
	return out
}

func indexMap(indexes []schema.IndexExport) map[string]indexExpectation {
	out := make(map[string]indexExpectation, len(indexes))
	for _, idx := range indexes {
		out[idx.Name] = indexExpectation{
			columns: idx.Columns,
			unique:  idx.Unique,
			primary: idx.Primary,
		}
	}
	return out
}

func reducerNames(reducers []schema.ReducerExport) []string {
	out := make([]string, len(reducers))
	for i, reducer := range reducers {
		out[i] = reducer.Name
	}
	return out
}

func permissionMap(decls []shunter.PermissionContractDeclaration) map[string][]string {
	out := make(map[string][]string, len(decls))
	for _, decl := range decls {
		out[decl.Name] = decl.Required
	}
	return out
}

func queryMap(queries []shunter.QueryDescription) map[string]string {
	out := make(map[string]string, len(queries))
	for _, query := range queries {
		out[query.Name] = query.SQL
	}
	return out
}

func viewMap(views []shunter.ViewDescription) map[string]string {
	out := make(map[string]string, len(views))
	for _, view := range views {
		out[view.Name] = view.SQL
	}
	return out
}

func visibilityFilterMap(filters []shunter.VisibilityFilterDescription) map[string]visibilityFilterExpectation {
	out := make(map[string]visibilityFilterExpectation, len(filters))
	for _, filter := range filters {
		out[filter.Name] = visibilityFilterExpectation{
			sql:        filter.SQL,
			table:      filter.ReturnTable,
			tableID:    filter.ReturnTableID,
			usesCaller: filter.UsesCallerIdentity,
		}
	}
	return out
}

func stringSlicesEqual(a, b []string) bool {
	if len(a) == 0 && len(b) == 0 {
		return true
	}
	return reflect.DeepEqual(a, b)
}
