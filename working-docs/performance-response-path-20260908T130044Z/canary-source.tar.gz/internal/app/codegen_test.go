package app

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/codegen"
)

func TestCommittedContractMatchesCurrentExport(t *testing.T) {
	want, err := os.ReadFile(filepath.Join("..", "..", "contracts", "shunter.contract.json"))
	if err != nil {
		t.Fatalf("read committed contract: %v", err)
	}

	rt, err := shunter.Build(NewModule(), shunter.Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatalf("Build returned error: %v", err)
	}
	got, err := rt.ExportContractJSON()
	if err != nil {
		t.Fatalf("ExportContractJSON returned error: %v", err)
	}
	if !bytes.Equal(got, want) {
		t.Fatalf("committed contract is stale; run `make contract`")
	}
}

func TestCommittedTypeScriptCodegenMatchesContract(t *testing.T) {
	contract, err := os.ReadFile(filepath.Join("..", "..", "contracts", "shunter.contract.json"))
	if err != nil {
		t.Fatalf("read committed contract: %v", err)
	}
	want, err := os.ReadFile(filepath.Join("..", "..", "generated", "typescript", "index.ts"))
	if err != nil {
		t.Fatalf("read committed TypeScript bindings: %v", err)
	}

	got, err := codegen.GenerateFromJSON(contract, codegen.Options{Language: codegen.LanguageTypeScript})
	if err != nil {
		t.Fatalf("GenerateFromJSON returned error: %v", err)
	}
	if !bytes.Equal(got, want) {
		t.Fatalf("committed TypeScript bindings are stale; run `make codegen`")
	}
}

func TestGeneratedTypeScriptPinsDeclaredReadHelpersAndMetadata(t *testing.T) {
	data, err := os.ReadFile(filepath.Join("..", "..", "generated", "typescript", "index.ts"))
	if err != nil {
		t.Fatalf("read committed TypeScript bindings: %v", err)
	}
	ts := string(data)

	assertGeneratedContains(t, ts, `export const shunterProtocol = {`)
	assertGeneratedContains(t, ts, `} from "@shunter/client";`)
	assertGeneratedContains(t, ts, `currentVersion: 2,`)
	assertGeneratedContains(t, ts, `defaultSubprotocol: "v2.bsatn.shunter",`)
	assertGeneratedContains(t, ts, `supportedSubprotocols: ["v2.bsatn.shunter", "v1.bsatn.shunter"],`)
	assertGeneratedContains(t, ts, `export const shunterContract = {`)
	assertGeneratedContains(t, ts, `export type ReducerCaller = ShunterReducerCaller<ReducerName, Uint8Array, Uint8Array>;`)
	assertGeneratedContains(t, ts, `export type ViewSubscriber = ShunterViewSubscriber;`)
	assertGeneratedContains(t, ts, `export type DeclaredQueryRunner = ShunterDeclaredQueryRunner<ExecutableQueryName, Uint8Array>;`)
	assertGeneratedContains(t, ts, `export type DeclaredViewSubscriber = ShunterDeclaredViewSubscriber<ExecutableViewName>;`)
	assertGeneratedContains(t, ts, `export type TableSubscriber<Row = never> = ShunterTableSubscriber<TableName, TableRows, Row>;`)
	assertGeneratedContains(t, ts, `export type TableRows = {`)
	assertGeneratedContains(t, ts, `export function decodeUsersRow(row: Uint8Array): UsersRow {`)
	assertGeneratedContains(t, ts, `export const tableRowDecoders = {`)
	assertGeneratedContains(t, ts, `export function queryMyProfile(runDeclaredQuery: DeclaredQueryRunner): Promise<Uint8Array> {`)
	assertGeneratedContains(t, ts, `return runDeclaredQuery("my_profile");`)
	assertGeneratedContains(t, ts, `export function queryMyProfileResult(data: unknown, options: DeclaredQueryDecodeOptions<MyProfileQueryRows> = {}): DecodedDeclaredQueryResult<typeof queries.myProfile, MyProfileQueryRows> {`)
	assertGeneratedContains(t, ts, `export async function queryMyProfileDecoded(runDeclaredQuery: DeclaredQueryRunner, options: DeclaredQueryDecodeOptions<MyProfileQueryRows> = {}): Promise<DecodedDeclaredQueryResult<typeof queries.myProfile, MyProfileQueryRows>> {`)
	assertGeneratedContains(t, ts, `export function subscribeLiveAlphaBoard(subscribeDeclaredView: DeclaredViewSubscriber, options: DeclaredViewSubscribeOptions<LiveAlphaBoardViewRow> = {}): Promise<SubscriptionUnsubscribe> {`)
	assertGeneratedContains(t, ts, `export function subscribeLiveAlphaBoardHandle(subscribeDeclaredView: DeclaredViewHandleSubscriber, options: DeclaredViewSubscriptionOptions<LiveAlphaBoardViewRow> & SubscriptionHandleReturnOptions): Promise<SubscriptionHandle<LiveAlphaBoardViewRow>> {`)
	assertGeneratedContains(t, ts, `return subscribeDeclaredView("live_alpha_board", subscribeOptions);`)
	assertGeneratedContains(t, ts, `export const querySQL = {`)
	assertGeneratedContains(t, ts, `myProfile: "SELECT * FROM users WHERE identity = :sender",`)
	assertGeneratedContains(t, ts, `export const viewSQL = {`)
	assertGeneratedContains(t, ts, `myNotifications: "SELECT * FROM notifications WHERE recipient_identity = :sender",`)
	assertGeneratedContains(t, ts, `export const tableReadPolicies = {`)
	assertGeneratedContains(t, ts, `notifications: { access: "private", permissions: [] },`)
	assertGeneratedContains(t, ts, `auditLog: { access: "permissioned", permissions: ["audit:read"] },`)
	assertGeneratedContains(t, ts, `export const visibilityFilters = {`)
	assertGeneratedContains(t, ts, `ticketReporter: { sql: "SELECT * FROM tickets WHERE reporter_identity = :sender", returnTable: "tickets", returnTableId: 3, usesCallerIdentity: true },`)

	assertGeneratedNotContains(t, ts, `return runDeclaredQuery("SELECT * FROM users WHERE identity = :sender");`)
	assertGeneratedNotContains(t, ts, `return subscribeDeclaredView("SELECT * FROM tickets WHERE project_id = 1");`)
	assertGeneratedNotContains(t, ts, `return runQuery("SELECT * FROM users WHERE identity = :sender");`)
	assertGeneratedNotContains(t, ts, `return subscribeView("SELECT * FROM tickets WHERE project_id = 1");`)
}

func assertGeneratedContains(t *testing.T, haystack, needle string) {
	t.Helper()
	if !strings.Contains(haystack, needle) {
		t.Fatalf("generated TypeScript missing %q", needle)
	}
}

func assertGeneratedNotContains(t *testing.T, haystack, needle string) {
	t.Helper()
	if strings.Contains(haystack, needle) {
		t.Fatalf("generated TypeScript unexpectedly contains %q", needle)
	}
}
