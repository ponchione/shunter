package app

import "github.com/ponchione/shunter"

const (
	StrictAuthIssuer     = "opsboard-canary"
	StrictAuthAudience   = "opsboard"
	StrictAuthSigningKey = "opsboard-canary-dev-signing-key-32"
)

// StrictAuthConfig returns the strict-auth runtime configuration used by the
// canary workflow tests and local server.
func StrictAuthConfig(dataDir, listenAddr string) shunter.Config {
	return shunter.Config{
		DataDir:        dataDir,
		EnableProtocol: true,
		ListenAddr:     listenAddr,
		AuthMode:       shunter.AuthModeStrict,
		AuthSigningKey: []byte(StrictAuthSigningKey),
		AuthIssuers:    []string{StrictAuthIssuer},
		AuthAudiences:  []string{StrictAuthAudience},
	}
}
