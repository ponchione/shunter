package app

import (
	"context"
	"fmt"
	"math"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/types"
)

const (
	MigrationOperationalProofAction      = "operational_migration_proof"
	MigrationOperationalProofActor       = "system"
	MigrationOperationalProofTargetTable = "migrations"
	MigrationOperationalProofBody        = "recorded app-owned offline migration"
	MigrationOperationalProofCreatedAtNS = int64(2_000_000)
)

// OperationalProofMigration is an app-owned offline migration hook used by the
// canary to prove Shunter migration APIs are usable from a separate module.
func OperationalProofMigration(ctx context.Context, mc *shunter.MigrationContext) error {
	select {
	case <-ctx.Done():
		return ctx.Err()
	default:
	}
	if mc.ModuleName() != ModuleName {
		return fmt.Errorf("migration module = %q, want %q", mc.ModuleName(), ModuleName)
	}

	tx := mc.Transaction()
	for _, row := range tx.ScanTable(TableAuditLog) {
		if row[2].AsString() == MigrationOperationalProofAction {
			return nil
		}
	}

	table, _, ok := mc.Schema().TableByName(auditAllocatorTable)
	if !ok {
		return fmt.Errorf("missing audit allocator table")
	}
	var counterID types.RowID
	var counter types.ProductValue
	for id, row := range tx.SeekIndex(table, 0, types.NewUint64(1)) {
		counterID, counter = id, row
		break
	}
	if counter == nil {
		return fmt.Errorf("audit allocator not initialized")
	}
	if counter[1].AsUint64() == math.MaxUint64 {
		return fmt.Errorf("audit IDs exhausted")
	}
	id := counter[1].AsUint64() + 1
	body := fmt.Sprintf("%s for %s %s", MigrationOperationalProofBody, mc.ModuleName(), mc.ModuleVersion())
	_, err := tx.Insert(TableAuditLog, auditLogRow(seedAuditLog{
		id:            id,
		actorIdentity: MigrationOperationalProofActor,
		action:        MigrationOperationalProofAction,
		targetTable:   MigrationOperationalProofTargetTable,
		targetID:      0,
		body:          body,
		createdAtNS:   MigrationOperationalProofCreatedAtNS,
	}))
	if err != nil {
		return fmt.Errorf("insert migration audit marker: %w", err)
	}
	counter[1] = types.NewUint64(id)
	_, err = tx.Update(table, counterID, counter)
	return err
}
