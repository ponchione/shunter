package app

import "github.com/ponchione/shunter"

const (
	ModuleName    = "opsboard-canary"
	ModuleVersion = "0.1.0-audit-allocator-dev"
	SchemaVersion = 2
)

// NewModule returns the OpsBoard Canary Shunter module definition.
func NewModule() *shunter.Module {
	m := shunter.NewModule(ModuleName).
		Version(ModuleVersion).
		SchemaVersion(SchemaVersion).
		Migration(shunter.MigrationMetadata{
			ModuleVersion:   ModuleVersion,
			SchemaVersion:   SchemaVersion,
			ContractVersion: shunter.ModuleContractVersion,
			PreviousVersion: "0.1.0-milestone1",
			Compatibility:   shunter.MigrationCompatibilityCompatible,
			Classifications: []shunter.MigrationClassification{
				shunter.MigrationClassificationAdditive,
			},
			Notes: "Additive audit allocator: automatic IDs advance above the committed high-water mark, including after deletion. Existing audit IDs and autoincrement flags are preserved.",
		})
	m.MigrationHook(initializeAuditAllocator)

	registerTables(m)
	registerReducers(m)
	registerReads(m)

	return m
}
