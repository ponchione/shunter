package app

import (
	"context"
	"fmt"
	"math"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

const auditAllocatorTable = "audit_allocator"

// initializeAuditAllocator scans legacy history once, in a durable transaction.
// A present counter is authoritative: deleting committed audits never reduces it.
func initializeAuditAllocator(ctx context.Context, mc *shunter.MigrationContext) error {
	table, _, ok := mc.Schema().TableByName(auditAllocatorTable)
	if !ok {
		return fmt.Errorf("missing audit allocator table")
	}
	tx := mc.Transaction()
	for range tx.SeekIndex(table, 0, types.NewUint64(1)) {
		return nil
	}
	var last uint64
	for _, row := range tx.ScanTable(TableAuditLog) {
		if err := ctx.Err(); err != nil {
			return err
		}
		last = max(last, row[0].AsUint64())
	}
	_, err := tx.Insert(table, types.ProductValue{types.NewUint64(1), types.NewUint64(last)})
	return err
}

// All application audit writes, including explicit bootstrap IDs, use this path.
// Failed inserts leave the counter untouched; reducer rollback reverts both rows.
func insertAuditRow(ctx *schema.ReducerContext, row seedAuditLog, allocate bool) error {
	table, ok := ctx.DB.TableID(auditAllocatorTable)
	if !ok {
		return fmt.Errorf("missing audit allocator table")
	}
	for rowID, counter := range ctx.DB.SeekIndex(table, 0, types.NewUint64(1)) {
		last := counter[1].AsUint64()
		if allocate {
			if last == math.MaxUint64 {
				return fmt.Errorf("audit IDs exhausted")
			}
			row.id = last + 1
		}
		if _, err := ctx.DB.Insert(uint32(TableAuditLog), auditLogRow(row)); err != nil {
			return fmt.Errorf("insert audit %d: %w", row.id, err)
		}
		if row.id > last {
			counter[1] = types.NewUint64(row.id)
			if _, err := ctx.DB.Update(table, rowID, counter); err != nil {
				return fmt.Errorf("advance audit allocator: %w", err)
			}
		}
		return nil
	}
	return fmt.Errorf("audit allocator not initialized")
}
