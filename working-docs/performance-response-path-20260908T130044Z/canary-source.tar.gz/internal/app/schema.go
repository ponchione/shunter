package app

import (
	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/schema"
)

const (
	TableUsers schema.TableID = iota
	TableProjects
	TableProjectMembers
	TableTickets
	TableComments
	TableNotifications
	TableAuditLog
	TableTicketReminders
)

func registerTables(m *shunter.Module) {
	m.TableDef(usersTable(), schema.WithPublicRead()).
		TableDef(projectsTable(), schema.WithPublicRead()).
		TableDef(projectMembersTable()).
		TableDef(ticketsTable(), schema.WithPublicRead()).
		TableDef(commentsTable(), schema.WithPublicRead()).
		TableDef(notificationsTable()).
		TableDef(auditLogTable(), schema.WithReadPermissions(PermAuditRead)).
		TableDef(ticketRemindersTable()).
		TableDef(schema.TableDefinition{
			Name: auditAllocatorTable,
			Columns: []schema.ColumnDefinition{
				{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
				{Name: "last_id", Type: schema.KindUint64},
			},
		})
}

func usersTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "users",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "identity", Type: schema.KindString},
			{Name: "handle", Type: schema.KindString},
			{Name: "display_name", Type: schema.KindString},
			{Name: "role", Type: schema.KindString},
			{Name: "active", Type: schema.KindBool},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "users_identity", Columns: []string{"identity"}, Unique: true},
			{Name: "users_handle", Columns: []string{"handle"}, Unique: true},
		},
	}
}

func projectsTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "projects",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "slug", Type: schema.KindString},
			{Name: "name", Type: schema.KindString},
			{Name: "visibility", Type: schema.KindString},
			{Name: "owner_identity", Type: schema.KindString},
			{Name: "created_at_ns", Type: schema.KindInt64},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "projects_slug", Columns: []string{"slug"}, Unique: true},
		},
	}
}

func projectMembersTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "project_members",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "project_id", Type: schema.KindUint64},
			{Name: "user_identity", Type: schema.KindString},
			{Name: "role", Type: schema.KindString},
			{Name: "created_at_ns", Type: schema.KindInt64},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "project_members_project", Columns: []string{"project_id"}},
			{Name: "project_members_user", Columns: []string{"user_identity"}},
		},
	}
}

func ticketsTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "tickets",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "project_id", Type: schema.KindUint64},
			{Name: "number", Type: schema.KindUint64},
			{Name: "title", Type: schema.KindString},
			{Name: "status", Type: schema.KindString},
			{Name: "priority", Type: schema.KindString},
			{Name: "visibility", Type: schema.KindString},
			{Name: "reporter_identity", Type: schema.KindString},
			{Name: "assignee_identity", Type: schema.KindString},
			{Name: "updated_at_ns", Type: schema.KindInt64},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "tickets_project", Columns: []string{"project_id"}},
			{Name: "tickets_assignee", Columns: []string{"assignee_identity"}},
			{Name: "tickets_reporter", Columns: []string{"reporter_identity"}},
			{Name: "tickets_project_number", Columns: []string{"project_id", "number"}, Unique: true},
		},
	}
}

func commentsTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "comments",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "ticket_id", Type: schema.KindUint64},
			{Name: "project_id", Type: schema.KindUint64},
			{Name: "author_identity", Type: schema.KindString},
			{Name: "visibility", Type: schema.KindString},
			{Name: "body", Type: schema.KindString},
			{Name: "created_at_ns", Type: schema.KindInt64},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "comments_ticket", Columns: []string{"ticket_id"}},
			{Name: "comments_author", Columns: []string{"author_identity"}},
		},
	}
}

func notificationsTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "notifications",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "recipient_identity", Type: schema.KindString},
			{Name: "ticket_id", Type: schema.KindUint64},
			{Name: "kind", Type: schema.KindString},
			{Name: "body", Type: schema.KindString},
			{Name: "delivered", Type: schema.KindBool},
			{Name: "created_at_ns", Type: schema.KindInt64},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "notifications_recipient", Columns: []string{"recipient_identity"}},
		},
	}
}

func auditLogTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "audit_log",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "actor_identity", Type: schema.KindString},
			{Name: "action", Type: schema.KindString},
			{Name: "target_table", Type: schema.KindString},
			{Name: "target_id", Type: schema.KindUint64},
			{Name: "body", Type: schema.KindString},
			{Name: "created_at_ns", Type: schema.KindInt64},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "audit_actor", Columns: []string{"actor_identity"}},
			{Name: "audit_target", Columns: []string{"target_table", "target_id"}},
		},
	}
}

func ticketRemindersTable() schema.TableDefinition {
	return schema.TableDefinition{
		Name: "ticket_reminders",
		Columns: []schema.ColumnDefinition{
			{Name: "id", Type: schema.KindUint64, PrimaryKey: true},
			{Name: "ticket_id", Type: schema.KindUint64},
			{Name: "recipient_identity", Type: schema.KindString},
			{Name: "schedule_id", Type: schema.KindUint64},
			{Name: "due_at_ns", Type: schema.KindInt64},
			{Name: "fired", Type: schema.KindBool},
		},
		Indexes: []schema.IndexDefinition{
			{Name: "reminders_ticket", Columns: []string{"ticket_id"}},
			{Name: "reminders_recipient", Columns: []string{"recipient_identity"}},
		},
	}
}
