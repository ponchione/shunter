package app

import (
	"context"
	"errors"
	"fmt"
	"math"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/schema"
	"github.com/ponchione/shunter/types"
)

func legacyAllocatorModule() *shunter.Module {
	m := shunter.NewModule(ModuleName).Version("0.1.0-milestone1").SchemaVersion(1)
	audit := auditLogTable()
	audit.Columns[0].AutoIncrement = false // Legacy snapshots pin this flag.
	m.TableDef(usersTable(), schema.WithPublicRead()).TableDef(projectsTable(), schema.WithPublicRead()).
		TableDef(projectMembersTable()).TableDef(ticketsTable(), schema.WithPublicRead()).
		TableDef(commentsTable(), schema.WithPublicRead()).TableDef(notificationsTable()).
		TableDef(audit, schema.WithReadPermissions(PermAuditRead)).TableDef(ticketRemindersTable())
	registerReducers(m)
	registerReads(m)
	return m
}

func requireAllocatorOK(t testing.TB, err error) {
	t.Helper()
	if err != nil {
		t.Fatal(err)
	}
}

type allocatorLegacyTable struct {
	ID   schema.TableID
	Rows map[types.RowID]types.ProductValue
}

func captureAllocatorLegacyRows(t *testing.T, m *shunter.Module, dir string) map[string]allocatorLegacyTable {
	t.Helper()
	result := map[string]allocatorLegacyTable{}
	_, err := shunter.RunDataDirMigrations(context.Background(), m, shunter.Config{DataDir: dir}, func(_ context.Context, mc *shunter.MigrationContext) error {
		for _, id := range mc.Schema().Tables() {
			name := mc.Schema().TableName(id)
			if name == auditAllocatorTable {
				continue
			}
			rows := map[types.RowID]types.ProductValue{}
			for rowID, row := range mc.Transaction().ScanTable(id) {
				rows[rowID] = row
			}
			result[name] = allocatorLegacyTable{id, rows}
		}
		return nil
	})
	requireAllocatorOK(t, err)
	return result
}

func TestAuditAllocatorLegacyMigration(t *testing.T) {
	for _, size := range []int{1, 128} {
		t.Run(fmt.Sprint(size), func(t *testing.T) {
			dir := filepath.Join(t.TempDir(), "data")
			createAllocatorLegacyData(t, dir, size)
			legacy := legacyAllocatorModule().Reducer("allocator_schedule", func(rc *schema.ReducerContext, _ []byte) ([]byte, error) {
				_, err := rc.Scheduler.Schedule(ReducerFireTicketReminder, []byte(`{"id":12345}`), time.Now().Add(24*time.Hour))
				return nil, err
			})
			rt, err := shunter.Build(legacy, shunter.Config{DataDir: dir})
			requireAllocatorOK(t, err)
			requireAllocatorOK(t, rt.Start(context.Background()))
			res, err := rt.CallReducer(context.Background(), "allocator_schedule", nil)
			requireAllocatorOK(t, err)
			requireAllocatorOK(t, res.Error)
			requireAllocatorOK(t, rt.WaitUntilDurable(context.Background(), res.TxID))
			_, err = rt.CreateSnapshot()
			requireAllocatorOK(t, err)
			requireAllocatorOK(t, rt.Close())
			before := captureAllocatorLegacyRows(t, legacyAllocatorModule(), dir)
			if len(before["sys_scheduled"].Rows) == 0 {
				t.Fatal("pending schedule missing from migration fixture")
			}
			makeModule := func() *shunter.Module {
				return NewModule().Reducer("allocator_insert", func(rc *schema.ReducerContext, _ []byte) ([]byte, error) {
					id, ok := rc.DB.TableID(auditAllocatorTable)
					if !ok || id != 10 {
						return nil, fmt.Errorf("restored allocator ID = %d, ok=%t", id, ok)
					}
					return nil, insertAudit(rc, "test", "migration-probe", "tickets", 100, "preserved", 123)
				})
			}
			m := makeModule()
			rollback := errors.New("interrupted initialization")
			_, err = shunter.RunDataDirMigrations(context.Background(), m, shunter.Config{DataDir: dir}, func(ctx context.Context, mc *shunter.MigrationContext) error {
				if err := initializeAuditAllocator(ctx, mc); err != nil {
					return err
				}
				return rollback
			})
			if !errors.Is(err, rollback) {
				t.Fatalf("migration error=%v", err)
			}
			if after := captureAllocatorLegacyRows(t, m, dir); !reflect.DeepEqual(before, after) {
				t.Fatal("failed migration changed existing rows or IDs")
			}
			first, err := shunter.RunModuleDataDirMigrations(context.Background(), m, shunter.Config{DataDir: dir})
			requireAllocatorOK(t, err)
			if len(first.Hooks) != 1 || !first.Hooks[0].Changed {
				t.Fatalf("retry did not initialize: %+v", first)
			}
			second, err := shunter.RunModuleDataDirMigrations(context.Background(), m, shunter.Config{DataDir: dir})
			requireAllocatorOK(t, err)
			if second.Hooks[0].Changed || first.DurableTxID != second.DurableTxID {
				t.Fatalf("retry mutated initialized allocator: %+v", second)
			}
			if after := captureAllocatorLegacyRows(t, m, dir); !reflect.DeepEqual(before, after) {
				t.Fatal("migration changed existing rows, row IDs, or table IDs")
			}
			var last uint64
			for _, row := range before["audit_log"].Rows {
				last = max(last, row[0].AsUint64())
			}
			// Fresh and restored runtimes coexist with their respective recovered table IDs.
			fresh, err := shunter.Build(makeModule(), shunter.Config{DataDir: t.TempDir()})
			requireAllocatorOK(t, err)
			requireAllocatorOK(t, fresh.Start(context.Background()))
			defer fresh.Close()
			rt, err = shunter.Build(makeModule(), shunter.Config{DataDir: dir})
			requireAllocatorOK(t, err)
			requireAllocatorOK(t, rt.Start(context.Background()))
			res, err = rt.CallReducer(context.Background(), "allocator_insert", nil)
			requireAllocatorOK(t, err)
			requireAllocatorOK(t, res.Error)
			requireAllocatorOK(t, rt.WaitUntilDurable(context.Background(), res.TxID))
			requireAllocatorOK(t, rt.Close())
			after := captureAllocatorLegacyRows(t, m, dir)
			found := false
			for _, row := range after["audit_log"].Rows {
				if row[0].AsUint64() == last+1 {
					found = row[2].AsString() == "migration-probe" && row[5].AsString() == "preserved"
				}
			}
			if !found {
				t.Fatalf("missing recovered audit %d", last+1)
			}
			t.Logf("preserved %d tables including pending schedules; rollback/retry/idempotence; durable audit %d", len(before), last+1)
		})
	}
}

func TestAuditAllocatorTransactionRecovery(t *testing.T) {
	dir := t.TempDir()
	ctx := context.Background()
	rollback := errors.New("deliberate reducer rollback")
	var action func(*schema.ReducerContext) error
	var escaped types.ReducerDB
	makeModule := func() *shunter.Module {
		return NewModule().Reducer("allocator_allocator", func(rc *schema.ReducerContext, _ []byte) ([]byte, error) { escaped = rc.DB; return nil, action(rc) })
	}
	open := func() *shunter.Runtime {
		rt, err := shunter.Build(makeModule(), shunter.Config{DataDir: dir})
		requireAllocatorOK(t, err)
		requireAllocatorOK(t, rt.Start(ctx))
		return rt
	}
	rt := open()
	defer func() { requireAllocatorOK(t, rt.Close()) }()
	call := func(fn func(*schema.ReducerContext) error, want error) {
		action = fn
		res, err := rt.CallReducer(ctx, "allocator_allocator", nil)
		requireAllocatorOK(t, err)
		if !errors.Is(res.Error, want) {
			t.Fatalf("reducer error=%v want=%v", res.Error, want)
		}
		if want == nil {
			requireAllocatorOK(t, rt.WaitUntilDurable(ctx, res.TxID))
		}
		if _, ok := escaped.TableID(auditAllocatorTable); ok {
			t.Fatal("table lookup survived reducer return")
		}
	}
	insert := func(want uint64) func(*schema.ReducerContext) error {
		return func(rc *schema.ReducerContext) error {
			if _, ok := rc.DB.TableID("missing"); ok {
				return fmt.Errorf("unknown table resolved")
			}
			if err := insertAudit(rc, "test", "probe", "tickets", 100, "row-content", 123); err != nil {
				return err
			}
			for _, row := range rc.DB.SeekIndex(uint32(TableAuditLog), 0, types.NewUint64(want)) {
				if row[2].AsString() == "probe" && row[5].AsString() == "row-content" && row[6].AsInt64() == 123 {
					return nil
				}
			}
			return fmt.Errorf("missing audit %d", want)
		}
	}
	call(insert(1), nil)
	call(func(rc *schema.ReducerContext) error {
		if id, ok := rc.DB.TableID(auditAllocatorTable); !ok || id != 8 {
			return fmt.Errorf("fresh allocator ID=%d", id)
		}
		for _, id := range []uint64{0, 903, 42} {
			if err := insertAuditRow(rc, seedAuditLog{id: id}, false); err != nil {
				return err
			}
		}
		if err := insertAuditRow(rc, seedAuditLog{id: 903}, false); err == nil {
			return fmt.Errorf("duplicate insert accepted")
		}
		if err := insert(904)(rc); err != nil {
			return err
		}
		return insert(905)(rc)
	}, nil)
	call(func(rc *schema.ReducerContext) error {
		if err := insert(906)(rc); err != nil {
			return err
		}
		return rollback
	}, rollback)
	call(insert(906), nil)
	_, err := rt.CreateSnapshot()
	requireAllocatorOK(t, err)
	call(insert(907), nil)
	requireAllocatorOK(t, rt.Close())
	rt = open()
	call(func(rc *schema.ReducerContext) error {
		found := false
		for id := range rc.DB.SeekIndex(uint32(TableAuditLog), 0, types.NewUint64(907)) {
			found = true
			if err := rc.DB.Delete(uint32(TableAuditLog), id); err != nil {
				return err
			}
		}
		if !found {
			return fmt.Errorf("snapshot-tail row 907 missing")
		}
		return nil
	}, nil)
	requireAllocatorOK(t, rt.Close())
	rt = open()
	call(insert(908), nil)
	call(func(rc *schema.ReducerContext) error {
		if err := insertAuditRow(rc, seedAuditLog{id: math.MaxUint64 - 1}, false); err != nil {
			return err
		}
		return insert(math.MaxUint64)(rc)
	}, nil)
	_, err = rt.CreateSnapshot()
	requireAllocatorOK(t, err)
	requireAllocatorOK(t, rt.Close())
	rt = open()
	call(func(rc *schema.ReducerContext) error {
		err := insertAudit(rc, "test", "overflow", "", 0, "", 0)
		if err == nil || !strings.Contains(err.Error(), "exhausted") {
			return fmt.Errorf("overflow error=%v", err)
		}
		return nil
	}, nil)
	t.Log("fresh IDs, explicit zero/sparse IDs, duplicate failure, multiple inserts, rollback, deletion retirement across restart, snapshot+tail, MaxUint64 and exhaustion verified")
}

// Build the old schema with ordinary data instead of depending on archived
// research fixtures. Every app table and a future schedule survive migration.
func createAllocatorLegacyData(t *testing.T, dir string, audits int) {
	t.Helper()
	m := legacyAllocatorModule().Reducer("legacy_seed", func(rc *schema.ReducerContext, _ []byte) ([]byte, error) {
		rows := []struct {
			table schema.TableID
			row   types.ProductValue
		}{
			{TableUsers, userRow(seedUser{id: 1, identity: "legacy", handle: "old", displayName: "Old user", role: "operator", active: true})},
			{TableProjects, projectRow(seedProject{id: 1, slug: "legacy", name: "Legacy project", visibility: "public", ownerIdentity: "legacy", createdAtNS: 10})},
			{TableProjectMembers, projectMemberRow(seedProjectMember{id: 1, projectID: 1, userIdentity: "legacy", role: "owner", createdAtNS: 11})},
			{TableTickets, ticketRow(seedTicket{id: 100, projectID: 1, number: 1, title: "Legacy ticket", status: "open", priority: "high", visibility: "public", reporterIdentity: "legacy", updatedAtNS: 12})},
			{TableComments, commentRow(seedComment{id: 500, ticketID: 100, projectID: 1, authorIdentity: "legacy", visibility: "public", body: "Legacy comment", createdAtNS: 13})},
			{TableNotifications, notificationRow(seedNotification{id: 600, recipientIdentity: "legacy", ticketID: 100, kind: "assigned", body: "Legacy notification", delivered: true, createdAtNS: 14})},
			{TableTicketReminders, ticketReminderRow(seedTicketReminder{id: 700, ticketID: 100, recipientIdentity: "legacy", scheduleID: 0, dueAtNS: 15, fired: true})},
		}
		for _, item := range rows {
			if _, err := rc.DB.Insert(uint32(item.table), item.row); err != nil {
				return nil, err
			}
		}
		for i := 0; i < audits; i++ {
			if _, err := rc.DB.Insert(uint32(TableAuditLog), auditLogRow(seedAuditLog{id: 900 + uint64(i), actorIdentity: "legacy", action: "seed", targetTable: "tickets", targetID: 100, body: fmt.Sprint("audit ", i), createdAtNS: int64(i)})); err != nil {
				return nil, err
			}
		}
		return nil, nil
	})
	rt, err := shunter.Build(m, shunter.Config{DataDir: dir})
	requireAllocatorOK(t, err)
	defer rt.Close()
	requireAllocatorOK(t, rt.Start(context.Background()))
	res, err := rt.CallReducer(context.Background(), "legacy_seed", nil)
	requireAllocatorOK(t, err)
	requireAllocatorOK(t, res.Error)
	requireAllocatorOK(t, rt.WaitUntilDurable(context.Background(), res.TxID))
	_, err = rt.CreateSnapshot()
	requireAllocatorOK(t, err)
	requireAllocatorOK(t, rt.Close())
}
