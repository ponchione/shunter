package app

const (
	PermAdminWrite   = "admin:write"
	PermProjectWrite = "project:write"
	PermTicketWrite  = "ticket:write"
	PermCommentWrite = "comment:write"
	PermAuditRead    = "audit:read"
)
