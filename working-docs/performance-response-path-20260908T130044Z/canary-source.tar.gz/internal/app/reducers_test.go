package app

import (
	"context"
	"fmt"
	"testing"

	"github.com/ponchione/shunter"
	"github.com/ponchione/shunter/schema"
)

func TestIndexedTicketTransactionVisibility(t *testing.T) {
	m := NewModule()
	m.Reducer("indexed_ticket_check", func(ctx *schema.ReducerContext, _ []byte) ([]byte, error) {
		if _, _, ok := findTicket(ctx, 987654); ok {
			return nil, fmt.Errorf("unexpected missing ticket")
		}
		id, err := ctx.DB.Insert(uint32(TableTickets), ticketRow(seedTicket{id: 987654, title: "insert", number: 987654}))
		if err != nil {
			return nil, err
		}
		if got, ticket, ok := findTicket(ctx, 987654); !ok || got != id || ticket.title != "insert" {
			return nil, fmt.Errorf("insert visibility")
		}
		id, err = ctx.DB.Update(uint32(TableTickets), id, ticketRow(seedTicket{id: 987654, title: "update", number: 987654}))
		if err != nil {
			return nil, err
		}
		if got, ticket, ok := findTicket(ctx, 987654); !ok || got != id || ticket.title != "update" {
			return nil, fmt.Errorf("update visibility")
		}
		if err := ctx.DB.Delete(uint32(TableTickets), id); err != nil {
			return nil, err
		}
		if _, _, ok := findTicket(ctx, 987654); ok {
			return nil, fmt.Errorf("delete visibility")
		}
		return nil, nil
	})
	rt, err := shunter.Build(m, shunter.Config{DataDir: t.TempDir()})
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	for _, table := range rt.ExportContract().Schema.Tables {
		if table.Name == "tickets" && (len(table.Indexes) == 0 || table.Indexes[0].ID != 0 || !table.Indexes[0].Primary) {
			t.Fatal("ticket index 0 must be primary")
		}
	}
	if err := rt.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	result, err := rt.CallReducer(context.Background(), "indexed_ticket_check", nil)
	if err != nil {
		t.Fatal(err)
	}
	if result.Error != nil {
		t.Fatal(result.Error)
	}
}
