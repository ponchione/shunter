package app

import "github.com/ponchione/shunter/types"

type seedUser struct {
	id          uint64
	identity    string
	handle      string
	displayName string
	role        string
	active      bool
}

func userRow(row seedUser) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewString(row.identity),
		types.NewString(row.handle),
		types.NewString(row.displayName),
		types.NewString(row.role),
		types.NewBool(row.active),
	}
}

type seedProject struct {
	id            uint64
	slug          string
	name          string
	visibility    string
	ownerIdentity string
	createdAtNS   int64
}

func projectRow(row seedProject) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewString(row.slug),
		types.NewString(row.name),
		types.NewString(row.visibility),
		types.NewString(row.ownerIdentity),
		types.NewInt64(row.createdAtNS),
	}
}

type seedProjectMember struct {
	id           uint64
	projectID    uint64
	userIdentity string
	role         string
	createdAtNS  int64
}

func projectMemberRow(row seedProjectMember) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewUint64(row.projectID),
		types.NewString(row.userIdentity),
		types.NewString(row.role),
		types.NewInt64(row.createdAtNS),
	}
}

type seedTicket struct {
	id               uint64
	projectID        uint64
	number           uint64
	title            string
	status           string
	priority         string
	visibility       string
	reporterIdentity string
	assigneeIdentity string
	updatedAtNS      int64
}

func ticketRow(row seedTicket) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewUint64(row.projectID),
		types.NewUint64(row.number),
		types.NewString(row.title),
		types.NewString(row.status),
		types.NewString(row.priority),
		types.NewString(row.visibility),
		types.NewString(row.reporterIdentity),
		types.NewString(row.assigneeIdentity),
		types.NewInt64(row.updatedAtNS),
	}
}

type seedComment struct {
	id             uint64
	ticketID       uint64
	projectID      uint64
	authorIdentity string
	visibility     string
	body           string
	createdAtNS    int64
}

func commentRow(row seedComment) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewUint64(row.ticketID),
		types.NewUint64(row.projectID),
		types.NewString(row.authorIdentity),
		types.NewString(row.visibility),
		types.NewString(row.body),
		types.NewInt64(row.createdAtNS),
	}
}

type seedNotification struct {
	id                uint64
	recipientIdentity string
	ticketID          uint64
	kind              string
	body              string
	delivered         bool
	createdAtNS       int64
}

func notificationRow(row seedNotification) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewString(row.recipientIdentity),
		types.NewUint64(row.ticketID),
		types.NewString(row.kind),
		types.NewString(row.body),
		types.NewBool(row.delivered),
		types.NewInt64(row.createdAtNS),
	}
}

type seedAuditLog struct {
	id            uint64
	actorIdentity string
	action        string
	targetTable   string
	targetID      uint64
	body          string
	createdAtNS   int64
}

func auditLogRow(row seedAuditLog) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewString(row.actorIdentity),
		types.NewString(row.action),
		types.NewString(row.targetTable),
		types.NewUint64(row.targetID),
		types.NewString(row.body),
		types.NewInt64(row.createdAtNS),
	}
}

type seedTicketReminder struct {
	id                uint64
	ticketID          uint64
	recipientIdentity string
	scheduleID        uint64
	dueAtNS           int64
	fired             bool
}

func ticketReminderRow(row seedTicketReminder) types.ProductValue {
	return types.ProductValue{
		types.NewUint64(row.id),
		types.NewUint64(row.ticketID),
		types.NewString(row.recipientIdentity),
		types.NewUint64(row.scheduleID),
		types.NewInt64(row.dueAtNS),
		types.NewBool(row.fired),
	}
}
