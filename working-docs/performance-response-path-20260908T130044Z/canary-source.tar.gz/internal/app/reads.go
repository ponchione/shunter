package app

import "github.com/ponchione/shunter"

const (
	QueryMyProfile       = "my_profile"
	QueryMyTickets       = "my_tickets"
	QueryAlphaBoard      = "alpha_board"
	QueryTicket100Detail = "ticket_100_detail"
	QueryAuditFeed       = "audit_feed"

	ViewLiveAlphaBoard        = "live_alpha_board"
	ViewLiveTicket100Comments = "live_ticket_100_comments"
	ViewMyNotifications       = "my_notifications"
	ViewLiveAuditFeed         = "live_audit_feed"
)

func registerReads(m *shunter.Module) {
	m.VisibilityFilter(shunter.VisibilityFilterDeclaration{
		Name: "ticket_reporter",
		SQL:  "SELECT * FROM tickets WHERE reporter_identity = :sender",
	}).
		VisibilityFilter(shunter.VisibilityFilterDeclaration{
			Name: "ticket_assignee",
			SQL:  "SELECT * FROM tickets WHERE assignee_identity = :sender",
		}).
		VisibilityFilter(shunter.VisibilityFilterDeclaration{
			Name: "ticket_public",
			SQL:  "SELECT * FROM tickets WHERE visibility = 'public'",
		}).
		VisibilityFilter(shunter.VisibilityFilterDeclaration{
			Name: "comment_author",
			SQL:  "SELECT * FROM comments WHERE author_identity = :sender",
		}).
		VisibilityFilter(shunter.VisibilityFilterDeclaration{
			Name: "comment_public",
			SQL:  "SELECT * FROM comments WHERE visibility = 'public'",
		}).
		VisibilityFilter(shunter.VisibilityFilterDeclaration{
			Name: "notification_recipient",
			SQL:  "SELECT * FROM notifications WHERE recipient_identity = :sender",
		}).
		Query(shunter.QueryDeclaration{
			Name: QueryMyProfile,
			SQL:  "SELECT * FROM users WHERE identity = :sender",
		}).
		Query(shunter.QueryDeclaration{
			Name: QueryMyTickets,
			SQL:  "SELECT * FROM tickets WHERE assignee_identity = :sender",
		}).
		Query(shunter.QueryDeclaration{
			Name: QueryAlphaBoard,
			SQL:  "SELECT * FROM tickets WHERE project_id = 1",
		}).
		Query(shunter.QueryDeclaration{
			Name: QueryTicket100Detail,
			SQL:  "SELECT * FROM tickets WHERE id = 100",
		}).
		Query(shunter.QueryDeclaration{
			Name:        QueryAuditFeed,
			SQL:         "SELECT * FROM audit_log",
			Permissions: auditReadPermission(),
		}).
		View(shunter.ViewDeclaration{
			Name: ViewLiveAlphaBoard,
			SQL:  "SELECT * FROM tickets WHERE project_id = 1",
		}).
		View(shunter.ViewDeclaration{
			Name: ViewLiveTicket100Comments,
			SQL:  "SELECT * FROM comments WHERE ticket_id = 100",
		}).
		View(shunter.ViewDeclaration{
			Name: ViewMyNotifications,
			SQL:  "SELECT * FROM notifications WHERE recipient_identity = :sender",
		}).
		View(shunter.ViewDeclaration{
			Name:        ViewLiveAuditFeed,
			SQL:         "SELECT * FROM audit_log",
			Permissions: auditReadPermission(),
		})
}

func auditReadPermission() shunter.PermissionMetadata {
	return shunter.PermissionMetadata{Required: []string{PermAuditRead}}
}
