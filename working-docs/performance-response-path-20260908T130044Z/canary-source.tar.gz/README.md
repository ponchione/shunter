# opsboard-canary

External Shunter canary app for exercising hosted-runtime workflows through
public APIs.

This repository is currently a local canary for a sibling Shunter checkout. The
Go module intentionally uses:

```sh
replace github.com/ponchione/shunter => ../shunter
```

That local replace is expected for now; CI against a pinned Shunter commit or
tag is a later step.

## Status

The app is usable as a Shunter pressure fixture through the Go test and Makefile
workflows. It covers:

- public-package imports only
- strict-auth protocol clients and token minting
- schema, reducers, declared reads, raw SQL reads, permissions, and visibility
- single subscriptions, declared view subscriptions, SubscribeMulti, deltas,
  unsubscribe boundaries, and duplicate query handling
- restart, rollback, scheduler reminders, and seeded randomized workflows
- offline backup/restore and an app-owned offline migration hook
- deterministic contract export and TypeScript codegen
- public `@shunter/client` TypeScript SDK smoke coverage against a strict-auth
  served canary runtime

Ticket reducers resolve the primary key through the shared indexed `findTicket`
helper, including transaction-local inserts, updates, deletes and missing IDs.

## Audit allocator migration

Schema version 2 (`0.1.0-audit-allocator-dev`) adds private
`audit_allocator(id, last_id)`. Startup's existing atomic migration initializes
the singleton keyed by `1` once from the maximum surviving audit ID. Retries
leave an existing counter unchanged. Original tables, physical row IDs, complete
values and pending schedules survive. The audit ID column's autoincrement flag
remains false; changing that flag on old snapshots is unsupported.

Allocator access uses `ReducerDB.TableID` and the recovered registry, never
registration order: its fresh table ID is 8, but legacy data retains system
tables 8/9 and assigns the allocator 10. This app requires a Shunter version
providing that API. The contract and generated TypeScript describe fresh schema
registration; runtime table IDs must be resolved in the current invocation.

All application audit writers use the counter: reducers, explicit bootstrap
seeds, rollback probes and offline migration markers. Automatic IDs start at 1;
successful higher explicit IDs advance the high-water mark. Committed deletion
never lowers it, and failed inserts or rolled-back transactions never advance
it. `MaxUint64` can be allocated once, after which automatic allocation fails
without wrapping. Future audit imports must use the same counter path.

This changes the old scan's reuse of the highest deleted ID. Initialization
cannot recover identifiers deleted before migration, and explicit imports may
still select unused lower IDs. The counter is not a permanent history of every
identifier ever used.

Before migration, stop the runtime and take a complete pre-migration DataDir
backup with its matching contract and binary. Run the existing offline migration
command below, or start the new app, then verify application reads and schedules.
For rollback, stop the new runtime, restore that backup into a fresh DataDir and
run the matching old binary. Post-backup writes require a separate app-owned
reconciliation plan. An old binary is not promised to consume later allocator
snapshots or log records.

The [Shunter performance guidance](../shunter/docs/performance-envelopes.md)
records the combined app/runtime evidence. Faster unpaced writes can worsen read
p95/p99 and retain more audit history; compare matched offered load and record
absolute milliseconds. A product latency acceptance budget remains unspecified.

`cmd/workflow` is a lightweight executable protocol smoke. It works in-process
or against an already running local server, but the full canary coverage remains
in `go test ./internal/workflows`.

## Commands

```sh
make test
make smoke
make seeded
make replay SEED=42
make operations
make contract
make codegen
make sdk-smoke
make race
make canary-quick
make canary-full
make stress
make soak
```

Regenerate and verify the committed contract/codegen artifacts:

```sh
make contract
make codegen
git diff --exit-code contracts generated
```

Run the standalone protocol smoke in-process:

```sh
go run ./cmd/workflow --in-process --data-dir ./artifacts/workflow-data
```

Run a strict-auth local server and smoke it from another shell:

```sh
go run ./cmd/server --strict --listen 127.0.0.1:3000
go run ./cmd/workflow --addr 127.0.0.1:3000
```

The server's strict mode defaults to the same signing key, issuer, and audience
used by the canary token helper.

Run the app-owned offline migration command against a stopped data directory:

```sh
go run ./cmd/migrate-data --data-dir ./artifacts/workflow-data
```

## Automation Strategy

Use the canary in layers:

- `make canary-quick` after each small Shunter edit
- `make canary-full` before considering a Shunter branch healthy
- `make sdk-smoke` after touching generated TypeScript or the public SDK
- `make operations` after touching backup, restore, migration, metadata, or
  recovery behavior
- `make stress` when touching scheduler, auth, subscription, reducer, or
  persistence behavior
- `make soak` before merging high-risk Shunter changes

The automation entry point is:

```sh
./scripts/shunter-canary <quick|full|stress|soak>
```

Each run prints the `opsboard-canary` and Shunter revisions under test. Set
`SHUNTER_CHECKOUT` when the sibling Shunter checkout is not `../shunter`.

Stress mode runs many deterministic seeds by setting `OPSBOARD_CANARY_SEED`.
Failures remain replayable:

```sh
CANARY_STRESS_ROUNDS=100 CANARY_STRESS_BASE_SEED=2026050300 make stress
make replay SEED=2026050317
```

For heavier concurrency checking:

```sh
CANARY_STRESS_ROUNDS=25 CANARY_STRESS_RACE=1 make stress
```

`make canary-full` also runs the standalone protocol smoke in-process and
against a strict-auth local server. Artifacts, server logs, and workflow traces
are written under `artifacts/canary/`.
