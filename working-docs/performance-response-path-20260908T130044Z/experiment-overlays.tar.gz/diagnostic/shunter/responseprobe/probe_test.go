package responseprobe

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

func TestBoundedCorrelation(t *testing.T) {
	frame := []byte{6, 3, 0, 0, 0, '1', '9', '9'}
	if FrameID(frame) != 199 {
		t.Fatal("wire identity")
	}
	if FrameID([]byte{6, 255, 255, 255, 255}) != 0 {
		t.Fatal("unbounded identity")
	}
	var wg sync.WaitGroup
	for range 8 {
		wg.Go(func() {
			for range Limit/8 + 1 {
				Mark([16]byte{1}, 199, "check", time.Now())
			}
		})
	}
	wg.Wait()
	dir := t.TempDir()
	t.Setenv("CANARY_CAPACITY_RESULT_DIR", dir)
	if err := Dump("test"); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(dir, "probe-test.json"))
	if err != nil {
		t.Fatal(err)
	}
	var out struct {
		Events                       []Event
		Dropped, CorrelationFailures uint64
	}
	if err := json.Unmarshal(data, &out); err != nil {
		t.Fatal(err)
	}
	if len(out.Events) != Limit || out.Dropped != 8 || out.CorrelationFailures != 1 {
		t.Fatal("bounded accounting", len(out.Events), out.Dropped, out.CorrelationFailures)
	}
	for _, e := range out.Events {
		if e.Request != 199 || e.Connection[0] != 1 || e.MonoNS <= 0 {
			t.Fatal("correlation")
		}
	}
}
