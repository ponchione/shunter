// Package responseprobe is bounded, diagnostic-only instrumentation.
package responseprobe

import (
	"encoding/binary"
	"encoding/json"
	"os"
	"path/filepath"
	"sync/atomic"
	"time"
	"unsafe"
)

const Limit = 65536

var origin = time.Now()

type Event struct {
	Connection     [16]byte
	Request        uint32
	Stage          string
	UnixNS, MonoNS int64
}
type slot struct {
	event Event
	ready atomic.Bool
}

var events [Limit]slot
var count, failures atomic.Uint64

func ID(b []byte) uint32 {
	if len(b) == 0 || len(b) > 9 {
		failures.Add(1)
		return 0
	}
	var n uint32
	for _, v := range b {
		if v < '0' || v > '9' {
			failures.Add(1)
			return 0
		}
		n = n*10 + uint32(v-'0')
	}
	return n
}

// FrameID examines only the uncompressed response tag and request identity.
// This experiment negotiates no compression. It never decodes application rows.
func FrameID(frame []byte) uint32 {
	if len(frame) == 0 || frame[0] != 6 {
		return 0
	}
	if len(frame) < 5 {
		failures.Add(1)
		return 0
	}
	n := int(binary.LittleEndian.Uint32(frame[1:5]))
	if n > len(frame)-5 {
		failures.Add(1)
		return 0
	}
	return ID(frame[5 : 5+n])
}
func Mark(conn [16]byte, id uint32, stage string, t time.Time) {
	if id == 0 {
		return
	}
	i := count.Add(1) - 1
	if i >= Limit {
		return
	}
	events[i].event = Event{conn, id, stage, t.UnixNano(), t.Sub(origin).Nanoseconds()}
	events[i].ready.Store(true)
}
func Clock() [2]int64 { t := time.Now(); return [2]int64{t.UnixNano(), t.Sub(origin).Nanoseconds()} }
func Dump(role string) error {
	var out []Event
	n := count.Load()
	for i := uint64(0); i < min(n, Limit); i++ {
		if events[i].ready.Load() {
			out = append(out, events[i].event)
		}
	}
	v := struct {
		Role                         string
		OriginUnixNS                 int64
		Clock                        [2]int64
		Events                       []Event
		Dropped, CorrelationFailures uint64
		BufferBytes                  uintptr
	}{role, origin.UnixNano(), Clock(), out, n - min(n, Limit), failures.Load(), unsafe.Sizeof(events)}
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(os.Getenv("CANARY_CAPACITY_RESULT_DIR"), "probe-"+role+".json"), append(data, '\n'), 0600)
}
