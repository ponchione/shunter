module github.com/ponchione/opsboard-canary

go 1.27.1

replace github.com/ponchione/shunter => /tmp/shunter-response-path-20260908T130044Z/shunter

require (
	github.com/coder/websocket v1.8.14
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/ponchione/shunter v0.0.0-00010101000000-000000000000
)

require (
	github.com/klauspost/cpuid/v2 v2.0.9 // indirect
	github.com/ponchione/websocket v1.8.15-shunter.1 // indirect
	golang.org/x/sys v0.47.0 // indirect
	lukechampine.com/blake3 v1.4.1 // indirect
)

replace github.com/coder/websocket => github.com/ponchione/websocket v1.8.14-shunter.1
